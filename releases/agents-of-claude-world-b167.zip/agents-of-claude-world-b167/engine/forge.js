// Agents of Claude — forge and trainer (rules version 1).
// Every roll is seeded by the item (or Agent) and an attempt counter, so a reload can't re-roll a result.

import { makeRng } from './rng.js';
import { AFFIXES, RARITY, NAMED, namedItem } from './items.js';

/* ---------------------------------------------------------------- Forge */

const RARITY_WORTH = { common: 1, uncommon: 3, rare: 8, epic: 20, legendary: 50, mythic: 120 };
export const MAX_UPGRADE = 10;
// Chance to succeed when upgrading TO this level. Up to +5 always succeeds.
const UPGRADE_CHANCE = { 6: 80, 7: 65, 8: 50, 9: 35, 10: 25 };

export function salvageValue(item) {
  return Math.max(1, Math.round(RARITY_WORTH[item.rarity] * (1 + item.ilvl / 10) * (1 + (item.upgrade || 0) * 0.25)));
}

// Costs grow with rarity and item level. Upgrades are paid in gold only (the guild's main gold sink); rerolls take
// both gold and essence (essence, from salvaging, is spent only here). Both double or climb steeply, so a fully
// upgraded or much-rerolled item is a long-term goal.
const round5 = (n) => Math.max(5, Math.round(n / 5) * 5);
const itemScale = (item) => Math.sqrt(RARITY_WORTH[item.rarity]) * (1 + (item.ilvl || 1) / 25);
export function rerollCost(item) {
  const n = item.rerolls || 0;
  return { essence: Math.round(4 * RARITY_WORTH[item.rarity] ** 0.6 * 2 ** n), gold: round5(40 * itemScale(item)) * 2 ** n };
}

export function canReroll(item) {
  return !item.named && (item.affixes || []).length > 0;
}

// Replace affix `index` with a different affix (not already on the item), rolled at the item's level.
export function reroll(item, index) {
  if (!canReroll(item) || !item.affixes[index]) throw new Error('This affix cannot be rerolled');
  const n = item.rerolls || 0;
  const r = makeRng(`reroll|${item.id}|${n}`);
  const taken = new Set(item.affixes.map(a => a.k));
  const pool = Object.keys(AFFIXES).filter(k => !taken.has(k));
  const k = pool[Math.floor(r() * pool.length)];
  const affixes = item.affixes.map((a, i) => i === index ? { k, v: AFFIXES[k].value(item.ilvl, r()) } : a);
  return { ...item, affixes, rerolls: n + 1 };
}

export function upgradeCost(item) {
  const next = (item.upgrade || 0) + 1;
  return { essence: 0, gold: round5(20 * next ** 1.4 * itemScale(item)) };
}

export function upgradeChance(item) {
  const next = (item.upgrade || 0) + 1;
  return UPGRADE_CHANCE[next] ?? 100;
}

// One upgrade attempt. Success adds +1 (each level is +4% base stats, applied in computeGear).
export function tryUpgrade(item) {
  const cur = item.upgrade || 0;
  if (cur >= MAX_UPGRADE) throw new Error('Already at +10');
  const attempts = item.upgradeAttempts || 0;
  const roll = makeRng(`upgrade|${item.id}|${attempts}`)() * 100;
  const success = roll < upgradeChance(item);
  return { success, item: { ...item, upgrade: success ? cur + 1 : cur, upgradeAttempts: attempts + 1 } };
}

export const itemLabel = (item) => (item.upgrade ? `+${item.upgrade} ` : '') + item.name;

/* ------------------------------------------------------------ Ascension */
// Only named items (heirloom weapons included) can rise in level, at the Forge, in tiers. Ordinary drops and dungeon set
// pieces never can. Each ascension raises the item level by up to ASCEND_STEP, never above the wearer's level or the
// last tier's cap, and the item becomes exactly what that named item is at the new level (namedItem(key, …, ilvl):
// stats and affixes), so verify.js rebuilds it like any other named item. Its id, ability, element, lore, +N upgrades,
// upgrade attempts and heirloom stage (transformedFrom) stay. `asc` records the tier reached: the tier whose band the
// new item level falls in (I is up to 24, II up to 34, …, VI up to 70); verify.js checks it.
//   floor: the lowest dungeon level whose boss drops a material this tier accepts ("at or above the tier's level").
//   mats:  how many ascension materials one ascension into this tier costs.
export const ASCEND_STEP = 10;
export const ASCENSION = [
  { tier: 1, label: 'I', cap: 24, floor: 14, mats: 1 },
  { tier: 2, label: 'II', cap: 34, floor: 24, mats: 2 },
  { tier: 3, label: 'III', cap: 44, floor: 34, mats: 2 },
  { tier: 4, label: 'IV', cap: 54, floor: 44, mats: 3 },
  { tier: 5, label: 'V', cap: 64, floor: 54, mats: 3 },
  { tier: 6, label: 'VI', cap: 70, floor: 64, mats: 4 },
];
export const ASCEND_CAP = ASCENSION.at(-1).cap;
// The tier an item level belongs to (null above the last cap).
export const tierOf = (ilvl) => ASCENSION.find(t => ilvl <= t.cap) || null;
// Ascension materials: one per dungeon from the Sunken Bazaar up, dropped only by its boss (progress `mats`). A tier
// takes any material whose dungeon is at or above its floor; the Forge spends the lowest-level ones first.
// Ascension materials, one per dungeon from level 18. Keys are permanent (progress.mats); names and colours are display only (build 165 renamed them).
export const MATERIALS = {
  sultans_brass: { name: 'Az-Zahab Dinar', dungeon: 'sunken_bazaar', level: 18, color: '#e7b53d', blurb: 'A coin-thin sliver of the Brass Sultan\'s treasury, still warm from the vault.' },
  rime_core: { name: 'Rimeheart\'s Frozen Tear', dungeon: 'glacier_vault', level: 28, color: '#8fd4ff', blurb: 'A tear the Matron wept into the Vault\'s deepest wall. It has never melted.' },
  unwritten_vellum: { name: 'The Blank Folio', dungeon: 'restricted_section', level: 38, color: '#efe6d2', blurb: 'A page nothing has ever been written on. The Forge can write a level on it.' },
  wyrm_spark: { name: 'Stormwyrm Heartspark', dungeon: 'wyrms_crown', level: 48, color: '#e7d14a', blurb: 'A spark of the Storm Wyrm\'s breath, trapped in one of its scales.' },
  bell_bronze: { name: 'Leviathan\'s Toll-Bronze', dungeon: 'sunken_bell', level: 55, color: '#3fa7a0', blurb: 'A shard of the Sunken Bell. It still rings at every tide.' },
  queens_briar: { name: 'Thorncrown Briarheart', dungeon: 'thorn_throne', level: 60, color: '#b277f0', blurb: 'A thorn from the Thorn Throne that never stops growing.' },
  brimstone_seal: { name: 'Pit-Sworn Brimstone Seal', dungeon: 'ninth_gate', level: 65, color: '#d9473c', blurb: 'The Pit Fiend\'s wax seal, still hot, still binding.' },
  dawn_ember: { name: 'Ember of the First Dawn', dungeon: 'throne_of_dawn', level: 70, color: '#ff9f3c', blurb: 'A coal from the first sunrise. It is never quite out.' },
};
export const MAT_OF_DUNGEON = Object.fromEntries(Object.entries(MATERIALS).map(([k, m]) => [m.dungeon, k]));
// How many of a dungeon's material one cleared run gives a player: Normal half the time one, Heroic one, Mythic two.
export const MAT_DROPS = { normal: [0.5, 1], heroic: [1, 1], mythic: [1, 2] };
// Materials a tier accepts, lowest level first.
export const matsForTier = (t) => Object.keys(MATERIALS).filter(k => MATERIALS[k].level >= t.floor).sort((a, b) => MATERIALS[a].level - MATERIALS[b].level);
// Which materials pay `n` for a tier from what the player has ({key: count}): {key: count} or null if not enough.
export function pickMats(have, t, n = t.mats) {
  const out = {}; let left = n;
  for (const k of matsForTier(t)) { const take = Math.min(left, Math.max(0, Math.floor(have?.[k] || 0))); if (take) { out[k] = take; left -= take; } if (!left) break; }
  return left ? null : out;
}

export const canAscendKind = (item) => !!(item?.named && Object.hasOwn(NAMED, item.named) && !item.set);
// The item level one ascension takes this item to for a wearer of `level`, or null if it cannot rise.
export function ascendTarget(item, level) {
  if (!canAscendKind(item) || !Number.isInteger(item.ilvl)) return null;
  const to = Math.min(item.ilvl + ASCEND_STEP, Math.floor(level) || 0, ASCEND_CAP);
  return to > item.ilvl ? to : null;
}
// What one ascension costs: essence and gold that grow with the target level (and the item's rarity), plus the tier's
// materials. null when the item cannot ascend for this wearer.
export function ascendCost(item, level) {
  const to = ascendTarget(item, level); if (to == null) return null;
  const t = tierOf(to), f = Math.sqrt(RARITY_WORTH[item.rarity] / RARITY_WORTH.epic);
  return { to, tier: t.tier, label: t.label, essence: round5(3 * to * f), gold: round5(2 * to * to * f), mats: t.mats, floor: t.floor };
}
// Why an item cannot ascend right now, in plain words (null: it can). have: { essence, gold, mats }.
export function ascendBlock(item, level, have = {}) {
  if (!canAscendKind(item)) return 'Only named items and heirloom weapons can ascend.';
  if (item.ilvl >= ASCEND_CAP) return `Already at item level ${ASCEND_CAP}, the highest there is.`;
  if (item.ilvl >= level) return `It is already at your level (${level}). Level up to ascend it further.`;
  const c = ascendCost(item, level);
  if ((have.essence || 0) < c.essence || (have.gold || 0) < c.gold) return `You need ${c.essence} essence and ${c.gold} gold.`;
  if (!pickMats(have.mats, tierOf(c.to))) return `You need ${c.mats} ascension material${c.mats > 1 ? 's' : ''} from a dungeon of level ${c.floor} or higher.`;
  return null;
}
// One ascension: the same item at the new level (namedItem's stats and affixes), everything else kept.
export function ascend(item, level) {
  const to = ascendTarget(item, level);
  if (to == null) throw new Error('This item cannot ascend');
  const ref = namedItem(item.named, item.id, to, item.source);
  return { ...item, ilvl: to, stats: ref.stats, affixes: ref.affixes, asc: tierOf(to).tier };
}

/* -------------------------------------------------------------- Trainer */

export const TRAIN_MINUTES = 60;

// A score's trained bonus may not exceed half the Agent's level.
export const trainCap = (level) => Math.floor(level / 2);

export function trainCost(currentBonus) {
  return { focus: 10 * (currentBonus + 1), gold: 20 * (currentBonus + 1) };
}

export { RARITY_WORTH };
export const rarityLabel = (r) => RARITY[r]?.label || r;
