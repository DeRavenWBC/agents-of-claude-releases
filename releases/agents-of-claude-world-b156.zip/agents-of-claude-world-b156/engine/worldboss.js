import { TZ_OFFSET_MS, TZ_ISO, worldDay, dayAt } from './worldtime.js';
// Agents of Claude — the weekly world boss (Season 1).
//
// One boss a week (Monday 00:00 SAST), shared by the whole org. A new boss starts with a full pool and fresh
// attempts; last week's boss stays on show (and claimable) for the week after. Each player gets one attempt a day:
// a fight to the end: it lasts until the Agent falls or the boss dies (the boss enters with what is left of the
// pool). No Sudden Death; the boss enrages instead (+3% damage per action after 40), and a 600-action safety cap ends
// a stalemate. The damage dealt comes off the boss's org-wide HP pool. Attempts carry `bv` (boss rules): those
// without it were 30-action fights against an unkillable boss and are re-simulated that way. Attempts are stored in each player's own doc and re-simulated by everyone.
// When the pool is empty, every contributor can claim a reward; the top three earn a title.

import { simulate, makeAgentUnit, makeMobUnit, deriveStats, MOBS, RULES_EPOCH, rulesOf } from './battle.js';
import { snapIssues } from './verify.js';
import { trustedOld } from './trusted.js';
import { replaySnap } from './items.js';
import { weekStart } from './arena.js';
// Boss fights are PvE: epochs 4 and 5 only changed the Arena and Fair Duels, so epoch-3 and -4 attempts replay the same.
const PVE_SAME = [];   // older epochs that still replay the same: none since epoch 7 (all abilities) and 8 (class balance)

export const BOSS_LEVEL = 45, ATTEMPT_ACTIONS = 30, HP_PER_PLAYER = 12_000, MIN_PLAYERS = 3;
export const BOSS_RULES = 3, BOSS_MAX_ACTIONS = 600, ENRAGE = { from: 40, per: 0.03 };
// Boss rules 3: a live fight. The Agent's move each round is picked as it happens (by the player's Claude or by the
// player), like a duel; the boss always follows its own AI. The attempt stores the picks (`picks`), and everyone
// re-simulates it from them. An attempt left unfinished (the tab closed mid-fight) is finished by the Agent's
// gambits, so walking away never costs or gains anything. Attempts with bv 2 (the whole fight on gambits) replay as before.
export const LIVE_BOSS = 3, MAX_PICKS = 400;
export const validPicks = (p) => Array.isArray(p) && p.length <= MAX_PICKS && p.every(x => typeof x === 'string' && x.length > 0 && x.length <= 40);
// Fights to the end deal about 1.5× what 30-action fights did, so from the week of 2026-11-23 the pool is bigger.
export const hpPerPlayer = (wk) => (wk >= '2026-11-23' ? 18_500 : HP_PER_PLAYER);
// An attempt fought under older combat rules can't be re-simulated; it counts if it predates the switch and stays
// under this cap. New attempts carry rv = RULES_EPOCH.
export const OLD_RULES_CAP = HP_PER_PLAYER / 4;
export const HISTORY_PLAYERS = 12;   // a stored week's damage counts up to the whole pool of a guild this size
export { RULES_EPOCH };
export const ROTATION = [
  { key: 'storm_wyrm', name: 'The Storm Wyrm, Unbound', scene: 'storm' },
  { key: 'head_librarian', name: 'The Head Librarian, Unread', scene: 'library' },
  { key: 'matron_rimeheart', name: 'Matron Rimeheart, Unthawed', scene: 'snow' },
  { key: 'brass_sultan', name: 'The Brass Sultan, Unpaid', scene: 'desert' },
  { key: 'grubnose', name: 'Grubnose, Unfed', scene: 'cave' },
];
const WEEK = 7 * 86_400_000;
export const weekIndex = (ms) => Math.floor((weekStart(ms) - weekStart(Date.UTC(2026, 10, 16))) / WEEK);
export const bossOfWeek = (ms) => ROTATION[((weekIndex(ms) % ROTATION.length) + ROTATION.length) % ROTATION.length];
export const weekKey = (ms) => worldDay(weekStart(ms));
// A moment in the previous boss's week (its standing is shown, and its reward can still be claimed, all week).
export const prevWeekMs = (ms) => weekStart(ms) - 86_400_000;
// The boss's size is fixed for its whole week: the characters that existed when the week began (a family's characters
// count, each fights). Characters created during the week don't grow it; it changes only on Monday.
// roster: [{ createdAt }] (an ISO date or ms; a character with no date counts: it is from before dates were kept).
export function weekPlayers(roster, ms) {
  const cut = weekStart(ms);
  return (roster || []).filter(r => { const c = typeof r?.createdAt === 'number' ? r.createdAt : Date.parse(r?.createdAt || ''); return !Number.isFinite(c) || c < cut; }).length;
}
// Attempts a player keeps: this week's and last week's (with snapshots, so both stay re-checkable).
export const keepAttempts = (list, nowMs) => (Array.isArray(list) ? list : []).filter(a => a && (a.week === weekKey(nowMs) || a.week === weekKey(prevWeekMs(nowMs))));

// One attempt. bv: the boss rules it was fought under (missing: the old 30-action fight); poolLeft: what was left of
// the boss's pool (in level-45 HP) when it started, so the boss can fall to the attempt that finishes it.
export function attempt(seed, snap, bossKey, { bv = 1, poolLeft = Infinity, picks = null, finish = false } = {}) {
  const me = makeAgentUnit(snap, { id: 'agent', level: snap.level });
  // The boss meets each fighter at their own level (+2), so everyone's damage counts about the same.
  const boss = makeMobUnit(bossKey, Math.max(3, Math.min(52, (snap.level || 1) + 2)), 'boss');
  // Damage counts as a share of the boss's own HP at that level, expressed at level 45, so levels are comparable.
  const hpAt = (lvl) => { const u = makeMobUnit(bossKey, lvl, 'x'); return deriveStats(u.scores, lvl, u.gear).maxHp; };
  const scale = hpAt(BOSS_LEVEL) / hpAt(boss.level);
  boss.hpMult = 1000;
  const toEnd = bv >= 2;
  // Its HP (and maximum, so its tactics read its health the right way) is what is left of the pool at this level.
  if (toEnd && Number.isFinite(poolLeft)) { const hp = Math.max(1, Math.ceil(Math.max(0, poolLeft) / scale)), base = deriveStats(boss.scores, boss.level, boss.gear).maxHp;
    boss.hpMult = hp / base; boss.hpOverride = hp; }
  // Its shields and % heals are sized from its normal HP at that level, not the 1000× pool it is given.
  if (toEnd) boss.hpBasis = Math.round(hpAt(boss.level) * (MOBS[bossKey]?.hpMult || 1));
  // Live fights (bv 3): the Agent's picks drive side A round by round; the boss (side B) always acts on its own AI.
  const live = bv >= LIVE_BOSS ? { duel: { rounds: (picks || []).map(p => [p, 'auto']), ...(finish ? { fill: 'auto' } : {}) } } : {};
  const res = simulate(`worldboss|${seed}`, [me], [boss], toEnd ? { maxActions: BOSS_MAX_ACTIONS, noSuddenDeath: true, enrage: ENRAGE, noPveTune: true, ...live } : { maxActions: ATTEMPT_ACTIONS });
  if (res.paused) return { paused: res.paused, state: res, scale, log: res.log, dmgSoFar: Math.round(res.log.filter(e => e.t === 'dmg' && e.uid === 'B:boss').reduce((n, e) => n + e.amt, 0) * scale) };
  const raw = res.log.filter(e => e.t === 'dmg' && e.uid === 'B:boss').reduce((n, e) => n + e.amt, 0);
  const dmg = Math.round(raw * scale);
  const actions = res.log.filter(e => e.t === 'act').length;
  return { dmg, hash: res.hash, log: res.log, actions, bossFell: res.winner === 'A', survived: res.survivors.find(u => u.side === 'A')?.alive ?? false };
}

/**
 * docs: { uid: { attempts: [{ week, day, seed, snap, dmg, hash }] } }. Counts one attempt per player per day,
 * re-simulating any that carry a snapshot; returns the week's standing.
 */
export function standing(docs, nowMs, players, { verify = true, trustOld = trustedOld.boss } = {}) {
  const today = worldDay(nowMs);
  const wk = weekKey(nowMs), boss = bossOfWeek(nowMs);
  const maxHp = hpPerPlayer(wk) * Math.max(MIN_PLAYERS, players);
  const per = Object.create(null), flagged = [], counted = [], attempts = Object.create(null), kept = [];
  for (const [uid, d] of Object.entries(docs || {})) {
    const days = new Set();
    for (const a of (Array.isArray(d?.attempts) ? d.attempts : []).slice(-60)) {
      // One broken attempt must never stop the standing for everyone: it is flagged and skipped.
      try { countOne(a); } catch { flagged.push({ uid, day: typeof a?.day === 'string' ? a.day : null, reason: 'a malformed record' }); }
    }
    function countOne(a) {
      // One attempt per real SAST day of this week, seeded by player, week and day, and always re-checkable.
      if (!a || a.week !== wk || days.has(a.day) || !/^\d{4}-\d{2}-\d{2}$/.test(a.day || '') || weekKey(dayAt(a.day, '12:00')) !== wk) return;
      if (a.seed !== `${uid}|${wk}|${a.day}` || !(a.bv >= LIVE_BOSS || (Number.isFinite(a.dmg) && a.dmg >= 0))) return;
      // One attempt per day that has actually come: tomorrow's can't be fought today.
      if (a.day > today) { flagged.push({ uid, day: a.day, reason: 'an attempt dated in the future' }); return; }
      if (verify && !a.snap) { flagged.push({ uid, day: a.day, reason: 'an attempt without the snapshot to check it' }); return; }
      days.add(a.day);
      if (verify && a.snap && snapIssues(a.snap).length) { flagged.push({ uid, day: a.day, reason: 'impossible attributes or gear' }); return; }
      const rules = rulesOf(a.rv, dayAt(a.day, '12:00'), PVE_SAME);
      if (verify && rules === 'bad') { flagged.push({ uid, day: a.day, reason: 'recorded under combat rules this page does not run (reload the game)' }); return; }
      // Old-rules attempts can't be re-simulated: only those on file when the rules changed count (engine/trusted.js).
      if (verify && rules === 'old' && !trustOld(uid, a)) { flagged.push({ uid, day: a.day, reason: 'an old-rules attempt that was not on file when the rules changed' }); return; }
      // The cap is for the old 30-action fights (no `bv`); fights to the end under an older epoch are trusted like any other
      // record from before the switch (epoch 7 wrongly capped them at first, hiding most of a week's damage).
      if (verify && rules === 'old' && !(a.bv >= 2) && a.dmg > OLD_RULES_CAP) { flagged.push({ uid, day: a.day, reason: 'more damage than the old rules allowed' }); return; }
      if (verify && a.snap && rules === 'current' && a.bv >= LIVE_BOSS) {
        // A live fight: its damage is whatever its picks deal (finished by gambits if it was left unfinished), never
        // the number the record states.
        if (!validPicks(a.picks || [])) { flagged.push({ uid, day: a.day, reason: 'malformed moves' }); return; }
        const re = attempt(a.seed, replaySnap(a.snap, a.rv), boss.key, { bv: a.bv, poolLeft: Number.isFinite(a.poolLeft) ? a.poolLeft : Infinity, picks: a.picks || [], finish: true });
        if (!a.live && re.hash !== a.hash) { flagged.push({ uid, day: a.day, reason: 'result does not match a re-simulation' }); return; }
        a = { ...a, dmg: re.dmg };
      } else if (verify && a.snap && rules === 'current') {
        const re = attempt(a.seed, replaySnap(a.snap, a.rv), boss.key, { bv: a.bv || 1, poolLeft: Number.isFinite(a.poolLeft) ? a.poolLeft : Infinity });
        if (re.hash !== a.hash || re.dmg !== a.dmg) { flagged.push({ uid, day: a.day }); return; }
      }
      kept.push({ uid, day: a.day, dmg: a.dmg, pool: verify && rules === 'current' && a.bv >= 2 ? (Number.isFinite(a.poolLeft) ? a.poolLeft : Infinity) : null });
    }
  }
  // The pool an attempt says it faced is its owner's word, and a bigger pool means more damage to deal. It can't have
  // been more than what the earlier days left (with one player's share of slack, for a guild that shrank since):
  // an attempt that claims more is dropped. Days are settled in order, so a dropped attempt frees nothing it used.
  const slack = hpPerPlayer(wk); let before = 0;
  for (const day of [...new Set(kept.map(k => k.day))].sort()) {
    let sum = 0;
    for (const k of kept.filter(x => x.day === day)) {
      if (k.pool != null && k.pool > Math.max(0, maxHp - before) + slack) { k.drop = true; flagged.push({ uid: k.uid, day, reason: 'it claims a bigger boss pool than was left' }); continue; }
      sum += k.dmg;
    }
    before += sum;
  }
  for (const k of kept) { if (k.drop) continue;
    per[k.uid] = (per[k.uid] || 0) + k.dmg; counted.push({ day: k.day, dmg: k.dmg }); (attempts[k.uid] ||= []).push({ day: k.day, dmg: k.dmg }); }
  // The day the pool ran out: the guild's damage added up day by day (the same answer on every page).
  let run = 0, fellOn = null;
  for (const c of counted.sort((x, y) => x.day.localeCompare(y.day))) { run += c.dmg; if (!fellOn && run >= maxHp) fellOn = c.day; }
  const total = Object.values(per).reduce((a, b) => a + b, 0);
  const ranked = Object.entries(per).sort((a, b) => b[1] - a[1]);
  return { week: wk, boss, maxHp, total, left: Math.max(0, maxHp - total), defeated: total >= maxHp, fellOn, per, ranked, flagged, top3: ranked.slice(0, 3).map(([id]) => id),
    attempts: Object.fromEntries(Object.entries(attempts).map(([k, v]) => [k, v.sort((x, y) => x.day.localeCompare(y.day))])) };
}

/* ------------------------------------------------------------ Damage history */
// Attempts are kept only for this week and last, so each player's own doc also keeps `history`: { [week]: { boss,
// dmg, n, best } } for every week they fought, written by their own page. That is what all-time totals add up.
export function mergeHistory(history, attempts) {
  const out = { ...(history && typeof history === 'object' ? history : {}) }, by = {};
  for (const a of Array.isArray(attempts) ? attempts : []) if (a?.week && Number.isFinite(a.dmg)) (by[a.week] ||= []).push(a);
  for (const [wk, list] of Object.entries(by)) {
    const days = new Map(); for (const a of list) if (!days.has(a.day)) days.set(a.day, a.dmg);   // one a day, as the standing counts
    const d = [...days.values()];
    out[wk] = { boss: bossOfWeek(dayAt(wk, '12:00')).key, dmg: d.reduce((x, y) => x + y, 0), n: d.length, best: Math.max(0, ...d) };
  }
  return out;
}
// All-time damage per player: the checked standings for the weeks still on record, the stored history before that.
export function lifetime(docs, standings = []) {
  const live = new Set(standings.map(s => s.week)), out = {};
  for (const [uid, d] of Object.entries(docs || {})) {
    let dmg = 0, n = 0, best = 0;
    // Stored history is the player's own word (the attempts behind it are gone), so it is bounded: a real past week,
    // at most 7 attempts, and no more damage than a large guild's whole pool.
    for (const [wk, h] of Object.entries(d?.history && typeof d.history === 'object' ? d.history : {})) {
      if (live.has(wk) || !/^\d{4}-\d{2}-\d{2}$/.test(wk) || wk < '2026-11-16' || !Number.isFinite(h?.dmg) || h.dmg < 0) continue;
      const cap = hpPerPlayer(wk) * HISTORY_PLAYERS, wd = Math.min(h.dmg, cap);
      dmg += wd; n += Math.max(0, Math.min(7, Math.floor(h.n) || 0)); best = Math.max(best, Math.min(Number.isFinite(h.best) ? h.best : 0, wd));
    }
    for (const s of standings) for (const a of s.attempts?.[uid] || []) { dmg += a.dmg; n++; best = Math.max(best, a.dmg); }
    if (dmg > 0 || n) out[uid] = { dmg, n, best };
  }
  return out;
}

export { MOBS };
