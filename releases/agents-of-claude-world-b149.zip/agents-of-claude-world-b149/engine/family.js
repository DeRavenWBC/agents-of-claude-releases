// Families: one player (uid) may have up to MAX_CHARS characters, all living in the world at the same time.
//
// Storage (no change to the permission rules: `<coll>/{self}` covers everything below a player's own doc):
//   the head character (n = 1) keeps every path it had before families:  <coll>/<uid>, data/users/<uid>/…
//   character n ≥ 2 lives one level down:                                   <coll>/<uid>/kin/<n>, data/users/<uid>/kin/<n>/…
// Inside records a character is named by its id: the uid for the head, `<uid>~<n>` for the others. An id is always
// derived from the PATH a doc was read from, never from what the doc says, so nobody can write a record as someone
// else's character. The family index lives on the head's public agent doc: `family = { name, kin: [2, 3] }`.

export const MAX_CHARS = 3;
const SEP = '~';
const SLOT_RE = /^[2-9]$/;

// A uid as the platform gives it never contains `~`; refuse one that does, so ids cannot be forged by a crafted uid.
export const isUid = (uid) => typeof uid === 'string' && uid.length > 0 && uid.length <= 128 && !uid.includes(SEP) && !uid.includes('/');
export const validSlot = (n) => Number.isInteger(n) && n >= 1 && n <= MAX_CHARS;

export function charId(uid, n = 1) {
  if (!isUid(uid) || !validSlot(n)) return null;
  return n === 1 ? uid : `${uid}${SEP}${n}`;
}
// { uid, n } for a character id, or null for anything malformed.
export function parseId(id) {
  if (typeof id !== 'string') return null;
  const i = id.indexOf(SEP);
  if (i < 0) return isUid(id) ? { uid: id, n: 1 } : null;
  const uid = id.slice(0, i), rest = id.slice(i + 1);
  if (!isUid(uid) || !SLOT_RE.test(rest)) return null;
  const n = +rest;
  return validSlot(n) && n > 1 ? { uid, n } : null;
}
export const ownerOf = (id) => parseId(id)?.uid ?? null;
export const slotOf = (id) => parseId(id)?.n ?? null;
export const isCharId = (id) => parseId(id) !== null;
export const isHead = (id) => slotOf(id) === 1;
export const sameFamily = (a, b) => { const x = ownerOf(a); return x !== null && x === ownerOf(b); };

// Public doc path of a character in a shared collection (agents, bouts, duels, worldboss, social, market, chronicle).
export function pubPath(coll, id) {
  const p = parseId(id); if (!p) return null;
  return p.n === 1 ? `${coll}/${p.uid}` : `${coll}/${p.uid}/kin/${p.n}`;
}
// Private root of a character: data/users/<uid> for the head, data/users/<uid>/kin/<n> for the others.
export function privRoot(id) {
  const p = parseId(id); if (!p) return null;
  return p.n === 1 ? `data/users/${p.uid}` : `data/users/${p.uid}/kin/${p.n}`;
}

// The kin slots a head doc declares: whole numbers 2..MAX_CHARS, no repeats, sorted.
export function kinSlots(headDoc) {
  const k = headDoc?.family?.kin;
  if (!Array.isArray(k)) return [];
  return [...new Set(k.filter(n => Number.isInteger(n) && n >= 2 && n <= MAX_CHARS))].sort((a, b) => a - b);
}
export const familyName = (headDoc) => cleanFamilyName(headDoc?.family?.name);
export function cleanFamilyName(s) {
  if (typeof s !== 'string') return '';
  return s.replace(/[\u0000-\u001f<>]/g, '').replace(/\s+/g, ' ').trim().slice(0, 24);
}
export function cleanFamily(f) {
  if (!f || typeof f !== 'object') return null;
  const kin = kinSlots({ family: f });
  return { name: cleanFamilyName(f.name), kin };
}

// Merge a collection's top-level docs ({ uid: data }) with the kin docs read under them
// ({ uid: { '<n>': data } }) into one map keyed by character id. A kin doc counts only if its slot is one the head
// declared (or `declared` is false, for collections whose head doc may be missing) and the slot is valid; anything a
// kin doc says about its own id is ignored (the id comes from the path).
export function expandFamily(topDocs = {}, kinDocs = {}, heads = topDocs) {
  const out = {};
  for (const [uid, d] of Object.entries(topDocs)) if (isUid(uid)) out[uid] = d;
  for (const [uid, byN] of Object.entries(kinDocs)) {
    if (!isUid(uid) || !byN || typeof byN !== 'object') continue;
    const allowed = new Set(kinSlots(heads[uid]));
    for (const [ns, d] of Object.entries(byN)) {
      if (!SLOT_RE.test(ns)) continue;
      const n = +ns;
      if (!allowed.has(n) || d == null) continue;
      out[charId(uid, n)] = d;
    }
  }
  return out;
}

// Every character id in a family (head first).
export const familyIds = (uid, headDoc) => (isUid(uid) ? [uid, ...kinSlots(headDoc).map(n => charId(uid, n))] : []);
// The next free slot, or null when the family is full.
export function nextSlot(headDoc) { const used = new Set(kinSlots(headDoc)); for (let n = 2; n <= MAX_CHARS; n++) if (!used.has(n)) return n; return null; }

// Character unlocks: a second character at player level 10, a third at 25 (XP is the player's, so every character
// shares the player's level).
export const UNLOCK = { 2: 10, 3: 25 };
export const slotsOpen = (level) => 1 + Object.values(UNLOCK).filter(l => (level || 0) >= l).length;

// Claude calls for a family: a shared budget so three characters don't triple a player's usage. Calls are taken in
// priority order; when the bucket is empty, lower-priority work falls back to the game's own heuristics.
export const PRIORITY = { player: 0, encounter: 1, plan: 2, social: 3, reflect: 4 };
export function familyBudget({ perMinute = 8, perDay = 600 } = {}) {
  let minute = [], day = [], dayKey = null, denied = 0;
  return {
    // Whether a call of this kind may run now (and if so, count it). The head and the player's own clicks always may.
    take(kind, now = Date.now()) {
      const dk = new Date(now).toISOString().slice(0, 10);
      if (dk !== dayKey) { dayKey = dk; day = []; denied = 0; }
      minute = minute.filter(t => now - t < 60000);
      const p = PRIORITY[kind] ?? 4;
      // Leave headroom for the more urgent kinds: lower priorities stop earlier.
      const cap = Math.max(1, perMinute - p), capDay = Math.max(1, perDay - p * 40);
      if (p > 0 && (minute.length >= cap || day.length >= capDay)) { denied++; return false; }
      minute.push(now); day.push(now);
      return true;
    },
    // What the Family page's meter shows: calls this minute and today, the caps, and how many fell back to heuristics.
    used: (now = Date.now()) => ({ minute: minute.filter(t => now - t < 60000).length, day: day.length, denied, perMinute, perDay }),
  };
}

// How many characters a family may have at this level, and the slot a new one would take (null: none now).
export function creatableSlot(level, headDoc) {
  if (!headDoc) return null;
  const have = 1 + kinSlots(headDoc).length;
  return have < slotsOpen(level) ? nextSlot(headDoc) : null;
}
// The head doc's `family` after adding a character in `slot` (and, optionally, naming the family).
export function withKin(headDoc, slot, name) {
  const f = cleanFamily(headDoc?.family) || { name: '', kin: [] };
  return { name: name != null ? cleanFamilyName(name) : f.name, kin: kinSlots({ family: { kin: [...f.kin, slot] } }) };
}

// The characters a room peer speaks for: its head (the peer's uid) and the kin its presence lists. Every id is made
// here from the peer's own uid, so a peer can never appear as someone else's character.
export function presenceChars(peerBy, tavern) {
  if (!isUid(peerBy) || !tavern || typeof tavern !== 'object') return [];
  const out = [[peerBy, tavern]];
  const k = tavern.kin;
  if (k && typeof k === 'object' && !Array.isArray(k)) for (const [ns, e] of Object.entries(k)) {
    if (!SLOT_RE.test(ns) || +ns > MAX_CHARS) continue;
    out.push([charId(peerBy, +ns), e && typeof e === 'object' && !Array.isArray(e) ? e : {}]);
  }
  return out;
}

// The family stash: gold and items moved between one player's own characters. A transfer leaves the giver first
// (its progress records it in `stashOut` in the same write that takes the gold; an item then leaves the bag), lands
// with the receiver (gold to the purse, an item to `pendingLoot`, which the page moves into the bag; `stashIn`
// remembers the id, so a retried delivery never pays twice), and then the giver forgets it.
export const STASH_KEEP = 200;
export const canStash = (fromId, toId) => fromId !== toId && sameFamily(fromId, toId);
export function stashOut(prog, t) {
  if (!prog || !t || typeof t.id !== 'string' || !canStash(t.from, t.to)) return null;
  const gold = Math.floor(t.gold || 0);
  if (gold < 0 || (!gold && !t.item) || (gold && (prog.gold || 0) < gold)) return null;
  if ((prog.stashOut || []).some(x => x.id === t.id)) return null;
  return { ...prog, gold: (prog.gold || 0) - gold, stashOut: [...(prog.stashOut || []), { id: t.id, from: t.from, to: t.to, gold, ...(t.item ? { item: t.item } : {}), at: t.at }] };
}
export function stashIn(prog, t) {
  if (!prog || !t || typeof t.id !== 'string' || (prog.stashIn || []).includes(t.id)) return null;
  return { ...prog, gold: (prog.gold || 0) + Math.max(0, Math.floor(t.gold || 0)), pendingLoot: [...(prog.pendingLoot || []), ...(t.item ? [t.item] : [])],
    stashIn: [...(prog.stashIn || []), t.id].slice(-STASH_KEEP) };
}
export function stashDone(prog, id) {
  if (!prog || !(prog.stashOut || []).some(t => t.id === id)) return null;
  return { ...prog, stashOut: prog.stashOut.filter(t => t.id !== id) };
}
