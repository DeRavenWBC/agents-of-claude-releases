import { TZ_OFFSET_MS, TZ_ISO, worldDay, dayAt } from './worldtime.js';
// Agents of Claude — live duels (rules version 1).
//
// Two players online at once. Each round both pick an action in secret (commit a hash, then reveal),
// and the battle engine resolves the round deterministically from the duel seed and every pick so far.
// Fair Duel scaling puts both Agents on level 30 with level-30 gear, so build and choices decide it.
// Each player records the finished duel in their own doc; Elo counts a duel only when both records agree.

import { simulate, makeAgentUnit, PER_LEVEL, ABILITIES, rulesOf, RULES_EPOCH } from './battle.js';
export { RULES_EPOCH };
import { snapIssues } from './verify.js';
import { trustedOld } from './trusted.js';
import * as I from './items.js';
const { rescaleAffix } = I;
import { fnv1a, makeRng, sha256 } from './rng.js';

export const DUEL_RULES = 1;
export const FAIR_LEVEL = 30;
export const MAX_ROUNDS = 40;
export const DUEL_HP = 2.5;
export const ELO_START = 1200, ELO_K = 32;

export const RANKS = [
  { min: 0, name: 'Bronze' }, { min: 1100, name: 'Silver' }, { min: 1250, name: 'Gold' },
  { min: 1400, name: 'Platinum' }, { min: 1550, name: 'Diamond' }, { min: 1700, name: 'Grandmaster' },
];
export const rankFor = (elo) => ([...RANKS].reverse().find(r => elo >= r.min) || RANKS[0]).name;   // total: a broken rating reads as Bronze

/* ---------------------------------------------------------- Fair scaling */

// Scale an item to item level `lvl`: base stats and affixes grow with (3 + level).
function scaleItem(it, lvl) {
  if (!it) return it;
  const f = (3 + lvl) / (3 + (it.ilvl || 1));
  const sc = (v) => (typeof v === 'number' && v > 0 ? Math.max(1, Math.round(v * f)) : v);
  return { ...it, ilvl: lvl, upgrade: 0, stats: Object.fromEntries(Object.entries(it.stats || {}).map(([k, v]) => [k, sc(v)])),
    affixes: (it.affixes || []).map(a => rescaleAffix(a, it.ilvl || 1, lvl, it.named)) };
}
// Fair Duels drop forge upgrades, so epoch 6 (the upgrade rework) didn't change them: epoch-5 duels still replay.
const DUEL_SAME = [];   // none since epochs 7-8 changed every kind of fight
// Fair Duel item: base stats rebuilt exactly as a level-`lvl` item of the same type and rarity (forge upgrades
// dropped), bonuses re-rolled at that level with the same roll quality. An unknown type keeps the ratio scaling.
function fairItem(it, lvl) {
  if (!it) return it;
  const scaled = scaleItem(it, lvl);
  return I.BASES[it.base] ? { ...scaled, stats: I.baseStats(it.base, it.rarity, lvl) } : scaled;
}

// The Fair Duel version of an Agent: level 30, spent points scaled to a level-30 budget in the same
// proportions, gear at item level 30 with no forge upgrades, and no trainer bonuses.
export function fairSnap(snap, level = FAIR_LEVEL) {
  const budget = 3 * (level - 1);
  const spent = snap.spent || {}, total = Object.values(spent).reduce((a, b) => a + (b || 0), 0);
  let fair;
  if (total > 0) {
    fair = Object.fromEntries(Object.entries(spent).map(([k, v]) => [k, Math.floor(v * budget / total)]));
    let left = budget - Object.values(fair).reduce((a, b) => a + b, 0);
    const keys = Object.keys(spent).sort((a, b) => spent[b] - spent[a]);
    for (let i = 0; left > 0; i++, left--) fair[keys[i % keys.length]] += 1;
  } else {
    fair = Object.fromEntries(Object.entries(PER_LEVEL[snap.cls] || {}).map(([k, n]) => [k, n * (level - 1)]));
  }
  // Every class active unlocked at level 30 is available (a new player isn't stuck with the few they had at their
  // own level); the saved loadout's abilities come first.
  const unlocked = Object.entries(ABILITIES).filter(([, a]) => a.cls === snap.cls && !a.basic && !a.ultimate && (a.lvl || 1) <= level).sort((x, y) => (x[1].lvl || 1) - (y[1].lvl || 1)).map(([k]) => k);
  const chosen = (snap.loadout || []).filter(k => k && ABILITIES[k]);
  const loadout = [...chosen, ...unlocked.filter(k => !chosen.includes(k))];
  return { ...snap, level, spent: fair, trained: {}, loadout, mount: null, gear: Object.fromEntries(Object.entries(snap.gear || {}).map(([s, it]) => [s, fairItem(it, level)])) };
}

/* ---------------------------------------------------------------- Rounds */

// Resolve a duel so far. a/b: fair snapshots (a is the challenger). rounds: [[pickA, pickB], ...].
// Returns { paused: { round, side }, units, log } while picks are needed, or { winner: 'a'|'b'|'draw', log, hash } when over.
export function duelState(seed, a, b, rounds) {
  const ua = makeAgentUnit(a, { id: 'a', level: a.level }), ub = makeAgentUnit(b, { id: 'b', level: b.level });
  ua.hpMult = ub.hpMult = DUEL_HP; // duels run longer than Pit fights, so decisions have room to matter
  const res = simulate(`duel|${seed}`, [ua], [ub], { crowd: true, duel: { rounds } });
  if (res.paused) return res;
  return { winner: res.winner === 'A' ? 'a' : res.winner === 'B' ? 'b' : 'draw', log: res.log, hash: res.hash, actions: res.actions };
}

// A commitment must not be openable two ways: SHA-256 over a 128-bit random salt. (It was a 32-bit hash, for which a
// second pick with the same commitment could be found in a fraction of a second, i.e. choosing after seeing the reveal.)
export const commitOf = (duelId, round, pick, salt) => sha256(`${duelId}|${round}|${pick}|${salt}`);
export const newSalt = () => { const b = new Uint8Array(16); if (globalThis.crypto?.getRandomValues) globalThis.crypto.getRandomValues(b); else for (let i = 0; i < 16; i++) b[i] = Math.floor(Math.random() * 256);
  return [...b].map(x => x.toString(16).padStart(2, '0')).join(''); };
// Rating from one opponent is rationed: the first DUELS_PER_PAIR_PER_DAY duels between two players on a SAST day move
// their ratings (for duels from PAIR_CAP_SINCE on), so two accounts can't trade wins all day.
export const DUELS_PER_PAIR_PER_DAY = 3, PAIR_CAP_SINCE = Date.parse('2026-11-26T00:00:00+02:00');

// Which picks a player may make right now (the paused state's options for their side).
export function optionsFor(state, side) {
  const u = state.units?.find(x => x.side === side && !x.summoned);
  return (u?.options || []).map(o => ({ ...o, name: ABILITIES[o.key]?.name || o.key, desc: ABILITIES[o.key]?.desc || '' }));
}

// A simple bot for tests and practice: a random ready ability, favouring the ultimate when charged.
export function botPick(state, side, rng = Math.random) {
  const opts = optionsFor(state, side).filter(o => o.ready);
  const ult = opts.find(o => ABILITIES[o.key]?.ultimate);
  if (ult && rng() < 0.8) return ult.key;
  return opts.length ? opts[Math.floor(rng() * opts.length)].key : 'basic';
}

// Play a whole duel with two pickers (for tests, practice and verification).
export function playDuel(seed, a, b, pickA, pickB) {
  const rounds = [];
  for (let i = 0; i < 400; i++) {
    const s = duelState(seed, a, b, rounds);
    if (!s.paused) return { ...s, rounds };
    rounds.push([pickA(s, 'A', rounds.length), pickB(s, 'B', rounds.length)]);
  }
  throw new Error('duel did not finish');
}

/* ------------------------------------------------------------------- Elo */

/**
 * duelDocs: { uid: [record] } where a record is { id, a, b, seed, rounds, winner ('a'|'b'|'draw'), hash, at, aSnap?, bSnap? }.
 * A duel counts once both players' docs hold it with the same winner and hash (and, if snapshots are
 * there, it re-simulates to that hash). Returns ratings, records and the counted duels in order.
 */
// started: { playerId: Set of duel ids that player's own page began } (from each player's duels doc).
// A player id used as an object key: a plain string that can't name something on Object.prototype.
const plainId = (s) => typeof s === 'string' && s.length > 0 && s.length <= 128 && !(s in Object.prototype);
export function replayElo(duelDocs, { verify = true, started = {}, trustOld = trustedOld.duel, now = 0 } = {}) {
  const byId = new Map();
  for (const [owner, list] of Object.entries(duelDocs || {})) for (const d of (Array.isArray(list) ? list : []).slice(-500)) {
    if (!d || typeof d !== 'object' || typeof d.id !== 'string' || !d.id || !plainId(d.a) || !plainId(d.b) || (d.a !== owner && d.b !== owner) || d.a === d.b || d.seed !== d.id
      || !Number.isFinite(d.at) || d.at < 1.7e12 || d.at > 4e12 || (now && d.at > now + 300_000)) continue;   // a real moment, not in the future
    const e = byId.get(d.id) || Object.create(null);
    e[owner] = d; byId.set(d.id, e);
  }
  const ratings = Object.create(null), record = Object.create(null), counted = [], disputed = [];
  const R = (id) => (ratings[id] ??= ELO_START);
  const rec = (id) => (record[id] ??= { w: 0, l: 0, d: 0 });
  // One broken record must never stop the replay for everyone: it is disputed and skipped.
  const matched = [...byId.values()].map(e => { try { return matchOne(e); } catch { disputed.push(Object.values(e)[0]?.id); return null; } })
    .filter(Boolean).sort((x, y) => (x.at - y.at) || x.id.localeCompare(y.id));
  function matchOne(e) {
    const anyRec = Object.values(e)[0];
    let ra = e[anyRec.a];
    const rb = e[anyRec.b];
    if (ra && rb) { if (ra.winner !== rb.winner || ra.hash !== rb.hash) { disputed.push(anyRec.id); return null; } }
    else {
      // Only one side recorded it (the other left). It still counts if it re-simulates exactly from its record and
      // either the loser is the one who recorded it, or the loser's own page shows it started that duel.
      const r = ra || rb, owner = ra ? r.a : r.b, loser = r.winner === 'a' ? r.b : r.winner === 'b' ? r.a : null;
      const resignedBy = String(r.hash).startsWith('resign:') ? (String(r.hash).slice(7) === 'a' ? r.a : r.b) : null;
      if (resignedBy) { if (resignedBy !== owner) return null; }
      else if (!(r.aRaw && r.bRaw) || !(loser === owner || started[loser]?.has(r.id))) return null;
      ra = r;
    }
    // v2 records keep each side's unscaled snapshot (aRaw/bRaw), checked exactly, then scaled here.
    if (verify && ra.aRaw && ra.bRaw && (snapIssues(ra.aRaw).length || snapIssues(ra.bRaw).length)) { disputed.push(ra.id); return null; }
    // Duels carry the combat rules they were fought under (rv). Older ones can't be replayed by this code: trusted if
    // fought before the switch (both sides already agreed on them), otherwise refused.
    const rules = rulesOf(ra.rv, ra.at, DUEL_SAME);
    if (verify && rules === 'bad') { disputed.push(ra.id); return null; }
    // Old-rules duels can't be replayed: only those on file when the rules changed count (engine/trusted.js).
    if (verify && rules === 'old') { if (!trustOld(ra)) { disputed.push(ra.id); return null; } }
    else if (verify && ra.aRaw && ra.bRaw && !String(ra.hash).startsWith('resign:')) {
      const s = duelState(ra.seed, fairSnap(ra.aRaw), fairSnap(ra.bRaw), ra.rounds || []);
      if (s.paused || s.hash !== ra.hash || s.winner !== ra.winner) { disputed.push(ra.id); return null; }
    } else if (verify && ra.aSnap && ra.bSnap && !String(ra.hash).startsWith('resign:')) {
      const s = duelState(ra.seed, ra.aSnap, ra.bSnap, ra.rounds || []);
      if (s.paused || s.hash !== ra.hash || s.winner !== ra.winner) { disputed.push(ra.id); return null; }
    }
    return ra;
  }
  const perPair = new Map();
  for (const d of matched) {
    if (d.at >= PAIR_CAP_SINCE) { const k = `${[d.a, d.b].sort().join('|')}|${worldDay(d.at)}`, n = (perPair.get(k) || 0) + 1; perPair.set(k, n); if (n > DUELS_PER_PAIR_PER_DAY) continue; }
    const ea = 1 / (1 + 10 ** ((R(d.b) - R(d.a)) / 400));
    const sa = d.winner === 'a' ? 1 : d.winner === 'b' ? 0 : 0.5;
    const delta = Math.round(ELO_K * (sa - ea));
    ratings[d.a] += delta; ratings[d.b] -= delta;
    if (sa === 1) { rec(d.a).w++; rec(d.b).l++; } else if (sa === 0) { rec(d.b).w++; rec(d.a).l++; } else { rec(d.a).d++; rec(d.b).d++; }
    counted.push({ ...d, delta });
  }
  return { ratings, record, counted, disputed };
}

export const duelId = (a, b, at) => `d-${at.toString(36)}-${fnv1a(`${a}|${b}|${at}`).slice(0, 6)}`;
export { makeRng };
