// Agents of Claude — battle engine (rules version 1).
// Pure and deterministic: simulate(seed, sideA, sideB) always returns the same event log
// for the same inputs. No Math.random, no Date, no DOM. Runs in Node (tests) and the browser (game).
// Rules follow the design doc: Characters, Abilities, Auto-battle system.

export const RULES_VERSION = 1;   // seeds every fight's RNG; never changes (results would all shift)
// Combat rules epochs. Bump RULES_EPOCH, and set EPOCH_SINCE to the day it goes live, whenever a change alters fight
// results that pages re-simulate to verify (world boss attempts, Pit bouts, Galas). Records carry the epoch they were
// fought under; only current-epoch records are re-simulated. Older ones are trusted if they predate the switch,
// because this code can no longer replay them (they were checked under their own rules at the time).
//   1: until 2026-11-20.  2: from 2026-11-20 (monster retune, PvE class tuning, mastery for heals and shields).
//   3: from 2026-11-20 (threat: monsters attack by threat, Presence and taunts pull aggro; 20 gambit slots).
//   4: from 2026-11-20 (no per-hit damage cap in the Arena; PvE fights are the same as epoch 3).
//   5: from 2026-11-20 (Fair Duels only: % item bonuses scale to a real level-30 roll instead of multiplying, and an
//      extra action from speed no longer breaks a picked Guard or Riposte; PvE and Pit bouts are the same as epoch 4).
//   6: from 2026-11-23 (forge upgrades raise base stats and bonuses by 5% a level with a minimum step, instead of +4%
//      base stats only. Older records replay exactly through items.replaySnap, which bakes the old +4% into the item;
//      Fair Duels drop upgrades, so duels are the same as 5).
//   7: from 2026-11-25 (no 4-ability loadout: every unlocked active is available in every fight).
//   8: from 2026-11-25 (tank balance: Unbreakable gives +15% max HP and +40% magic resist; Arcanists no longer take
//      less damage in PvE (PVE_TUNE refitted on damage dealt only); CLASS_TUNE refitted with tools/pvptune.mjs).
//   9: from 2026-11-25 (new abilities: Shield Wall, Rallying Cry, Smoke Bomb, Shadow Dance, Blizzard, Ironbark, Deadeye,
//      Doom; Iron Taunt adds +30% magic resist; new default gambits; CLASS_TUNE refitted again).
//  10: from 2026-11-25 (even kits: Charge, Intervene, Fire Blast, Poisoned Blades, Moonfire, Barkskin, Entangling Roots,
//      Starfall; Poison, Moonfire and Entangle ticks; the Ranger's companion is always out (wolf, boar or wisp) and
//      Kill Command replaces Call Companion; tunes refitted).
//  11: from 2026-11-25 (Ranger Enchanted Quiver: arrows 75% magical / 25% physical for mana; Shield Wall, Spell Ward and
//      Iron Taunt last one action longer).
//  12: from 2026-11-25 (no class damage multipliers in the Pit or Fair Duels; thorns only on contact, with diminishing
//      returns, splintered by Sunder and Feint; Sunder leaves the target Wounded (half healing); Polymorph leaves its target
//      Polymorph-proof for 4 actions; bosses have 3 Legendary Resistances against stuns, Polymorph and Freeze).
export const RULES_EPOCH = 12;
export const EPOCH_SINCE = Date.parse('2026-11-25T00:00:00+02:00');
// 'current' (re-simulate), 'old' (trust: made before this epoch began, or on its first day) or 'bad'.
// same: older epochs whose fights replay identically for this kind of record (e.g. world boss attempts didn't
// change from 3 to 4), so they are still re-simulated rather than merely trusted.
export function rulesOf(v, atMs, same = []) {
  const e = Number.isInteger(v) ? v : 1;
  if (e === RULES_EPOCH || same.includes(e)) return 'current';
  return e < RULES_EPOCH && atMs < EPOCH_SINCE + 86_400_000 ? 'old' : 'bad';
}
export const MAX_ACTIONS = 200;       // hard stop → draw
export const SUDDEN_DEATH_AT = 60;
// Damage over time, by status: the element each tick deals.
const DOT_ELEMENT = { burn: 'fire', bleed: 'physical', blight: 'shadow', corruption: 'shadow', siphon: 'shadow', moonfire: 'nature', entangle: 'nature', poison: 'nature' };
export const HOSTILE = ['burn', 'bleed', 'chill', 'stun', 'silence', 'sunder', 'marked', 'weakened', 'blight', 'poly', 'frozen', 'corruption', 'siphon', 'haunted', 'moonfire', 'entangle', 'poison', 'splinter', 'wounded'];
// Mastery: uses of an ability raise its rank (I–V): +3% power per rank; rank V also cuts its cooldown by 1.
export const MASTERY_STEPS = [20, 60, 150, 300, 500];
export const masteryRank = (uses) => MASTERY_STEPS.filter(n => (uses || 0) >= n).length;
// What mastery does, per rank (I–V), so every rank helps the ability in its own way: +3% to whatever number it has
// (damage, healing, shield size, damage or healing over time, a summon's strength), +2 percentage points to any chance
// it has to inflict a status; an ability with none of those (a pure buff: taunt, guard, riposte…) gives +2 ultimate
// charge per rank when used. From rank III a status with no number or chance lasts 1 action longer, and rank V cuts
// the cooldown by 1.
export const MASTERY = { power: 0.03, chance: 2, charge: 2, longerFrom: 3, cdFrom: 5 };
// A pure buff: nothing for mastery to scale, so it earns ultimate charge instead.
export const isPlainAbility = (ab) => !!ab && !ab.ultimate && !(ab.coef || ab.coefs || ab.healPctMax) && ab.kind !== 'heal' && ab.kind !== 'summon'
  && !(ab.effects || []).some(e => e.type === 'shield' || e.powerCoef || (e.chance != null && e.chance < 100));
export const UNIVERSAL = ['guard', 'focus'];
// Arena-only rules (PvP). PvE is untouched. Mutable so balance probes can sweep them.
export const ARENA = { healMult: 0.9, healPerLevel: 0.02, dodgeMult: 0.4, physMult: 1, summonActions: 3, speedComp: 0.2, speedSlope: 0.03, critBonus: 0.7 };
// Arena-only class tuning: damage dealt at each knot level (linear between, flat outside). Tuned with tools/pvptune.mjs.
export const TUNE_KNOTS = [14, 24, 34, 43]; // centres of the level bands 10–19, 20–29, 30–39, 40–45
// No per-class damage multipliers in the Pit or Fair Duels (epoch 12): every class fights with its own kit and stats.
// Kept as all-1 so older code paths and tools still read it.
export const CLASS_TUNE = { warblade: [1, 1, 1, 1], shadowstep: [1, 1, 1, 1], arcanist: [1, 1, 1, 1], warden: [1, 1, 1, 1], ranger: [1, 1, 1, 1], hexer: [1, 1, 1, 1], deathknight: [1, 1, 1, 1], necromancer: [1, 1, 1, 1], bard: [1, 1, 1, 1] };
export function classTune(cls, lvl = 1) {
  const t = CLASS_TUNE[cls]; if (!t) return 1;
  const K = TUNE_KNOTS, L = Math.max(K[0], Math.min(K.at(-1), lvl));
  let i = 0; while (i < K.length - 2 && L > K[i + 1]) i++;
  return t[i] + (t[i + 1] - t[i]) * (L - K[i]) / (K[i + 1] - K[i]);
}
// PvE-only class tuning (never in the Arena): damage an Agent of the class deals and takes, at each knot level
// (linear between, flat outside). Fitted with tools/classtune.mjs against the other classes' success across all
// content (tools/fullbalance.mjs). Hirelings are not tuned.
export const PVE_KNOTS = [3, 10, 20, 30, 45];
export const PVE_TUNE = {
  ranger: { dealt: [1.7, 1.7, 1.7, 0.8, 0.6], taken: [1, 1, 1, 1, 1] },   // fitted on damage dealt only since its companion arrived (epoch 10)
  // Arcanists are cloth glass cannons (no HP passive since epoch 9): fitted on damage dealt only (tools/classtune.mjs
  // --dealt-only), so they never take less damage than their armour says.
  arcanist: { dealt: [1.15, 1.75, 1.75, 1.75, 1.75], taken: [1, 1, 1, 1, 1] },
  // The assassin: refitted on damage dealt only when its kit grew (epoch 10).
  shadowstep: { dealt: [1.4, 1.2, 1.65, 1.45, 1.1], taken: [1, 1, 1, 1, 1] },
  // The warlock: its curses tick through this too (since epoch 9), fitted on damage dealt only.
  hexer: { dealt: [1.05, 1.1, 1.45, 1.65, 1.75], taken: [1, 1, 1, 1, 1] },
  // Season 1.5 classes, fitted with tools/classtune.mjs (20 seeds) to the reference classes' success in every band.
  // The rune knight is a plate tank, so it is fitted on both sides; the Necromancer's minions make it strong, so it is
  // fitted on damage dealt only (it never takes more damage than its armour says).
  deathknight: { dealt: [1.4, 1.35, 1.6, 1.5, 1.65], taken: [0.714, 0.741, 0.625, 0.667, 0.606] },
  necromancer: { dealt: [1.25, 0.65, 1.25, 0.7, 0.6], taken: [1, 1, 1, 1, 1] },
  bard: { dealt: [1.4, 1.05, 1.5, 1.35, 1.25], taken: [0.714, 0.952, 0.667, 0.741, 0.8] },
};
export function pveTune(cls, lvl, kind) {
  const t = PVE_TUNE[cls]?.[kind]; if (!t) return 1;
  const K = PVE_KNOTS, L = Math.max(K[0], Math.min(K.at(-1), lvl || 1));
  let i = 0; while (i < K.length - 2 && L > K[i + 1]) i++;
  return t[i] + (t[i + 1] - t[i]) * (L - K[i]) / (K[i + 1] - K[i]);
}
export const arenaHeal = (lvl) => Math.max(0.25, ARENA.healMult - ARENA.healPerLevel * Math.max(0, (lvl || 1) - 10));    // after this many actions, damage ×1.1 per action, compounding
export const GAUGE = 1000;

/* ------------------------------------------------------------------ RNG */

export { hashSeed, makeRng, fnv1a } from './rng.js';
import { makeRng, fnv1a } from './rng.js';
import { MOUNTS } from './mounts.js';
import { RACES, raceOf } from './races.js';
import { computeGear, PROFICIENT } from './items.js';

/* ------------------------------------------------------------- Elements */

export const ELEMENTS = ['physical', 'fire', 'frost', 'storm', 'nature', 'radiant', 'shadow'];
// "A → B" means A is strong against B: Fire → Nature → Storm → Frost → Fire.
const BEATS = { fire: 'nature', nature: 'storm', storm: 'frost', frost: 'fire' };

// Multiplier for an attack of element `atk` landing on a defender whose affinity is `def`.
export function elementMult(atk, def) {
  if (!atk || atk === 'physical' || !def || def === 'physical') return 1;
  if ((atk === 'radiant' && def === 'shadow') || (atk === 'shadow' && def === 'radiant')) return 1.5;
  if (BEATS[atk] === def) return 1.5;
  if (BEATS[def] === atk) return 0.67;
  return 1;
}

/* -------------------------------------------------------- Derived stats */

// Thorns rules (epoch 12 test): only contact moves trigger them; stacked gear thorns have diminishing returns;
// Sunder and Feint splinter them for a while. ONCE_PER_ACTION (off) would let only an action's first hit trigger them.
// Bosses resist this many stuns, Polymorphs and Freezes per fight; after Polymorph a unit is immune to it for a while.
export const LEGENDARY_RESISTS = 3, POLY_IMMUNE_TURNS = 5;   // 5 turns = its next 4 actions
export const THORNS = { contactOnly: true, diminish: true, oncePerAction: false };
// Physical moves that do not touch the target: arrows, area slams and waves. Pets and melee weapons are contact.
export const NON_CONTACT = new Set(['earthsplitter', 'inferno_arc', 'storm_volley', 'volley', 'rain_of_arrows', 'quick_shot', 'hunters_mark', 'snare_trap', 'piercing_arrow', 'called_shot', 'deadeye']);
export const isContact = (ab, src) => (ab?.kind === 'phys') && !NON_CONTACT.has(ab.id) && !(src?.cls === 'ranger' && !src.summoned && ab.id !== 'kill_command');
// Stacked thorns are worth less and less: 14% stays about 11%, 43% works like about 23%.
export const effectiveThorns = (t) => (THORNS.diminish ? Math.round(10 * t / (1 + t / 50)) / 10 : t);
export function deriveStats(scores, level = 1, gear = {}) {
  const s = scores, g = gear;
  return {
    maxHp: Math.round(50 + 10 * s.vit + 8 * level + (g.hp || 0)),
    maxMana: Math.round(30 + 4 * s.int + 2 * s.spi + (g.mana || 0)),
    regen: (2 + s.spi / 5 + (g.regen || 0)) * (1 + (g.regenPct || 0) / 100),
    phys: 2 * s.mig + (g.weapon || 0),
    finesse: 1.6 * s.agi + (g.weapon || 0),
    spell: (2 * s.int + (g.spell || 0)) * (1 + (g.spellPct || 0) / 100),
    heal: (1.5 * s.spi + (g.heal || 0)) * (1 + (g.healPct || 0) / 100),
    nature: 1.5 * s.spi + 0.5 * (g.heal || 0), // Warden nature magic: Spirit plus half of healing gear, no healing %
    song: (3 * s.pre + (g.spell || 0)) * (1 + (g.spellPct || 0) / 100), // Bard songs: Presence (3 a point) plus the lute's spell power
    speed: 100 + 1.5 * Math.min(s.agi, 20) + 0.75 * Math.max(0, s.agi - 20) + (g.speed || 0),
    crit: Math.min(50, 5 + s.agi / 3 + (g.crit || 0)),
    critDmg: 150 + (g.critDmg || 0),
    dodge: Math.min(30, s.agi / 5 + (g.dodge || 0)),
    block: Math.min(25, 0.5 * s.mig + (g.block || 0)),
    armor: 2 * s.vit + (g.armor || 0),
    mr: s.spi + (g.mr || 0),
    resist: Math.min(40, 0.5 * s.spi + (g.resist || 0)),
    lifesteal: g.lifesteal || 0,
    thorns: effectiveThorns(g.thorns || 0),
    healRecv: g.healRecv || 0,
    elem: { ...(g.elem || {}) },
  };
}

/* ------------------------------------------------------------ Abilities */
// kind: phys | spell | heal | buff | summon. coef is a fraction of power (1.2 = 120%).
// target: enemy | all-enemies | chain | self | ally-lowest | all-allies.
// effects: statuses applied to whoever the ability hits (or to self for buffs).

export const ABILITIES = {
  // Generic
  strike:          { desc: 'Free fallback when nothing else can be used: 100% physical damage.', name: 'Strike', kind: 'phys', coef: 1.0, cost: 0, cd: 0, target: 'enemy' },

  // Warblade
  cleave:          { desc: 'Basic attack. 130% physical damage, plus 65% to a second enemy.', name: 'Cleave', cls: 'warblade', lvl: 1, kind: 'phys', coef: 1.3, splash: 0.5, cost: 0, cd: 0, target: 'enemy', basic: true },
  shield_bash:     { desc: '80% physical damage. 60% chance to Silence the target for 1 action (no spells).', name: 'Shield Bash', cls: 'warblade', lvl: 3, kind: 'phys', coef: 0.8, cost: 8, cd: 3, target: 'enemy',
                     effects: [{ type: 'silence', chance: 60, turns: 1 }] },
  // Durations tick at the end of the holder's own actions, including the one that cast it: 3 turns = your next 2 actions.
  iron_taunt:      { desc: 'Until the end of your next 3 actions, enemies must target you and you gain +30% armour and +30% magic resist.', name: 'Iron Taunt', cls: 'warblade', lvl: 6, kind: 'buff', cost: 10, cd: 4, target: 'self',
                     effects: [{ type: 'taunt', turns: 4 }, { type: 'armorUp', turns: 4 }, { type: 'wardUp', turns: 4 }] },
  charge:          { desc: 'Opener (or from Stealth): charge in for 90% physical damage and Stun the target for 1 action.', name: 'Charge', cls: 'warblade', lvl: 9, kind: 'phys', coef: 0.9, firstActionOnly: true, cost: 6, cd: 2, target: 'enemy',
                     effects: [{ type: 'stun', chance: 100, turns: 1 }] },
  intervene:       { desc: 'Stand guard over the most hurt ally (not yourself): the next hit aimed at them strikes you instead.', name: 'Intervene', cls: 'warblade', lvl: 36, kind: 'buff', cost: 8, cd: 3, target: 'ally-lowest', allyOnly: true,
                     effects: [{ type: 'intervene', turns: 3 }] },
  shield_wall:     { desc: 'Raise your shield: for your next 3 actions you take 35% less damage from everything, spells included.', name: 'Shield Wall', cls: 'warblade', lvl: 18, kind: 'buff', cost: 12, cd: 5, target: 'self',
                     effects: [{ type: 'wall', turns: 4 }] },
  spell_ward:      { desc: 'For your next 2 actions, spells hit you for 40% less and 30% of their damage strikes back at the caster.', name: 'Spell Ward', cls: 'warblade', lvl: 28, kind: 'buff', cost: 10, cd: 4, target: 'self',
                     effects: [{ type: 'reflect', turns: 3 }] },
  rallying_cry:    { desc: 'Heal 15% of your max HP, shake off every ailment and gain 15 ultimate charge. A shout, so Silence cannot stop it.', name: 'Rallying Cry', cls: 'warblade', lvl: 40, kind: 'buff', cost: 16, cd: 7, target: 'self',
                     healPctMax: 15, cleanse: true, chargeGain: 15 },
  earthsplitter:   { desc: 'Ultimate. 200% physical damage to every enemy.', name: 'Earthsplitter', cls: 'warblade', lvl: 1, ultimate: true, kind: 'phys', coef: 2.0, cost: 0, cd: 0, target: 'all-enemies' },

  // Shadowstep
  twin_fangs:      { desc: 'Basic attack. Two quick strikes of 60% finesse damage.', name: 'Twin Fangs', cls: 'shadowstep', lvl: 1, kind: 'phys', power: 'finesse', coef: 0.6, hits: 2, cost: 0, cd: 0, target: 'enemy', basic: true },
  ambush:          { desc: 'First action only. 220% Shadow finesse damage, always a crit.', name: 'Ambush', cls: 'shadowstep', lvl: 1, kind: 'phys', power: 'finesse', element: 'shadow', coef: 2.2, cost: 0, cd: 0, target: 'enemy',
                     firstActionOnly: true, guaranteedCrit: true },
  hemorrhage:      { desc: '60% finesse damage and a Bleed: 15% of your power each action for 4 actions, stacks 3 times.', name: 'Hemorrhage', cls: 'shadowstep', lvl: 10, kind: 'phys', power: 'finesse', coef: 0.6, cost: 10, cd: 1, target: 'enemy',
                     effects: [{ type: 'bleed', chance: 100, turns: 4, powerCoef: 0.15, maxStacks: 3 }] },
  death_mark:      { desc: 'Ultimate. 250% Shadow finesse damage, always a crit.', name: 'Death Mark', cls: 'shadowstep', lvl: 1, ultimate: true, kind: 'phys', power: 'finesse', element: 'shadow', coef: 2.5, cost: 0, cd: 0,
                     target: 'enemy', guaranteedCrit: true },

  // Arcanist
  arcane_bolt:     { desc: 'Basic attack. 100% spell damage in your affinity element.', name: 'Arcane Bolt', cls: 'arcanist', lvl: 1, kind: 'spell', element: 'affinity', coef: 1.0, cost: 0, cd: 0, target: 'enemy', basic: true },
  firebolt:        { desc: '130% Fire spell damage. 20% chance to Burn for 3 actions.', name: 'Firebolt', cls: 'arcanist', lvl: 1, kind: 'spell', element: 'fire', coef: 1.3, cost: 8, cd: 0, target: 'enemy',
                     effects: [{ type: 'burn', chance: 20, turns: 3, powerCoef: 0.1 }] },
  frost_barrier:   { desc: 'Wrap yourself in ice: a shield worth 22% of your max HP.', name: 'Frost Barrier', cls: 'arcanist', lvl: 5, kind: 'buff', cost: 14, cd: 6, target: 'self',
                     effects: [{ type: 'shield', shieldPct: 22 }] },
  fire_blast:      { desc: '110% Fire spell damage, always a critical hit against a Burning target.', name: 'Fire Blast', cls: 'arcanist', lvl: 9, kind: 'spell', element: 'fire', coef: 1.1, critVsStatus: ['burn'], cost: 10, cd: 3, target: 'enemy' },
  polymorph:       { desc: 'Turn an enemy into a harmless animal: it cannot act for 2 actions, but any damage breaks it. Afterwards it cannot be Polymorphed again for its next 4 actions; bosses shrug off the first few with Legendary Resistance. Picks the foe you are not fighting if there is one.', name: 'Polymorph', cls: 'arcanist', lvl: 18, kind: 'spell', element: 'arcane', noDamage: true, ccTarget: true, cost: 14, cd: 6, target: 'enemy',
                     effects: [{ type: 'poly', chance: 100, turns: 2 }] },
  blink:           { desc: 'Blink away: the next attack aimed at you misses, spells included.', name: 'Blink', cls: 'arcanist', lvl: 28, kind: 'buff', cost: 8, cd: 5, target: 'self',
                     effects: [{ type: 'blink', turns: 3 }] },
  blizzard:        { desc: '120% Frost spell damage to every enemy and Chill (slower) for 2 actions, guaranteed.', name: 'Blizzard', cls: 'arcanist', lvl: 40, kind: 'spell', element: 'frost', coef: 1.2, cost: 24, cd: 5, target: 'all-enemies',
                     effects: [{ type: 'chill', chance: 100, turns: 2 }] },
  chain_lightning: { desc: 'Storm spell that hits up to 3 enemies for 110%, 80% and 60%.', name: 'Chain Lightning', cls: 'arcanist', lvl: 15, kind: 'spell', element: 'storm', coefs: [1.1, 0.8, 0.6], cost: 18, cd: 2, target: 'chain' },
  meteor:          { desc: 'Ultimate. 180% Fire spell damage to every enemy, 60% chance each to Burn.', name: 'Meteor', cls: 'arcanist', lvl: 1, ultimate: true, kind: 'spell', element: 'fire', coef: 1.8, cost: 0, cd: 0, target: 'all-enemies',
                     effects: [{ type: 'burn', chance: 60, turns: 3, powerCoef: 0.1 }] },

  // Warden
  thorn_whip:      { desc: 'Basic attack. 100% Nature damage, scaling with Spirit.', name: 'Thorn Whip', cls: 'warden', lvl: 1, kind: 'spell', power: 'spirit', element: 'nature', coef: 1.0, cost: 0, cd: 0, target: 'enemy', basic: true },
  mending_roots:   { desc: 'Heal the most hurt ally for 30% of healing power now and 30% at each of their next 3 actions.', name: 'Mending Roots', cls: 'warden', lvl: 1, kind: 'heal', coef: 0.3, cost: 12, cd: 2, target: 'ally-lowest',
                     effects: [{ type: 'regrow', turns: 3, powerCoef: 0.3 }] }, // 40% now + 40% × 3 over time = 160%
  spirit_bear:     { desc: 'Summon a Spirit Bear ally for 6 actions. One at a time.', name: 'Spirit Bear', cls: 'warden', lvl: 20, kind: 'summon', cost: 25, cd: 8, target: 'self', summon: 'spirit_bear' },
  grove_embrace:   { desc: 'Ultimate. Heal every ally for 100% of healing power and remove harmful effects.', name: "Grove's Embrace", cls: 'warden', lvl: 1, ultimate: true, kind: 'heal', coef: 1.0, cost: 0, cd: 0, target: 'all-allies', cleanse: true },

  // Item abilities (slot them in the loadout while the item is equipped)
  inferno_arc:     { desc: 'Item ability. 110% Fire physical damage to every enemy.', name: 'Inferno Arc', item: true, kind: 'phys', element: 'fire', coef: 1.1, cost: 15, cd: 4, target: 'all-enemies' },
  shimmer:         { desc: 'Item ability. For 2 actions, +25% dodge against physical attacks.', name: 'Shimmer', item: true, kind: 'buff', cost: 8, cd: 5, target: 'self',
                     effects: [{ type: 'evasive', turns: 2 }] },
  stew_of_fortitude: { desc: 'Item ability. Heal 30% of your max HP and gain +30% armour for 2 actions.', name: 'Stew of Fortitude', item: true, kind: 'heal', coef: 0, healPctMax: 30,
                     cost: 10, cd: 5, target: 'self', effects: [{ type: 'armorUp', turns: 2 }] },
  // Ranger (Season 1): a bow, marks and volleys
  quick_shot:      { desc: 'Basic attack. 100% finesse damage.', name: 'Quick Shot', cls: 'ranger', lvl: 1, kind: 'phys', power: 'finesse', coef: 1.0, cost: 0, cd: 0, target: 'enemy', basic: true },
  hunters_mark:    { desc: '60% finesse damage and Mark the target for 3 actions: it takes 20% more damage from everyone.', name: "Hunter's Mark", cls: 'ranger', lvl: 1, kind: 'phys', power: 'finesse', coef: 0.6, cost: 8, cd: 3, target: 'enemy',
                     effects: [{ type: 'marked', chance: 100, turns: 3 }] },
  volley:          { desc: '60% finesse damage to every enemy.', name: 'Volley', cls: 'ranger', lvl: 3, kind: 'phys', power: 'finesse', coef: 0.6, cost: 12, cd: 3, target: 'all-enemies' },
  snare_trap:      { desc: '50% physical damage and Chill (slower) for 2 actions, guaranteed.', name: 'Snare Trap', cls: 'ranger', lvl: 6, kind: 'phys', power: 'finesse', coef: 0.5, cost: 10, cd: 4, target: 'enemy',
                     effects: [{ type: 'chill', chance: 100, turns: 2 }] },
  piercing_arrow:  { desc: '150% finesse damage that ignores 40% of the target\'s armour.', name: 'Piercing Arrow', cls: 'ranger', lvl: 10, kind: 'phys', power: 'finesse', coef: 1.5, pierce: 0.4, cost: 14, cd: 3, target: 'enemy' },
  evasive_roll:    { desc: 'Roll clear: +25% dodge and Haste until your next action.', name: 'Evasive Roll', cls: 'ranger', lvl: 15, kind: 'buff', cost: 10, cd: 5, target: 'self',
                     effects: [{ type: 'evasive', turns: 2 }, { type: 'haste', turns: 3 }] },
  called_shot:     { desc: '160% finesse damage, +50% against a Marked target.', name: 'Called Shot', cls: 'ranger', lvl: 24, kind: 'phys', power: 'finesse', coef: 1.6, cost: 16, cd: 4, target: 'enemy',
                     bonusVsStatus: { statuses: ['marked'], mult: 1.5 } },
  kill_command:    { desc: 'Order your companion to go for the throat: it strikes the target for 200% of its own power. Needs your companion at your side.', name: 'Kill Command', cls: 'ranger', lvl: 8, kind: 'phys', power: 'finesse', coef: 2.0, needsPet: true, cost: 10, cd: 3, target: 'enemy' },
  enchanted_quiver: { desc: 'Toggle: enchant your arrows. While on, each of your attacks costs 5 mana and hits 75% as a spell in your armour\'s element (magic resist instead of armour; no dodge, block, Riposte or thorns on that part) and 25% as a plain arrow. Out of mana, arrows are plain again. In a gambit it stays on while the rule\'s condition holds and goes off when it does not.', name: 'Enchanted Quiver', cls: 'ranger', lvl: 14, kind: 'buff', toggle: 'quiver', cost: 0, cd: 1, target: 'self',
                     effects: [{ type: 'quiver', turns: 9999 }] },
  freezing_trap:   { desc: 'Freeze an enemy solid: it cannot act for 2 actions, but any damage breaks the ice. Bosses shrug off the first few with Legendary Resistance. Picks the foe you are not fighting if there is one.', name: 'Freezing Trap', cls: 'ranger', lvl: 20, kind: 'phys', element: 'frost', noDamage: true, ccTarget: true, cost: 12, cd: 6, target: 'enemy',
                     effects: [{ type: 'frozen', chance: 100, turns: 2 }] },
  deadeye:         { desc: '240% finesse damage that ignores 50% of the target\'s armour.', name: 'Deadeye', cls: 'ranger', lvl: 40, kind: 'phys', power: 'finesse', coef: 2.4, pierce: 0.5, cost: 20, cd: 6, target: 'enemy' },
  rain_of_arrows:  { desc: '90% finesse damage to every enemy, 50% chance each to Bleed.', name: 'Rain of Arrows', cls: 'ranger', lvl: 32, kind: 'phys', power: 'finesse', coef: 0.9, cost: 20, cd: 5, target: 'all-enemies',
                     effects: [{ type: 'bleed', chance: 50, turns: 3, powerCoef: 0.12, maxStacks: 2 }] },
  storm_volley:    { desc: 'Ultimate. 160% Storm-charged finesse damage to every enemy.', name: 'Storm Volley', cls: 'ranger', lvl: 1, ultimate: true, kind: 'phys', power: 'finesse', element: 'storm', coef: 1.6, cost: 0, cd: 0, target: 'all-enemies' },
  // Hexer (Season 1): curses, drains and blight
  shadow_bolt:     { desc: 'Basic attack. 100% Shadow spell damage.', name: 'Shadow Bolt', cls: 'hexer', lvl: 1, kind: 'spell', element: 'shadow', coef: 1.0, cost: 0, cd: 0, target: 'enemy', basic: true },
  curse_of_weakness: { desc: '60% Shadow damage and Weaken for 3 actions: the target deals 20% less damage.', name: 'Curse of Weakness', cls: 'hexer', lvl: 1, kind: 'spell', element: 'shadow', coef: 0.6, cost: 8, cd: 3, target: 'enemy',
                     effects: [{ type: 'weakened', chance: 100, turns: 3 }] },
  drain_life:      { desc: '100% Shadow damage; heal for 60% of the damage dealt.', name: 'Drain Life', cls: 'hexer', lvl: 3, kind: 'spell', element: 'shadow', coef: 1.0, drain: 0.6, cost: 12, cd: 2, target: 'enemy' },
  plague:          { desc: '30% Shadow damage to every enemy and Blight (Shadow damage over time) for 4 actions, stacking 3 times.', name: 'Plague', cls: 'hexer', lvl: 6, kind: 'spell', element: 'shadow', coef: 0.3, cost: 14, cd: 4, target: 'all-enemies',
                     effects: [{ type: 'blight', chance: 100, turns: 4, powerCoef: 0.18, maxStacks: 3 }] },
  dark_pact:       { desc: 'Pay 10% of your max HP: +25% damage for 2 actions and +20 ultimate charge.', name: 'Dark Pact', cls: 'hexer', lvl: 10, kind: 'buff', cost: 0, cd: 6, target: 'self', selfHpCostPct: 10, chargeGain: 20,
                     effects: [{ type: 'empower', turns: 3 }] },
  hex:             { desc: '30% Shadow damage and a 70% chance to Stun for 1 action.', name: 'Hex', cls: 'hexer', lvl: 15, kind: 'spell', element: 'shadow', coef: 0.3, cost: 14, cd: 5, target: 'enemy',
                     effects: [{ type: 'stun', chance: 70, turns: 1 }] },
  malediction:     { desc: '130% Shadow damage, +60% against a target that is Weakened, Blighted or Marked.', name: 'Malediction', cls: 'hexer', lvl: 24, kind: 'spell', element: 'shadow', coef: 1.3, cost: 16, cd: 3, target: 'enemy',
                     bonusVsStatus: { statuses: ['weakened', 'blight', 'marked'], mult: 1.6 } },
  corruption:      { desc: '20% Shadow damage and Corruption: Shadow damage at each of the target\'s next 5 actions, stacking 3 times.', name: 'Corruption', cls: 'hexer', lvl: 12, kind: 'spell', element: 'shadow', coef: 0.2, cost: 10, cd: 2, target: 'enemy',
                     effects: [{ type: 'corruption', chance: 100, turns: 5, powerCoef: 0.35, maxStacks: 3 }] },
  siphon_life:     { desc: '30% Shadow damage and Siphon Life for 4 actions: each tick hurts the target and heals you for half of it.', name: 'Siphon Life', cls: 'hexer', lvl: 20, kind: 'spell', element: 'shadow', coef: 0.3, cost: 12, cd: 3, target: 'enemy',
                     effects: [{ type: 'siphon', chance: 100, turns: 4, powerCoef: 0.3 }] },
  haunt:           { desc: '100% Shadow damage and Haunt for 4 actions: the target takes 20% more Shadow damage, curses and ticks included.', name: 'Haunt', cls: 'hexer', lvl: 28, kind: 'spell', element: 'shadow', coef: 1.0, cost: 16, cd: 5, target: 'enemy',
                     effects: [{ type: 'haunted', chance: 100, turns: 4 }] },
  summon_imp:      { desc: 'Summon an imp from the dark: it hurls Shadow Bolts at your foes for 6 actions. One pet at a time.', name: 'Summon Imp', cls: 'hexer', lvl: 40, kind: 'summon', cost: 22, cd: 8, target: 'self', summon: 'imp' },
  soul_rend:       { desc: '180% Shadow damage; heal for 30% of the damage dealt.', name: 'Soul Rend', cls: 'hexer', lvl: 32, kind: 'spell', element: 'shadow', coef: 1.8, drain: 0.3, cost: 24, cd: 5, target: 'enemy' },
  eclipse:         { desc: 'Ultimate. 150% Shadow damage to every enemy and Weaken them for 2 actions.', name: 'Eclipse', cls: 'hexer', lvl: 1, ultimate: true, kind: 'spell', element: 'shadow', coef: 1.5, cost: 0, cd: 0, target: 'all-enemies',
                     effects: [{ type: 'weakened', chance: 100, turns: 2 }] },

  // Death Knight (Season 1.5): a plate warrior who casts. Runeforge imbues his weapon with an element; every physical
  // weapon attack then also hits for IMBUE_COEF of his spell power in that element, so spell power, elemental damage
  // bonuses (Blazing, Frigid…) and armour of the same element all make him stronger.
  runic_strike:    { desc: 'Basic attack. 130% physical damage, plus your rune\'s elemental strike while your weapon is imbued.', name: 'Runic Strike', cls: 'deathknight', lvl: 1, kind: 'phys', coef: 1.3, cost: 0, cd: 0, target: 'enemy', basic: true },
  runeforge:       { desc: 'Imbue your weapon for your next 10 actions with the element that hurts your foe most: Frost, Fire (level 5), Storm (level 12) or Shadow (level 20), counting its affinity, your elemental damage bonuses and your armour\'s element. Imbued weapon attacks add 80% of your spell power in that element. Frost may Chill, Fire may Burn, Storm arcs to a second foe, Shadow heals you.', name: 'Runeforge', cls: 'deathknight', lvl: 1, kind: 'buff', cost: 6, cd: 3, target: 'self', runeforge: true },
  death_grip:      { desc: '70% Shadow spell damage and a 50% chance to Silence the target for 1 action.', name: 'Death Grip', cls: 'deathknight', lvl: 3, kind: 'spell', element: 'shadow', coef: 0.7, cost: 8, cd: 3, target: 'enemy',
                     effects: [{ type: 'silence', chance: 50, turns: 1 }] },
  anti_magic_shell: { desc: 'For your next 2 actions, spells hit you for 40% less and 30% of their damage strikes back at the caster.', name: 'Anti-Magic Shell', cls: 'deathknight', lvl: 6, kind: 'buff', cost: 10, cd: 5, target: 'self',
                     effects: [{ type: 'reflect', turns: 3 }] },
  obliterate:      { desc: '160% physical damage; its rune strike is twice as strong.', name: 'Obliterate', cls: 'deathknight', lvl: 9, kind: 'phys', coef: 1.6, imbueMult: 2, cost: 12, cd: 3, target: 'enemy' },
  blood_boil:      { desc: '60% Shadow spell damage to every enemy; heal for 30% of the damage dealt.', name: 'Blood Boil', cls: 'deathknight', lvl: 12, kind: 'spell', element: 'shadow', coef: 0.6, drain: 0.3, cost: 14, cd: 4, target: 'all-enemies' },
  icebound_fortitude: { desc: 'For your next 3 actions you take 35% less damage from everything.', name: 'Icebound Fortitude', cls: 'deathknight', lvl: 15, kind: 'buff', cost: 12, cd: 6, target: 'self',
                     effects: [{ type: 'wall', turns: 4 }] },
  death_strike:    { desc: '120% physical damage; heal for 25% of the damage dealt (rune strike included).', name: 'Death Strike', cls: 'deathknight', lvl: 18, kind: 'phys', coef: 1.2, drain: 0.25, cost: 10, cd: 2, target: 'enemy' },
  howling_blast:   { desc: '100% Frost spell damage to every enemy, 50% chance each to Chill for 2 actions.', name: 'Howling Blast', cls: 'deathknight', lvl: 24, kind: 'spell', element: 'frost', coef: 1.0, cost: 16, cd: 4, target: 'all-enemies',
                     effects: [{ type: 'chill', chance: 50, turns: 2 }] },
  rune_tap:        { desc: 'Heal 18% of your max HP and gain 10 ultimate charge.', name: 'Rune Tap', cls: 'deathknight', lvl: 28, kind: 'buff', cost: 12, cd: 6, target: 'self', healPctMax: 18, chargeGain: 10 },
  dancing_rune_weapon: { desc: 'Your weapon fights beside you in spirit: +25% damage for your next 3 actions.', name: 'Dancing Rune Weapon', cls: 'deathknight', lvl: 32, kind: 'buff', cost: 14, cd: 7, target: 'self',
                     effects: [{ type: 'empower', turns: 4 }] },
  chains_of_ice:   { desc: '90% Frost spell damage and Chill the target for 3 actions.', name: 'Chains of Ice', cls: 'deathknight', lvl: 36, kind: 'spell', element: 'frost', coef: 0.9, cost: 10, cd: 3, target: 'enemy',
                     effects: [{ type: 'chill', chance: 100, turns: 3 }] },
  soulreaver:      { desc: 'Ultimate. 220% physical damage and a rune strike three times as strong (Shadow if your weapon is not imbued).', name: 'Soulreaver', cls: 'deathknight', lvl: 1, ultimate: true, kind: 'phys', coef: 2.2, imbueMult: 3, imbueDefault: 'shadow', cost: 0, cd: 0, target: 'enemy' },

  // Necromancer (Season 1.5): a shadow caster who raises the dead to fight for him and rots his foes.
  bone_spear:      { desc: 'Basic attack. 100% Shadow spell damage.', name: 'Bone Spear', cls: 'necromancer', lvl: 1, kind: 'spell', element: 'shadow', coef: 1.0, cost: 0, cd: 0, target: 'enemy', basic: true },
  raise_skeleton:  { desc: 'Raise a skeleton warrior that fights for you for 6 actions. One minion at a time.', name: 'Raise Skeleton', cls: 'necromancer', lvl: 1, kind: 'summon', cost: 14, cd: 7, target: 'self', summon: 'skeleton' },
  withering_touch: { desc: '50% Shadow damage and Blight (Shadow damage over time) for 4 actions, stacking 3 times.', name: 'Withering Touch', cls: 'necromancer', lvl: 3, kind: 'spell', element: 'shadow', coef: 0.5, cost: 8, cd: 1, target: 'enemy',
                     effects: [{ type: 'blight', chance: 100, turns: 4, powerCoef: 0.15, maxStacks: 3 }] },
  bone_armor:      { desc: 'Wrap yourself in bone: a shield worth 15% of your max HP.', name: 'Bone Armor', cls: 'necromancer', lvl: 6, kind: 'buff', cost: 12, cd: 6, target: 'self',
                     effects: [{ type: 'shield', shieldPct: 15 }] },
  death_coil:      { desc: '130% Shadow damage; heal for 25% of the damage dealt.', name: 'Death Coil', cls: 'necromancer', lvl: 9, kind: 'spell', element: 'shadow', coef: 1.3, drain: 0.25, cost: 12, cd: 3, target: 'enemy' },
  terrify:         { desc: '40% Shadow damage, a 60% chance to Stun for 1 action, and Weaken for 2 actions (20% less damage).', name: 'Terrify', cls: 'necromancer', lvl: 12, kind: 'spell', element: 'shadow', coef: 0.4, cost: 14, cd: 5, target: 'enemy',
                     effects: [{ type: 'stun', chance: 60, turns: 1 }, { type: 'weakened', chance: 100, turns: 2 }] },
  corpse_explosion: { desc: '90% Shadow damage to every enemy, +50% against Blighted foes.', name: 'Corpse Explosion', cls: 'necromancer', lvl: 15, kind: 'spell', element: 'shadow', coef: 0.9, cost: 16, cd: 4, target: 'all-enemies',
                     bonusVsStatus: { statuses: ['blight'], mult: 1.5 } },
  decrepify:       { desc: '30% Shadow damage to every enemy and Weaken them all for 2 actions.', name: 'Decrepify', cls: 'necromancer', lvl: 18, kind: 'spell', element: 'shadow', coef: 0.3, cost: 12, cd: 5, target: 'all-enemies',
                     effects: [{ type: 'weakened', chance: 100, turns: 2 }] },
  lich_form:       { desc: 'Become a lich for your next 3 actions: +25% damage and +30% magic resist.', name: 'Lich Form', cls: 'necromancer', lvl: 24, kind: 'buff', cost: 14, cd: 7, target: 'self',
                     effects: [{ type: 'empower', turns: 4 }, { type: 'wardUp', turns: 4 }] },
  necrotic_lance:  { desc: '170% Shadow damage, +30% against a Weakened or Blighted target.', name: 'Necrotic Lance', cls: 'necromancer', lvl: 28, kind: 'spell', element: 'shadow', coef: 1.7, cost: 18, cd: 4, target: 'enemy',
                     bonusVsStatus: { statuses: ['weakened', 'blight'], mult: 1.3 } },
  raise_bone_golem: { desc: 'Raise a bone golem for 6 actions: a slow, tough minion that taunts foes off you. One minion at a time.', name: 'Raise Bone Golem', cls: 'necromancer', lvl: 32, kind: 'summon', cost: 20, cd: 8, target: 'self', summon: 'bone_golem' },
  soul_siphon:     { desc: '60% Shadow damage to every enemy; heal for 30% of the damage dealt.', name: 'Soul Siphon', cls: 'necromancer', lvl: 36, kind: 'spell', element: 'shadow', coef: 0.6, drain: 0.3, cost: 18, cd: 6, target: 'all-enemies' },
  army_of_the_dead: { desc: 'Ultimate. 140% Shadow damage to every enemy, and a skeleton rises to fight for you (if no minion is up).', name: 'Army of the Dead', cls: 'necromancer', lvl: 1, ultimate: true, kind: 'spell', element: 'shadow', coef: 1.4, cost: 0, cd: 0, target: 'all-enemies', alsoSummon: 'skeleton' },

  // Bard (Season 1.5): songs that lift the whole party, and sharp notes that hurt. Song power comes from Presence
  // (3 per point) plus spell power from the lute; healing songs use healing power (Spirit). Damaging songs are sung in
  // the element of the bard's armour (like Arcane Bolt), so elemental armour and damage bonuses count.
  cutting_chord:   { desc: 'Basic attack. 125% song damage in your armour\'s element.', name: 'Cutting Chord', cls: 'bard', lvl: 1, kind: 'spell', power: 'song', element: 'affinity', coef: 1.25, cost: 0, cd: 0, target: 'enemy', basic: true },
  ballad_of_valor: { desc: 'You and every ally: +25% damage for 2 actions.', name: 'Ballad of Valor', cls: 'bard', lvl: 1, kind: 'buff', cost: 12, cd: 5, target: 'all-allies',
                     effects: [{ type: 'empower', turns: 3 }] },
  song_of_rest:    { desc: 'Heal you and every ally for 45% of your healing power, then Regrowth for 2 actions.', name: 'Song of Rest', cls: 'bard', lvl: 3, kind: 'heal', coef: 0.45, cost: 14, cd: 4, target: 'all-allies',
                     effects: [{ type: 'regrow', turns: 3, powerCoef: 0.2 }] },
  dissonance:      { desc: '80% song damage in your armour\'s element and a 60% chance to Silence for 1 action.', name: 'Dissonance', cls: 'bard', lvl: 6, kind: 'spell', power: 'song', element: 'affinity', coef: 0.8, cost: 8, cd: 3, target: 'enemy',
                     effects: [{ type: 'silence', chance: 60, turns: 1 }] },
  lullaby:         { desc: 'Sing a foe to sleep: an 80% chance to Stun it for 1 action. No damage.', name: 'Lullaby', cls: 'bard', lvl: 9, kind: 'spell', power: 'song', noDamage: true, cost: 12, cd: 5, target: 'enemy',
                     effects: [{ type: 'stun', chance: 80, turns: 1 }] },
  hymn_of_haste:   { desc: 'You and every ally: Haste for 2 actions (act sooner).', name: 'Hymn of Haste', cls: 'bard', lvl: 12, kind: 'buff', cost: 12, cd: 5, target: 'all-allies',
                     effects: [{ type: 'haste', turns: 3 }] },
  discordant_note: { desc: '60% song damage in your armour\'s element to every enemy, 50% chance each to Weaken for 2 actions.', name: 'Discordant Note', cls: 'bard', lvl: 15, kind: 'spell', power: 'song', element: 'affinity', coef: 0.6, cost: 14, cd: 4, target: 'all-enemies',
                     effects: [{ type: 'weakened', chance: 50, turns: 2 }] },
  anthem_of_warding: { desc: 'You and every ally: a shield worth 12% of max HP.', name: 'Anthem of Warding', cls: 'bard', lvl: 18, kind: 'buff', cost: 16, cd: 6, target: 'all-allies',
                     effects: [{ type: 'shield', shieldPct: 12 }] },
  mocking_verse:   { desc: '130% song damage in your armour\'s element and Mark the target for 3 actions (it takes 20% more damage).', name: 'Mocking Verse', cls: 'bard', lvl: 24, kind: 'spell', power: 'song', element: 'affinity', coef: 1.3, cost: 10, cd: 3, target: 'enemy',
                     effects: [{ type: 'marked', chance: 100, turns: 3 }] },
  encore:          { desc: 'Play it again: every other cooldown is 2 actions shorter, and regain 15% of your mana.', name: 'Encore', cls: 'bard', lvl: 28, kind: 'buff', cost: 0, cd: 7, target: 'self', cutCooldowns: 2, manaPct: 15 },
  requiem:         { desc: '190% song damage in your armour\'s element and a 30% chance to Silence for 1 action.', name: 'Requiem', cls: 'bard', lvl: 32, kind: 'spell', power: 'song', element: 'affinity', coef: 1.9, cost: 18, cd: 4, target: 'enemy',
                     effects: [{ type: 'silence', chance: 30, turns: 1 }] },
  second_verse:    { desc: 'Bring a knocked-out ally back with 35% of their max HP.', name: 'Second Verse', cls: 'bard', lvl: 36, kind: 'heal', revive: 35, coef: 0, cost: 20, cd: 8, target: 'ally-down' },
  grand_finale:    { desc: 'Ultimate. 160% song damage in your armour\'s element to every enemy; you and every ally heal 10% of max HP and gain +25% damage for 2 actions.', name: 'Grand Finale', cls: 'bard', lvl: 1, ultimate: true, kind: 'spell', power: 'song', element: 'affinity', coef: 1.6, cost: 0, cd: 0, target: 'all-enemies',
                     allyHealPct: 10, allyEffects: [{ type: 'empower', turns: 3 }] },
  // Universal duel moves (every Agent has them, outside the loadout)
  guard:           { desc: 'Guard: take 50% less damage until your next action, and gain 15 ultimate charge.', name: 'Guard', universal: true, kind: 'buff', cost: 0, cd: 2, target: 'self',
                     chargeGain: 15, effects: [{ type: 'guard', turns: 2 }] },
  focus:           { desc: 'Focus: your next attack deals +60% and is a guaranteed critical hit.', name: 'Focus', universal: true, kind: 'buff', cost: 0, cd: 3, target: 'self',
                     effects: [{ type: 'focus', turns: 4 }] },
  // Warblade
  riposte:         { desc: 'Riposte: until your next action, physical hits on you deal 50% less and 80% of the damage is struck back.', name: 'Riposte', cls: 'warblade', lvl: 12, kind: 'buff', cost: 10, cd: 4, target: 'self',
                     effects: [{ type: 'counter', turns: 2 }] },
  sunder:          { desc: '90% physical damage and Sunder for 3 actions: the target\'s armour is 25% lower, its thorns are splintered (they do nothing) and it is Wounded: all healing it receives is halved.', name: 'Sunder', cls: 'warblade', lvl: 24, kind: 'phys', coef: 0.9, cost: 12, cd: 3, target: 'enemy',
                     effects: [{ type: 'sunder', chance: 100, turns: 3 }, { type: 'splinter', chance: 100, turns: 3 }, { type: 'wounded', chance: 100, turns: 3 }] },
  war_cry:         { desc: '+25% damage for 2 actions and +25 ultimate charge.', name: 'War Cry', cls: 'warblade', lvl: 32, kind: 'buff', cost: 15, cd: 6, target: 'self', chargeGain: 25,
                     effects: [{ type: 'empower', turns: 3 }] },
  // Shadowstep
  vanish:          { desc: 'Vanish into the shadows: Stealth until your next attack (single-target attacks miss you, and Ambush and Cheap Shot are open again), and that attack deals +60% and is a guaranteed crit.', name: 'Vanish', cls: 'shadowstep', lvl: 12, kind: 'buff', cost: 12, cd: 5, target: 'self',
                     effects: [{ type: 'stealth', turns: 3 }, { type: 'focus', turns: 4 }] },
  cheap_shot:      { desc: 'From Stealth or as your opener: 40% finesse damage and Stun for 1 action, guaranteed.', name: 'Cheap Shot', cls: 'shadowstep', lvl: 6, kind: 'phys', power: 'finesse', coef: 0.4, firstActionOnly: true, cost: 8, cd: 2, target: 'enemy',
                     effects: [{ type: 'stun', chance: 100, turns: 1 }] },
  poisoned_blades: { desc: 'Coat your blades: for your next 4 actions each of your physical hits has a 50% chance to Poison (Nature damage over 3 actions, stacking 3 times).', name: 'Poisoned Blades', cls: 'shadowstep', lvl: 15, kind: 'buff', cost: 10, cd: 6, target: 'self',
                     effects: [{ type: 'poisonBlades', turns: 5 }] },
  backstab:        { desc: '130% finesse damage, doubled against a target that is Stunned, Chilled, Frozen or Polymorphed.', name: 'Backstab', cls: 'shadowstep', lvl: 20, kind: 'phys', power: 'finesse', coef: 1.3, cost: 12, cd: 2, target: 'enemy',
                     bonusVsStatus: { statuses: ['stun', 'chill', 'frozen', 'poly'], mult: 2 } },
  smoke_bomb:      { desc: 'Vanish in smoke: +25% dodge for 2 actions, and until your next action you take 35% less damage from everything.', name: 'Smoke Bomb', cls: 'shadowstep', lvl: 28, kind: 'buff', cost: 10, cd: 6, target: 'self',
                     effects: [{ type: 'evasive', turns: 3 }, { type: 'wall', turns: 2 }] },
  shadow_dance:    { desc: 'Three quick strikes of 75% Shadow finesse damage.', name: 'Shadow Dance', cls: 'shadowstep', lvl: 40, kind: 'phys', power: 'finesse', element: 'shadow', coef: 0.75, hits: 3, cost: 18, cd: 4, target: 'enemy' },
  envenom:         { desc: '70% finesse damage and a deep Bleed that stacks up to 4 times.', name: 'Envenom', cls: 'shadowstep', lvl: 24, kind: 'phys', power: 'finesse', coef: 0.7, cost: 10, cd: 2, target: 'enemy',
                     effects: [{ type: 'bleed', chance: 100, turns: 4, powerCoef: 0.2, maxStacks: 4 }] },
  feint:           { desc: '80% finesse damage. Against a target that is guarding, countering or shielded it deals double and strips the guard. Splinters thorns for 3 actions.', name: 'Feint', cls: 'shadowstep', lvl: 32, kind: 'phys', power: 'finesse', coef: 0.8, cost: 10, cd: 2, target: 'enemy', breaksGuard: true,
                     effects: [{ type: 'splinter', chance: 100, turns: 3 }] },
  // Arcanist
  counterspell:    { desc: '50% spell damage and Silence for 2 actions (no spells).', name: 'Counterspell', cls: 'arcanist', lvl: 12, kind: 'spell', element: 'storm', coef: 0.5, cost: 12, cd: 4, target: 'enemy',
                     effects: [{ type: 'silence', chance: 100, turns: 2 }] },
  mana_surge:      { desc: 'Restore 40% of your mana; your next attack deals +60% and is a guaranteed crit.', name: 'Mana Surge', cls: 'arcanist', lvl: 24, kind: 'buff', cost: 0, cd: 6, target: 'self', manaPct: 40,
                     effects: [{ type: 'focus', turns: 4 }] },
  arcane_overload: { desc: '240% spell damage in your armour\'s element. Costs 12% of your own max HP.', name: 'Arcane Overload', cls: 'arcanist', lvl: 32, kind: 'spell', element: 'affinity', coef: 2.4, cost: 30, cd: 5, target: 'enemy', selfHpCostPct: 12 },
  // Warden
  thornguard:      { desc: 'For 3 actions you take 15% less damage, and physical attackers take 30% of their damage back.', name: 'Thornguard', cls: 'warden', lvl: 12, kind: 'buff', cost: 12, cd: 6, target: 'self',
                     effects: [{ type: 'thornguard', turns: 4 }] },
  natures_wrath:   { desc: '100% Nature damage, +50% against a target suffering Bleed, Burn, Chill or Sunder.', name: "Nature's Wrath", cls: 'warden', lvl: 24, kind: 'spell', power: 'spirit', element: 'nature', coef: 1.0, cost: 14, cd: 3, target: 'enemy',
                     bonusVsStatus: { statuses: ['bleed', 'burn', 'chill', 'sunder'], mult: 1.5 } },
  moonfire:        { desc: '70% Nature damage and Moonfire: Nature damage at each of the target\'s next 4 actions.', name: 'Moonfire', cls: 'warden', lvl: 3, kind: 'spell', power: 'spirit', element: 'nature', coef: 0.7, cost: 8, cd: 1, target: 'enemy',
                     effects: [{ type: 'moonfire', chance: 100, turns: 4, powerCoef: 0.25 }] },
  barkskin:        { desc: 'Your skin turns to bark: for your next 2 actions you take 25% less damage from everything. Not a spell, so Silence cannot stop it.', name: 'Barkskin', cls: 'warden', lvl: 6, kind: 'buff', cost: 8, cd: 5, target: 'self',
                     effects: [{ type: 'bark', turns: 3 }] },
  entangling_roots: { desc: '50% Nature damage; roots grip the target: Chill (slower) for 2 actions and Nature damage at each of its next 3 actions.', name: 'Entangling Roots', cls: 'warden', lvl: 10, kind: 'spell', power: 'spirit', element: 'nature', coef: 0.5, cost: 12, cd: 3, target: 'enemy',
                     effects: [{ type: 'chill', chance: 100, turns: 2 }, { type: 'entangle', chance: 100, turns: 3, powerCoef: 0.2 }] },
  starfall:        { desc: '110% Nature damage to every enemy as stars rain down.', name: 'Starfall', cls: 'warden', lvl: 36, kind: 'spell', power: 'spirit', element: 'nature', coef: 1.1, cost: 24, cd: 5, target: 'all-enemies' },
  wild_growth:     { desc: 'Heal every ally for 25% of healing power now and 20% at each of their next 3 actions.', name: 'Wild Growth', cls: 'warden', lvl: 18, kind: 'heal', coef: 0.25, cost: 22, cd: 4, target: 'all-allies',
                     effects: [{ type: 'regrow', turns: 3, powerCoef: 0.2 }] },
  rebirth:         { desc: 'Once per battle, bring a knocked-out ally back with 35% of their HP.', name: 'Rebirth', cls: 'warden', lvl: 28, kind: 'heal', revive: 35, coef: 0, cost: 30, cd: 99, target: 'ally-down' },
  ironbark:        { desc: 'Wrap the most hurt ally (or yourself) in bark: a shield worth 20% of their max HP.', name: 'Ironbark', cls: 'warden', lvl: 40, kind: 'buff', cost: 16, cd: 5, target: 'ally-lowest',
                     effects: [{ type: 'shield', shieldPct: 20 }] },
  renewal:         { desc: 'Cleanse the most hurt ally and heal them 15% of their max HP now, plus Regrowth for 3 actions.', name: 'Renewal', cls: 'warden', lvl: 32, kind: 'heal', coef: 0, healPctMax: 15, cost: 18, cd: 6, target: 'ally-lowest', cleanse: true,
                     effects: [{ type: 'regrow', turns: 3, powerCoef: 0.25 }] },
  hexmothers_brew: { desc: 'Item ability. Heal 35% of your max HP, gain +30% armour for 3 actions and shake off every ailment.', name: "Hexmother's Brew", item: true, kind: 'heal', coef: 0, healPctMax: 35,
                     cost: 10, cd: 5, target: 'self', cleanseSelf: true, effects: [{ type: 'armorUp', turns: 3 }] },
  // Heirloom weapons (stage two): each class's evolved weapon brings one of these.
  hexmothers_cauldron: { desc: 'Item ability. 45% Shadow damage to every enemy and Siphon Life on each for 4 actions: every tick hurts them and heals you for half of it.', name: "Hexmother's Cauldron", item: true, kind: 'spell', element: 'shadow', coef: 0.45, cost: 18, cd: 5, target: 'all-enemies',
                     effects: [{ type: 'siphon', chance: 100, turns: 4, powerCoef: 0.25 }] },
  moonless_step:   { desc: 'Item ability. 140% Shadow finesse damage. If it knocks the target out, you slip back into Stealth and your next attack deals +60% and is a guaranteed crit.', name: 'Moonless Step', item: true, kind: 'phys', power: 'finesse', element: 'shadow', coef: 1.4, cost: 12, cd: 4, target: 'enemy',
                     onKill: [{ type: 'stealth', turns: 3 }, { type: 'focus', turns: 4 }] },
  unyielding:      { desc: 'Item ability. Once per battle: heal 20% of your max HP, enemies must target you for 2 actions, you gain +30% armour, and the next blow that would knock you out this battle leaves you on 1 HP instead.', name: 'Unyielding', item: true, kind: 'buff', healPctMax: 20, cost: 12, cd: 99, target: 'self',
                     effects: [{ type: 'taunt', turns: 2 }, { type: 'armorUp', turns: 2 }, { type: 'deathward', turns: 99 }] },
  wyvern_volley:   { desc: 'Item ability. 120% Frost finesse damage that passes through to a second enemy at full strength, 60% chance each to Chill; your companion joins in for 60% of its own power.', name: 'Wyvern Volley', item: true, kind: 'phys', power: 'finesse', element: 'frost', coef: 1.2, splash: 1.0, petStrike: 0.6, cost: 14, cd: 3, target: 'enemy',
                     effects: [{ type: 'chill', chance: 60, turns: 2 }] },
  rewrite:         { desc: 'Item ability. 200% Storm spell damage, then every other cooldown is ready again and you restore 20% of your mana.', name: 'Rewrite', item: true, kind: 'spell', element: 'storm', coef: 2.0, cost: 14, cd: 4, target: 'enemy', cutCooldowns: 99, manaPct: 20 },
  grove_of_rebirth: { desc: 'Item ability. Heal every ally for 35% of healing power and Regrowth for 3 actions. Once per battle it also brings a knocked-out ally back with 30% of their HP.', name: 'Grove of Rebirth', item: true, kind: 'heal', coef: 0.35, cost: 24, cd: 6, target: 'all-allies', reviveOnce: 30,
                     effects: [{ type: 'regrow', turns: 3, powerCoef: 0.2 }] },
  granted_wish:    { desc: 'Item ability. Shake off every ailment, gain Haste for 3 actions and a shield worth 15% of your max HP.', name: 'Granted Wish', item: true, kind: 'buff', cost: 12, cd: 7, target: 'self',
                     cleanseSelf: true, effects: [{ type: 'haste', turns: 3 }, { type: 'shield', shieldPct: 15 }] },
  thaw_tide:       { desc: 'Item ability. 100% spell damage of your armour affinity to every enemy, 50% chance each to Chill.', name: 'Thaw Tide', item: true, kind: 'spell', element: 'affinity', coef: 1.0, cost: 16, cd: 4, target: 'all-enemies',
                     effects: [{ type: 'chill', chance: 50, turns: 2 }] },
  moonlit_bound:   { desc: 'Item ability. Gain Haste and Evasive (+25% dodge) for 2 actions.', name: 'Moonlit Bound', item: true, kind: 'buff', cost: 8, cd: 5, target: 'self',
                     effects: [{ type: 'haste', turns: 2 }, { type: 'evasive', turns: 2 }] },
  lid_slam:        { desc: 'Item ability. 100% physical damage with a 50% chance to Stun for 1 action.', name: 'Lid Slam', item: true, kind: 'phys', coef: 1.0, cost: 10, cd: 4, target: 'enemy',
                     effects: [{ type: 'stun', chance: 50, turns: 1 }] },
  glacial_aegis:   { desc: 'Item ability. 70% Frost spell damage to every enemy, 60% chance each to Chill (slower) for 2 actions.', name: 'Glacial Aegis', item: true, kind: 'spell', element: 'frost', coef: 0.7, cost: 14, cd: 5, target: 'all-enemies',
                     effects: [{ type: 'chill', chance: 60, turns: 2 }] },
  sultans_ward:    { desc: 'Item ability. Gain a shield worth 20% of your max HP.', name: "Sultan's Ward", item: true, kind: 'buff', cost: 12, cd: 6, target: 'self',
                     effects: [{ type: 'shield', shieldPct: 20 }] },
  second_wind:     { desc: 'Item ability. Once per battle, heal 30% of your max HP.', name: 'Second Wind', item: true, kind: 'heal', coef: 0, healPctMax: 30, cost: 0, cd: 99, target: 'self' },

  // Hidden abilities (found through the Codex: usage feats, rare drops, secret quests)
  refactor:        { desc: "Hidden. Steal an enemy's best buff for yourself. With nothing to steal, deal 80% physical damage.", name: 'Refactor', hidden: true,
                     kind: 'steal', coef: 0.8, cost: 10, cd: 4, target: 'enemy' },
  hallucination:   { desc: 'Hidden. Conjure a decoy: the next 2 attacks against you hit it instead.', name: 'Hallucination', hidden: true,
                     kind: 'buff', cost: 12, cd: 6, target: 'self', effects: [{ type: 'decoy', stacks: 2, turns: 6 }] },
  ship_it:         { desc: 'Hidden ultimate. 150% physical damage plus half your missing HP to every enemy, then cleanse yourself.', name: 'Ship It', hidden: true,
                     ultimate: true, kind: 'phys', coef: 1.5, missingHpPct: 50, cost: 0, cd: 0, target: 'all-enemies', cleanseSelf: true },

  // Mobs
  stab:            { name: 'Stab', kind: 'phys', coef: 1.0, cost: 0, cd: 0, target: 'enemy', basic: true },
  bite:            { name: 'Bite', kind: 'phys', power: 'finesse', coef: 1.0, cost: 0, cd: 0, target: 'enemy', basic: true,
                     effects: [{ type: 'bleed', chance: 20, turns: 3, powerCoef: 0.1, maxStacks: 2 }] },
  hex_bolt:        { name: 'Hex Bolt', kind: 'spell', element: 'shadow', coef: 1.0, cost: 0, cd: 0, target: 'enemy', basic: true },
  shaman_mend:     { name: 'Mend', kind: 'heal', coef: 1.0, cost: 10, cd: 3, target: 'ally-lowest' },
  slam:            { name: 'Slam', kind: 'phys', coef: 1.3, cost: 0, cd: 0, target: 'enemy', basic: true,
                     effects: [{ type: 'stun', chance: 20, turns: 1 }] },
  ladle_smash:     { name: 'Ladle Smash', kind: 'phys', coef: 1.4, cost: 0, cd: 0, target: 'enemy', basic: true },
  stew:            { name: 'Stew of Fortitude', kind: 'heal', coef: 0, healPctMax: 25, cost: 0, cd: 4, target: 'self',
                     effects: [{ type: 'armorUp', turns: 2 }] },
  maul:            { name: 'Maul', kind: 'phys', coef: 1.0, cost: 0, cd: 0, target: 'enemy', basic: true },

  // Ashen Barrens mobs
  cutthroat:       { name: 'Cutthroat', kind: 'phys', power: 'finesse', coef: 1.0, cost: 0, cd: 0, target: 'enemy', basic: true },
  venom_sting:     { name: 'Venom Sting', kind: 'phys', coef: 1.0, cost: 0, cd: 0, target: 'enemy', basic: true,
                     effects: [{ type: 'bleed', chance: 25, turns: 3, powerCoef: 0.1, maxStacks: 2 }] },
  scorch:          { name: 'Scorch', kind: 'spell', element: 'fire', coef: 1.0, cost: 0, cd: 0, target: 'enemy', basic: true,
                     effects: [{ type: 'burn', chance: 25, turns: 3, powerCoef: 0.1 }] },
  wail:            { name: 'Wail', kind: 'spell', element: 'shadow', coef: 0.4, cost: 12, cd: 4, target: 'all-enemies',
                     effects: [{ type: 'silence', chance: 20, turns: 1 }] },
  brass_fist:      { name: 'Brass Fist', kind: 'phys', coef: 1.2, cost: 0, cd: 0, target: 'enemy', basic: true,
                     effects: [{ type: 'stun', chance: 15, turns: 1 }] },
  mirage_bolt:     { name: 'Mirage Bolt', kind: 'spell', element: 'storm', coef: 1.2, cost: 0, cd: 0, target: 'enemy', basic: true },
  djinn_shimmer:   { name: 'Shimmer', kind: 'buff', cost: 8, cd: 5, target: 'self', effects: [{ type: 'evasive', turns: 2 }] },
  scimitar_sweep:  { name: 'Scimitar Sweep', kind: 'phys', coef: 1.3, splash: 0.5, cost: 0, cd: 0, target: 'enemy', basic: true },
  sandstorm:       { name: 'Sandstorm', kind: 'spell', element: 'fire', coef: 0.8, cost: 0, cd: 3, target: 'all-enemies',
                     effects: [{ type: 'burn', chance: 40, turns: 3, powerCoef: 0.08 }] },
  gilded_ward:     { name: 'Gilded Ward', kind: 'buff', cost: 0, cd: 5, target: 'self', effects: [{ type: 'shield', shieldPct: 12 }] },
  // Whispering Archive
  ink_lash:        { name: 'Ink Lash', kind: 'spell', element: 'shadow', coef: 0.95, cost: 0, cd: 0, target: 'enemy', basic: true },
  blot_out:        { name: 'Blot Out', kind: 'spell', element: 'shadow', coef: 0.5, cost: 10, cd: 4, target: 'enemy', effects: [{ type: 'silence', chance: 45, turns: 1 }] },
  tome_slam:       { name: 'Tome Slam', kind: 'phys', coef: 1.2, cost: 0, cd: 0, target: 'enemy', basic: true, effects: [{ type: 'stun', chance: 15, turns: 1 }] },
  bind:            { name: 'Bind', kind: 'buff', cost: 0, cd: 5, target: 'self', effects: [{ type: 'armorUp', turns: 2 }] },
  searing_light:   { name: 'Searing Light', kind: 'spell', element: 'radiant', coef: 0.9, cost: 0, cd: 0, target: 'enemy', basic: true, effects: [{ type: 'burn', chance: 20, turns: 3, powerCoef: 0.1 }] },
  flicker:         { name: 'Flicker', kind: 'buff', cost: 6, cd: 4, target: 'self', effects: [{ type: 'evasive', turns: 2 }] },
  censure:         { name: 'Censure', kind: 'phys', element: 'radiant', coef: 1.1, splash: 0.4, cost: 0, cd: 0, target: 'enemy', basic: true },
  paper_cut:       { name: 'Paper Cut', kind: 'phys', power: 'finesse', coef: 0.9, cost: 0, cd: 0, target: 'enemy', basic: true, effects: [{ type: 'bleed', chance: 35, turns: 3, powerCoef: 0.1, maxStacks: 3 }] },
  redact:          { name: 'Redact', kind: 'spell', element: 'shadow', coef: 0.9, cost: 0, cd: 4, target: 'enemy', effects: [{ type: 'silence', chance: 100, turns: 2 }] },
  forbidden_word:  { name: 'The Forbidden Word', kind: 'spell', element: 'shadow', coef: 0.8, cost: 0, cd: 4, target: 'all-enemies', effects: [{ type: 'stun', chance: 25, turns: 1 }] },
  index_ward:      { name: 'Index Ward', kind: 'buff', cost: 0, cd: 6, target: 'self', effects: [{ type: 'shield', shieldPct: 13 }] },
  // Thundercrag Spire
  thunderclap:     { name: 'Thunderclap', kind: 'phys', element: 'storm', coef: 1.1, cost: 0, cd: 0, target: 'enemy', basic: true, effects: [{ type: 'stun', chance: 15, turns: 1 }] },
  zap:             { name: 'Zap', kind: 'spell', element: 'storm', coefs: [0.8, 0.5], cost: 0, cd: 0, target: 'chain', basic: true },
  discharge:       { name: 'Discharge', kind: 'spell', element: 'storm', coef: 0.7, cost: 0, cd: 3, target: 'all-enemies' },
  static_touch:    { name: 'Static Touch', kind: 'spell', element: 'storm', coef: 0.9, cost: 0, cd: 0, target: 'enemy', basic: true },
  skyspear:        { name: 'Skyspear', kind: 'phys', coef: 1.15, cost: 0, cd: 0, target: 'enemy', basic: true },
  roc_dive:        { name: 'Roc Dive', kind: 'phys', element: 'storm', coef: 1.3, cost: 0, cd: 0, target: 'enemy', basic: true },
  gale:            { name: 'Gale', kind: 'spell', element: 'storm', coef: 0.6, cost: 0, cd: 4, target: 'all-enemies', effects: [{ type: 'chill', chance: 40, turns: 2 }] },
  wyrm_breath:     { name: 'Storm Breath', kind: 'spell', element: 'storm', coef: 0.9, cost: 0, cd: 3, target: 'all-enemies', effects: [{ type: 'stun', chance: 20, turns: 1 }] },
  wyrm_rend:       { name: 'Rend', kind: 'phys', coef: 1.35, cost: 0, cd: 0, target: 'enemy', basic: true },
  wyrm_scales:     { name: 'Scales of the Storm', kind: 'buff', cost: 0, cd: 6, target: 'self', effects: [{ type: 'shield', shieldPct: 12 }, { type: 'armorUp', turns: 2 }] },
  // Season 1 hidden ultimate and chase item abilities
  token_storm:     { desc: 'Hidden ultimate. 200% Storm spell damage to every enemy, 40% chance each to Stun.', name: 'Token Storm', hidden: true, ultimate: true, kind: 'spell', element: 'storm', coef: 2.0, cost: 0, cd: 0, target: 'all-enemies',
                     effects: [{ type: 'stun', chance: 40, turns: 1 }] },
  annotate:        { desc: 'Item ability. Cut every other cooldown by 2 and Focus: your next attack deals +60% and is a guaranteed crit.', name: 'Annotate', item: true, kind: 'buff', cost: 10, cd: 6, target: 'self', cutCooldowns: 2,
                     effects: [{ type: 'focus', turns: 4 }] },
  lightning_rod:   { desc: 'Item ability. A shield worth 18% of your max HP, and Thornguard for 3 actions.', name: 'Lightning Rod', item: true, kind: 'buff', cost: 12, cd: 6, target: 'self',
                     effects: [{ type: 'shield', shieldPct: 18 }, { type: 'thornguard', turns: 4 }] },
  // Secret bosses
  hex_lash:        { name: 'Hex Lash', kind: 'spell', element: 'shadow', coef: 1.15, cost: 0, cd: 0, target: 'enemy', basic: true,
                     effects: [{ type: 'bleed', chance: 25, turns: 3, powerCoef: 0.1, maxStacks: 2 }] },
  wither:          { name: 'Wither', kind: 'spell', element: 'shadow', coef: 0.7, cost: 0, cd: 4, target: 'all-enemies', effects: [{ type: 'silence', chance: 35, turns: 1 }] },
  bone_ward:       { name: 'Bone Ward', kind: 'buff', cost: 0, cd: 6, target: 'self', effects: [{ type: 'shield', shieldPct: 14 }] },
  antler_charge:   { name: 'Antler Charge', kind: 'phys', power: 'finesse', coef: 1.15, cost: 0, cd: 0, target: 'enemy', basic: true },
  moonlight:       { name: 'Moonlight', kind: 'heal', coef: 0, healPctMax: 15, cost: 0, cd: 5, target: 'self', effects: [{ type: 'evasive', turns: 2 }] },
  scald:           { name: 'Scald', kind: 'spell', element: 'fire', coef: 1.1, splash: 0.4, cost: 0, cd: 0, target: 'enemy', basic: true,
                     effects: [{ type: 'burn', chance: 30, turns: 3, powerCoef: 0.1 }] },
  bubble_up:       { name: 'Bubble Up', kind: 'heal', coef: 0, healPctMax: 10, cost: 0, cd: 4, target: 'self', effects: [{ type: 'armorUp', turns: 2 }] },
  // Frostfang Peaks
  frost_fang:      { name: 'Frost Fang', kind: 'phys', power: 'finesse', coef: 1.0, cost: 0, cd: 0, target: 'enemy', basic: true,
                     effects: [{ type: 'chill', chance: 25, turns: 2 }] },
  troll_smash:     { name: 'Troll Smash', kind: 'phys', coef: 1.15, cost: 0, cd: 0, target: 'enemy', basic: true },
  troll_hide:      { name: 'Troll Hide', kind: 'heal', coef: 0, healPctMax: 15, cost: 0, cd: 5, target: 'self', effects: [{ type: 'armorUp', turns: 2 }] },
  ice_shard:       { name: 'Ice Shard', kind: 'spell', element: 'frost', coef: 1.0, cost: 0, cd: 0, target: 'enemy', basic: true,
                     effects: [{ type: 'chill', chance: 30, turns: 2 }] },
  deep_freeze:     { name: 'Deep Freeze', kind: 'spell', element: 'frost', coef: 0.6, cost: 12, cd: 5, target: 'enemy',
                     effects: [{ type: 'stun', chance: 25, turns: 1 }] },
  grave_cleave:    { name: 'Grave Cleave', kind: 'phys', coef: 1.1, splash: 0.4, cost: 0, cd: 0, target: 'enemy', basic: true },
  talon_rake:      { name: 'Talon Rake', kind: 'phys', power: 'finesse', coef: 0.9, cost: 0, cd: 0, target: 'enemy', basic: true,
                     effects: [{ type: 'bleed', chance: 30, turns: 3, powerCoef: 0.1, maxStacks: 2 }] },
  wyvern_bite:     { name: 'Wyvern Bite', kind: 'phys', coef: 1.25, cost: 0, cd: 0, target: 'enemy', basic: true },
  frost_breath:    { name: 'Frost Breath', kind: 'spell', element: 'frost', coef: 0.7, cost: 0, cd: 4, target: 'all-enemies',
                     effects: [{ type: 'chill', chance: 50, turns: 2 }] },
  rime_lance:      { name: 'Rime Lance', kind: 'spell', element: 'frost', coef: 1.3, cost: 0, cd: 0, target: 'enemy', basic: true,
                     effects: [{ type: 'chill', chance: 30, turns: 2 }] },
  whiteout:        { name: 'Whiteout', kind: 'spell', element: 'frost', coef: 0.75, cost: 0, cd: 3, target: 'all-enemies',
                     effects: [{ type: 'chill', chance: 50, turns: 2 }] },
  ice_mirror:      { name: 'Ice Mirror', kind: 'buff', cost: 0, cd: 6, target: 'self', effects: [{ type: 'shield', shieldPct: 12 }] },
};

// Hidden passives can replace the class passive.
export const HIDDEN_PASSIVES = {
  echo_first_prompt: { id: 'echo_first_prompt', name: 'Echo of the First Prompt', desc: 'Hidden. The first ability you use each battle casts twice (the echo is free).' },
  context_window: { id: 'context_window', name: 'Context Window', desc: 'Hidden. You remember everything: your first three abilities each battle cost no mana.' },
  nemesis_brand: { id: 'nemesis_brand', name: 'Nemesis Brand', desc: 'Hidden. Your first damaging hit each battle is a guaranteed critical hit, and you take 10% less damage from Agents in the Arena.' },
};
export const HIDDEN_KEYS = ['echo_first_prompt', 'ship_it', 'refactor', 'hallucination', 'nemesis_brand', 'context_window', 'token_storm'];

export const PASSIVES = {
  warblade: { id: 'unbreakable', name: 'Unbreakable', desc: '+15% max HP and +40% magic resist, and +1% damage for every 4% of HP missing, up to +25%.' },
  shadowstep: { id: 'opportunist', name: 'Opportunist', desc: '+15% damage against bleeding targets.' },
  arcanist: { id: 'mana_font', name: 'Mana Font', desc: '+3 mana regen per action and +10% crit chance.' },
  warden: { id: 'verdant', name: 'Verdant', desc: '+15% healing done and +10 status resist.' },
  ranger: { id: 'eagle_eye', name: 'Eagle Eye', desc: '+8% crit chance and +12% max HP.' },
  hexer: { id: 'grim_harvest', name: 'Grim Harvest', desc: '+15% max HP, and +12% damage against targets below half HP.' },
  deathknight: { id: 'runebound', name: 'Runebound', desc: '+15% max HP and +30% magic resist, and your rune strikes deal 25% more.' },
  necromancer: { id: 'soul_harvest', name: 'Soul Harvest', desc: '+10% max HP; whenever a foe falls, heal 8% of your max HP and gain 15 ultimate charge.' },
  bard: { id: 'virtuoso', name: 'Virtuoso', desc: '+15% max HP and +10 status resist, and +15% damage while Valor or Haste is on you.' },
};

const SPELLISH = new Set(['spell', 'heal', 'summon']);
const BUFFS = ['imbue', 'shield', 'armorUp', 'evasive', 'haste', 'regrow', 'decoy', 'guard', 'counter', 'empower', 'focus', 'thornguard', 'wall', 'wardUp', 'reflect', 'blink', 'stealth', 'bark', 'poisonBlades', 'intervene', 'deathward'];

/* -------------------------------------------------------------- Gambits */
// Conditions: always | firstAction | selfHpBelow{pct} | allyHpBelow{pct} | enemyCountAtLeast{n}
//             | targetLacksStatus{status} | enemyIsCaster | ultimateReady

// Every Agent gets the full set of rule slots from level 1, so it can write real strategies (party and solo play).
export const GAMBIT_SLOTS = 20;
// Threat (PvE): each monster attacks whoever it holds most threat against. Presence multiplies all threat a fighter
// makes; damage to a monster adds to that monster's threat, healing adds to every monster's; a taunt snaps every
// monster's threat to the taunter (and forces attacks while it lasts). The Arena and duels have no monsters, so no threat.
export const THREAT = { base: 10, perPresence: 1 / 25, healShare: 0.5, tauntOver: 1.5, tauntFlat: 50 };
export const threatMult = (u) => 1 + (u?.scores?.pre || 0) * THREAT.perPresence;
export function gambitSlots() { return GAMBIT_SLOTS; }

// Gambit conditions the editor offers. param: the one number or status a condition takes.
export const CONDITIONS = {
  always:            { label: 'Always' },
  firstAction:       { label: 'On my first action' },
  selfHpBelow:       { label: 'My HP is below', param: { key: 'pct', kind: 'pct', min: 5, max: 95, def: 40 } },
  allyHpBelow:       { label: 'An ally (or I) is below', param: { key: 'pct', kind: 'pct', min: 5, max: 95, def: 40 } },
  enemyHpBelow:      { label: 'An enemy is below', param: { key: 'pct', kind: 'pct', min: 5, max: 95, def: 30 } },
  enemyCountAtLeast: { label: 'Enemies left: at least', param: { key: 'n', kind: 'count', min: 2, max: 5, def: 3 } },
  targetLacksStatus: { label: 'An enemy does not have', param: { key: 'status', kind: 'status', options: ['bleed', 'burn', 'silence', 'stun', 'chill', 'sunder', 'marked', 'weakened', 'blight', 'corruption', 'siphon', 'haunted', 'poly', 'frozen', 'moonfire', 'entangle', 'poison'], def: 'bleed' } },
  enemyIsCaster:     { label: 'An enemy can cast spells' },
  enemyHasBuff:      { label: 'An enemy has a buff (shield, armour, dodge…)' },
  ultimateReady:     { label: 'My ultimate is charged' },
  // Party play: tanks, healers and anyone whose plan differs between group and solo content.
  alone:             { label: 'I fight alone (no allies)' },
  alliesAtLeast:     { label: 'Allies fighting with me: at least', param: { key: 'n', kind: 'count', min: 1, max: 4, def: 1 } },
  allyUnderAttack:   { label: 'An ally (not me) was hit since my last turn' },
  otherAllyHpBelow:  { label: 'Another ally (not me) is below', param: { key: 'pct', kind: 'pct', min: 5, max: 95, def: 50 } },
  alliesHurt:        { label: 'Two or more of us are below', param: { key: 'pct', kind: 'pct', min: 5, max: 95, def: 60 } },
  selfLacksStatus:   { label: 'I do not have', param: { key: 'status', kind: 'status', options: ['taunt', 'guard', 'shield', 'counter', 'armorUp', 'evasive', 'haste', 'empower', 'focus', 'regrow', 'thornguard', 'wall', 'wardUp', 'reflect', 'blink', 'stealth', 'bark', 'poisonBlades'], def: 'taunt' } },
  enemyIsHealer:     { label: 'An enemy can heal' },
  allyDown:          { label: 'An ally is knocked out' },
  targetArmourOverMr: { label: 'An enemy has more armour than magic resist' },
};

// The class abilities an Agent of this class and level has unlocked (actives only, no basic or ultimate).
export function unlockedActives(cls, level, itemAbilities = []) {
  const own = Object.entries(ABILITIES).filter(([, a]) => a.cls === cls && !a.basic && !a.ultimate && (a.lvl || 1) <= level).map(([k]) => k);
  return [...own, ...itemAbilities.filter(k => (ABILITIES[k]?.item || ABILITIES[k]?.hidden) && !ABILITIES[k]?.ultimate && !own.includes(k))];
}

// Every unlocked active is available in every fight (no slot limit since epoch 7). A saved loadout only sets the
// order: its abilities first, then the rest of what is unlocked.
export function sanitizeLoadout(cls, level, loadout, itemAbilities = []) {
  const ok = unlockedActives(cls, level, itemAbilities);
  const src = Array.isArray(loadout) ? loadout.filter(k => ok.includes(k)) : [];
  return [...new Set([...src, ...ok])];
}

// Keep only well-formed rules with known conditions and abilities this class can ever use, clamp
// their numbers, and cut to the level's slot count. Shared by the editor and every battle.
export function sanitizeGambits(cls, level, gambits) {
  const usableKeys = new Set(Object.entries(ABILITIES).filter(([, a]) => a.cls === cls || a.item || a.hidden).map(([k]) => k));
  const out = [];
  for (const g of Array.isArray(gambits) ? gambits : []) {
    const def = CONDITIONS[g?.if?.type];
    if (!def || !usableKeys.has(g.use)) continue;
    const cond = { type: g.if.type };
    if (def.param) {
      const p = def.param, v = g.if[p.key];
      cond[p.key] = p.kind === 'status' ? (p.options.includes(v) ? v : p.def)
        : Math.min(p.max, Math.max(p.min, Math.round(Number.isFinite(v) ? v : p.def)));
    }
    out.push({ if: cond, use: g.use });
  }
  return out.slice(0, gambitSlots(level));
}

// Pets a class has, their default names, and the name the player gave theirs (agent doc `petName`).
// The Ranger's companion is always at its side (`petType`: wolf, boar or wisp, by level); the Warden's bear and the
// Hexer's imp are summoned.
export const PET_OF = { warden: 'spirit_bear', ranger: 'wolf', hexer: 'imp', necromancer: 'skeleton' };
export const PET_DEFAULT_NAME = { spirit_bear: 'Spirit Bear', wolf: 'Wolf Companion', boar: 'Boar Companion', wisp: 'Spirit Wisp', imp: 'Imp', skeleton: 'Skeleton', bone_golem: 'Bone Golem' };
export const RANGER_PETS = {
  wolf: { lvl: 1, role: 'Damage', desc: 'A fast biter that hunts with you.' },
  boar: { lvl: 12, role: 'Tank', desc: 'A tusked brute with a thick hide that taunts foes off you.' },
  wisp: { lvl: 24, role: 'Healer', desc: 'A forest spirit that mends your wounds.' },
};
export const PET_RESPAWN = 6;   // a fallen companion returns after this many of its Ranger's actions
// Companions grow with their Ranger: +15% at level 20, +30% at level 35.
export const petTier = (level) => (level >= 35 ? { mult: 1.3, name: 'Alpha' } : level >= 20 ? { mult: 1.15, name: 'Seasoned' } : { mult: 1, name: 'Young' });
export const companionOf = (agent, level) => { const k = RANGER_PETS[agent?.petType] && RANGER_PETS[agent.petType].lvl <= level ? agent.petType : 'wolf'; return k; };
// A pet unit for its owner (kind: spirit_bear, wolf, boar, wisp, imp); mm scales it (mastery or companion tier).
function petUnit(u, kind, mm = 1) {
  const S = u.scores, c = u.companion === kind ? 0.8 : 1, P = {
    spirit_bear: { name: 'Spirit Bear', affinity: 'nature', basic: 'maul', scores: { mig: Math.round(S.spi * 0.8 * mm), agi: 6, vit: Math.round(S.vit * 0.6 * mm), int: 4, spi: 6, pre: 6 } },
    wolf: { name: 'Wolf Companion', affinity: 'nature', basic: 'bite', scores: { mig: 6, agi: Math.round(S.agi * 0.7 * mm * c), vit: Math.round(S.vit * 0.5 * mm * c), int: 4, spi: 6, pre: 6 } },
    boar: { name: 'Boar Companion', affinity: 'nature', basic: 'maul', abilities: ['iron_taunt'], gambits: [{ if: { type: 'selfLacksStatus', status: 'taunt' }, use: 'iron_taunt' }],
      scores: { mig: Math.round(S.agi * 0.45 * mm * c), agi: 6, vit: Math.round(S.vit * 1.0 * mm * c), int: 4, spi: 6, pre: Math.round(10 * mm) } },
    wisp: { name: 'Spirit Wisp', affinity: 'nature', basic: 'thorn_whip', abilities: ['mending_roots'], gambits: [{ if: { type: 'allyHpBelow', pct: 70 }, use: 'mending_roots' }],
      scores: { mig: 4, agi: 8, vit: Math.round(S.vit * 0.4 * mm * c), int: 8, spi: Math.round(Math.max(S.spi, S.agi * 0.6) * 0.8 * mm * c), pre: 6 } },
    imp: { name: 'Imp', affinity: 'shadow', basic: 'shadow_bolt', scores: { mig: 4, agi: 10, vit: Math.round(S.vit * 0.4 * mm), int: Math.round(S.int * 0.7 * mm), spi: 6, pre: 6 } },
    skeleton: { name: 'Skeleton', affinity: 'shadow', basic: 'maul', scores: { mig: Math.round(S.int * 0.45 * mm), agi: 8, vit: Math.round(S.vit * 0.6 * mm), int: 4, spi: 4, pre: 6 } },
    bone_golem: { name: 'Bone Golem', affinity: 'shadow', basic: 'maul', abilities: ['iron_taunt'], gambits: [{ if: { type: 'selfLacksStatus', status: 'taunt' }, use: 'iron_taunt' }],
      scores: { mig: Math.round(S.int * 0.3 * mm), agi: 5, vit: Math.round(S.vit * 1.0 * mm), int: 4, spi: 6, pre: Math.round(10 * mm) } },
  }[kind];
  if (!P) return null;
  return { id: `${u.id}-${kind}`, name: u.petName || P.name, level: u.level, gear: {}, affinity: P.affinity, scores: P.scores, basic: P.basic, abilities: P.abilities || [], ultimate: null, passive: null, gambits: P.gambits || [], pet: kind };
}
export const PET_NAME_MAX = 20;
export function cleanPetName(s) {
  const t = String(s ?? '').replace(/[\u0000-\u001f\u007f<>{}\[\]"`]/g, '').replace(/\s+/g, ' ').trim().slice(0, PET_NAME_MAX);
  return t || null;
}

// Abilities that existed once and were removed: older saved builds and fight snapshots may still name them. Fights
// ignore them; record checks must not treat them as forged.
export const RETIRED_ABILITIES = ['call_companion'];

// Enchanted Quiver: mana per magical attack.
export const QUIVER_COST = 5;
// Death Knight runes: an imbued weapon attack also hits for IMBUE_COEF × its spell power in the rune's element.
// RUNES: the elements Runeforge can choose, by the level they unlock.
export const IMBUE_COEF = 0.8;
export const RUNES = { frost: 1, fire: 5, storm: 12, shadow: 20 };
export const QUIVER_MAGIC = 0.75;   // share of an enchanted arrow that is magical; the rest stays physical

export const DEFAULT_GAMBITS = {
  // The tank: survive first (a shout to recover, a wall when hurt), protect allies, shut casters down.
  warblade: [
    { if: { type: 'firstAction' }, use: 'charge' },
    { if: { type: 'selfHpBelow', pct: 35 }, use: 'rallying_cry' },
    { if: { type: 'otherAllyHpBelow', pct: 45 }, use: 'intervene' },
    { if: { type: 'allyHpBelow', pct: 40 }, use: 'iron_taunt' },
    { if: { type: 'enemyIsCaster' }, use: 'shield_bash' },
    { if: { type: 'selfHpBelow', pct: 50 }, use: 'shield_wall' },
  ],
  // The assassin: open from the shadows, vanish when it goes wrong, stun and stab.
  shadowstep: [
    { if: { type: 'firstAction' }, use: 'ambush' },
    { if: { type: 'always' }, use: 'cheap_shot' },
    { if: { type: 'selfHpBelow', pct: 50 }, use: 'vanish' },
    { if: { type: 'selfHpBelow', pct: 35 }, use: 'smoke_bomb' },
    { if: { type: 'selfLacksStatus', status: 'poisonBlades' }, use: 'poisoned_blades' },
    { if: { type: 'targetLacksStatus', status: 'bleed' }, use: 'hemorrhage' },
    { if: { type: 'always' }, use: 'backstab' },
  ],
  // The glass cannon: blow things up, control the second foe, get out of trouble.
  arcanist: [
    { if: { type: 'selfHpBelow', pct: 50 }, use: 'frost_barrier' },
    { if: { type: 'selfHpBelow', pct: 30 }, use: 'blink' },
    { if: { type: 'enemyCountAtLeast', n: 2 }, use: 'polymorph' },
    { if: { type: 'enemyCountAtLeast', n: 2 }, use: 'blizzard' },
    { if: { type: 'enemyCountAtLeast', n: 2 }, use: 'chain_lightning' },
    { if: { type: 'always' }, use: 'fire_blast' },
    { if: { type: 'always' }, use: 'firebolt' },
  ],
  // The druid: bring the fallen back, keep everyone topped up, call the bear.
  warden: [
    { if: { type: 'allyDown' }, use: 'rebirth' },
    { if: { type: 'allyHpBelow', pct: 45 }, use: 'ironbark' },
    { if: { type: 'alliesHurt', pct: 70 }, use: 'wild_growth' },
    { if: { type: 'allyHpBelow', pct: 50 }, use: 'mending_roots' },
    { if: { type: 'selfHpBelow', pct: 50 }, use: 'barkskin' },
    { if: { type: 'always' }, use: 'spirit_bear' },
    { if: { type: 'enemyCountAtLeast', n: 2 }, use: 'starfall' },
    { if: { type: 'targetLacksStatus', status: 'moonfire' }, use: 'moonfire' },
    { if: { type: 'targetLacksStatus', status: 'chill' }, use: 'entangling_roots' },
  ],
  // The hunter: wolf out, mark, trap the second foe, big shots.
  ranger: [
    { if: { type: 'targetArmourOverMr' }, use: 'enchanted_quiver' },
    { if: { type: 'targetLacksStatus', status: 'marked' }, use: 'hunters_mark' },
    { if: { type: 'enemyCountAtLeast', n: 2 }, use: 'freezing_trap' },
    { if: { type: 'enemyCountAtLeast', n: 2 }, use: 'volley' },
    { if: { type: 'always' }, use: 'kill_command' },
    { if: { type: 'always' }, use: 'deadeye' },
    { if: { type: 'always' }, use: 'called_shot' },
    { if: { type: 'always' }, use: 'piercing_arrow' },
  ],
  // The warlock: an imp, curses on everything, drain to stay alive.
  hexer: [
    { if: { type: 'always' }, use: 'summon_imp' },
    { if: { type: 'targetLacksStatus', status: 'corruption' }, use: 'corruption' },
    { if: { type: 'targetLacksStatus', status: 'siphon' }, use: 'siphon_life' },
    { if: { type: 'targetLacksStatus', status: 'haunted' }, use: 'haunt' },
    { if: { type: 'targetLacksStatus', status: 'weakened' }, use: 'curse_of_weakness' },
    { if: { type: 'selfHpBelow', pct: 60 }, use: 'drain_life' },
    { if: { type: 'enemyCountAtLeast', n: 2 }, use: 'plague' },
  ],
  // The rune knight: forge the right rune, hit hard, drain to stay up, shrug off spells.
  deathknight: [
    { if: { type: 'selfHpBelow', pct: 35 }, use: 'icebound_fortitude' },
    { if: { type: 'selfHpBelow', pct: 50 }, use: 'rune_tap' },
    { if: { type: 'selfLacksStatus', status: 'imbue' }, use: 'runeforge' },
    { if: { type: 'enemyIsCaster' }, use: 'anti_magic_shell' },
    { if: { type: 'selfHpBelow', pct: 65 }, use: 'death_strike' },
    { if: { type: 'enemyCountAtLeast', n: 2 }, use: 'howling_blast' },
    { if: { type: 'enemyCountAtLeast', n: 2 }, use: 'blood_boil' },
    { if: { type: 'always' }, use: 'dancing_rune_weapon' },
    { if: { type: 'always' }, use: 'obliterate' },
  ],
  // The necromancer: a minion up, rot on everything, drain to stay alive.
  necromancer: [
    { if: { type: 'always' }, use: 'raise_bone_golem' },
    { if: { type: 'always' }, use: 'raise_skeleton' },
    { if: { type: 'selfHpBelow', pct: 50 }, use: 'bone_armor' },
    { if: { type: 'targetLacksStatus', status: 'blight' }, use: 'withering_touch' },
    { if: { type: 'enemyCountAtLeast', n: 2 }, use: 'decrepify' },
    { if: { type: 'enemyCountAtLeast', n: 2 }, use: 'corpse_explosion' },
    { if: { type: 'selfHpBelow', pct: 60 }, use: 'death_coil' },
    { if: { type: 'always' }, use: 'lich_form' },
    { if: { type: 'always' }, use: 'necrotic_lance' },
  ],
  // The bard: lift the party, heal it, silence casters, mark the target.
  bard: [
    { if: { type: 'allyDown' }, use: 'second_verse' },
    { if: { type: 'alliesHurt', pct: 70 }, use: 'song_of_rest' },
    { if: { type: 'selfHpBelow', pct: 60 }, use: 'song_of_rest' },
    { if: { type: 'selfHpBelow', pct: 45 }, use: 'anthem_of_warding' },
    { if: { type: 'enemyIsCaster' }, use: 'dissonance' },
    { if: { type: 'always' }, use: 'ballad_of_valor' },
    { if: { type: 'always' }, use: 'hymn_of_haste' },
    { if: { type: 'targetLacksStatus', status: 'marked' }, use: 'mocking_verse' },
    { if: { type: 'enemyCountAtLeast', n: 2 }, use: 'discordant_note' },
    { if: { type: 'always' }, use: 'requiem' },
  ],
};

/* ---------------------------------------------------------- Unit makers */

const BASIC = { warblade: 'cleave', shadowstep: 'twin_fangs', arcanist: 'arcane_bolt', warden: 'thorn_whip', ranger: 'quick_shot', hexer: 'shadow_bolt', deathknight: 'runic_strike', necromancer: 'bone_spear', bard: 'cutting_chord' };

// An Agent as the engine sees it. `agent` is the game's agent doc { name, cls, scores }.
// Level-up points in each class's build-guide ratio (3 per level), used by the balance
// report and any Agent that has not spent its points yet.
// The score each class gains automatically every level (on top of the 3 points the player spends).
export const FIRST_PRIMARY = { warblade: 'mig', shadowstep: 'agi', arcanist: 'int', warden: 'spi', ranger: 'agi', hexer: 'int', deathknight: 'mig', necromancer: 'int', bard: 'pre' };
export const PER_LEVEL = { warblade: { mig: 2, vit: 1 }, shadowstep: { agi: 2, pre: 1 }, arcanist: { int: 2, spi: 1 }, warden: { spi: 2, vit: 1 }, ranger: { agi: 2, spi: 1 }, hexer: { int: 2, pre: 1 }, deathknight: { mig: 1, int: 2 }, necromancer: { int: 2, vit: 1 }, bard: { pre: 2, spi: 1 } };

// Class defence profiles (only for an Agent wearing no armour): Warblade fights in plate (tough, poor magic resist), Arcanist in cloth.
export const CLASS_DEFENCE = { warblade: { armor: 1.25, mr: 0.6 }, shadowstep: { armor: 1, mr: 1 }, arcanist: { armor: 0.8, mr: 1 }, warden: { armor: 1, mr: 1.15 }, ranger: { armor: 0.95, mr: 1 }, hexer: { armor: 0.85, mr: 1.05 }, deathknight: { armor: 1.2, mr: 0.9 }, necromancer: { armor: 0.85, mr: 1.05 }, bard: { armor: 0.95, mr: 1 } };

// Stat points spent on level-up: whole, non-negative, at most 3 per level gained in total.
export const SCORE_KEYS = ['mig', 'agi', 'vit', 'int', 'spi', 'pre'];
export function sanitizeSpent(spent, level) {
  let left = 3 * Math.max(0, level - 1);
  const out = {};
  for (const k of SCORE_KEYS) {
    const v = Math.max(0, Math.min(left, Math.floor(Number(spent?.[k]) || 0)));
    if (v) out[k] = v;
    left -= v;
  }
  return out;
}

// Trainer bonuses: whole, non-negative, each at most half the Agent's level.
export function sanitizeTrained(trained, level) {
  const cap = Math.floor(level / 2), out = {};
  for (const k of SCORE_KEYS) { const v = Math.max(0, Math.min(cap, Math.floor(Number(trained?.[k]) || 0))); if (v) out[k] = v; }
  return out;
}

export const ownedHidden = (agent) => (Array.isArray(agent?.hidden) ? agent.hidden : []).filter(k => HIDDEN_KEYS.includes(k));

export function makeAgentUnit(agent, { id = 'agent', level = 1, equipped, gambits, loadout, autoSpend = false } = {}) {
  const cls = agent.cls;
  const scores = { ...agent.scores };
  const first = FIRST_PRIMARY[cls];
  scores[first] += level - 1; // automatic +1 per level to the first primary
  if (autoSpend) for (const [k, n] of Object.entries(PER_LEVEL[cls])) scores[k] += n * (level - 1);
  else for (const [k, v] of Object.entries(sanitizeSpent(agent.spent, level))) scores[k] += v;
  for (const [k, v] of Object.entries(sanitizeTrained(agent.trained, level))) scores[k] += v;
  const race = RACES[raceOf(agent)];
  if (race) for (const [k, v] of Object.entries(race.mods)) scores[k] = (scores[k] || 0) + v;
  const gear = computeGear(equipped ?? agent.gear ?? {}, cls);
  race?.perk.apply(gear);
  for (const [k, v] of Object.entries(gear.scores)) scores[k] = (scores[k] || 0) + v;
  const abilities = Object.entries(ABILITIES)
    .filter(([, a]) => a.cls === cls && (a.lvl || 1) <= level)
    .map(([k]) => k);
  return {
    id, name: agent.name, cls, race: raceOf(agent), level, scores, gear, affinity: gear.affinity,
    // Class defence profiles stand in for armour weight only while no armour is worn.
    defence: gear.hasArmour ? null : CLASS_DEFENCE[cls],
    procs: gear.procs, set: gear.set,
    basic: BASIC[cls],
    abilities: sanitizeLoadout(cls, level, loadout ?? agent.loadout, [...gear.abilities, ...ownedHidden(agent).filter(k => ABILITIES[k] && !ABILITIES[k].ultimate)]),
    ultimate: ownedHidden(agent).includes(agent.ultimateChoice) && ABILITIES[agent.ultimateChoice]?.ultimate ? agent.ultimateChoice : (abilities.find(k => ABILITIES[k].ultimate) || null),
    passive: ownedHidden(agent).includes(agent.passiveChoice) && HIDDEN_PASSIVES[agent.passiveChoice] ? agent.passiveChoice : (PASSIVES[cls]?.id || null),
    gambits: sanitizeGambits(cls, level, gambits ?? agent.gambits ?? DEFAULT_GAMBITS[cls]),
    universal: [...UNIVERSAL],
    mountPerks: MOUNTS[agent.mount]?.perks || null, hireling: !!agent.hireling, petName: cleanPetName(agent.petName),
    companion: cls === 'ranger' && !agent.hireling ? companionOf(agent, level) : null,
    mastery: Object.fromEntries(Object.entries(agent.mastery || {}).filter(([k, n]) => ABILITIES[k] && Number.isFinite(n)).map(([k, n]) => [k, masteryRank(n)])),
  };
}

// How often each ability was used by one unit in a battle log (for mastery).
export function countUses(log, uid) {
  const out = {};
  for (const e of log) if (e.t === 'act' && e.uid === uid && !e.echo && e.ab !== 'strike') out[e.ab] = (out[e.ab] || 0) + 1;
  return out;
}

export const MOBS = {
  goblin_scout:  { name: 'Goblin Scout', scores: { mig: 9, agi: 10, vit: 7, int: 6, spi: 6, pre: 6 }, basic: 'stab', abilities: [], affinity: 'nature', growth: 0.6 },
  dire_wolf:     { name: 'Dire Wolf', scores: { mig: 10, agi: 12, vit: 8, int: 4, spi: 6, pre: 6 }, basic: 'bite', abilities: [], affinity: 'nature', growth: 0.6 },
  goblin_shaman: { name: 'Goblin Shaman', scores: { mig: 6, agi: 8, vit: 7, int: 11, spi: 10, pre: 6 }, basic: 'hex_bolt', abilities: ['shaman_mend'], affinity: 'shadow', growth: 0.6,
                   gambits: [{ if: { type: 'allyHpBelow', pct: 45 }, use: 'shaman_mend' }] },
  old_mossback:  { name: 'Old Mossback', elite: true, scores: { mig: 14, agi: 6, vit: 16, int: 6, spi: 10, pre: 8 }, basic: 'slam', abilities: [], affinity: 'nature', growth: 1.2 },
  grubnose:      { name: 'Goblin King Grubnose', boss: true, scores: { mig: 15, agi: 9, vit: 18, int: 8, spi: 10, pre: 12 }, basic: 'ladle_smash', abilities: ['stew'],
                   affinity: 'nature', growth: 1.45, hpMult: 4.2,
                   gambits: [{ if: { type: 'selfHpBelow', pct: 50 }, use: 'stew' }] },

  // Ashen Barrens (levels 10–20). Base scores are level-1 equivalents; growth carries them up.
  bandit_raider: { name: 'Bandit Raider', scores: { mig: 8, agi: 11, vit: 8, int: 5, spi: 6, pre: 7 }, basic: 'cutthroat', abilities: [], affinity: 'fire', growth: 0.55 },
  dune_scorpion: { name: 'Dune Scorpion', scores: { mig: 10, agi: 9, vit: 8, int: 4, spi: 7, pre: 5 }, basic: 'venom_sting', abilities: [], affinity: 'fire', growth: 0.55 },
  sand_wraith:   { name: 'Sand Wraith', scores: { mig: 5, agi: 10, vit: 7, int: 11, spi: 9, pre: 8 }, basic: 'scorch', abilities: ['wail'], affinity: 'shadow', growth: 0.65,
                   gambits: [{ if: { type: 'enemyCountAtLeast', n: 2 }, use: 'wail' }] },
  brass_golem:   { name: 'Brass Golem', scores: { mig: 13, agi: 4, vit: 15, int: 4, spi: 8, pre: 6 }, basic: 'brass_fist', abilities: [], affinity: 'fire', growth: 0.75 },
  mirage_djinn:  { name: 'Mirage Djinn', elite: true, scores: { mig: 6, agi: 14, vit: 12, int: 15, spi: 12, pre: 10 }, basic: 'mirage_bolt', abilities: ['djinn_shimmer'],
                   affinity: 'storm', growth: 1.1, gambits: [{ if: { type: 'selfHpBelow', pct: 70 }, use: 'djinn_shimmer' }] },
  brass_sultan:  { name: 'The Brass Sultan', boss: true, scores: { mig: 15, agi: 9, vit: 16, int: 13, spi: 11, pre: 14 }, basic: 'scimitar_sweep', abilities: ['sandstorm', 'gilded_ward'],
                   affinity: 'fire', growth: 1.3, hpMult: 3.6,
                   gambits: [{ if: { type: 'selfHpBelow', pct: 60 }, use: 'gilded_ward' }, { if: { type: 'enemyCountAtLeast', n: 2 }, use: 'sandstorm' }] },
  // Secret bosses: never in a quest log. Each fights at the Agent's own level.
  morwen:        { name: 'Morwen, the Hexmother', boss: true, scores: { mig: 8, agi: 10, vit: 13, int: 15, spi: 12, pre: 12 }, basic: 'hex_lash', abilities: ['wither', 'bone_ward'],
                   affinity: 'shadow', growth: 1.0, hpMult: 1.5,
                   gambits: [{ if: { type: 'selfHpBelow', pct: 50 }, use: 'bone_ward' }, { if: { type: 'always' }, use: 'wither' }] },
  white_stag:    { name: 'The White Stag', elite: true, scores: { mig: 10, agi: 15, vit: 11, int: 6, spi: 12, pre: 14 }, basic: 'antler_charge', abilities: ['moonlight'],
                   affinity: 'radiant', growth: 1.0, gambits: [{ if: { type: 'selfHpBelow', pct: 40 }, use: 'moonlight' }] },
  the_stew:      { name: 'The Stew', boss: true, scores: { mig: 12, agi: 5, vit: 18, int: 12, spi: 10, pre: 8 }, basic: 'scald', abilities: ['bubble_up'],
                   affinity: 'fire', growth: 1.3, hpMult: 3.8, gambits: [{ if: { type: 'selfHpBelow', pct: 60 }, use: 'bubble_up' }] },
  rimeheart_echo: { name: "Rimeheart's Echo", boss: true, scores: { mig: 8, agi: 11, vit: 12, int: 15, spi: 11, pre: 12 }, basic: 'rime_lance', abilities: ['whiteout'],
                   affinity: 'frost', growth: 1.0, hpMult: 1.5, gambits: [{ if: { type: 'enemyCountAtLeast', n: 1 }, use: 'whiteout' }] },
  // Heirloom guardians: they stand between a class's legendary weapon and what it becomes.
  moonless_reaver: { name: 'The Moonless Reaver', boss: true, scores: { mig: 9, agi: 15, vit: 11, int: 8, spi: 9, pre: 12 }, basic: 'cutthroat', abilities: ['wail'],
                   affinity: 'shadow', growth: 1.0, hpMult: 1.5, gambits: [{ if: { type: 'selfHpBelow', pct: 60 }, use: 'wail' }] },
  glaciers_grudge: { name: "The Glacier's Grudge", boss: true, scores: { mig: 14, agi: 7, vit: 15, int: 10, spi: 10, pre: 11 }, basic: 'grave_cleave', abilities: ['discharge'],
                   affinity: 'storm', growth: 1.0, hpMult: 1.6, gambits: [{ if: { type: 'enemyCountAtLeast', n: 1 }, use: 'discharge' }] },
  hoarfrost_matriarch: { name: 'The Hoarfrost Matriarch', boss: true, scores: { mig: 14, agi: 11, vit: 15, int: 12, spi: 10, pre: 12 }, basic: 'wyvern_bite', abilities: ['frost_breath'],
                   affinity: 'frost', growth: 1.0, hpMult: 1.6, gambits: [{ if: { type: 'enemyCountAtLeast', n: 1 }, use: 'frost_breath' }] },
  the_last_reader: { name: 'The Last Reader', boss: true, scores: { mig: 7, agi: 10, vit: 13, int: 16, spi: 13, pre: 13 }, basic: 'ink_lash', abilities: ['forbidden_word', 'index_ward'],
                   affinity: 'shadow', growth: 1.0, hpMult: 1.5, gambits: [{ if: { type: 'selfHpBelow', pct: 50 }, use: 'index_ward' }, { if: { type: 'always' }, use: 'forbidden_word' }] },
  heartwood_guardian: { name: 'The Heartwood Guardian', boss: true, scores: { mig: 13, agi: 5, vit: 17, int: 8, spi: 13, pre: 10 }, basic: 'slam', abilities: ['troll_hide'],
                   affinity: 'nature', growth: 1.0, hpMult: 1.7, gambits: [{ if: { type: 'selfHpBelow', pct: 50 }, use: 'troll_hide' }] },
  // Rare creatures: met only under special conditions (see bestiary.js)
  golden_goblin: { name: 'Golden Goblin', rare: true, scores: { mig: 8, agi: 15, vit: 9, int: 6, spi: 6, pre: 10 }, basic: 'stab', abilities: [], affinity: 'nature', growth: 0.62, hpMult: 1.3 },
  ember_phoenix: { name: 'Ember Phoenix', rare: true, scores: { mig: 6, agi: 13, vit: 10, int: 14, spi: 11, pre: 12 }, basic: 'scorch', abilities: ['sandstorm'], affinity: 'fire', growth: 0.75, hpMult: 1.4,
                   gambits: [{ if: { type: 'always' }, use: 'sandstorm' }] },
  aurora_wisp:   { name: 'Aurora Wisp', rare: true, scores: { mig: 4, agi: 14, vit: 8, int: 14, spi: 12, pre: 10 }, basic: 'ice_shard', abilities: ['deep_freeze'], affinity: 'radiant', growth: 0.7, hpMult: 1.3 },
  lost_page:     { name: 'The Lost Page', rare: true, scores: { mig: 6, agi: 14, vit: 8, int: 13, spi: 9, pre: 11 }, basic: 'paper_cut', abilities: ['blot_out'], affinity: 'shadow', growth: 0.65, hpMult: 1.3 },
  thunderbird:   { name: 'Thunderbird', rare: true, scores: { mig: 14, agi: 14, vit: 12, int: 10, spi: 10, pre: 12 }, basic: 'roc_dive', abilities: ['gale'], affinity: 'storm', growth: 0.95, hpMult: 1.3,
                   gambits: [{ if: { type: 'always' }, use: 'gale' }] },
  treasure_mimic: { name: 'Treasure Mimic', rare: true, scores: { mig: 14, agi: 6, vit: 16, int: 6, spi: 9, pre: 8 }, basic: 'tome_slam', abilities: ['bind'], affinity: 'physical', growth: 1.0, hpMult: 1.6,
                   gambits: [{ if: { type: 'selfHpBelow', pct: 50 }, use: 'bind' }] },
  // Whispering Archive (levels 30–40)
  ink_wraith:    { name: 'Ink Wraith', scores: { mig: 5, agi: 10, vit: 8, int: 12, spi: 9, pre: 8 }, basic: 'ink_lash', abilities: ['blot_out'], affinity: 'shadow', growth: 0.51,
                   gambits: [{ if: { type: 'enemyIsCaster' }, use: 'blot_out' }] },
  book_golem:    { name: 'Book Golem', scores: { mig: 13, agi: 4, vit: 15, int: 5, spi: 8, pre: 6 }, basic: 'tome_slam', abilities: ['bind'], affinity: 'physical', growth: 0.59,
                   gambits: [{ if: { type: 'selfHpBelow', pct: 50 }, use: 'bind' }] },
  lantern_wisp:  { name: 'Lantern Wisp', scores: { mig: 4, agi: 12, vit: 6, int: 12, spi: 9, pre: 7 }, basic: 'searing_light', abilities: ['flicker'], affinity: 'radiant', growth: 0.51,
                   gambits: [{ if: { type: 'selfHpBelow', pct: 60 }, use: 'flicker' }] },
  archive_warden: { name: 'Archive Warden', scores: { mig: 11, agi: 7, vit: 11, int: 6, spi: 9, pre: 10 }, basic: 'censure', abilities: [], affinity: 'radiant', growth: 0.53 },
  paper_moth:    { name: 'Paper Moth', scores: { mig: 7, agi: 13, vit: 6, int: 5, spi: 6, pre: 7 }, basic: 'paper_cut', abilities: [], affinity: 'physical', growth: 0.44 },
  the_redactor:  { name: 'The Redactor', elite: true, scores: { mig: 8, agi: 12, vit: 14, int: 16, spi: 12, pre: 12 }, basic: 'ink_lash', abilities: ['redact'],
                   affinity: 'shadow', growth: 1.15, gambits: [{ if: { type: 'enemyIsCaster' }, use: 'redact' }, { if: { type: 'always' }, use: 'redact' }] },
  head_librarian: { name: 'The Head Librarian', boss: true, scores: { mig: 9, agi: 10, vit: 17, int: 18, spi: 14, pre: 15 }, basic: 'ink_lash', abilities: ['forbidden_word', 'index_ward'],
                   affinity: 'shadow', growth: 1.4, hpMult: 5.6,
                   gambits: [{ if: { type: 'selfHpBelow', pct: 60 }, use: 'index_ward' }, { if: { type: 'enemyCountAtLeast', n: 2 }, use: 'forbidden_word' }] },
  // Thundercrag Spire (levels 40–50)
  thunder_giant: { name: 'Thunder Giant', scores: { mig: 14, agi: 5, vit: 15, int: 4, spi: 8, pre: 6 }, basic: 'thunderclap', abilities: [], affinity: 'storm', growth: 0.61 },
  spark_imp:     { name: 'Spark Imp', scores: { mig: 4, agi: 13, vit: 6, int: 12, spi: 7, pre: 8 }, basic: 'zap', abilities: [], affinity: 'storm', growth: 0.49 },
  static_elemental: { name: 'Static Elemental', scores: { mig: 6, agi: 8, vit: 12, int: 13, spi: 10, pre: 7 }, basic: 'static_touch', abilities: ['discharge'], affinity: 'storm', growth: 0.55,
                   gambits: [{ if: { type: 'enemyCountAtLeast', n: 2 }, use: 'discharge' }] },
  storm_harpy:   { name: 'Storm Harpy', scores: { mig: 8, agi: 14, vit: 7, int: 6, spi: 6, pre: 8 }, basic: 'talon_rake', abilities: [], affinity: 'storm', growth: 0.48 },
  skyguard_sentinel: { name: 'Skyguard Sentinel', scores: { mig: 12, agi: 8, vit: 12, int: 6, spi: 9, pre: 10 }, basic: 'skyspear', abilities: [], affinity: 'physical', growth: 0.54 },
  tempest_roc:   { name: 'Tempest Roc', elite: true, scores: { mig: 15, agi: 13, vit: 14, int: 10, spi: 10, pre: 11 }, basic: 'roc_dive', abilities: ['gale'],
                   affinity: 'storm', growth: 1.15, gambits: [{ if: { type: 'enemyCountAtLeast', n: 1 }, use: 'gale' }] },
  storm_wyrm:    { name: 'The Storm Wyrm', boss: true, scores: { mig: 16, agi: 11, vit: 18, int: 15, spi: 12, pre: 15 }, basic: 'wyrm_rend', abilities: ['wyrm_breath', 'wyrm_scales'],
                   affinity: 'storm', growth: 1.45, hpMult: 5.2,
                   gambits: [{ if: { type: 'selfHpBelow', pct: 55 }, use: 'wyrm_scales' }, { if: { type: 'enemyCountAtLeast', n: 1 }, use: 'wyrm_breath' }] },
  // Frostfang Peaks (levels 20–30)
  rime_stalker:  { name: 'Rime Stalker', scores: { mig: 9, agi: 12, vit: 8, int: 5, spi: 6, pre: 6 }, basic: 'frost_fang', abilities: [], affinity: 'frost', growth: 0.55 },
  glacier_troll: { name: 'Glacier Troll', scores: { mig: 13, agi: 5, vit: 14, int: 4, spi: 8, pre: 5 }, basic: 'troll_smash', abilities: ['troll_hide'], affinity: 'frost', growth: 0.7,
                   gambits: [{ if: { type: 'selfHpBelow', pct: 50 }, use: 'troll_hide' }] },
  frost_wisp:    { name: 'Frost Wisp', scores: { mig: 4, agi: 11, vit: 6, int: 12, spi: 9, pre: 7 }, basic: 'ice_shard', abilities: ['deep_freeze'], affinity: 'frost', growth: 0.6 },
  icebound_revenant: { name: 'Icebound Revenant', scores: { mig: 10, agi: 7, vit: 10, int: 6, spi: 8, pre: 9 }, basic: 'grave_cleave', abilities: [], affinity: 'shadow', growth: 0.6 },
  crag_harpy:    { name: 'Crag Harpy', scores: { mig: 8, agi: 13, vit: 7, int: 5, spi: 6, pre: 8 }, basic: 'talon_rake', abilities: [], affinity: 'storm', growth: 0.55 },
  hoarfrost_wyvern: { name: 'Hoarfrost Wyvern', elite: true, scores: { mig: 14, agi: 10, vit: 15, int: 12, spi: 10, pre: 10 }, basic: 'wyvern_bite', abilities: ['frost_breath'],
                   affinity: 'frost', growth: 1.15, gambits: [{ if: { type: 'enemyCountAtLeast', n: 1 }, use: 'frost_breath' }] },
  matron_rimeheart: { name: 'Matron Rimeheart', boss: true, scores: { mig: 10, agi: 11, vit: 17, int: 18, spi: 13, pre: 14 }, basic: 'rime_lance', abilities: ['whiteout', 'ice_mirror'],
                   affinity: 'frost', growth: 1.4, hpMult: 4.8,
                   gambits: [{ if: { type: 'selfHpBelow', pct: 60 }, use: 'ice_mirror' }, { if: { type: 'enemyCountAtLeast', n: 2 }, use: 'whiteout' }] },
};

// Monster damage tuning: weapon and spell power on every mob. Raised when shoulders and capes added armour and
// magic resist to every Agent (see tools/fullbalance.mjs), so content keeps the difficulty it was tuned for.
export const MOB_TUNE = { dmg: 1.38, spell: 1.6 };
export function makeMobUnit(kind, level = 1, id = kind, { mult = 1 } = {}) {
  const m = MOBS[kind];
  const bump = Math.round((level - 1) * m.growth);
  // mult: Heroic dungeons scale mob scores up (and HP further, below)
  const scores = Object.fromEntries(Object.entries(m.scores).map(([k, v]) => [k, Math.round((v + bump) * mult)]));
  return {
    id, name: m.name, mob: kind, level, scores, affinity: m.affinity,
    // Gear-equivalent bonus so mobs keep pace with geared Agents.
    gear: { weapon: Math.round((3 + 1.4 * level) * MOB_TUNE.dmg), spell: Math.round((3 + 1.4 * level) * MOB_TUNE.spell), armor: Math.round((3 + level) * 2.4), mr: Math.round((3 + level) * 1.6), hp: level * 6 },
    basic: m.basic, abilities: m.abilities, ultimate: null, passive: null,
    gambits: m.gambits || [], hpMult: (m.hpMult || 1) * (mult > 1 ? 1 + (mult - 1) * 2 : 1),
  };
}

/* ------------------------------------------------------------ Simulation */

// A unit's battle stats as a fight starts (the Character window's All stats panel shows the same numbers).
// opts.crowd: an Arena or duel fight (no mount perks).
export function unitStats(u, opts = {}) {
  const st = deriveStats(u.scores, u.level, u.gear);
  if (u.hpMult) st.maxHp = Math.round(st.maxHp * u.hpMult);
  if (u.defence) { st.armor *= u.defence.armor; st.mr *= u.defence.mr; }
  if (u.passive === 'mana_font') { st.regen += 3; st.crit = Math.min(60, st.crit + 10); }
  if (u.passive === 'verdant') st.resist = Math.min(50, st.resist + 10);
  if (u.passive === 'eagle_eye') { st.crit += 8; st.maxHp = Math.round(st.maxHp * 1.12); }
  if (u.passive === 'grim_harvest') st.maxHp = Math.round(st.maxHp * 1.15);
  // The guild's tank: plate is light on magic resist, so the Warblade's own grit makes up for it.
  if (u.passive === 'unbreakable') { st.maxHp = Math.round(st.maxHp * 1.15); st.mr *= 1.4; }
  if (u.passive === 'runebound') { st.maxHp = Math.round(st.maxHp * 1.15); st.mr *= 1.3; }
  if (u.passive === 'soul_harvest') st.maxHp = Math.round(st.maxHp * 1.1);
  if (u.passive === 'virtuoso') { st.maxHp = Math.round(st.maxHp * 1.15); st.resist = Math.min(50, st.resist + 10); }
  if (!opts.crowd && u.mountPerks?.ward) st.maxHp = Math.round(st.maxHp * 1.08);
  if (!opts.crowd && u.mountPerks?.phase) st.dodge += 5;
  return st;
}

// Where each attribute point of an Agent comes from (sums to makeAgentUnit's scores):
// { mig: { cls, level, spent, trained, race, gear, total }, ... }
export function scoreParts(agent, level = 1, equipped) {
  const cls = agent.cls, first = FIRST_PRIMARY[cls];
  const spent = sanitizeSpent(agent.spent, level), trained = sanitizeTrained(agent.trained, level);
  const race = RACES[raceOf(agent)], gear = computeGear(equipped ?? agent.gear ?? {}, cls);
  race?.perk.apply(gear);
  return Object.fromEntries(SCORE_KEYS.map(k => {
    const p = { cls: agent.scores?.[k] || 0, level: k === first ? level - 1 : 0, spent: spent[k] || 0, trained: trained[k] || 0, race: race?.mods[k] || 0, gear: gear.scores[k] || 0 };
    return [k, { ...p, total: Object.values(p).reduce((x, y) => x + y, 0) }];
  }));
}

export function simulate(seed, sideA, sideB, opts = {}) {
  const r = makeRng(`${RULES_VERSION}|${seed}`);
  const log = [];
  const emit = (ev) => log.push(ev);
  let actionNo = 0;

  const units = [], thornsFired = new Set();
  const spawn = (u, side) => {
    const st = unitStats(u, opts);
    const unit = {
      ...u, uid: `${side}:${u.id}`, side, st,
      hp: u.hpOverride ?? st.maxHp, mana: st.maxMana, gauge: Math.floor(r() * GAUGE * 0.15), charge: 0, actions: 0,
      cds: {}, statuses: [], alive: true, order: units.length,
    };
    units.push(unit);
    return unit;
  };
  sideA.forEach(u => spawn(u, 'A'));
  sideB.forEach(u => spawn(u, 'B'));
  // A Ranger's companion: at its side from the start, back PET_RESPAWN of its actions after it falls.
  const spawnCompanion = (u, respawn = false) => {
    const p = petUnit(u, u.companion, petTier(u.level).mult); if (!p) return null;
    const s = spawn(p, u.side); s.summoned = true; s.summoner = u.uid; s.companion = true; s.expires = Infinity; s.gauge = GAUGE * 0.5;
    emit({ t: 'summon', uid: s.uid, by: u.uid, name: s.name, hp: s.hp, maxHp: s.st.maxHp, pet: u.companion, ...(respawn ? { respawn: true } : {}) });
    return s;
  };
  emit({ t: 'start', rules: RULES_VERSION, units: units.map(u => ({ uid: u.uid, name: u.name, side: u.side, hp: u.hp, maxHp: u.st.maxHp, mana: u.mana, mob: u.mob || null, cls: u.cls || null })) });

  for (const u of [...units]) if (u.companion && !u.summoned) spawnCompanion(u);
  const has = (u, type) => u.statuses.some(s => s.type === type);
  const trait = (u, k) => !!u.traits?.includes(k);
  // In the Arena, speed differences are compressed toward 100 so the fastest class can't act twice as often.
  const baseSpeed = (u) => (opts.crowd ? 100 + (u.st.speed - 100) * Math.max(ARENA.speedComp, 1 - ARENA.speedSlope * Math.max(0, (u.level || 1) - 10)) : u.st.speed);
  const speedOf = (u) => baseSpeed(u) * (has(u, 'chill') ? 0.75 : 1) * (has(u, 'haste') ? 1.25 : 1) * (has(u, 'roar') ? 1.2 : 1);

  // Arena crowd: each side's meter fills from crits, dodges and Presence. Full = Crowd Roar for that side.
  const crowd = { A: 0, B: 0 };
  const other = (side) => (side === 'A' ? 'B' : 'A');
  const crowdFavours = (side) => units.some(x => x.alive && x.side === side && has(x, 'roar')) || crowd[side] >= crowd[other(side)] + 25;
  function cheer(side, n) {
    if (!opts.crowd) return;
    crowd[side] += n;
    if (crowd[side] < 100) return;
    crowd[side] = 0;
    emit({ t: 'crowd', side });
    for (const x of units) if (x.alive && x.side === side) {
      const cur = x.statuses.find(s => s.type === 'roar');
      if (cur) cur.turns = 3; else x.statuses.push({ type: 'roar', turns: 3, power: 0, stacks: 1, src: x.uid });
      emit({ t: 'status', uid: x.uid, status: 'roar', turns: 3, stacks: 1 });
    }
  }
  const foes = (u) => units.filter(x => x.alive && x.side !== u.side);
  const friends = (u) => units.filter(x => x.alive && x.side === u.side);
  // Knocked-out allies a Rebirth can bring back (not pets, which simply vanish).
  const downed = (u) => units.filter(x => !x.alive && x.side === u.side && !x.summoned && !x.vanished);
  const allies = (u) => friends(u).filter(x => x !== u && !x.summoned);   // other fighters on my side (not pets)
  // Threat: threat.get(monsterUid)?.get(fighterUid). Only monsters keep it.
  const threat = new Map();
  const tget = (m, f) => threat.get(m.uid)?.get(f.uid) ?? THREAT.base * threatMult(f);
  const tadd = (m, f, amt) => { if (!m.mob || f.mob || amt <= 0) return; if (!threat.has(m.uid)) threat.set(m.uid, new Map()); threat.get(m.uid).set(f.uid, tget(m, f) + amt * threatMult(f)); };
  const tauntSnap = (f) => { for (const m of units) if (m.alive && m.mob && m.side !== f.side) {
    const top = Math.max(0, ...units.filter(x => x.alive && x.side === f.side && x !== f).map(x => tget(m, x)));
    if (!threat.has(m.uid)) threat.set(m.uid, new Map());
    threat.get(m.uid).set(f.uid, Math.max(tget(m, f), top * THREAT.tauntOver + THREAT.tauntFlat)); } };
  const pctHp = (u) => u.hp / u.st.maxHp;
  const sideDown = (side) => !units.some(x => x.alive && x.side === side && !x.summoned);
  const byLowHp = (a, b) => (a.hp - b.hp) || (a.order - b.order);
  const byLowPct = (a, b) => (pctHp(a) - pctHp(b)) || (a.order - b.order);

  function kill(u, by) {
    // Unyielding: the blow that would knock you out leaves you on 1 HP instead, once.
    const ward = u.statuses.find(s => s.type === 'deathward');
    if (ward) { u.statuses = u.statuses.filter(s => s !== ward); u.hp = 1; emit({ t: 'deathward', uid: u.uid, by: by?.uid ?? null }); return; }
    u.alive = false; u.hp = 0;
    if (u.companion) { const o = units.find(x => x.uid === u.summoner); if (o) o.petDownAt = o.actions; }
    emit({ t: 'ko', uid: u.uid, by: by?.uid ?? null });
    // Soul Harvest: a Necromancer heals and charges whenever a foe of theirs falls (to anyone).
    for (const n of units) if (n.alive && n.passive === 'soul_harvest' && n.side !== u.side && !u.summoned) {
      heal(n, n, Math.round(n.st.maxHp * 0.08), 'soul_harvest'); n.charge = Math.min(100, n.charge + 15);
    }
    // a summoner's summons vanish with it
    for (const s of units) if (s.alive && s.summoner === u.uid) { s.alive = false; emit({ t: 'vanish', uid: s.uid }); }
  }

  function polyImmunity(u) {
    if (!u.alive || has(u, 'polyImmune')) return;
    u.statuses.push({ type: 'polyImmune', turns: POLY_IMMUNE_TURNS, power: 0, stacks: 1, src: u.uid });
    emit({ t: 'status', uid: u.uid, status: 'polyImmune', turns: POLY_IMMUNE_TURNS, stacks: 1 });
  }

  function applyStatus(src, tgt, eff, ab, rank = 0) {
    if (!tgt.alive) return;
    const hostile = HOSTILE.includes(eff.type);
    // Arena adaptations: Fireproof ignores Burn, Frostproof ignores Chill.
    if ((eff.type === 'burn' && trait(tgt, 'fireproof')) || (eff.type === 'chill' && trait(tgt, 'frostproof'))) { emit({ t: 'resist', uid: tgt.uid, status: eff.type }); return; }
    // Legendary Resistance: a boss shrugs off its first LEGENDARY_RESISTS stuns, Polymorphs and Freezes each fight.
    if ((eff.type === 'poly' || eff.type === 'frozen' || eff.type === 'stun') && (MOBS[tgt.mob]?.boss || tgt.uid === 'B:boss')) {
      tgt.legendary ??= LEGENDARY_RESISTS;
      if (tgt.legendary > 0) { tgt.legendary -= 1; emit({ t: 'resist', uid: tgt.uid, status: eff.type, legendary: true, left: tgt.legendary }); return; }
    }
    // Polymorph diminishing returns: a unit that was just Polymorphed cannot be again for a while.
    if (eff.type === 'poly' && has(tgt, 'polyImmune')) { emit({ t: 'resist', uid: tgt.uid, status: 'poly', immune: true }); return; }
    if (hostile && eff.chance != null) {
      const base = Math.min(100, eff.chance + MASTERY.chance * rank);                    // mastery: +2 points a rank
      const chance = base * (1 - tgt.st.resist / 100);
      const roll = r() * 100;
      if (roll >= base) return;                                                         // the effect simply didn't trigger
      if (roll >= chance) { emit({ t: 'resist', uid: tgt.uid, status: eff.type }); return; } // it would have, but resist blocked it
    }
    const base = eff.type === 'regrow' ? src.st.heal * healBonus(src) : ab ? powerOf(src, ab) : src.st.phys;
    const mm = 1 + MASTERY.power * rank;
    // Damage over time follows the same class tuning as hits (the Arena's CLASS_TUNE, PvE's PVE_TUNE), so the tuners can balance curse classes.
    const dotTune = eff.type !== 'regrow' && eff.powerCoef && src.cls && !src.summoned && !src.hireling ? (opts.crowd ? classTune(src.cls, src.level) : opts.noPveTune ? 1 : pveTune(src.cls, src.level, 'dealt')) : 1;
    const power = eff.type === 'shield' ? Math.round((tgt.hpBasis ?? tgt.st.maxHp) * (eff.shieldPct || 10) / 100 * (trait(tgt, 'brittle_guard') ? 0.6 : 1) * mm) : eff.powerCoef ? Math.max(1, Math.round(eff.powerCoef * base * mm * dotTune)) : 0;
    // A status with no number and no chance (a taunt, a haste, a riposte…) lasts longer instead.
    if (rank >= MASTERY.longerFrom && !power && eff.chance == null && eff.turns) eff = { ...eff, turns: eff.turns + 1 };
    const cur = tgt.statuses.find(s => s.type === eff.type);
    if (eff.stacks) { if (cur) { cur.stacks = eff.stacks; cur.turns = eff.turns; } else tgt.statuses.push({ type: eff.type, turns: eff.turns, power: 0, stacks: eff.stacks, src: src.uid }); emit({ t: 'status', uid: tgt.uid, status: eff.type, turns: eff.turns, stacks: eff.stacks }); return; }
    if (cur && eff.maxStacks) { cur.stacks = Math.min(eff.maxStacks, cur.stacks + 1); cur.turns = eff.turns; cur.power = Math.max(cur.power, power); }
    else if (cur) { cur.turns = Math.max(cur.turns, eff.turns); cur.power = Math.max(cur.power, power); }
    else tgt.statuses.push({ type: eff.type, turns: eff.turns, power, stacks: 1, src: src.uid });
    if (eff.type === 'taunt' && !opts.crowd && !tgt.mob) tauntSnap(tgt);
    const now = tgt.statuses.find(s => s.type === eff.type);
    emit({ t: 'status', uid: tgt.uid, status: eff.type, turns: eff.turns, stacks: now.stacks, ...(eff.type === 'shield' ? { shield: now.power } : {}) });
  }

  // Which stat an ability scales from: Might (phys), Agility (finesse: daggers, claws), Intellect (spell), Spirit (nature magic).
  const powerOf = (u, ab) => ab.power === 'finesse' ? u.st.finesse : ab.power === 'spirit' ? u.st.nature : ab.power === 'song' ? u.st.song : ab.kind === 'phys' ? u.st.phys : u.st.spell;

  const healBonus = (u) => (u.passive === 'verdant' ? 1.15 : 1);

  function damage(src, tgt, ab, coef, { guaranteedCrit = false, dot = false, element } = {}) {
    if (!tgt.alive) return 0;
    // Intervene: the protector takes the next hit aimed at this ally instead.
    const iv = !dot && src.side !== tgt.side && tgt.statuses.find(s => s.type === 'intervene');
    if (iv) {
      tgt.statuses = tgt.statuses.filter(s => s !== iv);
      const P = units.find(x => x.uid === iv.src && x.alive);
      if (P && P !== tgt) { emit({ t: 'intercept', uid: P.uid, for: tgt.uid, src: src.uid }); return damage(src, P, ab, coef, { guaranteedCrit, dot, element }); }
    }
    const isPhys = ab.kind === 'phys';
    const decoy = !dot && tgt.statuses.find(s => s.type === 'decoy' && s.stacks > 0);
    if (decoy) { decoy.stacks -= 1; if (!decoy.stacks) tgt.statuses = tgt.statuses.filter(s => s !== decoy); emit({ t: 'miss', src: src.uid, uid: tgt.uid, ab: ab.id, decoy: true }); return 0; }
    // Stealth: single-target attacks miss. Blink: the next attack of any kind misses (used up).
    if (!dot && has(tgt, 'stealth') && (ab.target === 'enemy' || ab.target === 'chain')) { emit({ t: 'miss', src: src.uid, uid: tgt.uid, ab: ab.id, stealth: true }); return 0; }
    const blink = !dot && tgt.statuses.find(s => s.type === 'blink');
    if (blink) { tgt.statuses = tgt.statuses.filter(s => s !== blink); emit({ t: 'miss', src: src.uid, uid: tgt.uid, ab: ab.id, blink: true }); emit({ t: 'expire', uid: tgt.uid, status: 'blink' }); return 0; }
    if (isPhys && !dot && r() * 100 < (tgt.st.dodge + (has(tgt, 'evasive') ? 25 : 0)) * (opts.crowd ? ARENA.dodgeMult : 1)) { emit({ t: 'miss', src: src.uid, uid: tgt.uid, ab: ab.id }); cheer(tgt.side, 10); return 0; }
    const el = element || (ab.element === 'affinity' ? src.affinity : ab.element) || 'physical';
    const P = powerOf(src, ab);
    const A = isPhys ? tgt.st.armor * (has(tgt, 'armorUp') ? (trait(tgt, 'brittle_guard') ? 1.18 : 1.3) : 1) * (has(tgt, 'sunder') ? 0.75 : 1) * (1 - (ab.pierce || 0)) : tgt.st.mr * (has(tgt, 'wardUp') ? 1.3 : 1);
    const e = elementMult(el, tgt.affinity);
    const attune = el !== 'physical' && el === src.affinity ? 1.1 : 1;
    const branded = !dot && src.passive === 'nemesis_brand' && !src.brandUsed;
    if (branded) src.brandUsed = true;
    const crit = !dot && (guaranteedCrit || branded || r() * 100 < src.st.crit);
    const k = crit ? 1 + (src.st.critDmg / 100 - 1) * (opts.crowd ? ARENA.critBonus : 1) : 1; // the Arena blunts crit damage
    const v = dot ? 1 : 0.9 + 0.2 * r();
    let bonus = 1;
    if (src.passive === 'unbreakable') bonus *= 1 + Math.min(0.25, Math.floor((1 - pctHp(src)) * 100 / 4) / 100);
    if (src.passive === 'opportunist' && has(tgt, 'bleed')) bonus *= 1.15;
    if (el !== 'physical' && src.st.elem?.[el]) bonus *= 1 + src.st.elem[el] / 100;
    // Arena traits, rivalries and the crowd
    if (has(src, 'roar')) bonus *= 1.2;
    if (has(src, 'empower')) bonus *= 1.25;
    if (!opts.crowd && !dot && src.mountPerks?.charge && src.actions === 0) bonus *= 1.25;
    if (has(src, 'weakened')) bonus *= 0.8;
    if (has(tgt, 'marked')) bonus *= 1.2;
    if (src.passive === 'grim_harvest' && pctHp(tgt) < 0.5) bonus *= 1.12;
    if (src.passive === 'virtuoso' && (has(src, 'empower') || has(src, 'haste'))) bonus *= 1.15;
    if (ab.runeStrike && src.passive === 'runebound') bonus *= 1.25;
    if (src.mastery?.[ab.id]) bonus *= 1 + 0.03 * src.mastery[ab.id];
    if (ab.bonusVsStatus && tgt.statuses.some(s => ab.bonusVsStatus.statuses.includes(s.type))) bonus *= ab.bonusVsStatus.mult;
    if (!dot && ab.breaksGuard && tgt.statuses.some(s => ['guard', 'counter', 'shield'].includes(s.type))) {
      bonus *= 2; tgt.statuses = tgt.statuses.filter(s => !['guard', 'counter'].includes(s.type)); emit({ t: 'expire', uid: tgt.uid, status: 'guard' });
    }
    if (!dot && has(tgt, 'guard')) bonus *= 0.5;
    if (!dot && isPhys && has(tgt, 'counter')) bonus *= 0.5;
    if (has(tgt, 'thornguard')) bonus *= 0.85;
    if (!dot && has(tgt, 'wall')) bonus *= 0.65;
    if (!dot && has(tgt, 'bark')) bonus *= 0.75;
    const warded = !dot && !isPhys && has(tgt, 'reflect') && src.side !== tgt.side;
    if (warded) bonus *= 0.6;
    if (!dot && el === 'shadow' && has(tgt, 'haunted')) bonus *= 1.2;
    if (opts.crowd && isPhys && !dot) bonus *= ARENA.physMult;
    if (opts.crowd && src.cls && !src.summoned) bonus *= classTune(src.cls, src.level);
    // PvE class tuning balances adventure success; world boss attempts (opts.noPveTune) measure raw damage instead.
    if (!opts.crowd && !opts.noPveTune && src.cls && !src.summoned && !src.hireling) bonus *= pveTune(src.cls, src.level, 'dealt');
    if (!opts.crowd && !opts.noPveTune && tgt.cls && !tgt.summoned && !tgt.hireling) bonus *= pveTune(tgt.cls, tgt.level, 'taken');
    if (opts.crowd && trait(src, 'afraid_crowd') && crowdFavours(other(src.side))) bonus *= 0.85;
    if (trait(src, 'enraged_shadow') && src.actions < (src.enragedUntil || 0)) bonus *= 1.2;
    if (trait(src, 'beast_slayer') && tgt.summoned) bonus *= 1.25;
    if (src.foeMult && !tgt.summoned) bonus *= src.foeMult;
    if (!dot && trait(tgt, 'vuln_ambush') && src.actions === 0) bonus *= 2;
    if (el !== 'physical' && trait(tgt, `${el}proof`)) bonus *= 0.75;
    if (opts.crowd && tgt.passive === 'nemesis_brand' && src.cls) bonus *= 0.9;
    let bulwark = 1;
    if (!dot && tgt.set === 'bulwark' && !tgt.bulwarkUsed) { tgt.bulwarkUsed = true; bulwark = 0.5; }
    // Sudden Death compounds (×1.1 per action past 60) so even two pure tanks finish.
    const sudden = !opts.noSuddenDeath && actionNo > SUDDEN_DEATH_AT ? Math.pow(1.1, actionNo - SUDDEN_DEATH_AT) : 1;
    // World boss fights (opts.enrage): no Sudden Death; the boss side hits a little harder every action after `from`.
    if (opts.enrage && src.side === 'B' && actionNo > opts.enrage.from) bonus *= 1 + (actionNo - opts.enrage.from) * opts.enrage.per;
    const blocked = isPhys && !dot && r() * 100 < tgt.st.block * (trait(tgt, 'brittle_guard') ? 0.6 : 1);
    let amt = dot ? coef * (el === 'shadow' && has(tgt, 'haunted') ? 1.2 : 1) : P * coef * (100 / (100 + A)) * e * attune * k * v * bonus * sudden * bulwark * (blocked ? 0.5 : 1);
    amt = Math.max(1, Math.round(amt));
    const shield = tgt.statuses.find(s => s.type === 'shield');
    let absorbed = 0;
    if (shield) { absorbed = Math.min(shield.power, amt); shield.power -= absorbed; amt -= absorbed; if (shield.power <= 0) tgt.statuses = tgt.statuses.filter(s => s !== shield); }
    tgt.hp = Math.max(0, tgt.hp - amt);
    // Damage breaks Polymorph and Freezing Trap.
    if (amt > 0) for (const s of tgt.statuses.filter(x => x.type === 'poly' || x.type === 'frozen')) { tgt.statuses = tgt.statuses.filter(x => x !== s); emit({ t: 'expire', uid: tgt.uid, status: s.type, broken: true }); if (s.type === 'poly') polyImmunity(tgt); }
    if (src.side !== tgt.side && !dot) { tgt.lastHitAt = actionNo; tgt.lastHitBy = src.uid; }   // for 'allyUnderAttack'
    if (src.side !== tgt.side && !opts.crowd) tadd(tgt, src.summoner ? units.find(x => x.uid === src.summoner) || src : src, amt);   // a pet's damage is its owner's threat
    if (el === 'shadow' && trait(tgt, 'enraged_shadow')) tgt.enragedUntil = tgt.actions + 3;
    if (crit) cheer(src.side, 12);
    // shieldLeft (only when a shield took part): what is left of it, 0 when this hit broke it; replays draw it.
    emit({ t: 'dmg', src: src.uid, uid: tgt.uid, ab: ab.id, amt, crit, el, mult: e, blocked, absorbed, hp: tgt.hp, dot, ...(shield ? { shieldLeft: Math.max(0, shield.power) } : {}), ...(ab.runeStrike ? { rune: true } : {}) });
    // Poisoned Blades: physical hits may leave a stacking Poison.
    if (!dot && isPhys && amt + absorbed > 0 && has(src, 'poisonBlades') && tgt.alive) applyStatus(src, tgt, { type: 'poison', chance: 50, turns: 3, powerCoef: 0.15, maxStacks: 3 }, ab, 0);
    if (warded && amt + absorbed > 0 && src.alive) {   // Spell Ward strikes 30% back at the caster
      const back = Math.max(1, Math.round((amt + absorbed) / 0.6 * 0.3));
      src.hp = Math.max(0, src.hp - back);
      emit({ t: 'dmg', src: tgt.uid, uid: src.uid, ab: 'spell_ward', amt: back, crit: false, el: 'arcane', mult: 1, blocked: false, absorbed: 0, hp: src.hp, dot: true });
      if (src.hp <= 0) kill(src, tgt);
    }
    tgt.charge = Math.min(100, tgt.charge + (amt / tgt.st.maxHp) * 40);
    src.charge = Math.min(100, src.charge + (amt / tgt.st.maxHp) * 20);
    // Lifesteal heals from the hit as it would be without PvE class tuning, so a damage bonus never doubles as toughness.
    if (!dot && src.st.lifesteal && amt > 0) heal(src, src, Math.round(amt / (!opts.crowd && !opts.noPveTune && src.cls && !src.summoned && !src.hireling ? pveTune(src.cls, src.level, 'dealt') : 1) * src.st.lifesteal / 100), 'lifesteal');
    const contact = !THORNS.contactOnly || isContact(ab, src), splintered = has(tgt, 'splinter');
    const reflect = !dot && isPhys && amt > 0 && src.alive && src !== tgt ? (has(tgt, 'counter') ? 0.8 : 0) + (has(tgt, 'thornguard') && contact && !splintered ? 0.3 : 0) : 0;
    if (reflect) {
      const back = Math.max(1, Math.round(amt * reflect));
      src.hp = Math.max(0, src.hp - back);
      emit({ t: 'dmg', src: tgt.uid, uid: src.uid, ab: has(tgt, 'counter') ? 'riposte' : 'thornguard', amt: back, crit: false, el: 'physical', mult: 1, blocked: false, absorbed: 0, hp: src.hp, dot: true });
      if (src.hp <= 0) kill(src, tgt);
    }
    const thornKey = `${actionNo}|${src.uid}|${tgt.uid}`;
    if (!dot && isPhys && contact && !splintered && tgt.st.thorns && amt > 0 && src.alive && !(THORNS.oncePerAction && thornsFired.has(thornKey))) {
      thornsFired.add(thornKey);
      const back = Math.max(1, Math.round(amt * tgt.st.thorns / 100));
      src.hp = Math.max(0, src.hp - back);
      emit({ t: 'dmg', src: tgt.uid, uid: src.uid, ab: 'thorns', amt: back, crit: false, el: 'physical', mult: 1, blocked: false, absorbed: 0, hp: src.hp, dot: true });
      if (src.hp <= 0) kill(src, tgt);
    }
    if (tgt.hp <= 0) kill(tgt, src);
    // Item procs: on a crit, a chance to strike again (never from a proc or damage over time).
    if (crit && !ab.isProc && src.alive && tgt.alive) for (const p of src.procs || []) {
      if (p.on === 'crit' && r() * 100 < p.chance) damage(src, tgt, { kind: 'spell', id: p.id, element: p.element, isProc: true }, p.coef);
    }
    return amt;
  }

  function heal(src, tgt, amt, ab) {
    if (!tgt.alive || amt <= 0) return 0;
    if (!opts.noSuddenDeath && actionNo > SUDDEN_DEATH_AT) amt = Math.round(amt * Math.pow(0.9, actionNo - SUDDEN_DEATH_AT)); // Sudden Death also smothers healing
    amt = Math.round(amt * (1 + (tgt.st.healRecv || 0) / 100) * (has(tgt, 'wounded') ? 0.5 : 1));   // Wounded (Sunder): half healing
    if (opts.crowd && ab !== 'lifesteal' && !ABILITIES[ab]?.drain) amt = Math.round(amt * arenaHeal(src.level)); // Arena Wounds (drains and lifesteal are exempt)
    if (amt <= 0) return 0;
    const got = Math.min(amt, tgt.st.maxHp - tgt.hp);
    tgt.hp += got;
    if (!opts.crowd && got > 0 && !src.mob) for (const m of units) if (m.alive && m.mob && m.side !== src.side) tadd(m, src, got * THREAT.healShare);
    emit({ t: 'heal', src: src.uid, uid: tgt.uid, ab, amt: got, hp: tgt.hp });
    return got;
  }

  function cond(u, c) {
    switch (c?.type) {
      case 'always': return { ok: true };
      case 'firstAction': return { ok: u.actions === 0 };
      case 'selfHpBelow': return { ok: pctHp(u) * 100 < c.pct, target: u };
      case 'allyHpBelow': { const t = friends(u).filter(x => pctHp(x) * 100 < c.pct).sort(byLowPct)[0]; return { ok: !!t, target: t }; }
      case 'enemyCountAtLeast': return { ok: foes(u).length >= c.n };
      case 'targetLacksStatus': { const t = foes(u).filter(x => !has(x, c.status)).sort(byLowHp)[0]; return { ok: !!t, target: t }; }
      case 'enemyIsCaster': { const t = foes(u).filter(x => !has(x, 'silence') && [x.basic, ...x.abilities].some(k => SPELLISH.has(ABILITIES[k]?.kind))).sort(byLowHp)[0]; return { ok: !!t, target: t }; }
      case 'ultimateReady': return { ok: u.charge >= 100 };
      case 'enemyHasBuff': { const t = foes(u).filter(x => x.statuses.some(s => BUFFS.includes(s.type))).sort(byLowHp)[0]; return { ok: !!t, target: t }; }
      case 'enemyHpBelow': { const t = foes(u).filter(x => pctHp(x) * 100 < c.pct).sort(byLowPct)[0]; return { ok: !!t, target: t }; }
      case 'alone': return { ok: allies(u).length === 0 };
      case 'alliesAtLeast': return { ok: allies(u).length >= c.n };
      case 'allyUnderAttack': { // an ally was hit by an enemy after my last action: the hint is the attacker (to peel or taunt)
        const hit = allies(u).filter(x => (x.lastHitAt ?? -1) > (u.lastActAt ?? -1)).sort(byLowPct)[0];
        const by = hit && units.find(x => x.uid === hit.lastHitBy && x.alive && x.side !== u.side);
        return { ok: !!hit, target: by || undefined };
      }
      case 'otherAllyHpBelow': { const t = allies(u).filter(x => pctHp(x) * 100 < c.pct).sort(byLowPct)[0]; return { ok: !!t, target: t }; }
      case 'alliesHurt': { const hurt = friends(u).filter(x => !x.summoned && pctHp(x) * 100 < c.pct); return { ok: hurt.length >= 2, target: hurt.sort(byLowPct)[0] }; }
      case 'selfLacksStatus': return { ok: !has(u, c.status) };
      case 'targetArmourOverMr': { const t = foes(u).filter(x => x.st.armor * (has(x, 'armorUp') ? 1.3 : 1) > x.st.mr).sort(byLowHp)[0]; return { ok: !!t, target: t }; }
      case 'allyDown': { const t = downed(u)[0]; return { ok: !!t, target: t }; }
      case 'enemyIsHealer': { const t = foes(u).filter(x => [x.basic, ...(x.abilities || [])].some(k => ABILITIES[k]?.kind === 'heal')).sort(byLowHp)[0]; return { ok: !!t, target: t }; }
      default: return { ok: false };
    }
  }

  function usable(u, key) {
    const ab = ABILITIES[key];
    if (!ab) return false;
    const known = key === u.basic || u.abilities.includes(key) || key === u.ultimate || !!u.universal?.includes(key);
    if (!known) return false;
    if (ab.ultimate) return u.charge >= 100;
    if ((u.cds[key] || 0) > 0 || u.mana < ab.cost) return false;
    if (ab.firstActionOnly && u.actions > 0 && !has(u, 'stealth')) return false;     // openers: first action, or from Stealth
    if (ab.revive && !downed(u).length) return false;
    if (ab.allyOnly && !friends(u).some(x => x !== u && !x.summoned)) return false;
    if ((ab.effects || []).some(e => e.type === 'poly') && !foes(u).some(x => !has(x, 'poly') && !has(x, 'polyImmune'))) return false;   // nobody left to Polymorph
    if (ab.needsPet && !units.some(x => x.alive && x.summoner === u.uid)) return false;
    if (has(u, 'silence') && SPELLISH.has(ab.kind)) return false;
    if (ab.summon && units.some(x => x.alive && x.summoner === u.uid)) return false;
    return true;
  }

  function pickTarget(u, ab, hinted) {
    const enemies = foes(u);
    if (ab.target === 'ally-down') return (hinted && !hinted.alive && hinted.side === u.side) ? hinted : downed(u)[0];
    if (ab.target === 'enemy' || ab.target === 'chain') {
      // Crowd control (Polymorph, Freezing Trap) goes on the foe you are NOT fighting: the healthiest one not already
      // controlled, and never a boss when anything else is there.
      if (ab.ccTarget) {
        const isPoly = (ab.effects || []).some(e => e.type === 'poly');
        const free = enemies.filter(x => !has(x, 'poly') && !has(x, 'frozen') && !has(x, 'stealth') && !(isPoly && has(x, 'polyImmune')));
        const pool = free.filter(x => !(MOBS[x.mob]?.boss)).length ? free.filter(x => !(MOBS[x.mob]?.boss)) : free;
        if (pool.length) return [...pool].sort((a, b) => b.hp - a.hp)[0];
      }
      const seen = enemies.filter(x => !has(x, 'stealth'));       // a Stealthed foe can't be picked while anyone else is there
      if (seen.length && seen.length < enemies.length) enemies.splice(0, enemies.length, ...seen);
      const taunter = enemies.filter(x => has(x, 'taunt')).sort(byLowHp)[0];
      if (taunter) return taunter;
      if (hinted && hinted.alive && hinted.side !== u.side && !(opts.crowd && hinted.summoned)) return hinted;
      // In the Arena, fighters go for the rival Agent, not its pets (unless only pets are left).
      const pool = opts.crowd && enemies.some(x => !x.summoned) ? enemies.filter(x => !x.summoned) : enemies;
      // Monsters attack whoever they hold most threat against (ties: the weakest).
      if (u.mob && !opts.crowd) return pool.sort((a, b) => tget(u, b) - tget(u, a) || a.hp - b.hp)[0];
      return pool.sort(byLowHp)[0];
    }
    if (ab.target === 'ally-lowest') { const pool = ab.allyOnly ? friends(u).filter(x => x !== u && !x.summoned) : friends(u); return (hinted && hinted.alive && hinted.side === u.side && (!ab.allyOnly || hinted !== u)) ? hinted : pool.sort(byLowPct)[0]; }
    return u;
  }

  function choose(u) {
    for (const g of u.gambits) {
      const c = cond(u, g.if), tg = ABILITIES[g.use]?.toggle;
      // A toggle (Enchanted Quiver) in a gambit means "on while the condition holds": switch only when that changes.
      if (tg) { if (c.ok !== has(u, tg) && usable(u, g.use)) return { key: g.use }; continue; }
      if (c.ok && usable(u, g.use)) return { key: g.use, hint: c.target };
    }
    if (u.ultimate && usable(u, u.ultimate)) return { key: u.ultimate };
    // default: best expected damage among ready offensive abilities, else the basic attack
    let best = { key: u.basic, score: -1 };
    for (const key of [u.basic, ...u.abilities]) {
      const ab = ABILITIES[key];
      if (!usable(u, key) || !['phys', 'spell'].includes(ab.kind)) continue;
      const power = powerOf(u, ab);
      const coef = ab.coefs ? ab.coefs.reduce((a, b) => a + b, 0) : (ab.coef || 0) * (ab.hits || 1) * (ab.guaranteedCrit ? u.st.critDmg / 100 : 1) + (ab.splash || 0);
      const n = ab.target === 'all-enemies' ? foes(u).length : 1;
      const score = power * coef * n;
      if (score > best.score) best = { key, score };
    }
    return usable(u, best.key) ? { key: best.key } : { key: 'strike' };
  }

  function act(u, { key, hint }) {
    const ab = { ...ABILITIES[key], id: key };
    const target = pickTarget(u, ab, hint);
    emit({ t: 'act', n: actionNo, uid: u.uid, ab: key, target: target?.uid ?? null, ult: !!ab.ultimate });
    u.lastActAt = actionNo;
    let cost = ab.cost;
    if (u.set === 'arcaneFlow' && !u.flowUsed && ab.kind === 'spell' && cost > 0) { u.flowUsed = true; cost = 0; }
    if (u.passive === 'context_window' && (u.freeCasts || 0) < 3 && cost > 0) { u.freeCasts = (u.freeCasts || 0) + 1; cost = 0; }
    if (ab.ultimate) u.charge = 0; else { u.mana -= cost; if (ab.cd) u.cds[key] = Math.max(1, ab.cd + 1 - ((u.mastery?.[key] || 0) >= 5 ? 1 : 0)); }
    effects(u, ab, key, target);
    // Attacking (or any harmful spell) breaks your own Stealth.
    if ((ab.kind === 'phys' || ab.kind === 'spell') && has(u, 'stealth') && u.stealthFromKill !== actionNo) { u.statuses = u.statuses.filter(s => s.type !== 'stealth'); emit({ t: 'expire', uid: u.uid, status: 'stealth' }); }
    // Echo of the First Prompt: the first non-basic ability of the battle casts again, free.
    if (u.passive === 'echo_first_prompt' && !u.echoUsed && !ab.basic && !ab.ultimate && key !== 'strike' && u.alive && foes(u).length) {
      u.echoUsed = true;
      const again = pickTarget(u, ab, target?.alive ? target : null);
      emit({ t: 'act', n: actionNo, uid: u.uid, ab: key, target: again?.uid ?? null, ult: false, echo: true });
      effects(u, ab, key, again);
    }
  }

  function summonPet(u, kind, mm) {
    const bear = petUnit(u, kind, mm);
    if (!bear) return;
    const s = spawn(bear, u.side);
    s.summoned = true; s.summoner = u.uid; s.expires = opts.crowd ? ARENA.summonActions : 6; s.gauge = GAUGE * 0.5;
    emit({ t: 'summon', uid: s.uid, by: u.uid, name: s.name, hp: s.hp, maxHp: s.st.maxHp, pet: kind });
  }
  // Which rune a Runeforge picks: among the elements the Death Knight knows (RUNES, by level), the one that does most
  // against this foe: its affinity (elementMult), the knight's bonus for that element and his armour's element.
  function runeElement(u, foe) {
    let best = null, score = -1;
    for (const [el, lvl] of Object.entries(RUNES)) {
      if ((u.level || 1) < lvl) continue;
      const s = elementMult(el, foe?.affinity) * (1 + (u.st.elem?.[el] || 0) / 100) * (el === u.affinity ? 1.1 : 1);
      if (s > score + 1e-9) { best = el; score = s; }
    }
    return best || 'frost';
  }
  // The rune strike after an imbued weapon hit, and its element's extra: Frost may Chill, Fire may Burn, Storm arcs to a
  // second foe for half, Shadow heals the knight for 30% of it. Returns the damage dealt to the main target.
  function runeStrike(u, t, ab, key, el, share) {
    const k = IMBUE_COEF * (ab.imbueMult || 1) * share, hitAb = { kind: 'spell', id: key, element: el, runeStrike: true };
    const dealt = damage(u, t, hitAb, k, { element: el });
    if (dealt > 0 && t.alive && el === 'frost') applyStatus(u, t, { type: 'chill', chance: 25, turns: 2 }, hitAb, 0);
    if (dealt > 0 && t.alive && el === 'fire') applyStatus(u, t, { type: 'burn', chance: 20, turns: 3, powerCoef: 0.1 }, hitAb, 0);
    if (el === 'storm' && u.alive) { const t2 = foes(u).filter(x => x !== t).sort(byLowHp)[0]; if (t2) damage(u, t2, hitAb, k * 0.5, { element: el }); }
    if (el === 'shadow' && dealt > 0 && u.alive) heal(u, u, Math.max(1, Math.round(dealt * 0.3)), key);
    return dealt;
  }

  function effects(u, ab, key, target) {
    if (ab.kind === 'steal') {
      const holder = (target && target.statuses.some(s => BUFFS.includes(s.type))) ? target : foes(u).find(x => x.statuses.some(s => BUFFS.includes(s.type)));
      const buff = holder?.statuses.find(s => BUFFS.includes(s.type));
      if (buff) {
        holder.statuses = holder.statuses.filter(s => s !== buff);
        const mine = u.statuses.find(s => s.type === buff.type);
        if (mine) { mine.turns = Math.max(mine.turns, buff.turns); mine.power = Math.max(mine.power, buff.power); mine.stacks = Math.max(mine.stacks, buff.stacks); }
        else u.statuses.push({ ...buff, src: u.uid });
        emit({ t: 'steal', uid: u.uid, from: holder.uid, status: buff.type });
      } else if (target) damage(u, target, { ...ab, kind: 'phys' }, ab.coef);
      return;
    }

    if (ab.selfHpCostPct) { u.hp = Math.max(1, u.hp - Math.round(u.st.maxHp * ab.selfHpCostPct / 100)); emit({ t: 'dmg', src: u.uid, uid: u.uid, ab: key, amt: Math.round(u.st.maxHp * ab.selfHpCostPct / 100), crit: false, el: 'physical', mult: 1, blocked: false, absorbed: 0, hp: u.hp, dot: true }); }
    const masteryCharge = isPlainAbility(ab) ? MASTERY.charge * (u.mastery?.[key] || 0) : 0;
    if (ab.chargeGain || masteryCharge) u.charge = Math.min(100, u.charge + (ab.chargeGain || 0) + masteryCharge);
    if (ab.manaPct) u.mana = Math.min(u.st.maxMana, u.mana + Math.round(u.st.maxMana * ab.manaPct / 100));
    if (ab.cutCooldowns) for (const k of Object.keys(u.cds)) if (k !== key) u.cds[k] = Math.max(0, u.cds[k] - ab.cutCooldowns);
    if (ab.needsPet) {   // Kill Command: the companion strikes, with its own power
      const pet = units.find(x => x.alive && x.summoner === u.uid);
      if (pet && target?.alive) { damage(pet, target, { ...ab, id: key, power: pet.pet === 'wisp' ? 'spirit' : pet.pet === 'boar' ? undefined : 'finesse' }, ab.coef); }
      return;
    }
    if ((ab.kind === 'phys' || ab.kind === 'spell') && ab.noDamage) {   // pure control (Polymorph, Freezing Trap): no hit, so nothing breaks it
      if (target?.alive) for (const eff of ab.effects || []) applyStatus(u, target, eff, ab, u.mastery?.[key] || 0);
      return;
    }
    // Enchanted Quiver: a finesse attack paid with mana hits 75% as a spell in the Ranger's element and 25% as a
    // plain physical arrow (QUIVER_MAGIC), so armour, dodge and thorns still matter a little.
    let quiverPhys = null;
    if (ab.kind === 'phys' && ab.power === 'finesse' && has(u, 'quiver') && u.mana >= QUIVER_COST) {
      u.mana -= QUIVER_COST;
      quiverPhys = { ...ab };
      ab = { ...ab, kind: 'spell', element: ab.element && ab.element !== 'physical' ? ab.element : (u.affinity && u.affinity !== 'physical' ? u.affinity : 'arcane'), magicArrow: true };
    }
    if (ab.kind === 'phys' || ab.kind === 'spell') {
      const focused = u.statuses.find(s => s.type === 'focus');
      if (focused) { u.statuses = u.statuses.filter(s => s !== focused); ab = { ...ab, guaranteedCrit: true, coef: (ab.coef || 0) * 1.6, coefs: ab.coefs?.map(c => c * 1.6) }; }
      let hits = [];
      // Area attacks pass over a Polymorphed or Frozen foe (it is out of the fight until it wakes), unless nothing else is left.
      const held = (x) => has(x, 'poly') || has(x, 'frozen'), areaFoes = foes(u).some(x => !held(x)) ? foes(u).filter(x => !held(x)) : foes(u);
      if (ab.target === 'all-enemies') hits = areaFoes.sort((a, b) => a.order - b.order).map(t => [t, ab.coef]);
      else if (ab.target === 'chain') {
        const first = target; const rest = areaFoes.filter(x => x !== first).sort(byLowHp);
        hits = [first, ...rest].slice(0, ab.coefs.length).map((t, i) => [t, ab.coefs[i]]);
      } else {
        for (let h = 0; h < (ab.hits || 1); h++) hits.push([target, ab.coef]);
        if (ab.splash) { const second = foes(u).filter(x => x !== target).sort(byLowHp)[0]; if (second) hits.push([second, ab.coef * ab.splash]); }
      }
      const extra = ab.missingHpPct ? (u.st.maxHp - u.hp) * ab.missingHpPct / 100 / Math.max(1, powerOf(u, ab)) : 0;
      for (const [t, coef] of hits) {
        if (!t.alive) continue;
        const crit0 = ab.guaranteedCrit || !!ab.critVsStatus?.some(st => has(t, st));
        const dealt = quiverPhys
          ? damage(u, t, ab, (coef + extra) * QUIVER_MAGIC, { guaranteedCrit: crit0 }) + (t.alive ? damage(u, t, quiverPhys, (coef + extra) * (1 - QUIVER_MAGIC), { guaranteedCrit: crit0 }) : 0)
          : damage(u, t, ab, coef + extra, { guaranteedCrit: crit0 });
        // A Death Knight's rune strike: an imbued weapon attack also hits for IMBUE_COEF of spell power in the rune's element.
        const rune = !quiverPhys && ab.kind === 'phys' && u.alive && t.alive ? (u.statuses.find(s => s.type === 'imbue')?.el || ab.imbueDefault || null) : null;
        const runeDealt = rune ? runeStrike(u, t, ab, key, rune, (coef + extra) / (ab.coef || 1)) : 0;
        if (dealt + runeDealt > 0 && ab.drain && u.alive) heal(u, u, Math.round((dealt + runeDealt) * ab.drain), key);
        if (dealt > 0) for (const eff of ab.effects || []) applyStatus(u, t, eff, ab, u.mastery?.[key] || 0);
        // Moonless Step: a knockout puts you straight back into Stealth (kept past this attack, see act()).
        if (ab.onKill && !t.alive && u.alive) { for (const eff of ab.onKill) applyStatus(u, u, eff, null, 0); if (ab.onKill.some(e => e.type === 'stealth')) u.stealthFromKill = actionNo; }
        if (!u.alive) break;
      }
      // Wyvern Volley: the companion joins the attack on the first target (or the next foe if it fell).
      if (ab.petStrike && u.alive) {
        const pet = units.find(x => x.alive && x.summoner === u.uid && x.companion);
        const t = target?.alive ? target : foes(u).sort(byLowHp)[0];
        if (pet && t) damage(pet, t, { kind: 'phys', id: key, power: pet.pet === 'wisp' ? 'spirit' : pet.pet === 'boar' ? undefined : 'finesse', element: ab.element }, ab.petStrike);
      }
      if (ab.cleanseSelf && u.alive) { const before = u.statuses.length; u.statuses = u.statuses.filter(s => !HOSTILE.includes(s.type)); if (u.statuses.length < before) emit({ t: 'cleanse', uid: u.uid }); }
      // Grand Finale: the whole party heals and is lifted; Army of the Dead: a skeleton rises if no minion is up.
      if (u.alive && (ab.allyHealPct || ab.allyEffects)) for (const f of friends(u)) {
        if (ab.allyHealPct) heal(u, f, Math.round((f.hpBasis ?? f.st.maxHp) * ab.allyHealPct / 100), key);
        for (const eff of ab.allyEffects || []) applyStatus(u, f, eff, null, 0);
      }
      if (u.alive && ab.alsoSummon && !units.some(x => x.alive && x.summoner === u.uid)) summonPet(u, ab.alsoSummon, 1);
    } else if (ab.kind === 'heal' && ab.revive) {   // Rebirth: a knocked-out ally stands back up
      const t = target && !target.alive && target.side === u.side ? target : downed(u)[0];
      if (!t) return;
      t.alive = true; t.statuses = []; t.gauge = 0;
      t.hp = Math.max(1, Math.round(t.st.maxHp * ab.revive / 100));
      emit({ t: 'revive', uid: t.uid, by: u.uid, hp: t.hp });
    } else if (ab.kind === 'heal') {
      // Grove of Rebirth: once per battle, a knocked-out ally stands back up before the heal lands.
      if (ab.reviveOnce && !u.groveRevived) {
        const down = downed(u)[0];
        if (down) { u.groveRevived = true; down.alive = true; down.statuses = []; down.gauge = 0; down.hp = Math.max(1, Math.round(down.st.maxHp * ab.reviveOnce / 100)); emit({ t: 'revive', uid: down.uid, by: u.uid, hp: down.hp }); }
      }
      const v = 0.95 + 0.1 * r();
      const tg = ab.target === 'all-allies' ? friends(u) : [target];
      for (const t of tg) {
        const mm = 1 + MASTERY.power * (u.mastery?.[key] || 0);
        const amt = ab.healPctMax ? Math.round((t.hpBasis ?? t.st.maxHp) * ab.healPctMax / 100 * mm) : Math.round(u.st.heal * ab.coef * healBonus(u) * v * mm);
        heal(u, t, amt, key);
        if (ab.cleanse) { const before = t.statuses.length; t.statuses = t.statuses.filter(s => !HOSTILE.includes(s.type)); if (t.statuses.length < before) emit({ t: 'cleanse', uid: t.uid }); }
        for (const eff of ab.effects || []) applyStatus(u, t, eff, null, u.mastery?.[key] || 0);
      }
    } else if (ab.kind === 'buff') {
      // Buffs land on yourself, or on the most hurt ally for an ally-target buff (Ironbark). A buff can also heal a share
      // of max HP and shake off ailments (Rallying Cry): it is not a spell, so Silence does not stop it.
      if (ab.toggle && has(u, ab.toggle)) { u.statuses = u.statuses.filter(s => s.type !== ab.toggle); emit({ t: 'expire', uid: u.uid, status: ab.toggle, toggled: true }); return; }
      // Runeforge: imbue the weapon with the element that hurts the likely target most (see runeElement).
      if (ab.runeforge) {
        const foe = foes(u).sort(byLowHp)[0], el = runeElement(u, foe), mm = u.mastery?.[key] || 0, turns = 11 + (mm >= MASTERY.longerFrom ? 1 : 0);
        u.statuses = u.statuses.filter(s => s.type !== 'imbue');
        u.statuses.push({ type: 'imbue', turns, power: 0, stacks: 1, src: u.uid, el });
        emit({ t: 'status', uid: u.uid, status: 'imbue', turns, stacks: 1, el });
        return;
      }
      // Party songs (target all-allies) land on you and every ally; other buffs on you, or on the most hurt ally.
      const whos = ab.target === 'all-allies' ? friends(u) : [ab.target === 'ally-lowest' && target?.alive ? target : u];
      for (const who of whos) {
        if (ab.healPctMax) heal(u, who, Math.round((who.hpBasis ?? who.st.maxHp) * ab.healPctMax / 100 * (1 + MASTERY.power * (u.mastery?.[key] || 0))), key);
        if (ab.cleanse) { const before = who.statuses.length; who.statuses = who.statuses.filter(s => !HOSTILE.includes(s.type)); if (who.statuses.length < before) emit({ t: 'cleanse', uid: who.uid }); }
        for (const eff of ab.effects || []) applyStatus(u, who, eff, null, u.mastery?.[key] || 0);
      }
    } else if (ab.kind === 'summon') {
      summonPet(u, ab.summon, 1 + MASTERY.power * (u.mastery?.[key] || 0));
    }
  }

  // Start of a unit's own action: damage/heal over time, tick durations, regen, cooldowns.
  function upkeep(u) {
    for (const s of [...u.statuses]) {
      if (DOT_ELEMENT[s.type]) {
        const src = units.find(x => x.uid === s.src) || u;
        const dealt = damage(src, u, { kind: s.type === 'bleed' ? 'phys' : 'spell', id: s.type }, s.power * s.stacks, { dot: true, element: DOT_ELEMENT[s.type] });
        if (s.type === 'siphon' && dealt > 0 && src.alive && src !== u) heal(src, src, Math.max(1, Math.round(dealt * 0.5)), 'siphon_life');
        if (!u.alive) return;
      }
      if (s.type === 'regrow') heal(units.find(x => x.uid === s.src) || u, u, s.power, 'regrow');
    }
    u.mana = Math.min(u.st.maxMana, u.mana + u.st.regen);
    for (const k of Object.keys(u.cds)) if (u.cds[k] > 0) u.cds[k] -= 1;
    u.charge = Math.min(100, u.charge + 8);
  }

  // End of a unit's own action (or skipped turn): durations count down, so a 1-turn
  // Silence or Stun always costs its holder exactly one action.
  function endTurn(u) {
    u.actions += 1;
    for (const s of u.statuses) if (s.type !== 'shield' && s.type !== 'stun') s.turns -= 1;
    const expired = u.statuses.filter(s => s.type !== 'stun' && s.type !== 'shield' && s.turns <= 0);
    for (const s of expired) emit({ t: 'expire', uid: u.uid, status: s.type });
    if (expired.length) u.statuses = u.statuses.filter(s => !expired.includes(s));
    if (expired.some(s => s.type === 'poly')) polyImmunity(u);
  }

  // Live duels: each round both players pick one action for their Agent. A controlled Agent takes its
  // pick from opts.duel.rounds; an extra action from speed (before the rival has acted this round)
  // follows the Agent's gambits. With no pick left, the battle pauses and says who must choose.
  const duel = opts.duel ? { round: 0, used: [false, false] } : null;
  let paused = null;
  const duelSide = (u) => (u.side === 'A' ? 0 : 1);
  function useDuelTurn(u) {
    const S = duelSide(u);
    duel.used[S] = true;
    if (duel.used[0] && duel.used[1]) { duel.round += 1; duel.used = [false, false]; }
  }
  function duelChoice(u) {
    const S = duelSide(u);
    if (duel.used[S]) return choose(u); // extra action from speed
    // duel.fill: rounds with no pick left take this pick instead of pausing (a live boss fight left unfinished is
    // completed by the Agent's gambits).
    const want = (opts.duel.rounds[duel.round] || [opts.duel.fill, opts.duel.fill])[S];
    useDuelTurn(u);
    if (want === 'auto') return choose(u); // timed out or handed to gambits
    const key = want === 'basic' ? u.basic : want;
    if (key && usable(u, key)) return { key };
    return usable(u, u.basic) ? { key: u.basic } : { key: 'strike' };
  }

  let winner = null;
  while (actionNo < (opts.maxActions || MAX_ACTIONS)) {
    if (sideDown('A') || sideDown('B')) break;
    // advance the action gauge to the next actor
    let next = null, wait = Infinity;
    for (const u of units) {
      if (!u.alive) continue;
      const w = (GAUGE - u.gauge) / speedOf(u);
      if (w < wait - 1e-9 || (Math.abs(w - wait) <= 1e-9 && (speedOf(u) > speedOf(next) || (speedOf(u) === speedOf(next) && u.order < next.order)))) { next = u; wait = w; }
    }
    for (const u of units) if (u.alive) u.gauge += speedOf(u) * wait;
    next.gauge -= GAUGE;
    actionNo += 1;
    cheer(next.side, 2 + (next.scores?.pre || 0) / 10);

    const u = next;
    if (duel && !opts.duel.fill && !u.summoned && !duel.used[duelSide(u)] && duel.round >= opts.duel.rounds.length) { paused = { round: duel.round, side: u.side }; break; }
    upkeep(u);
    if (!u.alive) continue;
    if (u.summoned && --u.expires < 0) { u.alive = false; emit({ t: 'vanish', uid: u.uid }); continue; }
    if (u.companion && !u.summoned && u.petDownAt != null && u.actions - u.petDownAt >= PET_RESPAWN && !units.some(x => x.alive && x.summoner === u.uid && x.companion)) { u.petDownAt = null; spawnCompanion(u, true); }
    // Polymorphed or Frozen: the turn is lost, and the effect counts down like any other (damage breaks it early).
    const held = u.statuses.find(s => s.type === 'poly' || s.type === 'frozen');
    if (held) { emit({ t: 'skip', n: actionNo, uid: u.uid, reason: held.type }); if (duel && !u.summoned && !duel.used[duelSide(u)]) useDuelTurn(u); endTurn(u); continue; }
    const stun = u.statuses.find(s => s.type === 'stun');
    if (stun) { u.statuses = u.statuses.filter(s => s !== stun); emit({ t: 'skip', n: actionNo, uid: u.uid, reason: 'stun' }); if (duel && !u.summoned && !duel.used[duelSide(u)]) useDuelTurn(u); endTurn(u); continue; }
    // Duels: an extra action from speed would end the Guard or Riposte the player picked this round (both last until
    // your next action), and the player never chose it, so a braced Agent holds its stance instead.
    if (duel && !u.summoned && duel.used[duelSide(u)] && u.statuses.some(s => s.type === 'guard' || s.type === 'counter')) {
      emit({ t: 'skip', n: actionNo, uid: u.uid, reason: 'braced' }); continue;
    }
    act(u, duel && !u.summoned ? duelChoice(u) : choose(u));
    if (u.alive) endTurn(u);
  }

  if (paused) {
    // Where the duel stands, and what each Agent could choose next.
    const view = units.filter(x => !x.summoned || x.alive).map(x => ({ uid: x.uid, side: x.side, name: x.name, hp: x.hp, maxHp: x.st.maxHp, mana: x.mana, maxMana: x.st.maxMana, pet: x.pet || null, mob: x.mob || null,
      charge: x.charge, alive: x.alive, summoned: !!x.summoned, statuses: x.statuses.map(s => ({ type: s.type, turns: s.turns, stacks: s.stacks })),
      options: x.summoned ? [] : [x.basic, ...x.abilities, ...(x.ultimate ? [x.ultimate] : []), ...(x.universal || [])].map(key => ({ key, ready: usable(x, key), cd: x.cds[key] || 0, cost: ABILITIES[key]?.cost || 0 })) }));
    return { rules: RULES_VERSION, seed: String(seed), paused, units: view, actions: actionNo, log };
  }
  const aDown = sideDown('A'), bDown = sideDown('B');
  winner = aDown && !bDown ? 'B' : bDown && !aDown ? 'A' : 'draw';
  emit({ t: 'end', winner, actions: actionNo });
  const survivors = units.filter(u => !u.summoned).map(u => ({ uid: u.uid, name: u.name, side: u.side, hp: u.hp, maxHp: u.st.maxHp, alive: u.alive }));
  const pets = units.filter(u => u.companion).map(u => ({ uid: u.uid, owner: u.summoner, alive: u.alive }));   // Ranger companions, for secrets
  return { rules: RULES_VERSION, seed: String(seed), winner, actions: actionNo, survivors, pets, log, hash: fnv1a(JSON.stringify(log)) };
}

/* ------------------------------------------------------------- Reading */

// One human-readable line per event, for logs and tests.
export const STATUS_NAMES = { imbue: 'Runic Imbue', burn: 'Burn', bleed: 'Bleed', chill: 'Chill', stun: 'Stun', silence: 'Silence', taunt: 'Taunt', armorUp: 'Iron Skin (+30% armour)', evasive: 'Evasive (+25% dodge)', decoy: 'Hallucination', shield: 'Shield', haste: 'Haste', regrow: 'Regrowth', roar: 'Crowd Roar (+20% damage and Speed)', guard: 'Guard (−50% damage taken)', counter: 'Riposte (counter stance)', sunder: 'Sunder (−25% armour)', empower: 'Empowered (+25% damage)', focus: 'Focused (next attack +60%, crit)', thornguard: 'Thornguard', quiver: 'Enchanted Quiver (magical arrows)', splinter: 'Splintered (no thorns)', wounded: 'Wounded (−50% healing received)', polyImmune: 'Polymorph-proof', wall: 'Shield Wall (−35% damage taken)', wardUp: 'Warded (+30% magic resist)', reflect: 'Spell Ward (−40% spell damage, reflects 30%)', blink: 'Blink (next attack misses)', stealth: 'Stealth', poly: 'Polymorphed', frozen: 'Frozen', corruption: 'Corruption', siphon: 'Siphon Life', haunted: 'Haunted (+20% Shadow damage taken)', moonfire: 'Moonfire', entangle: 'Entangled', poison: 'Poison', bark: 'Barkskin (−25% damage taken)', poisonBlades: 'Poisoned Blades', intervene: 'Intervene (protected)', deathward: 'Unyielding (cannot be knocked out)', marked: 'Marked (+20% damage taken)', weakened: 'Weakened (−20% damage dealt)', blight: 'Blight' };

export function describe(ev, names) {
  const n = (uid) => names[uid] || uid;
  const st = (s) => STATUS_NAMES[s] || s;
  const ab = (k) => ABILITIES[k]?.name || k;
  switch (ev.t) {
    case 'start': return `Battle begins: ${ev.units.map(u => `${u.name} (${u.hp} HP)`).join(' vs ')}`;
    case 'steal': return `  ${n(ev.uid)} steals ${st(ev.status)} from ${n(ev.from)}`;
    case 'act': return `${n(ev.uid)} ${ev.echo ? 'echoes' : 'uses'} ${ab(ev.ab)}${ev.ult ? ' (ULTIMATE)' : ''}${ev.target && ev.target !== ev.uid ? ` on ${n(ev.target)}` : ''}`;
    case 'dmg': if (!ev.amt && ev.absorbed) return `  ${n(ev.uid)}'s shield absorbs ${ev.absorbed}${ev.shieldLeft === 0 ? ' and breaks' : ev.shieldLeft ? ` (${ev.shieldLeft} shield left)` : ''}`;
      return `  ${n(ev.uid)} takes ${ev.amt}${ev.rune ? ` ${ev.el[0].toUpperCase()}${ev.el.slice(1)} rune damage` : ''}${ev.absorbed ? ` (shield absorbs ${ev.absorbed}${ev.shieldLeft === 0 ? ' and breaks' : ''})` : ''}${ev.crit ? ' CRIT' : ''}${ev.blocked ? ' (blocked)' : ''}${ev.mult > 1 ? ' (super effective)' : ev.mult < 1 ? ' (resisted)' : ''}${ev.dot ? ` from ${st(ev.ab)}` : ''} → ${ev.hp} HP`;
    case 'heal': return `  ${n(ev.uid)} heals ${ev.amt} → ${ev.hp} HP`;
    case 'miss': return ev.stealth ? `  ${n(ev.uid)} is in Stealth and can't be hit` : ev.blink ? `  ${n(ev.uid)} blinks away` : ev.decoy ? `  ${n(ev.uid)}'s hallucination takes the hit` : `  ${n(ev.uid)} dodges`;
    case 'deathward': return `  ${n(ev.uid)} refuses to fall (Unyielding) and stands on 1 HP`;
    case 'revive': return `  ${n(ev.uid)} is brought back by Rebirth (${ev.hp} HP)`;
    case 'intercept': return `  ${n(ev.uid)} intervenes and takes the hit meant for ${n(ev.for)}`;
    case 'status': return `  ${n(ev.uid)} gains ${st(ev.status)}${ev.el ? ` (${ev.el[0].toUpperCase()}${ev.el.slice(1)})` : ''}${ev.stacks > 1 ? ` ×${ev.stacks}` : ''}`;
    case 'resist': return ev.legendary ? `  ${n(ev.uid)} uses a Legendary Resistance against ${st(ev.status)} (${ev.left} left)` : ev.immune ? `  ${n(ev.uid)} is immune to ${st(ev.status)}` : `  ${n(ev.uid)} resists ${st(ev.status)}`;
    case 'expire': return ev.broken ? `  ${n(ev.uid)}'s ${st(ev.status)} breaks` : `  ${n(ev.uid)}'s ${st(ev.status)} fades`;
    case 'cleanse': return `  ${n(ev.uid)} is cleansed`;
    case 'skip': return ev.reason === 'braced' ? `${n(ev.uid)} holds their stance` : ev.reason === 'poly' ? `${n(ev.uid)} is Polymorphed and can't act` : ev.reason === 'frozen' ? `${n(ev.uid)} is Frozen and can't act` : `${n(ev.uid)} is stunned and loses a turn`;
    case 'summon': return `  ${ev.name} appears (${ev.hp} HP)`;
    case 'vanish': return `  ${n(ev.uid)} vanishes`;
    case 'ko': return `  ${n(ev.uid)} is knocked out!`;
    case 'end': return ev.winner === 'draw' ? `Draw after ${ev.actions} actions` : `Side ${ev.winner} wins after ${ev.actions} actions`;
    default: return JSON.stringify(ev);
  }
}
