import { TZ_OFFSET_MS, TZ_ISO, worldDay, dayAt } from './worldtime.js';
// Agents of Claude — the Org Arena ("the Pit"), rules version 1.
//
// Nobody writes anyone else's record. Each player appends their own challenges to `bouts/<their id>`;
// every client replays all bouts in time order and derives the same ladder: ranks, traits, scars,
// nemeses, humiliations and earnings. Recent bouts keep both snapshots, so any client can re-simulate
// them, and a bout whose stored result doesn't match its re-simulation is flagged and ignored.

import { trustedOld } from './trusted.js';
import { makeRng, fnv1a } from './rng.js';
import { simulate, makeAgentUnit, RULES_EPOCH, rulesOf } from './battle.js';
import { snapIssues } from './verify.js';
import { replaySnap } from './items.js';

export const ARENA_RULES = RULES_EPOCH;
// Epoch 5 changed only Fair Duels, so Pit bouts and Galas recorded under epoch 4 still replay exactly.
// Galas set aside by hand (day|champion). The 2026-11-20 Gala failed its re-simulation from the epoch-6 forge change
// until build 121 (epoch 7) re-recorded it and it counted again for about an hour; with epoch 8 its record could no
// longer be checked, and the player chose to keep the ladder as it stood before build 121.
const REJECTED_GALAS = ['2026-11-20|u_RVxJsls0fr3BQiIfStL1aw'];   // day|champion
const PIT_SAME = [];   // older epochs that still replay the same: none since epoch 7 (all abilities) and 8 (class balance)
export const GALA_AGREE = 3;   // matching recorders needed for a Gala older than the kept bout history   // stored on bouts and Galas as `v`; see battle.js rulesOf
export const CHALLENGES_PER_DAY = 5;
export const SCOUT_COST = 3; // Intel
export const SNAPSHOT_KEEP = 10; // at least this many recent bouts keep full snapshots for verification
export const VERIFY_DAYS = 14;   // bouts this recent must carry snapshots; older compacted ones are trusted history

export const TIERS = [
  { key: 'champion', name: 'Arena Champion', seats: 1 },
  { key: 'warlord', name: 'Warlord', seats: 4 },
  { key: 'captain', name: 'Captain', seats: 12 },
  { key: 'pit', name: 'Pit Fighter', seats: Infinity },
];
const TIER_START = [0, 1, 5, 17];
export const tierAt = (index) => (index < 1 ? 0 : index < 5 ? 1 : index < 17 ? 2 : 3);

export const TRAITS = {
  fireproof:      { kind: 'strength', name: 'Fireproof', desc: 'Immune to Burn; takes 25% less Fire damage.' },
  frostproof:     { kind: 'strength', name: 'Frostproof', desc: 'Immune to Chill; takes 25% less Frost damage.' },
  stormproof:     { kind: 'strength', name: 'Stormproof', desc: 'Takes 25% less Storm damage.' },
  natureproof:    { kind: 'strength', name: 'Rooted', desc: 'Takes 25% less Nature damage.' },
  shadowproof:    { kind: 'strength', name: 'Shadow-Wise', desc: 'Takes 25% less Shadow damage.' },
  radiantproof:   { kind: 'strength', name: 'Sun-Blind', desc: 'Takes 25% less Radiant damage.' },
  enraged_shadow: { kind: 'strength', name: 'Enraged by Shadow', desc: '+20% damage for 3 actions after taking Shadow damage.' },
  beast_slayer:   { kind: 'strength', name: 'Beast Slayer', desc: '+25% damage against summons and pets.' },
  afraid_crowd:   { kind: 'weakness', name: 'Afraid of the Crowd', desc: '−15% damage while the crowd favours the opponent.' },
  vuln_ambush:    { kind: 'weakness', name: 'Vulnerable to Ambush', desc: "Takes double damage from an opponent's first action." },
  brittle_guard:  { kind: 'weakness', name: 'Brittle Guard', desc: 'Shields, guard and block are 40% weaker.' },
};
const BIRTH_STRENGTHS = ['fireproof', 'enraged_shadow', 'beast_slayer', 'frostproof', 'stormproof'];
const BIRTH_WEAKNESSES = ['afraid_crowd', 'vuln_ambush', 'brittle_guard'];

// Every Agent's birth traits, fixed by its id.
export function birthTraits(agentId) {
  const r = makeRng(`arena-birth|${agentId}`);
  return [BIRTH_STRENGTHS[Math.floor(r() * BIRTH_STRENGTHS.length)], BIRTH_WEAKNESSES[Math.floor(r() * BIRTH_WEAKNESSES.length)]];
}

export const traitInfo = (k) => k.startsWith('haunted:') ? { kind: 'weakness', name: 'Haunted', desc: '−10% damage against the Agent who humiliated them.', foe: k.slice(8) } : TRAITS[k];

/* ------------------------------------------------------------------ Fight */

// The mods each side brings into a bout, from the ladder state at that moment.
export function modsFor(state, me, foe) {
  const s = state.agents[me] || newAgentState(me);
  const foeMult = (s.nemesis === foe ? 1.15 : 1) * (s.traits.includes(`haunted:${foe}`) ? 0.9 : 1);
  return { traits: s.traits.filter(k => !k.startsWith('haunted:')), scars: s.scars, foeMult: Math.round(foeMult * 1000) / 1000 };
}

function arenaUnit(snap, id, mods) {
  const u = makeAgentUnit(snap, { id, level: snap.level });
  u.traits = mods.traits || [];
  u.scores = { ...u.scores, pre: (u.scores.pre || 0) + (mods.scars || 0) };
  if (mods.foeMult && mods.foeMult !== 1) u.foeMult = mods.foeMult;
  return u;
}

// One Arena fight. a = challenger (side A), d = defender (side B).
export function arenaFight(seed, aSnap, dSnap, aMods, dMods) {
  const res = simulate(`arena|${seed}`, [arenaUnit(aSnap, 'challenger', aMods)], [arenaUnit(dSnap, 'defender', dMods)], { crowd: true });
  const end = Object.fromEntries(res.survivors.map(u => [u.side, Math.round(100 * Math.max(0, u.hp) / u.maxHp)]));
  // the element that dealt each side the most damage (for Adaptation)
  const taken = { A: {}, B: {} };
  for (const e of res.log) if (e.t === 'dmg' && e.amt > 0) { const side = e.uid[0]; taken[side][e.el || 'physical'] = (taken[side][e.el || 'physical'] || 0) + e.amt; }
  const top = (m) => Object.entries(m).sort((x, y) => y[1] - x[1])[0]?.[0] || 'physical';
  return { winner: res.winner === 'A' ? 'challenger' : 'defender', hash: res.hash, actions: res.actions, log: res.log,
    aHp: end.A ?? 0, dHp: end.B ?? 0, aEl: top(taken.A), dEl: top(taken.B) };
}

const FOE_MULTS = new Set([1, 1.15, 0.9, 1.035]);
function plausibleMods(m) {
  return !!m && Array.isArray(m.traits) && m.traits.every(k => TRAITS[k]) && m.traits.length <= 10
    && Number.isInteger(m.scars) && m.scars >= 0 && m.scars <= 5 && FOE_MULTS.has(m.foeMult);
}

/* ----------------------------------------------------------------- Ladder */

function newAgentState(id) {
  return { id, traits: birthTraits(id), scars: 0, wins: 0, losses: 0, defences: 0, beatenBy: {}, beat: {}, nemesis: null, nemesisWins: 0,
    brands: 0, elLosses: {}, gold: 0, intel: 0, trophies: [], fought: [], streak: 0, lastLossAt: 0, history: [] };
}

/**
 * Replay every bout. agents: [{ id, createdAt }]; boutsByOwner: { ownerId: [bout] }.
 * A bout: { id, at, day, c (challenger), d (defender), seed, winner, aHp, dHp, aEl, dEl, hash, aMods, dMods, aSnap?, dSnap? }.
 * verify: re-simulate bouts that carry snapshots and drop any that don't match.
 */
export function replayLadder(agents, boutsByOwner, { verify = true, galas = {}, now = 0, trustOld = trustedOld.bout } = {}) {
  const known = new Set(agents.map(a => a.id));
  // No creation date, a malformed one, or one from before the game existed sorts last, never first: a made-up early
  // date must not take seat 1.
  const created = (a) => (typeof a.createdAt === 'string' && Date.parse(a.createdAt) >= GAME_LAUNCH ? new Date(Date.parse(a.createdAt)).toISOString() : '\uffff');   // a date from before the game existed is no date
  const order = [...agents].sort((x, y) => created(x).localeCompare(created(y)) || x.id.localeCompare(y.id)).map(a => a.id);
  const state = { order, agents: Object.fromEntries(order.map(id => [id, newAgentState(id)])), bouts: [], flagged: [], feed: [] };
  // A bout counts only if it is well formed: its seed names both players and its time, its day matches its time,
  // at most CHALLENGES_PER_DAY a day, and (when recent) it carries the snapshots everyone re-simulates.
  const perDay = {}, recent = (now || Date.now()) - VERIFY_DAYS * 86_400_000;
  const all = Object.entries(boutsByOwner || {}).flatMap(([owner, list]) => (Array.isArray(list) ? list : []).slice(-2000).filter(b => b && typeof b === 'object' && b.c === owner && known.has(b.d) && b.c !== b.d
    && saneAt(b.at, now) && b.seed === `${b.c}|${b.d}|${b.at}` && b.day === sastDate(b.at) && typeof b.id === 'string'));
  all.sort((x, y) => (x.at - y.at) || x.id.localeCompare(y.id));
  const counted = all.filter(b => { const k = `${b.c}|${b.day}`; perDay[k] = (perDay[k] || 0) + 1; return perDay[k] <= CHALLENGES_PER_DAY; });
  state.firstBoutAt = counted[0]?.at ?? null;
  // Galas run on the timeline too, between bouts.
  const galaList = Object.entries(galas || {}).filter(([, g]) => g && typeof g === 'object').map(([day, g]) => ({ ...g, day, gala: true })).filter(g => saneAt(g.at, now)).sort((x, y) => x.at - y.at);
  const timeline = [...counted, ...galaList].sort((x, y) => (x.at - y.at) || (x.gala ? -1 : 0) - (y.gala ? -1 : 0));
  state.week = { start: weekStart(timeline[0]?.at || now || 0), tiers: {}, bouts: {}, losses: {} };
  snapshotWeek(state);
  for (const b of timeline) {
    closeWeeks(state, b.at);
    // One broken record must never stop the replay for everyone: it is flagged and skipped.
    try { replayOne(state, b, verify, recent, trustOld); }
    catch { state.flagged.push({ id: b.gala ? `gala-${b.day}` : b.id, by: b.gala ? null : b.c, reason: 'a malformed record' }); }
  }
  if (now) closeWeeks(state, now);
  state.rank = Object.fromEntries(state.order.map((id, i) => [id, i]));
  return state;
}
// A record's time must be a real moment: not before the game's calendar starts, and not in the future (a future
// time would sidestep the daily cap and make every page walk centuries of weeks).
export const AT_SLACK_MS = 5 * 60_000;
// The first day anything in the game could have happened (the first world opened on 18 November 2026, SAST).
export const GAME_LAUNCH = Date.parse('2026-11-18T00:00:00+02:00');
export const saneAt = (at, now = 0) => Number.isFinite(at) && at >= MONDAY_EPOCH && at < 4e12 && (!now || at <= now + AT_SLACK_MS);
function replayOne(state, b, verify, recent, trustOld) {
  {
    if (b.gala) { applyGala(state, b, verify); return; }
    // A bout's mods should match the ladder at that moment. Two players fighting at nearly the same time
    // can see slightly different ladders, so a mismatch is tolerated if the stored mods are plausible.
    if (!plausibleMods(b.aMods) || !plausibleMods(b.dMods)) { state.flagged.push({ id: b.id, by: b.c, reason: 'impossible traits or bonuses' }); return; }
    if (verify && !(b.aSnap && b.dSnap) && b.at >= recent) { state.flagged.push({ id: b.id, by: b.c, reason: 'a recent bout without the snapshots to check it' }); return; }
    const rules = rulesOf(b.v, b.at, PIT_SAME);
    if (verify && rules === 'bad') { state.flagged.push({ id: b.id, by: b.c, reason: 'recorded under combat rules this page does not run (reload the game)' }); return; }
    // An old-rules bout can't be re-simulated, and its epoch tag and date are its owner's own word: it counts only if it
    // was on file when the rules changed (engine/trusted.js).
    if (verify && rules === 'old' && !trustOld(b)) { state.flagged.push({ id: b.id, by: b.c, reason: 'an old-rules bout that was not on file when the rules changed' }); return; }
    if (verify && b.aSnap && b.dSnap) {
      const bad = snapIssues(b.aSnap).length ? b.c : snapIssues(b.dSnap).length ? b.d : null;
      if (bad) { state.flagged.push({ id: b.id, by: b.c, reason: bad === b.c ? 'impossible attributes or gear' : 'impossible opponent snapshot' }); return; }
    }
    if (verify && b.aSnap && b.dSnap && rules === 'current') {
      const f = arenaFight(b.seed, replaySnap(b.aSnap, b.v), replaySnap(b.dSnap, b.v), b.aMods, b.dMods);
      if (f.hash !== b.hash || f.winner !== b.winner) { state.flagged.push({ id: b.id, by: b.c, reason: 'result does not match a re-simulation' }); return; }
    }
    applyBout(state, b);
  }
}

/* ------------------------------------------------------------- Promotions */
// Weeks run Monday 00:00 to Monday 00:00 SAST. A Captain or Warlord who fought that week (challenging or
// defending), held the same tier all week and lost nothing is promoted into the tier above, taking the
// lowest seat whose holder sat the whole week out (an "open" seat).
const WEEK = 7 * 86_400_000, SAST = TZ_OFFSET_MS;
const MONDAY_EPOCH = Date.UTC(2024, 0, 1) - SAST; // Monday 1 Jan 2024, 00:00 SAST
export const weekStart = (ms) => MONDAY_EPOCH + Math.floor((ms - MONDAY_EPOCH) / WEEK) * WEEK;

function snapshotWeek(state) {
  state.week.tiers = Object.fromEntries(state.order.map((id, i) => [id, tierAt(i)]));
  state.week.bouts = {}; state.week.losses = {};
}

function closeWeeks(state, upTo) {
  while (state.week.start + WEEK <= upTo) {
    const end = state.week.start + WEEK;
    for (const tier of [1, 2]) {
      const idx = (id) => state.order.indexOf(id);
      const cands = state.order.filter((id, i) => tierAt(i) === tier && state.week.tiers[id] === tier && (state.week.bouts[id] || 0) > 0 && !(state.week.losses[id] || 0));
      for (const id of cands) {
        const above = state.order.map((x, i) => [x, i]).filter(([, i]) => tierAt(i) === tier - 1);
        const open = above.reverse().find(([x]) => !(state.week.bouts[x] || 0));
        if (!open) break;
        const [idle, seat] = open, from = idx(id);
        state.order[seat] = id; state.order[from] = idle;
        const rec = { id: `promo-${id}-${end}`, at: end, promo: true, c: id, d: idle, events: [{ k: 'promote', who: id, seat: TIERS[tier - 1].name, over: idle }] };
        state.feed.push(rec);
        state.week.bouts[idle] = 0; // the demoted seat-holder can't be promoted the same week
      }
    }
    state.week.start = end;
    snapshotWeek(state);
  }
}

/* ------------------------------------------------------------------ Gala */
// Every Friday 16:00 SAST the top Agents (16, or 8 or 4 if the Pit is smaller) enter a knockout bracket.
// The first player to open the page after it starts computes it and stores it once; everyone re-simulates
// its fights to verify. If the Champion enters and loses, the Gala winner takes the Champion's seat.

export const GALA_LOCAL_HOUR = 16;   // Friday 16:00 on the world's clock
export function lastGalaAt(now) {
  const d = new Date(now + SAST); const back = (d.getUTCDay() - 5 + 7) % 7;
  let at = Date.UTC(d.getUTCFullYear(), d.getUTCMonth(), d.getUTCDate() - back, GALA_LOCAL_HOUR) - SAST;
  if (at > now) at -= WEEK;
  return at;
}
export const galaDay = (at) => new Date(at + SAST).toISOString().slice(0, 10);
export const bracketSize = (n) => (n >= 16 ? 16 : n >= 8 ? 8 : n >= 4 ? 4 : 0);

// Seed order for a bracket of n: 1 meets n, and the top two seeds can only meet in the final.
function seedOrder(n) {
  let order = [1];
  while (order.length < n) { const m = order.length * 2 + 1; order = order.flatMap(s => [s, m - s]); }
  return order;
}

// Run the whole bracket. entrants: ids in seed order; snaps/mods by id.
export function runGala(day, entrants, snaps, mods) {
  let round = seedOrder(entrants.length).map(s => entrants[s - 1]);
  const rounds = [];
  let r = 0;
  while (round.length > 1) {
    const matches = [];
    for (let i = 0; i < round.length; i += 2) {
      const a = round[i], b = round[i + 1], seed = `gala|${day}|r${r}|${a}|${b}`;
      const f = arenaFight(seed, snaps[a], snaps[b], mods[a]?.[b], mods[b]?.[a]);
      matches.push({ a, b, seed, winner: f.winner === 'challenger' ? a : b, hash: f.hash });
    }
    rounds.push(matches);
    round = matches.map(m => m.winner);
    r++;
  }
  return { rounds, champion: round[0] };
}

// Build a Gala from the ladder as it stood at `at`. agentDocs: { id: public agent doc }; snapOf builds snapshots.
export function prepareGala(state, at, agentDocs, snapOf) {
  const size = bracketSize(state.order.filter(id => agentDocs[id]).length);
  if (!size) return null;
  const entrants = state.order.filter(id => agentDocs[id]).slice(0, size);
  const snaps = Object.fromEntries(entrants.map(id => [id, snapOf(agentDocs[id])]));
  const mods = Object.fromEntries(entrants.map(a => [a, Object.fromEntries(entrants.filter(b => b !== a).map(b => [b, modsFor(state, a, b)]))]));
  const day = galaDay(at);
  const { rounds, champion } = runGala(day, entrants, snaps, mods);
  return { at, day, entrants, snaps, mods, rounds, champion, v: ARENA_RULES };
}

function applyGala(state, g, verify) {
  // It must be the real Friday Gala, with the ladder's actual top seeds and their actual bonuses at that moment,
  // and plausible fighters. (Forged-but-plausible snapshots of rivals remain a known gap.)
  const top = state.order.slice(0, Array.isArray(g.entrants) ? g.entrants.length : 0);
  // If fights are recorded after this Gala but none before it, the bout history was cleared (it was, on the 2026-11
  // security update) and the ladder as it stood can't be rebuilt, so its entrants and bonuses can't be checked. Then it counts only if GALA_AGREE players recorded the
  // exact same result.
  const covered = state.firstBoutAt == null || state.firstBoutAt < g.at;
  const ok = Array.isArray(g.entrants) && [4, 8, 16].includes(g.entrants.length) && g.entrants.every(id => state.agents[id])
    && g.at === lastGalaAt(g.at) && g.day === galaDay(g.at) && !(state.galas || []).some(x => x.day === g.day)
    && (covered ? JSON.stringify(g.entrants) === JSON.stringify(top)
      && g.entrants.every(a => g.entrants.every(b => a === b || JSON.stringify(g.mods?.[a]?.[b]) === JSON.stringify(modsFor(state, a, b))))
      : (g.agreed || 0) >= GALA_AGREE)
    && g.entrants.every(id => g.snaps?.[id] && !snapIssues(g.snaps[id]).length);
  let valid = ok;
  const rules = rulesOf(g.v, g.at, PIT_SAME);
  if (verify && rules === 'bad') valid = false;
  else if (verify && REJECTED_GALAS.includes(`${g.day}|${g.champion}`)) { state.flagged.push({ id: `gala-${g.day}`, by: null, reason: 'set aside when the combat rules changed on 25 November' }); return; }
  else if (ok && verify && rules === 'current') {
    const re = runGala(g.day, g.entrants, Object.fromEntries(Object.entries(g.snaps || {}).map(([k, sn]) => [k, replaySnap(sn, g.v)])), g.mods);
    valid = re.champion === g.champion && JSON.stringify(re.rounds.map(r => r.map(m => m.hash))) === JSON.stringify((g.rounds || []).map(r => r.map(m => m.hash)));
  }
  if (!valid) { state.flagged.push({ id: `gala-${g.day}`, by: null, reason: 'Gala results do not match a re-simulation' }); return; }
  const champ = state.order[0], winner = g.champion;
  const events = [{ k: 'gala', who: winner, day: g.day }];
  const champLost = g.entrants.includes(champ) && winner !== champ;
  if (champLost) {
    const wi = state.order.indexOf(winner);
    state.order[0] = winner; state.order[wi] = champ;
    events.push({ k: 'rank', who: winner, seat: TIERS[0].name });
  }
  const W = state.agents[winner];
  W.gold += 300; W.galaWins = [...(W.galaWins || []), g.day];
  const final = g.rounds.at(-1)?.[0];
  if (final) { const ru = final.a === winner ? final.b : final.a; state.agents[ru].gold += 120; }
  state.galas = [...(state.galas || []), { day: g.day, at: g.at, champion: winner, entrants: g.entrants, rounds: g.rounds }];
  state.feed.push({ id: `gala-${g.day}`, at: g.at, gala: true, c: winner, d: champLost ? champ : null, events });
}

function applyBout(state, b) {
  const A = state.agents[b.c], D = state.agents[b.d];
  const ai = state.order.indexOf(b.c), di = state.order.indexOf(b.d);
  const aTier = tierAt(ai), dTier = tierAt(di);
  const r = makeRng(`arena-after|${b.seed}`);
  const challengerWon = b.winner === 'challenger';
  const W = challengerWon ? A : D, L = challengerWon ? D : A;
  const wHp = challengerWon ? b.aHp : b.dHp, lTier = challengerWon ? dTier : aTier, wTier = challengerWon ? aTier : dTier;
  const events = [];

  // Rank: a challenger who beats a higher-ranked Agent takes its place (only if the challenge was legal).
  const legal = dTier === aTier || dTier === aTier - 1;
  if (challengerWon && legal && di < ai) {
    state.order.splice(ai, 1);
    state.order.splice(di, 0, b.c);
    // the loser drops to the challenger's old place, or to the top of the Pit if the challenger came from it
    state.order.splice(state.order.indexOf(b.d), 1);
    const dropTo = aTier === 3 && dTier < 3 ? TIER_START[3] : ai;
    state.order.splice(Math.min(dropTo, state.order.length), 0, b.d);
    events.push({ k: 'rank', who: b.c, seat: TIERS[tierAt(di)].name });
  }

  W.wins++; L.losses++; W.streak++; L.streak = 0; L.lastLossAt = b.at;
  if (state.week) { for (const id of [A.id, D.id]) state.week.bouts[id] = (state.week.bouts[id] || 0) + 1; state.week.losses[L.id] = (state.week.losses[L.id] || 0) + 1; }
  if (!challengerWon) D.defences++;
  for (const [x, y] of [[A, D.id], [D, A.id]]) if (!x.fought.includes(y)) x.fought.push(y);
  W.beat[L.id] = (W.beat[L.id] || 0) + 1;
  L.beatenBy[W.id] = (L.beatenBy[W.id] || 0) + 1;

  // Earnings: the challenger always earns some Intel; a successful defence pays the defender while offline.
  if (challengerWon) { A.gold += 40; A.intel += 2; } else { A.intel += 1; D.gold += 25; D.intel += 1; }

  // Scars: survive under 10% HP, or lose while the winner is under 10%. Half the time. Max 5.
  if (wHp > 0 && wHp < 10 && W.scars < 5 && r() < 0.5) { W.scars++; events.push({ k: 'scar', who: W.id }); }
  if (wHp > 0 && wHp < 10 && L.scars < 5 && r() < 0.5) { L.scars++; events.push({ k: 'scar', who: L.id }); }

  // Adaptation: the third loss to one element gives a 50% chance of resisting it.
  const lEl = challengerWon ? b.dEl : b.aEl;
  if (lEl && lEl !== 'physical') {
    L.elLosses[lEl] = (L.elLosses[lEl] || 0) + 1;
    if (L.elLosses[lEl] >= 3) {
      L.elLosses[lEl] = 0;
      const k = `${lEl}proof`;
      if (TRAITS[k] && !L.traits.includes(k) && r() < 0.5) { L.traits.push(k); events.push({ k: 'adapt', who: L.id, trait: k }); }
    }
  }

  // Humiliation: losing to someone two or more tiers lower.
  if (wTier - lTier >= 2 && !L.traits.includes(`haunted:${W.id}`)) { L.traits.push(`haunted:${W.id}`); events.push({ k: 'haunted', who: L.id, by: W.id }); }

  // Nemesis: whoever beats you three times becomes your Nemesis.
  if (L.beatenBy[W.id] >= 3 && L.nemesis !== W.id) { L.nemesis = W.id; L.nemesisWins = 0; events.push({ k: 'nemesis', who: L.id, nemesis: W.id }); }
  // Beating your Nemesis three times: a trophy, and a step toward the Nemesis Brand.
  if (W.nemesis === L.id) {
    W.nemesisWins++;
    if (W.nemesisWins >= 3) {
      W.trophies.push({ from: L.id, at: b.at, bout: b.id, cycle: W.brands });
      W.brands++; W.nemesis = null; W.nemesisWins = 0;
      W.beatenBy[L.id] = 0; // the slate is clean; they must beat you three times again
      events.push({ k: 'trophy', who: W.id, from: L.id, brands: W.brands });
    }
  }

  const rec = { ...b, events, aTier, dTier };
  state.bouts.push(rec);
  for (const x of [A, D]) x.history.push(b.id);
  state.feed.push(rec);
}

/* --------------------------------------------------------------- Helpers */

export const tierOf = (state, id) => tierAt(state.rank[id] ?? state.order.length);
export function canChallenge(state, me, target) {
  if (me === target || state.rank[me] == null || state.rank[target] == null) return false;
  const mt = tierOf(state, me), tt = tierOf(state, target);
  return tt === mt || tt === mt - 1;
}
export const challengesToday = (bouts, day) => (bouts || []).filter(b => b.day === day).length;

// Keep the newest SNAPSHOT_KEEP bouts with full snapshots; older ones are kept compact.
// Keep full snapshots on the newest SNAPSHOT_KEEP bouts and on every bout from the last VERIFY_DAYS days (they must
// be re-simulated by everyone); older ones are kept compact.
export function compactBouts(list, now = Date.now()) {
  const keepFrom = Math.max(0, list.length - SNAPSHOT_KEEP), recent = now - VERIFY_DAYS * 86_400_000;
  return list.map((b, i) => (i >= keepFrom || b.at >= recent ? b : (({ aSnap, dSnap, ...rest }) => rest)(b)));
}
const sastDate = (at) => new Date(at + SAST).toISOString().slice(0, 10);

// Gala records live in each recorder's own bouts doc (`galas: { day: record }`), so nobody can delete another's.
// For each day, the version most recorders agree on wins (honest clients produce identical results); ties go to
// the lowest recorder id. Validity is checked later, in replay, against the ladder as it stood.
export function pickGalas(boutsDocs) {
  const byDay = Object.create(null);
  for (const [owner, doc] of Object.entries(boutsDocs || {})) {
    const galas = doc?.galas; if (!galas || typeof galas !== 'object') continue;
    for (const [day, g] of Object.entries(galas)) {
      if (!g || typeof g !== 'object' || g.day !== day || !/^\d{4}-\d{2}-\d{2}$/.test(day) || !Number.isFinite(g.at) || !Array.isArray(g.entrants) || !Array.isArray(g.rounds)) continue;
      let key; try { key = JSON.stringify([g.at, g.entrants, g.champion, g.rounds.map(r => (Array.isArray(r) ? r : []).map(m => m?.hash))]); } catch { continue; }
      ((byDay[day] ??= Object.create(null))[key] ??= { g, by: [] }).by.push(owner);
    }
  }
  // `agreed`: how many players recorded the same outcome (time, entrants, champion), used when the ladder history
  // can't check the Gala. Fight hashes may differ between recorders' pages and aren't part of it.
  const outcome = (g) => JSON.stringify([g.at, g.entrants, g.champion]);
  return Object.fromEntries(Object.entries(byDay).map(([day, alts]) => {
    const w = Object.values(alts).sort((x, y) => y.by.length - x.by.length || [...x.by].sort()[0].localeCompare([...y.by].sort()[0]))[0];
    const agreed = new Set(Object.values(alts).filter(a => outcome(a.g) === outcome(w.g)).flatMap(a => a.by)).size;
    return [day, { ...w.g, agreed }];
  }));
}

/* ---------------------------------------------------------------- Banter */
// Template taunts from names, history and scars. The page may replace them with Claude-written lines.

const T = {
  first: ['Never heard of you, {foe}. Let\'s fix that.', 'Fresh meat. The Pit loves fresh meat.', 'Another day, another {foeClass}.'],
  revenge: ['You got lucky last time, {foe}. Twice is a pattern; once is luck.', 'I remember you, {foe}. I remember everything.'],
  nemesis: ['{foe}. My Nemesis. I\'ve been training for this.', 'Every scar I have, {foe}, has your name on it.'],
  bully: ['Back for more, {foe}? Your {scarPart} still hasn\'t healed.', 'Again, {foe}? I\'m starting to feel bad. Starting.'],
  haunted: ['Not you again. Not you, {foe}.'],
  champ: ['Kneel, {foe}. Everyone does eventually.', 'The seat is warm, {foe}. It stays mine.'],
};
const SCAR_PARTS = ['left eye', 'jaw', 'pride', 'shield arm', 'ego'];

export function banter(state, me, foe, names = {}, classes = {}) {
  const s = state.agents[me] || newAgentState(me), f = state.agents[foe] || newAgentState(foe);
  const r = makeRng(`banter|${me}|${foe}|${s.history.length}|${f.history.length}`);
  const pick = (k) => T[k][Math.floor(r() * T[k].length)];
  let line;
  if (s.traits.includes(`haunted:${foe}`)) line = pick('haunted');
  else if (s.nemesis === foe) line = pick('nemesis');
  else if ((s.beat[foe] || 0) >= 2) line = pick('bully');
  else if ((s.beatenBy[foe] || 0) > 0) line = pick('revenge');
  else if (tierOf(state, me) === 0) line = pick('champ');
  else line = pick('first');
  return line.replace(/\{foe\}/g, names[foe] || 'stranger').replace('{foeClass}', classes[foe] || 'challenger')
    .replace('{scarPart}', SCAR_PARTS[Math.floor(r() * SCAR_PARTS.length)]);
}

export const boutId = (owner, at) => `${owner.slice(-6)}-${at.toString(36)}-${fnv1a(`${owner}|${at}`).toString(36).slice(0, 4)}`;
