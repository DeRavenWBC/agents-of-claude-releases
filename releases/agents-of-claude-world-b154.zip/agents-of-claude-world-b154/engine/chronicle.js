import { TZ_OFFSET_MS, TZ_ISO, worldDay, dayAt } from './worldtime.js';
// Agents of Claude — the Chronicle: a public, dated history of each Agent, so its story can be told later.
//
// Each page keeps its own Agent's `chronicle/<uid>` doc: { last, entries: [{ at, kind, text, ids? , d? }], days: { 'YYYY-MM-DD': snapshot } }.
// The page builds a snapshot of the Agent as it is now (public facts only: no gold, no private journal), and
// diffChronicle compares it with `last` to produce new entries. Nothing here calls Claude.

export const MAX_ENTRIES = 400;
export const MAX_DAYS = 120;
const BOND_TEXT = { friend: 'became friends with', rival: 'became rivals with', crush: 'took a shine to', sweetheart: 'fell for' };

// snap: { level, race, cls, title, traits:[], voice, bonds:{id:bond}, elo, duels:{w,l,d}, seat, ladderSize, pitTraits:[], nemesis,
//         cleared:{dungeonName:n}, mounts:[name], hidden:[name], duelsCounted:[{id, opp, won, delta}], trades:[{id, kind, item, price, other}],
//         trips:[{seed, kind, name, cleared, ko}] }
// names: { id: Agent name } for readable text.
export function diffChronicle(last, snap, now, names = {}) {
  const nm = (id) => names[id] || 'another Agent';
  const out = [], add = (kind, text, extra = {}) => out.push({ at: now, kind, text, ...extra });
  if (!last) {
    add('begin', `The chronicle begins: a level ${snap.level} ${snap.cls}${snap.traits?.length ? `, ${snap.traits.join(', ')}` : ''}.`, { d: { level: snap.level, traits: snap.traits || [] } });
    return { entries: out, last: memo(snap) };
  }
  if (snap.level > (last.level || 0)) add('level', `Reached level ${snap.level}.`, { d: { from: last.level, to: snap.level } });
  const tA = (last.traits || []).join('|'), tB = (snap.traits || []).join('|');
  if (tB && tA !== tB) {
    const gained = (snap.traits || []).filter(t => !(last.traits || []).includes(t)), lost = (last.traits || []).filter(t => !(snap.traits || []).includes(t));
    add('persona', `Personality shifted${gained.length ? `: now ${gained.join(', ')}` : ''}${lost.length ? `; no longer ${lost.join(', ')}` : ''}.`, { d: { from: last.traits || [], to: snap.traits || [], voice: snap.voice || null } });
  }
  for (const [id, bond] of Object.entries(snap.bonds || {})) {
    const was = last.bonds?.[id] || null;
    if (bond && bond !== was && BOND_TEXT[bond]) add('bond', `${cap(BOND_TEXT[bond])} ${nm(id)}.`, { ids: [id], d: { from: was, to: bond } });
    else if (!bond && was === 'rival') add('bond', `Made peace with ${nm(id)}.`, { ids: [id], d: { from: was, to: null } });
  }
  if (snap.title && snap.title !== last.title) add('title', `Earned the title "${snap.title}".`);
  const seen = new Set(last.duelIds || []);
  for (const d of snap.duelsCounted || []) if (!seen.has(d.id)) add('duel', `${d.won === true ? 'Beat' : d.won === false ? 'Lost to' : 'Drew with'} ${nm(d.opp)} in a duel (${d.delta > 0 ? '+' : ''}${d.delta} Elo).`, { ids: [d.opp], d: { won: d.won, delta: d.delta } });
  const pitSeen = new Set(last.pitIds || []);
  if (last.pitIds) for (const b of snap.pitBouts || []) if (!pitSeen.has(b.id)) add('pit', `${b.challenged ? (b.auto ? 'Chose to challenge' : 'Challenged') : 'Was challenged by'} ${nm(b.opp)} in the Pit and ${b.won ? 'won' : 'lost'}.`, { ids: [b.opp], d: { won: b.won, auto: b.auto } });
  if (snap.seat && last.seat && snap.seat < last.seat && snap.seat <= 3) add('pit', `Climbed to seat ${snap.seat} in the Pit.`, { d: { from: last.seat, to: snap.seat } });
  if (snap.nemesis && snap.nemesis !== last.nemesis) add('pit', `${nm(snap.nemesis)} became their Nemesis in the Pit.`, { ids: [snap.nemesis] });
  for (const t of snap.pitTraits || []) if (!(last.pitTraits || []).includes(t)) add('pit', `The Pit gave them a new trait: ${t}.`);
  for (const [k, n] of Object.entries(snap.cleared || {})) if (n > (last.cleared?.[k] || 0)) add('dungeon', n === 1 ? `Cleared ${k} for the first time.` : `Cleared ${k} again (${ordinal(n)} time).`, { d: { dungeon: k, n } });
  for (const m of snap.mounts || []) if (!(last.mounts || []).includes(m)) add('mount', `Got a new mount: ${m}.`);
  for (const h of snap.hidden || []) if (!(last.hidden || []).includes(h)) add('secret', `Discovered a hidden ability: ${h}.`);
  const tradeSeen = new Set(last.tradeIds || []);
  for (const t of snap.trades || []) if (!tradeSeen.has(t.id)) add('trade', tradeText(t, nm), { ids: [t.other] });
  const tripSeen = new Set(last.tripSeeds || []);
  for (const t of snap.trips || []) if (!tripSeen.has(t.seed)) for (const e of t.encounters || []) add('encounter', `${e.title}: chose to ${e.choice.charAt(0).toLowerCase() + e.choice.slice(1)}. ${e.text}`, { d: { title: e.title } });
  for (const t of snap.trips || []) {
    if (tripSeen.has(t.seed) || !['quest', 'explore', 'dungeon'].includes(t.kind) || (t.kind === 'dungeon' && t.cleared)) continue; // clears are told above
    add('trip', t.ko ? `Was knocked out in ${t.name}.` : t.kind === 'quest' ? (t.done ? `Completed ${t.name}.` : `Failed ${t.name}.`) : t.kind === 'dungeon' ? `Was beaten back from ${t.name}.` : `Explored ${t.name}.`, { d: { kind: t.kind } });
  }
  return { entries: out, last: memo(snap, last) };
}

// What is remembered between runs (ids are kept so nothing is told twice).
function memo(s, prev = {}) {
  const keep = (a, b, n) => [...new Set([...(a || []), ...(b || [])])].slice(-n);
  return { level: s.level, traits: s.traits || [], bonds: s.bonds || {}, title: s.title || null, seat: s.seat || null, nemesis: s.nemesis || null,
    pitTraits: s.pitTraits || [], cleared: s.cleared || {}, mounts: s.mounts || [], hidden: s.hidden || [],
    duelIds: keep(prev.duelIds, (s.duelsCounted || []).map(d => d.id), 300), tradeIds: keep(prev.tradeIds, (s.trades || []).map(t => t.id), 300),
    tripSeeds: keep(prev.tripSeeds, (s.trips || []).map(t => t.seed), 50), pitIds: keep(prev.pitIds, (s.pitBouts || []).map(b => b.id), 300) };
}

// One row a day for charts: level, Elo, Pit seat, personality, and how many friends and rivals.
export const daySnapshot = (s) => ({ level: s.level, elo: s.elo ?? null, duels: s.duels || null, seat: s.seat ?? null, ladderSize: s.ladderSize ?? null,
  traits: s.traits || [], friends: Object.values(s.bonds || {}).filter(b => b && b !== 'rival').length, rivals: Object.values(s.bonds || {}).filter(b => b === 'rival').length,
  cleared: Object.values(s.cleared || {}).reduce((x, y) => x + y, 0) });

export function nextChronicle(doc, snap, now, day, names) {
  const { entries, last } = diffChronicle(doc?.last || null, snap, now, names);
  const days = { ...(doc?.days || {}) };
  const today = daySnapshot(snap), changedDay = JSON.stringify(days[day]) !== JSON.stringify(today);
  if (changedDay) days[day] = today;
  const keys = Object.keys(days).sort(); for (const k of keys.slice(0, Math.max(0, keys.length - MAX_DAYS))) delete days[k];
  if (!entries.length && !changedDay && JSON.stringify(last) === JSON.stringify(doc?.last)) return null; // nothing to write
  return { v: 1, last, days, entries: [...(doc?.entries || []), ...entries].slice(-MAX_ENTRIES), startedAt: doc?.startedAt || now };
}

const cap = (s) => s[0].toUpperCase() + s.slice(1);
const ordinal = (n) => `${n}${[, 'st', 'nd', 'rd'][(n % 100 >> 3 ^ 1) && n % 10] || 'th'}`;

// One-time backfill from what the game already stored, dated to when it happened. Entries carry `back: true`.
// h: { createdAt, cls, duels:[{id, opp, won, delta, at}], pit:[{id, at, opp, won, challenged, events:[{k, ...}]}], hidden:[{name, at}],
//      bonds:[{id, bond, at}], trades:[{id, kind, item, price, other, at}], persona:[{at, traits}], mounts:[{name, at}],
//      days:{ 'YYYY-MM-DD': { level, elo, seat } } }
export function backfillEntries(h, names = {}) {
  const nm = (id) => names[id] || 'another Agent', out = [];
  const add = (at, kind, text, extra = {}) => { if (Number.isFinite(at)) out.push({ at, kind, text, back: true, ...extra }); };
  add(h.createdAt, 'joined', `Joined the guild as a ${h.cls}.`);
  for (const d of h.duels || []) add(d.at, 'duel', `${d.won === true ? 'Beat' : d.won === false ? 'Lost to' : 'Drew with'} ${nm(d.opp)} in a duel (${d.delta > 0 ? '+' : ''}${d.delta} Elo).`, { ids: [d.opp], d: { won: d.won, delta: d.delta } });
  for (const b of h.pit || []) {
    add(b.at, 'pit', `${b.challenged ? 'Challenged' : 'Was challenged by'} ${nm(b.opp)} in the Pit and ${b.won ? 'won' : 'lost'}.`, { ids: [b.opp], d: { won: b.won } });
    for (const e of b.events || []) {
      if (e.k === 'nemesis') add(b.at + 1, 'pit', `${nm(e.nemesis)} became their Nemesis.`, { ids: [e.nemesis] });
      else if (e.k === 'trophy') add(b.at + 1, 'pit', `Beat their Nemesis ${nm(e.from)} three times and took a trophy.`, { ids: [e.from] });
      else if (e.k === 'rank' || e.k === 'promote') add(b.at + 1, 'pit', `Rose to ${e.seat || 'a higher seat'} in the Pit.`);
      else if (e.k === 'haunted') add(b.at + 1, 'pit', `Was humiliated by ${nm(e.by)} and is haunted by it.`, { ids: [e.by] });
    }
  }
  for (const x of h.hidden || []) add(x.at, 'secret', `Discovered a hidden ability: ${x.name}.`);
  for (const b of h.bonds || []) if (BOND_TEXT[b.bond]) add(b.at, 'bond', `${cap(BOND_TEXT[b.bond])} ${nm(b.id)}.`, { ids: [b.id], d: { to: b.bond } });
  for (const t of h.trades || []) add(t.at, 'trade', tradeText(t, nm), { ids: [t.other] });
  let prev = null;
  for (const p of [...(h.persona || [])].sort((x, y) => x.at - y.at)) {
    if (prev && prev.join('|') !== (p.traits || []).join('|')) add(p.at, 'persona', `Personality shifted: now ${(p.traits || []).join(', ')}.`, { d: { from: prev, to: p.traits } });
    prev = p.traits || [];
  }
  for (const m of h.mounts || []) add(m.at, 'mount', `Got a new mount: ${m.name}.`);
  let lvl = null;
  for (const day of Object.keys(h.days || {}).sort()) {
    const L = h.days[day].level;
    if (lvl != null && L > lvl) add(dayAt(day, '20:00'), 'level', `Reached level ${L}.`, { d: { from: lvl, to: L } });
    if (L != null) lvl = L;
  }
  return out.sort((x, y) => x.at - y.at);
}

// Merge a backfill into an existing chronicle: older entries first, existing days kept, nothing told twice.
export function applyBackfill(doc, h, names) {
  const have = new Set((doc?.entries || []).map(e => `${e.kind}|${e.text}`));
  const since = doc?.startedAt ?? Infinity;   // the live chronicle already covers everything after it began
  const back = backfillEntries(h, names).filter(e => e.at < since && !have.has(`${e.kind}|${e.text}`));
  const days = { ...(doc?.days || {}) };
  for (const [day, s] of Object.entries(h.days || {})) if (!days[day]) days[day] = { ...s, back: true };
  const keys = Object.keys(days).sort(); for (const k of keys.slice(0, Math.max(0, keys.length - MAX_DAYS))) delete days[k];
  const entries = [...back, ...(doc?.entries || [])].sort((x, y) => x.at - y.at).slice(-MAX_ENTRIES);
  return { ...(doc || {}), entries, days, backfilled: Date.now() };
}

export const tradeText = (t, nm) => t.kind === 'sold' ? `Sold ${t.item} to ${nm(t.other)} for ${t.price} gold.`
  : t.kind === 'gift' ? `Received ${t.item} as a gift from ${nm(t.other)}.`
  : t.kind === 'gave' ? `Gave ${t.item} to ${nm(t.other)} as a gift.`
  : `Bought ${t.item} from ${nm(t.other)} for ${t.price} gold.`;
