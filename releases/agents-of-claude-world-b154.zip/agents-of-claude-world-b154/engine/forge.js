// Agents of Claude — forge and trainer (rules version 1).
// Every roll is seeded by the item (or Agent) and an attempt counter, so a reload can't re-roll a result.

import { makeRng } from './rng.js';
import { AFFIXES, RARITY } from './items.js';

/* ---------------------------------------------------------------- Forge */

const RARITY_WORTH = { common: 1, uncommon: 3, rare: 8, epic: 20, legendary: 50, mythic: 120 };
export const MAX_UPGRADE = 10;
// Chance to succeed when upgrading TO this level. Up to +5 always succeeds.
const UPGRADE_CHANCE = { 6: 80, 7: 65, 8: 50, 9: 35, 10: 25 };

export function salvageValue(item) {
  return Math.max(1, Math.round(RARITY_WORTH[item.rarity] * (1 + item.ilvl / 10) * (1 + (item.upgrade || 0) * 0.25)));
}

// Costs grow with rarity and item level. Upgrades are paid in gold only (the guild's main gold sink); rerolls take
// both gold and essence (essence, from salvaging, is spent only here). Both double or climb steeply, so a fully
// upgraded or much-rerolled item is a long-term goal.
const round5 = (n) => Math.max(5, Math.round(n / 5) * 5);
const itemScale = (item) => Math.sqrt(RARITY_WORTH[item.rarity]) * (1 + (item.ilvl || 1) / 25);
export function rerollCost(item) {
  const n = item.rerolls || 0;
  return { essence: Math.round(4 * RARITY_WORTH[item.rarity] ** 0.6 * 2 ** n), gold: round5(40 * itemScale(item)) * 2 ** n };
}

export function canReroll(item) {
  return !item.named && (item.affixes || []).length > 0;
}

// Replace affix `index` with a different affix (not already on the item), rolled at the item's level.
export function reroll(item, index) {
  if (!canReroll(item) || !item.affixes[index]) throw new Error('This affix cannot be rerolled');
  const n = item.rerolls || 0;
  const r = makeRng(`reroll|${item.id}|${n}`);
  const taken = new Set(item.affixes.map(a => a.k));
  const pool = Object.keys(AFFIXES).filter(k => !taken.has(k));
  const k = pool[Math.floor(r() * pool.length)];
  const affixes = item.affixes.map((a, i) => i === index ? { k, v: AFFIXES[k].value(item.ilvl, r()) } : a);
  return { ...item, affixes, rerolls: n + 1 };
}

export function upgradeCost(item) {
  const next = (item.upgrade || 0) + 1;
  return { essence: 0, gold: round5(20 * next ** 1.4 * itemScale(item)) };
}

export function upgradeChance(item) {
  const next = (item.upgrade || 0) + 1;
  return UPGRADE_CHANCE[next] ?? 100;
}

// One upgrade attempt. Success adds +1 (each level is +4% base stats, applied in computeGear).
export function tryUpgrade(item) {
  const cur = item.upgrade || 0;
  if (cur >= MAX_UPGRADE) throw new Error('Already at +10');
  const attempts = item.upgradeAttempts || 0;
  const roll = makeRng(`upgrade|${item.id}|${attempts}`)() * 100;
  const success = roll < upgradeChance(item);
  return { success, item: { ...item, upgrade: success ? cur + 1 : cur, upgradeAttempts: attempts + 1 } };
}

export const itemLabel = (item) => (item.upgrade ? `+${item.upgrade} ` : '') + item.name;

/* -------------------------------------------------------------- Trainer */

export const TRAIN_MINUTES = 60;

// A score's trained bonus may not exceed half the Agent's level.
export const trainCap = (level) => Math.floor(level / 2);

export function trainCost(currentBonus) {
  return { focus: 10 * (currentBonus + 1), gold: 20 * (currentBonus + 1) };
}

export { RARITY_WORTH };
export const rarityLabel = (r) => RARITY[r]?.label || r;
