// Agents of Claude — the Auction House and direct trades.
//
// No server: every player writes only their own public `market/<id>` doc, and every page derives the same
// outcome from all of them.
//   Seller: { listings: [{ id, item, buyout|null, minBid|null, at, ends, to|null, cancelled }] }.
//           The item leaves the seller's private bag when listed (escrow) and sits in the listing.
//   Buyer:  { bids: [{ id, listing, seller, amount, at }] }. The gold leaves the buyer's private purse when bidding.
// A listing with `gift: true` (and `to`) is a free gift: it belongs to that player at once.
// Outcome per listing: the earliest bid at the buyout price wins at once; otherwise, when it ends, the highest bid
// at or above the minimum wins (ties: earliest). A listing `to` one player is a direct trade: only they may buy it.
// Each page then settles its own side, once (ids recorded in its private progress): sellers collect gold minus the
// fee or reclaim unsold items, winners collect items, everyone else is refunded.

import { itemIssues } from './verify.js';
import { canonItem } from './items.js';
import { sha256 } from './rng.js';
import { sameFamily } from './family.js';

export const FEE = 0.05;                       // of the sale price, removed from the game
export const DURATIONS_H = [24, 72];
export const MAX_PRICE = 1_000_000;
const MIN_STEP = 0.05;                         // a new top bid beats the old one by at least 5%
export const LISTING_KEEP = 120, BID_KEEP = 300;   // closed history kept per player doc (open listings are never trimmed: no limit on those)
export const RETAIN_MS = 30 * 86_400_000;          // closed and settled entries are pruned after this

export const feeOf = (price) => Math.max(1, Math.round(price * FEE));
export const minNextBid = (l, top) => (top ? Math.max(top.amount + 1, Math.ceil(top.amount * (1 + MIN_STEP))) : l.minBid);
const intIn = (v, lo, hi) => Number.isInteger(v) && v >= lo && v <= hi;

export const MAX_ITEM_BYTES = 4000;
export const GIFTS_PER_PAIR_PER_DAY = 3;
// What a bid is for: the exact item and terms the bidder saw. A bid names this fingerprint (`ih`), so a seller who swaps
// the item or changes the terms after a bid only makes that bid invalid (the bidder is refunded), never a sale of
// something else. Required on bids from BID_HASH_SINCE on.
export const BID_HASH_SINCE = Date.parse('2026-11-27T00:00:00Z');
export const listingHash = (l) => sha256(JSON.stringify([canonItem(l.item), l.buyout ?? null, l.minBid ?? null, l.at, l.ends, l.to ?? null])).slice(0, 24);
// Gifts made before the ration existed all stand (taking one back would hand the giver a copy of an item already received).
export const GIFT_CAP_SINCE = Date.parse('2026-11-26T00:00:00Z');
// A listing everyone accepts: well formed, a genuine item, a sane price and window.
export function validListing(l, seller, sellerLevel = 50) {
  if (!l || typeof l.id !== 'string' || !l.item || typeof l.item !== 'object') return false;
  // An item is a few hundred bytes. A padded one would bloat the bag of whoever receives it (their saves would then fail).
  try { if (JSON.stringify(l.item).length > MAX_ITEM_BYTES) return false; } catch { return false; }
  if (!Number.isFinite(l.at) || !Number.isFinite(l.ends) || !DURATIONS_H.some(h => l.ends - l.at === h * 3_600_000)) return false;
  if (l.gift) {   // a free gift: no price, straight to one named player
    if (l.buyout != null || l.minBid != null || typeof l.to !== 'string' || l.to === seller) return false;
    return itemIssues(l.item, null, sellerLevel).length === 0;
  }
  if (l.buyout == null && l.minBid == null) return false;
  if (l.buyout != null && !intIn(l.buyout, 1, MAX_PRICE)) return false;
  if (l.minBid != null && !intIn(l.minBid, 1, MAX_PRICE)) return false;
  if (l.buyout != null && l.minBid != null && l.minBid > l.buyout) return false;
  if (l.to != null && (typeof l.to !== 'string' || l.to === seller)) return false;
  return itemIssues(l.item, null, sellerLevel).length === 0;
}

// The whole market from every player's doc. levels: { id: Agent level } (to check item levels).
// Returns { listings: [{ ...l, seller, status, winner, price, bids }], bids: [{ ...b, bidder, outcome }] }.
export function marketState(docs, now, levels = {}) {
  const listings = [], byId = new Map();
  for (const [seller, d] of Object.entries(docs || {})) {
    const own = Array.isArray(d?.listings) ? d.listings : [];
    const seen = new Set();
    for (const l of own) {
      if (!validListing(l, seller, levels[seller] ?? 50) || seen.has(l.id) || byId.has(l.id)) continue;
      // The item everyone sees and receives is rebuilt from the game's own tables: no free text travels with it.
      const item = canonItem(l.item); if (!item) continue;
      seen.add(l.id);
      const L = { ...l, item, seller, bids: [] }; listings.push(L); byId.set(l.id, L);
    }
  }
  // Gifts need no yes from the receiver, so they are rationed: the first GIFTS_PER_PAIR_PER_DAY from one player to
  // another on a UTC day count; later ones are no listing at all (the item stays with the giver, who reclaims it).
  const giftCount = new Map();
  for (const L of [...listings].filter(x => x.gift && x.at >= GIFT_CAP_SINCE).sort((x, y) => x.at - y.at || x.id.localeCompare(y.id))) {
    const k = `${L.seller}|${L.to}|${Math.floor(L.at / 86_400_000)}`, n = (giftCount.get(k) || 0) + 1; giftCount.set(k, n);
    if (n > GIFTS_PER_PAIR_PER_DAY) L.overGiftCap = true;
  }
  const bids = [];
  for (const [bidder, d] of Object.entries(docs || {})) {
   const seenBid = new Set();
   for (const b of (Array.isArray(d?.bids) ? d.bids : []).slice(-BID_KEEP)) {
    if (!b || typeof b.id !== 'string' || seenBid.has(b.id) || !intIn(b.amount, 1, MAX_PRICE) || !Number.isFinite(b.at)) continue;
    seenBid.add(b.id);
    const L = byId.get(b.listing);
    const ok = !!L && (b.ih != null ? b.ih === listingHash(L) : b.at < BID_HASH_SINCE) && b.seller === L.seller && bidder !== L.seller && !sameFamily(bidder, L.seller) && (L.to == null || L.to === bidder) && b.at >= L.at && b.at <= L.ends && !(L.cancelled && L.cancelled <= b.at)
      && (b.amount === L.buyout || (L.minBid != null && b.amount >= L.minBid && (L.buyout == null || b.amount < L.buyout)));
    const B = { ...b, bidder, valid: ok }; bids.push(B);
    if (ok) L.bids.push(B);
   }
  }
  for (const L of listings) {
    L.bids.sort((x, y) => x.at - y.at || x.id.localeCompare(y.id));
    const buy = L.buyout != null ? L.bids.find(b => b.amount === L.buyout) : null;
    // Auction bids only count if they beat the top bid at the time they were placed.
    let top = null;
    for (const b of L.bids) { if (buy && b.at > buy.at) break; if (b.amount === L.buyout) continue; if (!top || b.amount >= minNextBid(L, top)) top = b; }
    L.top = top;
    if (L.gift && L.overGiftCap) { L.status = 'cancelled'; L.closedAt = L.at; }
    else if (L.gift) { L.status = 'sold'; L.winner = L.to; L.price = 0; L.closedAt = L.at; }
    else if (buy) { L.status = 'sold'; L.winner = buy.bidder; L.winBid = buy.id; L.price = buy.amount; L.closedAt = buy.at; }
    else if (L.cancelled && !top) { L.status = 'cancelled'; L.closedAt = L.cancelled; }
    else if (now >= L.ends) { if (top) { L.status = 'sold'; L.winner = top.bidder; L.winBid = top.id; L.price = top.amount; } else L.status = 'expired'; L.closedAt = L.ends; }
    else L.status = 'open';
  }
  for (const B of bids) {
    const L = byId.get(B.listing);
    B.outcome = !B.valid ? 'invalid' : L.winBid === B.id ? 'won' : L.status === 'open' ? (L.top?.id === B.id ? 'leading' : 'outbid') : 'lost';
  }
  return { listings, bids, byId };
}

// What this player's page must settle now, given what it already settled (ids in its private progress).
// done: { paid: [listingId], reclaimed: [listingId], received: [listingId], refunded: [bidId] }.
export function settlementsFor(uid, state, done = {}) {
  const has = (k, id) => (done[k] || []).includes(id);
  const out = { payouts: [], reclaims: [], receives: [], refunds: [] };
  for (const L of state.listings) {
    if (L.seller === uid && L.status === 'sold' && !L.gift && !has('paid', L.id)) out.payouts.push({ id: L.id, gold: L.price - feeOf(L.price), fee: feeOf(L.price), price: L.price, buyer: L.winner, item: L.item });
    if (L.seller === uid && (L.status === 'expired' || L.status === 'cancelled') && !has('reclaimed', L.id)) out.reclaims.push({ id: L.id, item: L.item });
    if (L.winner === uid && L.status === 'sold' && !has('received', L.id)) out.receives.push({ id: L.id, item: L.item, price: L.price, seller: L.seller });
  }
  for (const B of state.bids) if (B.bidder === uid && (B.outcome === 'outbid' || B.outcome === 'lost' || B.outcome === 'invalid') && !has('refunded', B.id)) out.refunds.push({ id: B.id, gold: B.amount, listing: B.listing });
  return out;
}

export const listingId = (seller, at) => `L-${at.toString(36)}-${seller.slice(-5)}`;
export const bidId = (bidder, at) => `B-${at.toString(36)}-${bidder.slice(-5)}`;

// Lost deliveries: an item this player bought or was given (settled: its listing is in done.received) that is no
// longer anywhere it could have gone on purpose: not in the bag, not worn, not salvaged (gone), and not in one of the
// player's own listings (sold, gifted or listed on). That means a bag write was lost (an older copy of the bag saved
// over the delivery), so the page puts it back, once per listing (done.healed).
// Only for deliveries within HEAL_MS: own listings are kept RETAIN_MS after they close, so within this window an item
// the player listed on is always still visible in their own doc and never comes back twice.
export const HEAL_MS = 7 * 86_400_000;
export function lostDeliveries({ uid, state, done, bagIds, wornIds, goneIds, ownItemIds, now }) {
  const healed = new Set(done?.healed || []), received = new Set(done?.received || []);
  const has = (s, id) => !!s && s.has(id);
  return (state?.listings || []).filter(L => L.status === 'sold' && L.winner === uid && L.seller !== uid && received.has(L.id) && !healed.has(L.id)
    && L.item?.id && Number.isFinite(L.closedAt) && now - L.closedAt < HEAL_MS
    && !has(bagIds, L.item.id) && !has(wornIds, L.item.id) && !has(goneIds, L.item.id) && !has(ownItemIds, L.item.id))
    .map(L => ({ id: L.id, item: L.item, seller: L.seller, price: L.price || 0 }));
}
