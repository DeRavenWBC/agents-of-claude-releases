// Agents of Claude — snapshot checks.
//
// Fights are re-simulated from seeds, so a forged *result* is caught. This module catches a forged *input*:
// an Agent snapshot whose starting attributes, level or gear could not have come out of the game.
// `snapIssues` lists what is wrong (empty = plausible); `cleanSnap` drops what is wrong, so an honest
// player who fights a cheater stores a clean snapshot of them.
//
// Not checkable from public data: an Agent's real level (it comes from private XP) beyond the level cap,
// and which hidden abilities it has earned.

import { BASES, NAMED, DUNGEON_SETS, AFFIXES, RARITY, ITEM_ABILITIES, SLOTS, generateItem, namedItem, LEGACY_NAMED } from './items.js';
import { ABILITIES, ELEMENTS, SCORE_KEYS, RETIRED_ABILITIES } from './battle.js';
import { MAX_UPGRADE } from './forge.js';
import { RACES } from './races.js';

export const LEVEL_CAP = 50;
export const BUY = { points: 12, min: 8, max: 15 };
export const CLASS_PRIMARY = { warblade: ['mig', 'vit'], shadowstep: ['agi', 'pre'], arcanist: ['int', 'spi'], warden: ['spi', 'vit'], ranger: ['agi', 'spi'], hexer: ['int', 'pre'], deathknight: ['mig', 'int'], necromancer: ['int', 'vit'], bard: ['pre', 'spi'], artificer: ['agi', 'int'], tinkerer: ['int', 'spi'], paladin: ['mig', 'spi'], priest: ['spi', 'int'] };
const ILVL_OVER_LEVEL = 10; // Mythic dungeons drop up to 8 levels above their entry level
const SLOT_OF = (slot) => (slot === 'ring1' || slot === 'ring2' ? 'ring' : slot);

// The range an affix can roll at an item level (value() rises with its roll).
export function affixRange(k, ilvl) {
  const a = AFFIXES[k].value(ilvl, 0), b = AFFIXES[k].value(ilvl, 1);
  return [Math.min(a, b), Math.max(a, b)];
}

const sameStats = (x = {}, y = {}) => {
  const keys = new Set([...Object.keys(x), ...Object.keys(y)]);
  for (const k of keys) if ((x[k] || 0) !== (y[k] || 0)) return false;
  return true;
};

// What is impossible about one item worn in `slot` by an Agent of `level`.
// Remote data can be any shape: a check that throws would stop every page's replay, so a broken item or snapshot
// is simply reported as impossible.
export function itemIssues(it, slot, level = LEVEL_CAP) {
  try { return itemIssuesOf(it, slot, level); } catch { return ['a malformed item']; }
}
function itemIssuesOf(it, slot, level) {
  const out = [], name = it?.name || 'an item';
  if (!it || typeof it !== 'object') return ['an empty or broken item'];
  const base = BASES[it.base];
  if (!base) return [`${name}: unknown base`];
  if (slot && SLOT_OF(slot) !== base.slot) out.push(`${name}: worn in the wrong slot`);
  if (!RARITY[it.rarity]) return [...out, `${name}: unknown rarity`];
  if (!Number.isInteger(it.ilvl) || it.ilvl < 1 || it.ilvl > Math.min(level, LEVEL_CAP) + ILVL_OVER_LEVEL) out.push(`${name}: item level ${it.ilvl} is too high`);
  const up = it.upgrade || 0;
  if (!Number.isInteger(up) || up < 0 || up > MAX_UPGRADE) out.push(`${name}: impossible upgrade +${up}`);
  if (it.element && !ELEMENTS.includes(it.element)) out.push(`${name}: unknown element`);
  if (out.length) return out;

  if (it.named) {
    const n = NAMED[it.named];
    if (!n) return [`${name}: unknown named item`];
    // The current shape, or an older one from before a rework (LEGACY_NAMED) for records made back then.
    const check = (def) => {
      const o = [], ref = namedItem(it.named, 'check', it.ilvl, undefined, def);
      if (it.base !== def.base || it.rarity !== def.rarity) o.push(`${name}: not what ${n.name} looks like`);
      if (!sameStats(it.stats, ref.stats)) o.push(`${name}: base stats do not match`);
      if (JSON.stringify(it.affixes || []) !== JSON.stringify(ref.affixes)) o.push(`${name}: affixes do not match`);
      if ((it.ability || null) !== (def.ability || null)) o.push(`${name}: wrong ability`);
      return o;
    };
    const now = check(n);
    if (!now.length) return out;
    for (const old of LEGACY_NAMED[it.named] || []) if (!check(old).length) return out;
    return [...out, ...now];
  }

  if (it.set && !DUNGEON_SETS[it.set]) out.push(`${name}: unknown set`);
  const ref = generateItem('check', { base: it.base, rarity: it.rarity, ilvl: it.ilvl, element: it.element || undefined });
  if (!sameStats(it.stats, ref.stats)) out.push(`${name}: base stats do not match its type, rarity and level`);
  const affixes = Array.isArray(it.affixes) ? it.affixes : [];
  if (affixes.length > RARITY[it.rarity].affixes) out.push(`${name}: too many affixes`);
  const seen = new Set();
  for (const a of affixes) {
    if (!AFFIXES[a?.k]) { out.push(`${name}: unknown affix`); continue; }
    if (seen.has(a.k)) out.push(`${name}: repeated affix`);
    seen.add(a.k);
    const [lo, hi] = affixRange(a.k, it.ilvl);
    if (!Number.isFinite(a.v) || a.v < lo || a.v > hi) out.push(`${name}: ${AFFIXES[a.k].label} ${a.v} is outside ${lo}–${hi}`);
  }
  if (it.ability && !(ITEM_ABILITIES[it.ability]?.slots || []).includes(base.slot)) out.push(`${name}: impossible ability`);
  return out;
}

// What is impossible about an Agent snapshot (or a public Agent doc with `level`).
export function snapIssues(snap) {
  try { return snapIssuesOf(snap); } catch { return ['a malformed snapshot']; }
}
function snapIssuesOf(snap) {
  const out = [];
  if (!snap || typeof snap !== 'object' || typeof snap.cls !== 'string' || !Object.hasOwn(CLASS_PRIMARY, snap.cls)) return ['unknown class'];
  if (snap.loadout != null && !Array.isArray(snap.loadout)) return ['a malformed loadout'];
  if (snap.gear != null && (typeof snap.gear !== 'object' || Array.isArray(snap.gear))) return ['malformed gear'];
  const L = snap.level;
  if (snap.race != null && !RACES[snap.race]) out.push('unknown race');
  if (!Number.isInteger(L) || L < 1 || L > LEVEL_CAP) out.push(`level ${L} is impossible`);
  // Starting attributes: 8–15 bought with 12 points, plus the class bonus (+2 first primary, +1 second).
  const [p1, p2] = CLASS_PRIMARY[snap.cls];
  let spent = 0;
  for (const k of SCORE_KEYS) {
    const bought = (snap.scores?.[k] ?? NaN) - (k === p1 ? 2 : k === p2 ? 1 : 0);
    if (!Number.isInteger(bought) || bought < BUY.min || bought > BUY.max) { out.push(`starting ${k} is impossible`); continue; }
    spent += bought - BUY.min;
  }
  if (spent > BUY.points) out.push(`starting attributes use ${spent} of ${BUY.points} points`);
  // Gear: every worn item, and no item worn twice.
  const ids = new Set();
  for (const [slot, it] of Object.entries(snap.gear || {})) {
    if (!it) continue;
    if (!SLOTS.includes(slot)) { out.push(`unknown slot ${slot}`); continue; }
    if (it.id && ids.has(it.id)) out.push(`${it.name || 'an item'} is worn twice`);
    ids.add(it.id);
    out.push(...itemIssues(it, slot, Number.isInteger(L) ? L : LEVEL_CAP));
  }
  for (const k of [...(snap.loadout || [])]) if (k && !ABILITIES[k] && !RETIRED_ABILITIES.includes(k)) out.push(`unknown ability ${k}`);
  return out;
}

export const plausibleSnap = (snap) => snapIssues(snap).length === 0;

// A copy with impossible gear removed and impossible attributes reset to the class's default spread.
export function cleanSnap(snap) {
  if (snapIssues({ cls: snap?.cls, level: 1, scores: null, gear: {} })[0] === 'unknown class') return snap;
  const L = Math.max(1, Math.min(LEVEL_CAP, Math.floor(snap.level) || 1));
  const gear = {};
  const ids = new Set();
  for (const [slot, it] of Object.entries(snap.gear || {})) {
    if (!it || !SLOTS.includes(slot) || ids.has(it.id) || itemIssues(it, slot, L).length) continue;
    ids.add(it.id); gear[slot] = it;
  }
  let scores = snap.scores;
  if (snapIssues({ cls: snap.cls, level: L, scores, gear: {} }).length) {
    // Default spread: 12 points split evenly over the two primaries, plus the class bonus.
    const [p1, p2] = CLASS_PRIMARY[snap.cls];
    scores = Object.fromEntries(SCORE_KEYS.map(k => [k, BUY.min]));
    scores[p1] += 6 + 2; scores[p2] += 6 + 1;
  }
  return { ...snap, level: L, scores, gear };
}
