// Agents of Claude — a player's goal for their Agent: free text ("Complete Grubnose's set and get the chase item"),
// kept in private progress.goal. Every autopilot decision reads it first and works toward it; when it is done the
// Agent goes back to its own choices.
//
// The text is the player's; the game also reads it for things it can check itself (a dungeon's set, its chase item,
// any named item), so progress is exact and "done" doesn't rest on Claude's word alone: a goal with checkable targets
// is done when they are all owned (in the bag or worn). A goal with none is done when the Agent's Claude says so.

import { DUNGEONS } from './world.js';
import { DUNGEON_SETS, NAMED } from './items.js';
import { MOBS } from './battle.js';

export const GOAL_MAX = 300;
export const cleanGoal = (t) => String(t || '').replace(/\s+/g, ' ').trim().slice(0, GOAL_MAX);

const norm = (s) => ' ' + String(s || '').toLowerCase().replace(/['’]s\b/g, '').replace(/[^a-z0-9 ]+/g, ' ').replace(/\s+/g, ' ').trim() + ' ';
const STOP = new Set(['the', 'of', 'king', 'goblin', 'set', 'hoard', 'crown', 'section', 'vault', 'shard', 'aegis']);
// Words that name a dungeon: its name, its set's name, its boss's name, and their distinctive words.
function dungeonWords(key) {
  const d = DUNGEONS[key], set = Object.values(DUNGEON_SETS).find(s => s.dungeon === key), boss = MOBS[d.rooms.find(r => r.boss)?.mobs?.[0]];
  const phrases = [d.name, set?.name, boss?.name].filter(Boolean).map(p => norm(p).trim());
  const words = phrases.flatMap(p => p.split(' ')).filter(w => w.length >= 5 && !STOP.has(w));
  return [...new Set([...phrases, ...words])];
}
const mentions = (t, w) => t.includes(` ${w} `) || t.includes(` ${w}s `) || t.includes(` ${w}es `);

// What the text names that the game can check: { dungeons: [key], targets: [{ kind: 'set'|'named', key, dungeon? }] }.
export function parseGoal(text) {
  const t = norm(text), dungeons = [], targets = [];
  for (const key of Object.keys(DUNGEONS)) if (dungeonWords(key).some(w => mentions(t, w))) dungeons.push(key);
  const wantsSet = /\b(set|sets|pieces?)\b/.test(t), wantsChase = /\bchase\b/.test(t);
  for (const key of dungeons) {
    const setKey = Object.keys(DUNGEON_SETS).find(k => DUNGEON_SETS[k].dungeon === key), chase = DUNGEONS[key].chase?.key;
    if (wantsSet && setKey) targets.push({ kind: 'set', key: setKey, dungeon: key });
    if (wantsChase && chase && NAMED[chase]) targets.push({ kind: 'named', key: chase, dungeon: key });
  }
  for (const [key, n] of Object.entries(NAMED)) if (!targets.some(x => x.kind === 'named' && x.key === key) && t.includes(norm(n.name))) {
    const dungeon = Object.keys(DUNGEONS).find(k => DUNGEONS[k].chase?.key === key) || null;
    targets.push({ kind: 'named', key, dungeon });
    if (dungeon && !dungeons.includes(dungeon)) dungeons.push(dungeon);
  }
  return { dungeons, targets };
}

// Progress from what the Agent owns (bag and worn items): one line per target, whether all are done (null when the
// game can't check the goal), and the ids of owned items that serve the goal (never sold or given away).
export function goalProgress(parsed, items) {
  const lines = [], keep = new Set(); let all = parsed.targets.length ? true : null;
  for (const tg of parsed.targets) {
    if (tg.kind === 'set') {
      const s = DUNGEON_SETS[tg.key], have = [], missing = [];
      for (const [slot, name] of Object.entries(s.pieces)) {
        const it = items.find(i => i?.set === tg.key && i.slot === slot);
        if (it) { have.push(name); keep.add(it.id); } else missing.push(name);
      }
      if (missing.length) all = false;
      lines.push({ done: !missing.length, text: `${s.name} set (drops from ${DUNGEONS[s.dungeon].name}'s boss): ${have.length} of 4${have.length ? ` (have ${have.join(', ')})` : ''}${missing.length ? `; missing ${missing.join(', ')}` : ''}.` });
    } else {
      const n = NAMED[tg.key], it = items.find(i => i?.named === tg.key);
      if (it) keep.add(it.id); else all = false;
      lines.push({ done: !!it, text: `${n.name}${tg.dungeon ? ` (chase item of ${DUNGEONS[tg.dungeon].name}: a rare boss drop, likelier on Heroic and Mythic)` : ''}: ${it ? 'got it' : 'not yet'}.` });
    }
  }
  return { lines, done: all, keep };
}

// The goal block every decision prompt starts with.
export function goalPromptLines(goal, prog) {
  if (!goal?.text || goal.done) return [];
  return ['', `YOUR PLAYER'S GOAL FOR YOU (your top priority until it is done): "${goal.text}"`,
    ...(prog?.lines?.length ? ['Progress the game can see:', ...prog.lines.map(l => `- ${l.done ? '[done] ' : ''}${l.text}`)] : []),
    ...(goal.note ? [`Your last note on it: ${goal.note}`] : []),
    'Choose what moves this goal forward (the dungeon or quest it needs, teaming up for it, keeping keys and gold for it, gear that helps you get it). Never sell or give away anything that counts toward it. Only do something else when nothing toward the goal is possible right now, and say why.',
    'Add "goalNote": "<one short sentence on your progress>", and "goalDone": true once the goal is fully achieved.'];
}
