// Agents of Claude — the activity log: everything an Agent did, day by day, so a player can see what happened while
// they were away. One private doc per SAST day (data/users/<uid>/activity/<YYYY-MM-DD>), never trimmed across days,
// plus a meta doc (activity/_meta: which days have entries, when the player last looked, whether it was backfilled).
//
// Entry: { id, at, kind, cat, text, why?, by?, decision? }
//   kind: decision (anything decided, by the Agent's Claude, its routine or the player) | outcome (what came of one) |
//         secret (a secret found: its own highlighted entry with story, how and reward) |
//         story (level-ups and other chronicle moments) | persona (its personality changed) | social | market | loot
//   cat:  trips | fights | road | gear | market | social | growth | loot | other (the log's filters)

export const DAY_MAX = 600;          // entries kept per day (a very busy day keeps its latest)
export const CATS = [['trips', 'Trips'], ['fights', 'Fights'], ['road', 'Road'], ['gear', 'Gear'], ['market', 'Market'], ['social', 'Social'], ['growth', 'Growth'], ['loot', 'Loot']];

const BY_DO = {
  patrol: 'trips', quest: 'trips', explore: 'trips', dungeon: 'trips', train: 'trips', training: 'trips', wait: 'trips',
  party: 'social', join: 'social', decline: 'social', tavern: 'social',
  duel: 'fights', 'duel-accept': 'fights', 'duel-decline': 'fights', pit: 'fights', fight: 'fights', tactics: 'fights',
  encounter: 'road', equip: 'gear', unequip: 'gear', 'keep-gear': 'gear', forge: 'gear',
  sell: 'market', buy: 'market', bid: 'market', gift: 'market', stats: 'growth', goal: 'growth', loot: 'loot',
};
export const catOfDecision = (d) => BY_DO[d] || 'other';
// An outcome's category: its decision's, or read from its text.
export function catOfOutcome(text, decisionCat = null) {
  if (decisionCat && decisionCat !== 'other') return decisionCat;
  const t = String(text || '');
  if (/^(Fair Duel|Practice duel|Pit bout|World boss|Fights on|How my build fought)/.test(t)) return 'fights';
  if (/Auction House|sold|bought/i.test(t)) return 'market';
  return 'trips';
}

// Add entries to a day doc: no duplicates (by id), in time order, the latest DAY_MAX kept.
export function addEntries(doc, entries) {
  const have = new Map((doc?.entries || []).map(e => [e.id, e]));
  for (const e of entries) if (e?.id && Number.isFinite(e.at)) have.set(e.id, { ...have.get(e.id), ...e });
  return { ...(doc || {}), entries: [...have.values()].sort((a, b) => a.at - b.at).slice(-DAY_MAX) };
}

// The log's first entries, from what the mind already holds (decisions and outcomes).
export function backfill(mind) {
  const m = mind || {}, cat = new Map();
  const out = (m.decisions || []).map(d => { const c = catOfDecision(d.do); cat.set(d.id, c);
    return { id: d.id, at: d.at, kind: 'decision', cat: c, text: d.what || d.do, why: d.why || '', by: d.by || 'claude' }; });
  for (const e of m.events || []) out.push({ id: e.id + '@' + e.at, at: e.at, kind: 'outcome', cat: catOfOutcome(e.text, cat.get(e.decision)), text: e.text, decision: e.decision || null });
  return out.filter(e => Number.isFinite(e.at));
}

// What happened since a moment, for the welcome-back banner: counts by category and the highlights.
export function summarize(entries, since) {
  const recent = (entries || []).filter(e => e.at > since);
  const by = {}; for (const e of recent) if (e.kind === 'decision') by[e.cat] = (by[e.cat] || 0) + 1;
  const decisions = recent.filter(e => e.kind === 'decision').length;
  const highlights = recent.filter(e => e.kind === 'story' || e.kind === 'persona' || (e.kind === 'outcome' && /won|lost|knocked out|succeeded|failed|Reached/i.test(e.text))).slice(-6);
  return { count: recent.length, decisions, by, highlights, first: recent[0]?.at || null };
}
