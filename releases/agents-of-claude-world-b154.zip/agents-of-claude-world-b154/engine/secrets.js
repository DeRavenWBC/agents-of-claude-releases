import { TZ_OFFSET_MS, TZ_ISO, worldDay, dayAt } from './worldtime.js';
// Agents of Claude — landmarks and secrets (rules version 1).
//
// Landmarks are short, repeatable explorations, one or two per zone. Secrets are hidden triggers: an item
// you happen to be wearing, the hour you set out, the phase of the moon, who is in your party. They never
// appear in the quest log or the Codex; item lore and landmark descriptions are the only clues.
// Every check reads the action as it was when it started (snapshot, start time, party), so it is
// deterministic and replayable like the rest of the world.

export const SITES = {
  hollow_barrow: { zone: 'promptwood', name: 'The Hollow Barrow', level: 8, minutes: 30,
    blurb: 'An old barrow on the hill. They say a witch was buried here with her staff, and that grave robbers found the coffin empty of both.',
    fights: [['goblin_shaman', 'goblin_shaman'], ['dire_wolf']] },
  ember_shrine: { zone: 'ashen', name: 'The Ember Shrine', level: 14, minutes: 30,
    blurb: 'The old road priests kept a fire burning here for three hundred years. It is still burning. Nobody feeds it.',
    fights: [['sand_wraith', 'bandit_raider']] },
  dry_oasis: { zone: 'ashen', name: 'The Dry Oasis', level: 17, minutes: 30,
    blurb: 'Dead palms around a basin of cracked mud. Caravan drivers swear it is full of water at night, but only for those who can see through mirages.',
    fights: [['dune_scorpion', 'dune_scorpion'], ['sand_wraith']] },
  reading_room: { zone: 'archive', name: 'The Reading Room', level: 34, minutes: 30,
    blurb: 'Long tables, green lamps, and books left open as if their readers just stepped away. The Archive notices who comes back to read.',
    fights: [['ink_wraith'], ['paper_moth', 'paper_moth']] },
  lightning_altar: { zone: 'thundercrag', name: 'The Lightning Altar', level: 44, minutes: 30,
    blurb: 'A ring of copper rods on a bare ledge. Lightning strikes it every few minutes, and something in the middle is always waiting for the next one.',
    fights: [['spark_imp', 'spark_imp'], ['static_elemental']] },
  heartwood: { zone: 'promptwood', name: 'The Heartwood', level: 12, minutes: 30,
    blurb: 'A ring of oaks so old their roots have grown together. Druids say the grove is waiting for a totem that remembers the sky to come home to the ground.',
    fights: [['dire_wolf', 'dire_wolf'], ['old_mossback']] },
  frozen_stair: { zone: 'frostfang', name: 'The Frozen Stair', level: 26, minutes: 30,
    blurb: 'Steps cut into the glacier, climbing to nothing. Up here the wind sounds like people arguing.',
    fights: [['crag_harpy', 'crag_harpy'], ['icebound_revenant']] },
};

const SAST_OFFSET_H = TZ_OFFSET_MS / 3_600_000;
export const sastHour = (ms) => new Date(ms + SAST_OFFSET_H * 3_600_000).getUTCHours();

// Moon phase 0..1 (0 new, 0.5 full) from a known new moon (2000-01-06 18:14 UTC).
const SYNODIC = 29.530588853;
export function moonPhase(ms) {
  const days = (ms - Date.UTC(2000, 0, 6, 18, 14)) / 86_400_000;
  return ((days / SYNODIC) % 1 + 1) % 1;
}
export const isFullMoon = (ms) => Math.abs(moonPhase(ms) - 0.5) < 0.034; // about two days a month
export const isNewMoon = (ms) => { const p = moonPhase(ms); return p < 0.034 || p > 0.966; }; // about two days a month

const wearing = (snap, named) => Object.values(snap?.gear || {}).some(it => it?.named === named);

/**
 * Secret definitions. `on` says where it can trigger: { site } for landmarks, { dungeon, difficulty }
 * after a boss clear, { patrolZone } for patrol encounters. `when(ctx)` gets { snap, party, startedAt }.
 * `how` says plainly how it is found: shown only to Agents who have found it (keep it in step with `on`/`when`).
 * `fights` use the Agent's own level (+ offset). `rewards` are granted once per Agent.
 */
export const SECRETS = {
  hexmother: {
    on: { site: 'hollow_barrow' }, when: ({ snap }) => wearing(snap, 'goblin_kings_ladle'),
    how: 'Explore the Hollow Barrow in Promptwood Vale while wearing the Goblin King\'s Ladle.',
    title: 'The Hexmother Wakes',
    text: 'The ladle turns cold in your hand and points at the barrow door like a dowsing rod. The runes on the handle match the runes on the stone. Something inside says: "My staff. You brought my staff."',
    win: 'Morwen crumbles to bone-dust. The ladle cracks, and the old staff grows out of it, whole again.',
    fights: [['morwen', 1]],
    rewards: { transform: { from: 'goblin_kings_ladle', to: 'morwens_hexstaff' }, title: 'Barrow-Breaker', gold: 600, xp: 1200 },
  },
  true_oasis: {
    on: { site: 'dry_oasis' }, when: ({ snap, startedAt }) => wearing(snap, 'mirage_veil') && sastHour(startedAt) < 4,
    how: 'Explore the Dry Oasis in the Ashen Barrens wearing the Mirage Veil, setting out between midnight and 04:00.',
    title: 'The True Oasis',
    text: 'Through the damp veil, in the small hours, the basin is full of black water and starlight. A djinn rises from it, older and calmer than the one in the dunes. "You can see. Then you may ask."',
    win: 'The djinn bows, unties a knot of blue silk from its wrist, and ties it around your finger.',
    fights: [['mirage_djinn', 3]],
    rewards: { named: 'wish_knot', title: 'Wish-Keeper', gold: 400, xp: 900, mount: 'wishweave_carpet' },
  },
  thaw: {
    on: { site: 'ember_shrine' }, when: ({ snap }) => wearing(snap, 'rimeheart_shard'),
    how: 'Explore the Ember Shrine in the Ashen Barrens while wearing the Rimeheart Shard.',
    title: 'The Thaw',
    text: 'The shard screams as you near the undying fire. Frost pours out of it and takes the shape of Matron Rimeheart, furious and half-melted.',
    win: 'The echo melts into the fire. The shard comes out of the flames warm, cold and humming at once.',
    fights: [['rimeheart_echo', 2]],
    rewards: { transform: { from: 'rimeheart_shard', to: 'heart_of_the_thaw' }, title: 'Fire-and-Frost', gold: 700, xp: 1500 },
  },
  white_stag: {
    on: { patrolZone: 'promptwood' }, when: ({ startedAt }) => isFullMoon(startedAt), chance: 0.35,
    how: 'Patrol Promptwood Vale during a full moon (about two days a month). It shows itself on roughly one patrol in three.',
    title: 'The White Stag',
    text: 'Under the full moon, a stag the colour of moonlight steps out of the trees and lowers its antlers at you.',
    win: 'The stag bows its head and is gone. Where it stood lies a shed antler, glowing faintly.',
    fights: [['white_stag', 2]],
    rewards: { named: 'stag_antler', title: 'Moon-Touched', xp: 800, mount: 'moonlit_stag' },
  },
  stair_summit: {
    on: { site: 'frozen_stair' }, when: ({ startedAt, found }) => isStormDayLocal(startedAt) && (found || []).length >= 1,
    how: 'Explore the Frozen Stair in Frostfang Peaks on a Thundercrag storm day, once you have found at least one other secret.',
    title: 'The Top of the Stair',
    text: 'Today the wind stops arguing. The Stair keeps going, up through the cloud, and at the top a winged shape of frost turns its head toward you. Something guards it.',
    win: 'The guardian falls back into the storm. The pegasus watches you for a long moment, then kneels.',
    fights: [['tempest_roc', 1]],
    rewards: { title: 'Stairwalker', xp: 1500, gold: 800, mount: 'skyfrost_pegasus' },
  },
  kings_larder: {
    on: { dungeon: 'gobbler_warren', difficulty: 'heroic' }, when: ({ party }) => party.length >= 3 && party.every(p => !p.hireling),
    how: 'Clear Gobbler Warren on Heroic with three or more players in the party and no hired help.',
    title: "The King's Larder",
    text: "Behind Grubnose's throne a door you never noticed swings open: 'LARDER: KING'S GUESTS ONLY. NO HIRED HELP.' Something in the pot is still moving.",
    win: 'The Stew settles down to a gentle simmer. On the shelf, the king\'s second-best pot lid.',
    fights: [['the_stew', 2]],
    rewards: { named: 'pot_lid', title: 'Larder Raider', gold: 500, xp: 1000 },
  },
  // Heirloom weapons: each class's legendary weapon has a secret that turns it into its mythic form.
  new_moon: {
    on: { patrolZone: 'ashen' }, when: ({ snap, startedAt }) => wearing(snap, 'dune_reavers_fangs') && isNewMoon(startedAt), chance: 0.35,
    how: "Patrol the Ashen Barrens during a new moon (about two days a month) wearing Dune Reaver's Fangs. It shows itself on roughly one patrol in three.",
    title: 'The Moonless Night',
    text: 'There is no moon tonight, and the Fangs go cold as a grave. A figure steps out of the dark that the moon would have shown you: the Reaver they were taken from, wanting them back.',
    win: 'The Reaver comes apart like smoke. The Fangs drink the last of the dark and stop shining for good.',
    fights: [['moonless_reaver', 2]],
    rewards: { transform: { from: 'dune_reavers_fangs', to: 'fangs_of_the_new_moon' }, title: 'Moonless', gold: 600, xp: 1200 },
  },
  tempered: {
    on: { site: 'lightning_altar' }, when: ({ snap }) => wearing(snap, 'glacier_splitter'),
    how: 'Explore the Lightning Altar in Thundercrag with the Glacier-Splitter equipped.',
    title: 'Tempered by Lightning',
    text: 'The copper rods bend toward the axe. Lightning finds it, and the old ice on the blade screams. Something frozen into that ice comes out with it, and it holds a grudge.',
    win: 'The Grudge shatters. The axe comes out of the next strike blue-hot, ringing, and it will not stop humming.',
    fights: [['glaciers_grudge', 2]],
    rewards: { transform: { from: 'glacier_splitter', to: 'thunderforged_splitter' }, title: 'Unbroken', gold: 800, xp: 1600 },
  },
  matriarch: {
    on: { patrolZone: 'frostfang' }, when: ({ snap }) => wearing(snap, 'frostbite_longbow'), chance: 0.3, needsPet: true,
    how: 'Patrol Frostfang Peaks with the Frostbite Longbow equipped (about one patrol in three), then defeat the Hoarfrost Matriarch without your companion ever falling.',
    title: 'The Hoarfrost Matriarch',
    text: 'The bowstring twangs on its own, like a wingbeat. Above the pass, the mother of every wyvern in the Peaks folds her wings and drops toward you and your companion.',
    win: 'The Matriarch lands, bows her long neck to your companion, and leaves a single tendon of frost-wire behind as she goes.',
    fights: [['hoarfrost_matriarch', 2]],
    rewards: { transform: { from: 'frostbite_longbow', to: 'wyvernstring' }, title: 'Wyvern-Friend', gold: 700, xp: 1400 },
  },
  last_reader: {
    on: { site: 'reading_room' }, when: ({ snap, startedAt }) => wearing(snap, 'stormcallers_staff') && sastHour(startedAt) < 4,
    how: "Explore the Archive's Reading Room with the Stormcaller's Staff equipped, setting out between midnight and 04:00.",
    title: 'The Last Reader',
    text: 'In the small hours the staff crackles like pages turning, and every lamp in the Reading Room goes out but one. Under it sits a reader who has been reading for a very long time and does not want company.',
    win: 'The Last Reader closes the book. The final page tears free and wraps itself around your staff.',
    fights: [['the_last_reader', 2]],
    rewards: { transform: { from: 'stormcallers_staff', to: 'staff_of_the_last_page' }, title: 'Last Reader', gold: 800, xp: 1600 },
  },
  heartwood: {
    on: { site: 'heartwood' }, when: ({ snap }) => wearing(snap, 'totem_of_the_spire'),
    how: 'Explore the Heartwood in Promptwood Vale with the Totem of the Spire equipped.',
    title: 'Roots Remember',
    text: 'The faces on the totem stop looking up. The old oaks lean in, and the roots under your feet heave: the grove has a guardian, and it wants to know if you are worthy of bringing a piece of the sky home.',
    win: 'The guardian settles back into the earth. Green shoots wrap the totem, and its faces turn to look at the ground.',
    fights: [['heartwood_guardian', 2]],
    rewards: { transform: { from: 'totem_of_the_spire', to: 'heartwood_totem' }, title: 'Rootkeeper', gold: 800, xp: 1600 },
  },
};

// Which secrets fire for this context (not yet found by this Agent). Pure; `r` is the action's seeded RNG.
// Storm days, as in the Bestiary (kept local to avoid an import cycle).
const isStormDayLocal = (ms) => { const d = worldDay(ms); let h = 2166136261; for (const c of `storm|${d}`) { h ^= c.charCodeAt(0); h = Math.imul(h, 16777619); } return parseInt((h >>> 0).toString(16).padStart(8, '0').slice(0, 6), 16) % 4 === 0; };

export function secretsFor(where, ctx, found = [], r = Math.random) {
  if (!ctx.startedAt) return []; // actions from before secrets existed never trigger one
  ctx = { ...ctx, found };
  return Object.entries(SECRETS).filter(([id, s]) => {
    if (found.includes(id)) return false;
    const on = s.on;
    if (where.site && on.site !== where.site) return false;
    if (where.dungeon && (on.dungeon !== where.dungeon || (on.difficulty && on.difficulty !== where.difficulty))) return false;
    if (where.patrolZone && on.patrolZone !== where.patrolZone) return false;
    if (!where.site && !where.dungeon && !where.patrolZone) return false;
    if (!s.when(ctx)) return false;
    return s.chance == null || r() < s.chance;
  }).map(([id]) => id);
}

/* --------------------------------------------------------------- Rumours */
// Vague lore tidbits that circle each secret without spelling it out, plus a few that lead nowhere yet.
// The page surfaces them in result cards, at the trainer, on the bounty board and in the Codex.
export const RUMOURS = [
  { about: 'hexmother', zone: 'promptwood', text: "Goblins can't carve runes. Whoever made that ladle's handle wasn't a goblin." },
  { about: 'hexmother', zone: 'promptwood', text: 'Old Wenna says the barrow on the hill hums when the right thing comes home.' },
  { about: 'hexmother', zone: 'promptwood', text: 'A witch never really lets go of her staff. Not even after she lets go of everything else.' },
  { about: 'hexmother', zone: null, text: 'Grave robbers took two things from the barrow on the hill. Only one of them was gold, and the goblins have the other.' },
  { about: 'true_oasis', zone: 'ashen', text: 'Caravan drivers who cross by night swear the Dry Oasis holds water. The ones who cross by day call them liars.' },
  { about: 'true_oasis', zone: 'ashen', text: 'A veil that sees through one mirage might see through another.' },
  { about: 'true_oasis', zone: null, text: 'The djinn in the dunes is young. They say its mother sleeps somewhere wetter, and only wakes in the small hours.' },
  { about: 'thaw', zone: 'frostfang', text: 'Ice remembers. Bring it near a fire that never dies and it remembers louder.' },
  { about: 'thaw', zone: 'ashen', text: 'The shrine priests claim their flame has melted a crown before.' },
  { about: 'thaw', zone: null, text: "The Matron's heart was never in her vault. Pieces of it were, though." },
  { about: 'white_stag', zone: 'promptwood', text: "Promptwood hunters stay home when the moon is round. They call it bad luck. They mean it's bad for the hunter." },
  { about: 'white_stag', zone: 'promptwood', text: 'Something white walks the vale when the night is at its brightest.' },
  { about: 'white_stag', zone: null, text: 'There is an antler that glows once a month, wherever it happens to be lying.' },
  { about: 'kings_larder', zone: 'promptwood', text: 'Grubnose never shared supper with hired hands. Only with proper guests.' },
  { about: 'kings_larder', zone: null, text: "Every king keeps a larder. They say the goblin king's is still cooking." },
  { about: 'kings_larder', zone: null, text: 'Bring friends into the warren, not sellswords. The king can smell coin.' },
  { about: 'frozen_stair', zone: 'frostfang', text: 'On the Frozen Stair the wind argues with itself, as if waiting for someone to settle it.' },
  { about: 'frozen_stair', zone: 'frostfang', text: 'Nobody has reached the top of the Frozen Stair. Some say there is no top. Some say there is, but only on certain days.' },
  { about: 'new_moon', zone: 'ashen', text: 'The Dune Reaver lost his blades, not his grudge. He walks when there is no moon to see him.' },
  { about: 'new_moon', zone: null, text: 'Some blades shine at noon. The best ones learn not to shine at all.' },
  { about: 'tempered', zone: 'frostfang', text: 'An axe was frozen blade-first into the glacier. The ice took it from a storm, and storms remember.' },
  { about: 'tempered', zone: 'thundercrag', text: 'The altar rods bend toward cold iron. The giants say lightning likes to finish what it started.' },
  { about: 'matriarch', zone: 'frostfang', text: 'Every wyvern in the Peaks has the same mother. She only comes down for an archer who keeps their companion safe.' },
  { about: 'matriarch', zone: null, text: 'A bow strung with a frozen hair can hear wings that are not there yet.' },
  { about: 'last_reader', zone: 'archive', text: 'One reader never leaves the Reading Room. You can only see them by the light of a staff that has read lightning.' },
  { about: 'last_reader', zone: null, text: 'Storms are just stories told very fast. Some staves learn to read them, late at night.' },
  { about: 'heartwood', zone: 'promptwood', text: 'The Heartwood is waiting for something carved from a lightning-split tree to come home.' },
  { about: 'heartwood', zone: 'thundercrag', text: 'The pines on the Spire grew from Promptwood acorns, the druids say. Their faces still miss the forest floor.' },
  { about: 'archive', zone: null, text: 'Every library has a book nobody can find. The Whispering Archive has a whole room of them.' },
  { about: 'stag', zone: 'promptwood', text: 'They say the white stag lets one rider in a thousand onto its back. Nobody knows what the other nine hundred and ninety-nine did wrong.' },
  { about: 'carpet', zone: 'ashen', text: 'A wish is a strange thing to weave. The old djinn are said to make carpets of the ones nobody claimed.' },
  { about: 'pegasus', zone: 'frostfang', text: 'Shepherds in the high passes swear they have seen something with wings land on the Frozen Stair, but only when the sky over the Spire is angry.' },
  { about: 'staff', zone: null, text: 'Old witches never throw anything away. Especially not their staves. Especially not when stolen.' },
  { about: 'archive', zone: 'archive', text: 'The Reading Room lamps burn brighter for regulars. The librarians say the Archive keeps a list.' },
  { about: 'wyrm', zone: 'thundercrag', text: 'The giants say the Storm Wyrm only respects a fight where nobody falls.' },
  { about: 'wyrm', zone: null, text: 'A storm is just a lot of small tokens moving very fast, says the old sky-priest. Nobody knows what he means.' },
  { about: 'mirror', zone: null, text: 'A door with no house is still a door. What matters is who you bring through it, and what they remember.' },
];

// One rumour, fixed by a seed. Prefers rumours tied to `zone` (or general ones), and skips secrets already found.
export function rumourFor(seed, { zone = null, found = [] } = {}) {
  const pool = RUMOURS.filter(x => !found.includes(x.about) && (x.zone === zone || x.zone === null));
  const list = pool.length ? pool : RUMOURS;
  let h = 2166136261; for (const c of String(seed)) { h ^= c.charCodeAt(0); h = Math.imul(h, 16777619); }
  return list[(h >>> 0) % list.length].text;
}
