// Agents of Claude — world: zones, patrols, quests, dungeons, loot (rules version 1).
// Every action is resolved from (seed, snapshot): the same inputs always give the same fights,
// rewards and loot, so a result can be recomputed and replayed later.

import { makeRng } from './rng.js';
import { simulate, makeAgentUnit, makeMobUnit, deriveStats, PER_LEVEL, MOBS } from './battle.js';
import { generateItem, namedItem, setPiece, SET_OF_DUNGEON, NAMED } from './items.js';
const SET_SLOTS = ['helm', 'gloves', 'boots', 'amulet'];
const MOBS_NAME = (k) => MOBS[k]?.name || k;
import { doorReward } from './codex-rewards.js';
import { SITES, SECRETS, secretsFor } from './secrets.js';
import { rareFor, RARE_SPAWNS, MIMIC_CHANCE } from './bestiary.js';
import { MOUNTS, MOUNT_DROPS, RARE_MOUNT_DROPS, travelFactor } from './mounts.js';
export { SITES, SECRETS };

export const WORLD_RULES = 1;
const MIN = 60_000;

/* -------------------------------------------------------------- Zones */

export const ZONES = {
  promptwood: {
    name: 'Promptwood Vale', levels: [1, 10], element: 'nature',
    blurb: 'Sunlit forest at the edge of the Weave. Goblin scouts, dire wolves and hedge shamans.',
    encounters: [
      { mobs: ['goblin_scout'], w: 4 },
      { mobs: ['dire_wolf'], w: 3 },
      { mobs: ['goblin_scout', 'goblin_scout'], w: 2 },
      { mobs: ['goblin_shaman', 'goblin_scout'], w: 2 },
      { mobs: ['dire_wolf', 'dire_wolf'], w: 1 },
      { mobs: ['old_mossback'], w: 0.3, elite: true },
    ],
  },
  ashen: {
    name: 'Ashen Barrens', levels: [10, 20], element: 'fire', unlock: 10,
    blurb: 'Sun-scorched ruins of an old trade road. Bandits, dune scorpions and the singing sand wraiths.',
    encounters: [
      { mobs: ['bandit_raider'], w: 4 },
      { mobs: ['dune_scorpion'], w: 3 },
      { mobs: ['bandit_raider', 'bandit_raider'], w: 2 },
      { mobs: ['sand_wraith', 'bandit_raider'], w: 2 },
      { mobs: ['dune_scorpion', 'dune_scorpion'], w: 1 },
      { mobs: ['mirage_djinn'], w: 0.3, elite: true },
    ],
  },
  frostfang: {
    name: 'Frostfang Peaks', levels: [20, 30], element: 'frost', unlock: 20,
    blurb: 'Knife-edged mountains above the cloud line. Rime stalkers, glacier trolls, and a witch in a palace of ice. Fire falters in the cold; storms cut through it.',
    encounters: [
      { mobs: ['rime_stalker'], w: 4 },
      { mobs: ['glacier_troll'], w: 3 },
      { mobs: ['rime_stalker', 'rime_stalker'], w: 2 },
      { mobs: ['frost_wisp', 'icebound_revenant'], w: 2 },
      { mobs: ['crag_harpy', 'crag_harpy'], w: 1.5 },
      { mobs: ['hoarfrost_wyvern'], w: 0.3, elite: true },
    ],
  },
  archive: {
    name: 'The Whispering Archive', levels: [30, 40], element: 'shadow', unlock: 30,
    blurb: 'A library that kept growing after its librarians stopped. The books whisper, the ink walks, and the lamps watch. Steel is little use against words: bring magic resist.',
    encounters: [
      { mobs: ['ink_wraith'], w: 4 },
      { mobs: ['book_golem'], w: 3 },
      { mobs: ['paper_moth', 'paper_moth'], w: 2 },
      { mobs: ['lantern_wisp', 'archive_warden'], w: 2 },
      { mobs: ['ink_wraith', 'book_golem'], w: 1.5 },
      { mobs: ['the_redactor'], w: 0.3, elite: true },
    ],
  },
  thundercrag: {
    name: 'Thundercrag Spire', levels: [40, 50], element: 'storm', unlock: 40,
    blurb: 'A needle of rock that pierces the storm itself. Giants climb it, imps ride the lightning, and at the top something old is coiled in the clouds.',
    encounters: [
      { mobs: ['thunder_giant'], w: 4 },
      { mobs: ['spark_imp', 'spark_imp'], w: 3 },
      { mobs: ['storm_harpy', 'storm_harpy'], w: 2 },
      { mobs: ['static_elemental', 'skyguard_sentinel'], w: 2 },
      { mobs: ['thunder_giant', 'spark_imp'], w: 1.5 },
      { mobs: ['tempest_roc'], w: 0.3, elite: true },
    ],
  },
};
export const ZONE_ORDER = ['promptwood', 'ashen', 'frostfang', 'archive', 'thundercrag'];

export const PATROL_MINUTES = [15, 30, 60, 120, 240, 480];
export const REST_MINUTES = 30;
export const KEYS = { perDay: 3, max: 7 };

/* ------------------------------------------------------------- Quests */
// Each step: fights in order (mob lists at an offset from the quest level), optional path choice.

export const QUESTS = [
  { zone: 'promptwood', id: 'goblin_trouble', title: 'Goblin Trouble', level: 1, minutes: 30,
    blurb: 'Goblin scouts are raiding the woodcutters\' camp. Drive them off.',
    fights: [['goblin_scout'], ['goblin_scout', 'goblin_scout']],
    reward: { xp: 60, gold: 25, item: { slot: 'weapon', rarity: 'uncommon' } } },
  { zone: 'promptwood', id: 'howling_at_dusk', title: 'The Howling at Dusk', level: 2, minutes: 45,
    blurb: 'Wolves circle the Brindle farm every night. The farmer will pay for peace.',
    paths: {
      track: { label: 'Track the pack to its den', fights: [['dire_wolf'], ['dire_wolf', 'dire_wolf']], reward: { item: { rarity: 'rare' } } },
      guard: { label: 'Guard the farm until dawn', fights: [['dire_wolf'], ['goblin_scout'], ['dire_wolf']], reward: { gold: 40 } },
    },
    reward: { xp: 90, gold: 30 } },
  { zone: 'promptwood', id: 'hedge_shamans', title: 'Hedge Shamans', level: 4, minutes: 45,
    blurb: 'Goblin shamans are cursing the springs. Break their circle.',
    fights: [['goblin_shaman', 'goblin_scout'], ['goblin_shaman', 'goblin_shaman']],
    reward: { xp: 140, gold: 45, item: { slot: 'trinket', rarity: 'rare' } } },
  { zone: 'promptwood', id: 'old_mossback', title: 'Old Mossback', level: 6, minutes: 60,
    blurb: 'An ancient bear-turtle has woken in the hollow. The rangers want it moved, one way or another.',
    paths: {
      fight: { label: 'Face it head on', fights: [['old_mossback']], reward: { item: { rarity: 'rare', slot: 'chest' } } },
      lure: { label: 'Lure it out past the wolves', fights: [['dire_wolf', 'dire_wolf'], ['old_mossback', -2]], reward: { gold: 60 } },
    },
    reward: { xp: 200, gold: 60 } },
  { zone: 'promptwood', id: 'warren_map', title: 'The Warren Map', level: 8, minutes: 60,
    blurb: 'A goblin courier carries a map of the Gobbler Warren. Catch him before he reaches the hills.',
    fights: [['goblin_scout', 'goblin_scout'], ['goblin_shaman', 'dire_wolf'], ['goblin_scout', 'goblin_shaman']],
    reward: { xp: 260, gold: 80, keys: 1 } },
  { zone: 'promptwood', id: 'king_of_the_warren', title: 'King of the Warren', level: 10, minutes: 60, needsClear: 'gobbler_warren',
    blurb: 'Grubnose is beaten but not broken. Clear his war band before he rallies the tribes again.',
    fights: [['goblin_shaman', 'goblin_scout', 'goblin_scout'], ['old_mossback'], ['goblin_shaman', 'dire_wolf', 'dire_wolf']],
    reward: { xp: 400, gold: 150, item: { rarity: 'epic' } } },

  // Ashen Barrens
  { zone: 'ashen', id: 'dust_on_the_road', title: 'Dust on the Road', level: 10, minutes: 45,
    blurb: 'Bandits are robbing caravans on the old trade road. The caravan master wants them gone.',
    fights: [['bandit_raider'], ['bandit_raider', 'bandit_raider']],
    reward: { xp: 450, gold: 120, item: { slot: 'weapon', rarity: 'rare' } } },
  { zone: 'ashen', id: 'singing_sands', title: 'The Singing Sands', level: 12, minutes: 60,
    blurb: 'At dusk the dunes sing, and travellers walk into them and never come back.',
    paths: {
      follow: { label: 'Follow the singing', fights: [['sand_wraith'], ['sand_wraith', 'sand_wraith']], reward: { item: { rarity: 'rare' } } },
      seal: { label: 'Seal the old well instead', fights: [['dune_scorpion'], ['dune_scorpion', 'bandit_raider']], reward: { gold: 90 } },
    },
    reward: { xp: 520, gold: 130 } },
  { zone: 'ashen', id: 'scorpion_season', title: 'Scorpion Season', level: 14, minutes: 60,
    blurb: 'The scorpions are breeding in the ruined baths. Clear the nest before it hatches.',
    fights: [['dune_scorpion', 'dune_scorpion'], ['dune_scorpion', 'bandit_raider'], ['dune_scorpion', 'dune_scorpion']],
    reward: { xp: 600, gold: 150, item: { slot: 'trinket', rarity: 'rare' } } },
  { zone: 'ashen', id: 'the_mirage', title: 'The Mirage', level: 16, minutes: 60,
    blurb: 'A djinn guards an oasis that is not there. It trades in wishes, and keeps what it trades for.',
    paths: {
      confront: { label: 'Confront the djinn', fights: [['mirage_djinn']], reward: { named: 'mirage_veil' } },
      bargain: { label: 'Bargain, then fight its servants', fights: [['bandit_raider', 'bandit_raider'], ['mirage_djinn', -2]], reward: { gold: 160 } },
    },
    reward: { xp: 700, gold: 160 } },
  { zone: 'ashen', id: 'bazaar_keys', title: 'Keys to the Bazaar', level: 18, minutes: 60,
    blurb: 'The Sunken Bazaar only opens for those carrying a merchant\'s seal. Take one from the raiders.',
    fights: [['bandit_raider', 'bandit_raider'], ['sand_wraith', 'bandit_raider'], ['brass_golem']],
    reward: { xp: 800, gold: 200, keys: 1 } },
  { zone: 'ashen', id: 'sultans_debt', title: "The Sultan's Debt", level: 20, minutes: 75, needsClear: 'sunken_bazaar',
    blurb: 'With the Sultan fallen, his creditors come to collect from whoever holds his gold. That is you.',
    fights: [['bandit_raider', 'sand_wraith'], ['mirage_djinn', -2]],
    reward: { xp: 1000, gold: 300, item: { rarity: 'epic' } } },
  { zone: 'frostfang', id: 'the_pass', title: 'The Pass', level: 21, minutes: 60,
    blurb: 'The only road over the peaks is a ledge a cart wide. Something has been eating the carts.',
    fights: [['rime_stalker'], ['rime_stalker', 'rime_stalker']],
    reward: { xp: 1100, gold: 300, item: { slot: 'boots', rarity: 'rare' } } },
  { zone: 'frostfang', id: 'harpy_eyrie', title: 'Harpy Eyrie', level: 22, minutes: 60,
    blurb: 'Harpies have taken the signal tower. The valley below has had no warning of storms for a month.',
    paths: {
      climb: { label: 'Climb the tower', fights: [['crag_harpy', 'crag_harpy'], ['crag_harpy', 'crag_harpy']], reward: { item: { rarity: 'rare' } } },
      smoke: { label: 'Smoke them out, fight what falls', fights: [['crag_harpy'], ['glacier_troll']], reward: { gold: 160 } },
    },
    reward: { xp: 1200, gold: 320 } },
  { zone: 'frostfang', id: 'troll_toll', title: 'Troll Toll', level: 24, minutes: 75,
    blurb: 'A glacier troll has built a bridge and wants paying. It does not take coin.',
    fights: [['glacier_troll'], ['glacier_troll', 'rime_stalker']],
    reward: { xp: 1350, gold: 360, item: { slot: 'weapon', rarity: 'rare' } } },
  { zone: 'frostfang', id: 'the_frozen_dead', title: 'The Frozen Dead', level: 26, minutes: 75,
    blurb: 'The climbers lost in the last avalanche have come back down the mountain. They are not looking for help.',
    fights: [['icebound_revenant'], ['frost_wisp', 'icebound_revenant'], ['icebound_revenant', 'icebound_revenant']],
    reward: { xp: 1500, gold: 400, item: { slot: 'chest', rarity: 'epic' } } },
  { zone: 'frostfang', id: 'wyvern_hunt', title: 'Wyvern Hunt', level: 28, minutes: 90,
    blurb: 'The wyvern nests above the vault door. Nobody gets in until it comes down.',
    paths: {
      lure: { label: 'Lure it down with bait', fights: [['rime_stalker', 'rime_stalker'], ['hoarfrost_wyvern', -2]], reward: { gold: 220 } },
      climb: { label: 'Climb to the nest', fights: [['crag_harpy', 'crag_harpy'], ['hoarfrost_wyvern']], reward: { item: { rarity: 'epic' } } },
    },
    reward: { xp: 1700, gold: 450, keys: 1 } },
  { zone: 'frostfang', id: 'thaw', title: 'Thaw', level: 30, minutes: 90, needsClear: 'glacier_vault',
    blurb: 'With the Matron gone, the glacier is melting. The valley needs warning, and the peaks are emptying of everything that lived in the cold.',
    fights: [['glacier_troll', 'frost_wisp'], ['hoarfrost_wyvern', -2]],
    reward: { xp: 2000, gold: 600, item: { rarity: 'epic' }, mount: 'frostmane_elk' } },
  // The Whispering Archive (30–40)
  { zone: 'archive', id: 'overdue', title: 'Overdue', level: 31, minutes: 75,
    blurb: 'The Archive has started sending its own collectors after borrowed books. They do not stop at the borrower.',
    fights: [['ink_wraith'], ['ink_wraith', 'paper_moth']], reward: { xp: 2200, gold: 650, item: { slot: 'gloves', rarity: 'rare' } } },
  { zone: 'archive', id: 'quiet_please', title: 'Quiet, Please', level: 32, minutes: 75,
    blurb: 'Every sound in the east wing wakes something. Something is making a great deal of sound.',
    paths: {
      sneak: { label: 'Creep through the stacks', fights: [['paper_moth', 'paper_moth'], ['lantern_wisp']], reward: { item: { rarity: 'epic' } } },
      silence: { label: 'Find and silence the noise', fights: [['book_golem'], ['book_golem', 'archive_warden']], reward: { gold: 300 } },
    }, reward: { xp: 2400, gold: 700 } },
  { zone: 'archive', id: 'the_burned_index', title: 'The Burned Index', level: 34, minutes: 90,
    blurb: 'Someone burned the catalogue. Without it, the Archive cannot find its own way out.',
    fights: [['lantern_wisp', 'lantern_wisp'], ['archive_warden', 'ink_wraith'], ['book_golem']], reward: { xp: 2700, gold: 780, item: { slot: 'chest', rarity: 'epic' } } },
  { zone: 'archive', id: 'marginalia', title: 'Marginalia', level: 36, minutes: 90,
    blurb: 'Notes in the margins of a thousand books, all in the same hand, all warning about the same page.',
    fights: [['ink_wraith', 'ink_wraith'], ['the_redactor', -2]], reward: { xp: 3000, gold: 850, item: { slot: 'trinket', rarity: 'epic' } } },
  { zone: 'archive', id: 'the_sealed_wing', title: 'The Sealed Wing', level: 38, minutes: 90,
    blurb: 'The last door in the Archive is sealed with wax and a word. You have the word now. You wish you did not.',
    fights: [['archive_warden', 'archive_warden'], ['book_golem', 'lantern_wisp'], ['the_redactor']], reward: { xp: 3300, gold: 950, keys: 1 } },
  { zone: 'archive', id: 'last_page', title: 'The Last Page', level: 40, minutes: 100, needsClear: 'restricted_section',
    blurb: 'The Head Librarian is gone, and the books are quiet for the first time in a century. One page still turns by itself.',
    fights: [['ink_wraith', 'lantern_wisp'], ['the_redactor', -1]], reward: { xp: 3800, gold: 1100, item: { rarity: 'legendary' }, mount: 'bookwyrm' } },
  // Thundercrag Spire (40–50)
  { zone: 'thundercrag', id: 'the_climb', title: 'The Climb', level: 41, minutes: 90,
    blurb: 'The first thousand steps are carved. After that you use the giants as handholds, carefully.',
    fights: [['thunder_giant'], ['thunder_giant', 'spark_imp']], reward: { xp: 4200, gold: 1200, item: { slot: 'boots', rarity: 'epic' } } },
  { zone: 'thundercrag', id: 'imp_weather', title: 'Imp Weather', level: 42, minutes: 90,
    blurb: 'Spark imps are riding the lightning down to the valley farms. Somebody has to ground them.',
    paths: {
      ground: { label: 'Ground them at the copper spire', fights: [['spark_imp', 'spark_imp'], ['static_elemental']], reward: { item: { rarity: 'epic' } } },
      chase: { label: 'Chase them into the clouds', fights: [['spark_imp', 'storm_harpy'], ['storm_harpy', 'storm_harpy']], reward: { gold: 400 } },
    }, reward: { xp: 4500, gold: 1300 } },
  { zone: 'thundercrag', id: 'the_sentinels', title: 'The Sentinels', level: 44, minutes: 100,
    blurb: 'Bronze guards line the upper path. They were built to keep something in, not to keep you out.',
    fights: [['skyguard_sentinel', 'skyguard_sentinel'], ['skyguard_sentinel', 'static_elemental'], ['thunder_giant']], reward: { xp: 5000, gold: 1450, item: { slot: 'weapon', rarity: 'epic' } } },
  { zone: 'thundercrag', id: 'roc_nest', title: "The Roc's Nest", level: 46, minutes: 100,
    blurb: 'The Tempest Roc nests on the last ledge before the summit. Its eggs crackle.',
    paths: {
      steal: { label: 'Steal an egg', fights: [['storm_harpy', 'storm_harpy'], ['tempest_roc', -2]], reward: { gold: 500 } },
      fight: { label: 'Fight the roc in the open', fights: [['tempest_roc']], reward: { item: { rarity: 'legendary' } } },
    }, reward: { xp: 5400, gold: 1550, keys: 1 } },
  { zone: 'thundercrag', id: 'eye_of_the_storm', title: 'Into the Eye', level: 48, minutes: 110,
    blurb: 'The clouds part at the summit, just for a moment, and you see an eye the size of a house open and look at you.',
    fights: [['thunder_giant'], ['skyguard_sentinel', 'spark_imp']], reward: { xp: 5900, gold: 1700, item: { slot: 'helm', rarity: 'epic' } } },
  { zone: 'thundercrag', id: 'calm', title: 'Calm', level: 50, minutes: 120, needsClear: 'wyrms_crown',
    blurb: 'For the first time anyone remembers, there is no storm over the Spire. The giants do not know what to do with themselves.',
    fights: [['thunder_giant'], ['tempest_roc', -3]], reward: { xp: 7000, gold: 2000, item: { rarity: 'legendary' }, mount: 'stormcloud_ram' } },
];

// The Door Without a House: a secret chain opened by the Strange Door patrol event. Quests run at
// the Agent's own level; the last grants a random hidden ability the Agent doesn't have yet.
QUESTS.push(
  { zone: 'door', id: 'door_threshold', title: 'The Threshold', level: 'agent', minutes: 30,
    blurb: 'A door stands alone in a clearing, frame and all, with no house behind it. It is ajar.',
    fights: [['goblin_shaman', 'goblin_shaman']], reward: { xp: 150, gold: 60 } },
  { zone: 'door', id: 'door_hallway', title: 'The Hallway That Should Not Be', level: 'agent', minutes: 45,
    blurb: 'Behind the door is a hallway longer than the clearing is wide. Something whispers from the far end.',
    fights: [['sand_wraith'], ['sand_wraith', 'goblin_shaman']], reward: { xp: 250, gold: 90 } },
  { zone: 'door', id: 'door_room', title: 'The Room at the End', level: 'agent', minutes: 60,
    blurb: 'The last room holds only a mirror. Your reflection is already fighting.',
    fights: [['sand_wraith', 'sand_wraith'], ['mirage_djinn', -2]], reward: { xp: 400, gold: 150, hidden: true } },
);

export const QUEST_CHAINS = Object.fromEntries([...ZONE_ORDER, 'door'].map(z => [z, QUESTS.filter(q => q.zone === z)]));

/* ----------------------------------------------------------- Dungeons */

export const DUNGEONS = {
  gobbler_warren: {
    name: 'Gobbler Warren', zone: 'promptwood', level: 10, minutes: 45, keys: 1,
    blurb: 'Tunnels under the hills where Goblin King Grubnose hoards everything shiny. Bring friends.',
    rooms: [
      { name: 'Guard tunnel', mobs: ['goblin_scout', 'goblin_scout', 'goblin_scout'] },
      { name: 'Kennels', mobs: ['dire_wolf', 'dire_wolf'] },
      { name: 'Shaman circle', mobs: ['goblin_shaman', 'goblin_shaman', 'goblin_scout'] },
      { name: 'Stew hall', mobs: ['goblin_scout', 'dire_wolf', 'goblin_shaman'] },
      { name: "Grubnose's throne", mobs: ['grubnose'], boss: true },
    ],
    chase: { key: 'goblin_kings_ladle', chance: 3, pity: 0.5 },
  },
  sunken_bazaar: {
    name: 'Sunken Bazaar', zone: 'ashen', level: 18, minutes: 60, keys: 1,
    blurb: 'A market swallowed by the sands, still guarded by brass and still ruled by its Sultan.',
    rooms: [
      { name: 'Collapsed gate', mobs: ['bandit_raider', 'bandit_raider', 'dune_scorpion'] },
      { name: 'Spice hall', mobs: ['sand_wraith', 'sand_wraith', 'bandit_raider'] },
      { name: 'Brass foundry', mobs: ['brass_golem', 'brass_golem'] },
      { name: 'Treasury', mobs: ['brass_golem', 'sand_wraith', 'dune_scorpion'] },
      { name: "The Sultan's court", mobs: ['brass_sultan'], boss: true },
    ],
    chase: { key: 'sultans_signet', chance: 3, pity: 0.5 },
  },
  glacier_vault: {
    name: 'Glacier Vault', zone: 'frostfang', level: 28, minutes: 75, keys: 1,
    blurb: "A palace carved inside the glacier, where Matron Rimeheart keeps everything the mountain has ever frozen.",
    rooms: [
      { name: 'Ice gate', mobs: ['rime_stalker', 'rime_stalker', 'glacier_troll'] },
      { name: 'Hall of the frozen', mobs: ['icebound_revenant', 'icebound_revenant', 'frost_wisp'] },
      { name: 'Troll barracks', mobs: ['glacier_troll', 'glacier_troll', 'rime_stalker'] },
      { name: 'Wisp gallery', mobs: ['frost_wisp', 'frost_wisp', 'crag_harpy'] },
      { name: "The Matron's throne", mobs: ['matron_rimeheart'], boss: true },
    ],
    chase: { key: 'rimeheart_shard', chance: 3, pity: 0.5 },
  },
  restricted_section: {
    name: 'The Restricted Section', zone: 'archive', level: 38, minutes: 90, keys: 1,
    blurb: 'Behind the sealed wing, the books nobody was meant to read, and the librarian who never stopped reading them.',
    rooms: [
      { name: 'The reading room', mobs: ['ink_wraith', 'ink_wraith', 'paper_moth'] },
      { name: 'Lamplit stacks', mobs: ['lantern_wisp', 'lantern_wisp', 'archive_warden'] },
      { name: 'The bindery', mobs: ['book_golem', 'book_golem'] },
      { name: 'The catalogue', mobs: ['archive_warden', 'ink_wraith', 'paper_moth'] },
      { name: "The Librarian's desk", mobs: ['head_librarian'], boss: true },
    ],
    chase: { key: 'quill_of_margins', chance: 3, pity: 0.5 },
  },
  wyrms_crown: {
    name: "The Wyrm's Crown", zone: 'thundercrag', level: 48, minutes: 110, keys: 1,
    blurb: 'The summit of the Spire, inside the storm. The Storm Wyrm coils around it and does not like visitors.',
    rooms: [
      { name: 'The last stair', mobs: ['thunder_giant', 'spark_imp', 'spark_imp'] },
      { name: 'Copper gallery', mobs: ['static_elemental', 'static_elemental', 'skyguard_sentinel'] },
      { name: 'Harpy roost', mobs: ['storm_harpy', 'storm_harpy', 'storm_harpy'] },
      { name: 'Giant\'s landing', mobs: ['thunder_giant', 'skyguard_sentinel'] },
      { name: 'The eye of the storm', mobs: ['storm_wyrm'], boss: true },
    ],
    chase: { key: 'wyrmscale_aegis', chance: 3, pity: 0.5 },
  },
};

// Each difficulty is its own reward tier, so the harder run is always worth its risk (keys and time are the same):
// more XP and gold, rooms that drop more often and rarer, rarer boss drops (two on Mythic), better chase, set and
// mount odds. Heroic is unlocked by a Normal clear, Mythic by a Heroic clear. Check: node tools/dungeonrewards.mjs
//   xpMult/goldMult: on top of the higher item level; roomChance: [solo, shared pool]; bossDrops: per player.
export const DIFFICULTY = {
  normal: { label: 'Normal', levelBonus: 0, chaseMult: 1, boss: 'boss', room: 'room', xpMult: 1, goldMult: 1, roomChance: [0.2, 0.45], bossDrops: 1 },
  heroic: { label: 'Heroic', levelBonus: 4, mult: 1.08, chaseMult: 2, boss: 'bossHeroic', room: 'roomHeroic', xpMult: 1.5, goldMult: 1.5, roomChance: [0.3, 0.55], bossDrops: 1 },
  mythic: { label: 'Mythic', levelBonus: 8, mult: 1.15, chaseMult: 3, boss: 'bossMythic', room: 'roomMythic', xpMult: 2.25, goldMult: 2.25, roomChance: [0.4, 0.65], bossDrops: 2 },
};

/* ---------------------------------------------------------- Hirelings */
// Guild hirelings fill a dungeon party when no guildmate is around. Built like a player who spent
// their points by the build guide, in uncommon gear one level behind.

export const HIRELINGS = {
  sellsword:    { name: 'Sellsword', cls: 'warblade', scores: { mig: 16, agi: 9, vit: 14, int: 8, spi: 8, pre: 8 }, weapon: 'longsword', offhand: 'kite_shield', weight: 'plate' },
  cutpurse:     { name: 'Cutpurse', cls: 'shadowstep', scores: { mig: 8, agi: 17, vit: 10, int: 8, spi: 8, pre: 12 }, weapon: 'twin_daggers', offhand: 'parry_dagger', weight: 'leather' },
  arcane_adept: { name: 'Arcane Adept', cls: 'arcanist', scores: { mig: 8, agi: 8, vit: 10, int: 17, spi: 12, pre: 8 }, weapon: 'oak_staff', offhand: 'spell_tome', weight: 'cloth' },
  hedge_witch:  { name: 'Hedge Witch', cls: 'warden', scores: { mig: 8, agi: 8, vit: 13, int: 9, spi: 17, pre: 8 }, weapon: 'spirit_totem', offhand: 'fetish', weight: 'hide' },
};

export function hirelingSnapshot(key, level) {
  const h = HIRELINGS[key], ilvl = Math.max(1, level - 1);
  const it = (slot, base) => generateItem(`hire|${key}|${ilvl}|${slot}`, { base, rarity: 'uncommon', ilvl });
  const gear = { weapon: it('weapon', h.weapon), offhand: it('offhand', h.offhand) };
  for (const s of ['helm', 'shoulders', 'chest', 'gloves', 'boots']) gear[s] = it(s, `${h.weight}_${s}`);
  gear.cape = it('cape', 'cloak');   // hirelings are kitted like Agents, so retuned monsters treat them the same
  const scores = { ...h.scores };
  for (const [k, n] of Object.entries(PER_LEVEL[h.cls])) scores[k] += n * (level - 1);
  return { name: `${h.name} (hireling)`, cls: h.cls, scores, level, gear, hireling: key };
}

/* --------------------------------------------------------------- Loot */

const LOOT_WEIGHTS = {
  patrol: { common: 50, uncommon: 35, rare: 13, epic: 2 },
  room:   { uncommon: 60, rare: 35, epic: 5 },
  boss:   { rare: 60, epic: 35, legendary: 5 },
  // Each difficulty a tier up: Heroic never drops uncommon, Mythic never drops below epic.
  roomHeroic: { rare: 55, epic: 35, legendary: 10 },
  bossHeroic: { epic: 55, legendary: 40, mythic: 5 },
  roomMythic: { epic: 55, legendary: 35, mythic: 10 },
  bossMythic: { legendary: 60, mythic: 40 },
};

// Named items come only from special sources (extra.special): a rare spawn or treasure mimic ('rare': half its drops)
// or a dungeon boss ('boss': epic or better drops, by rarity). Decided on their own stream, so no other roll changes.
// Common mobs, elites, rooms, patrols and encounters never drop them; quests and secrets give theirs directly.
export const NAMED_TURN = { boss: { epic: 0.15, legendary: 0.35, mythic: 0.5 }, rare: 0.5 };
export const namedPool = (zone) => Object.keys(NAMED).filter(k => NAMED[k].drop === zone);
export function rollItem(seed, ilvl, table, zone, extra = {}) {
  const r = makeRng(`loot|${seed}`);
  const element = r() < 0.4 ? ZONES[zone]?.element : 'physical';
  const it = generateItem(seed, { ilvl, rarityWeights: LOOT_WEIGHTS[table], element, source: extra.source, ...extra.opts });
  const chance = extra.special === 'rare' ? NAMED_TURN.rare : extra.special === 'boss' ? NAMED_TURN.boss[it.rarity] || 0 : 0;
  const pool = chance ? namedPool(zone) : [], r2 = makeRng(`named-turn|${seed}`);
  if (pool.length && r2() < chance) return namedItem(pool[Math.floor(r2() * pool.length)], seed, it.ilvl, extra.source);
  return it;
}

/* ----------------------------------------------------------- Helpers */

const pickWeighted = (r, list) => {
  const total = list.reduce((a, x) => a + x.w, 0);
  let x = r() * total;
  for (const e of list) { x -= e.w; if (x < 0) return e; }
  return list.at(-1);
};
const clamp = (v, lo, hi) => Math.max(lo, Math.min(hi, v));

// Turn a snapshot (agent doc fields at departure) into a battle unit at the given HP.
function unitFrom(snap, id, hp) {
  const u = makeAgentUnit(snap, { id, level: snap.level });
  if (hp != null) u.hpOverride = hp;
  return u;
}

// Run a chain of fights for a party, carrying HP between them. Returns fights, survivor HP, and whether
// the party (or the solo Agent) was knocked out.
function runChain(seedBase, party, encounters, { healBetween = 0.2, restBelow = 0, restTo = 0.85 } = {}) {
  const hp = party.map(() => null);
  const fights = [];
  let ko = false, rests = 0;
  for (let i = 0; i < encounters.length; i++) {
    const enc = encounters[i];
    // Patrols: a badly hurt Agent rests through this encounter instead of fighting it.
    if (restBelow && hp[0] != null && hp[0] > 0 && hp[0] / maxHpOf(party[0]) < restBelow) {
      hp[0] = Math.round(maxHpOf(party[0]) * restTo); rests++;
      fights.push({ rest: true, label: 'Rested', hp: hp[0] });
      continue;
    }
    // Patrols: a hurt Agent slips past a rare elite instead of engaging it.
    if (restBelow && enc.elite && hp[0] != null && hp[0] / maxHpOf(party[0]) < 0.8) {
      fights.push({ rest: true, avoided: true, label: `Avoided ${enc.mobs.length === 1 ? 'a rare elite' : 'an elite pack'}`, hp: hp[0] });
      continue;
    }
    const hpIn = [...hp];
    const units = party.map((p, j) => unitFrom(p, j === 0 ? 'agent' : `ally${j}`, hp[j]));
    const alive = units.filter((u, j) => hp[j] == null || hp[j] > 0);
    if (!alive.length) { ko = true; break; }
    const mobs = enc.mobs.map((m, k) => makeMobUnit(m.kind, m.level, `${m.kind}${k}`, { mult: m.mult || 1 }));
    const seed = `${seedBase}|f${i}`;
    const res = simulate(seed, alive, mobs);
    fights.push({ seed, label: enc.label, mobs: enc.mobs, winner: res.winner, actions: res.actions, hash: res.hash, elite: !!enc.elite, boss: !!enc.boss, hpIn, ...(enc.secret ? { secret: enc.secret, petUp: res.pets.length > 0 && res.pets.every(p => p.alive) } : {}), ...(enc.rare ? { rare: true } : {}) });
    // carry HP (non-summon survivors), then heal a little before the next fight
    for (const s of res.survivors.filter(x => x.side === 'A')) {
      const j = s.uid === 'A:agent' ? 0 : Number(s.uid.replace('A:ally', ''));
      hp[j] = s.alive ? Math.min(s.maxHp, Math.round(s.hp + s.maxHp * healBetween)) : 0;
    }
    if (res.winner !== 'A') { ko = true; break; }
  }
  return { fights, ko, hp, rests };
}

const maxHpOf = (snap) => { const u = makeAgentUnit(snap, { level: snap.level }); return deriveStats(u.scores, u.level, u.gear).maxHp; };

// Hallucination: a 1% drop each time the Mirage Djinn is defeated.
function djinnDrop(seed, fights) {
  const r = makeRng(`djinn|${seed}`);
  return fights.some(f => !f.rest && f.winner === 'A' && f.mobs.some(m => m.kind === 'mirage_djinn') && r() < 0.01) ? ['hidden:hallucination'] : [];
}

/* ----------------------------------------------------------- Patrols */

export function planPatrol(seed, level, minutes, zone = 'promptwood', ctx = null) {
  const r = makeRng(`patrol|${seed}`);
  const z = ZONES[zone];
  const n = Math.max(1, Math.round(minutes / 15));
  const encounters = [];
  for (let i = 0; i < n; i++) {
    const enc = pickWeighted(r, z.encounters);
    const lvl = clamp(level - Math.floor(r() * 2), z.levels[0], z.levels[1] + 2); // never below the zone's floor
    encounters.push({ mobs: enc.mobs.map(kind => ({ kind, level: lvl })), elite: !!enc.elite, label: enc.elite ? 'Rare elite' : 'Patrol' });
  }
  const strangeDoor = r() < 0.005;
  // A rare creature, when the conditions are right, joins somewhere in the middle of the patrol.
  const rare = ctx ? rareFor(zone, { ...ctx, minutes }, makeRng(`rare|${seed}`)) : null;
  if (rare) {
    const at = Math.min(encounters.length, 1 + Math.floor(makeRng(`rare-at|${seed}`)() * Math.max(1, encounters.length - 1)));
    const lvl = clamp(level, z.levels[0], z.levels[1] + 2);
    encounters.splice(at, 0, { mobs: [{ kind: rare, level: lvl }], rare: true, label: 'Something rare' });
  }
  return { encounters, strangeDoor };
}

export function resolvePatrol(seed, snap, { minutes, zone = 'promptwood', found = [], startedAt = 0 }) {
  if (!ZONES[zone]) zone = 'promptwood';
  const plan = planPatrol(seed, snap.level, minutes, zone, startedAt ? { startedAt, found, scout: !!MOUNTS[snap.mount]?.perks?.scout } : null);
  // A secret encounter, if one wakes, comes first (while the Agent is fresh).
  const secret = secretsFor({ patrolZone: zone }, { snap, party: [snap], startedAt }, found, makeRng(`secret|${seed}`))[0];
  if (secret) plan.encounters.unshift(...secretEncounters(secret, snap.level));
  const { fights, ko, rests } = runChain(`patrol|${seed}`, [snap], plan.encounters, { healBetween: 0.5, restBelow: 0.7 });
  const r = makeRng(`patrol-loot|${seed}`);
  const wins = fights.filter(f => !f.rest && f.winner === 'A');
  let xp = 0, gold = 0; const items = [];
  wins.forEach((f, i) => {
    const lvl = f.mobs[0].level, count = f.mobs.length * (f.elite ? 3 : f.rare ? 4 : 1);
    xp += Math.round((4 + 1.5 * lvl) * count);
    gold += Math.round((2 + lvl) * count * (0.8 + r() * 0.4) * (f.rare ? RARE_SPAWNS[f.mobs[0].kind]?.reward.goldMult || 3 : 1));
    if (f.rare) items.push(rollItem(`${seed}|rare${i}`, lvl, 'boss', zone, { source: `${MOBS_NAME(f.mobs[0].kind)}`, special: 'rare' }));
    else if (r() < (f.elite ? 0.6 : 0.12)) items.push(rollItem(`${seed}|drop${i}`, lvl, f.elite ? 'room' : 'patrol', zone, { source: `${ZONES[zone].name} patrol` }));
  });
  if (ko) gold = Math.round(gold * 0.9);
  const res = { type: 'patrol', fights, ko, rests, xp, gold, items, keys: 0, events: [...(plan.strangeDoor && !ko ? ['strange_door'] : []), ...djinnDrop(seed, fights)] };
  for (const f of wins) { const md = RARE_MOUNT_DROPS[f.mobs[0]?.kind]; if (f.rare && md && makeRng(`rare-mount|${seed}`)() < md.chance) res.events.push(`mount:${md.key}`); }
  if (secret) settleSecret(res, secret, seed, snap);
  return res;
}

const CLASS_WEAPONS = { warblade: ['longsword', 'greataxe'], shadowstep: ['twin_daggers'], arcanist: ['oak_staff'], warden: ['spirit_totem'], ranger: ['longbow'], hexer: ['bone_wand'], deathknight: ['longsword', 'greataxe'], necromancer: ['oak_staff', 'bone_wand'], bard: ['lute'], artificer: ['flintlock'], tinkerer: ['wrench'], paladin: ['longsword', 'greataxe'], priest: ['scepter'] };

/* ------------------------------------------------------------ Quests */

export function questEncounters(q, level, path) {
  const fights = q.paths ? q.paths[path]?.fights : q.fights;
  if (!fights) return null;
  const lvl = q.level === 'agent' ? Math.max(1, level - 1) : q.level; // quests keep their own level, so early ones stay easy
  return fights.map(list => {
    const off = typeof list.at(-1) === 'number' ? list.at(-1) : 0;
    const kinds = list.filter(x => typeof x === 'string');
    return { mobs: kinds.map(kind => ({ kind, level: Math.max(1, lvl + off) })), elite: kinds.includes('old_mossback'), label: q.title };
  });
}

// A quest can be done with guildmates (`party`): everyone fights the same battles; `me`/`who` give each member
// their own reward (a weapon for their class, their own roll of the item).
// Named items a quest rewards (NAMED[key].quest), given on top of its usual reward when it is completed.
const QUEST_NAMED = Object.fromEntries(Object.entries(NAMED).filter(([, n]) => n.quest).map(([k, n]) => [n.quest, k]));
// helper: this member had already finished the quest and came along to help: half the gold and XP, no quest reward.
export function resolveQuest(seed, lead, { quest, path, party = [], me = 0, who = null, helper = false }) {
  const all = [lead, ...party], snap = all[me] || lead, lootSeed = who ? `${seed}|${who}` : seed;
  const q0 = QUESTS.find(x => x.id === quest);
  const q = q0.level === 'agent' ? { ...q0, level: Math.max(1, lead.level - 1) } : q0;
  const encounters = questEncounters(q, lead.level, path);
  const { fights, ko } = runChain(`quest|${seed}`, all, encounters, { healBetween: 0.5 });
  if (ko) return { type: 'quest', quest, path, fights, ko, xp: 0, gold: 0, items: [], keys: 0, done: false, events: [] };
  const full = { ...q.reward, ...(q.paths?.[path]?.reward || {}), ...(QUEST_NAMED[q.id] && !q.reward?.named ? { named: QUEST_NAMED[q.id] } : {}) };
  const rw = helper ? { xp: Math.floor((full.xp || 0) / 2), gold: Math.floor((full.gold || 0) / 2) } : full;
  const items = [];
  if (rw.item) {
    // Quest givers hand out a weapon your class can use; other slots stay random.
    const base = rw.item.slot === 'weapon' ? CLASS_WEAPONS[snap.cls][Math.floor(makeRng(`qw|${lootSeed}`)() * CLASS_WEAPONS[snap.cls].length)] : undefined;
    items.push(rollItem(`${lootSeed}|quest`, Math.max(q.level, Math.min(snap.level, q.level + 2)), 'patrol', q.zone, { source: `Quest: ${q.title}`, opts: { rarity: rw.item.rarity, slot: rw.item.slot, base } }));
  }
  if (rw.named) items.push(namedItem(rw.named, lootSeed, Math.max(q.level, Math.min(snap.level, q.level + 2)), `Quest: ${q.title}`));
  const events = djinnDrop(seed, fights);
  const hidden = rw.hidden ? doorReward(seed, snap.hidden || []) : null;
  if (hidden) events.push(`hidden:${hidden}`);
  if (rw.mount) events.push(`mount:${rw.mount}`);
  return { type: 'quest', quest, path, fights, ko, xp: rw.xp || 0, gold: rw.gold || 0, items, keys: rw.keys || 0, done: true, events };
}

/* ---------------------------------------------------------- Dungeons */

export function dungeonEncounters(d, difficulty = 'normal') {
  const lvl = d.level + DIFFICULTY[difficulty].levelBonus;
  const mult = DIFFICULTY[difficulty].mult || 1;
  return d.rooms.map(room => ({ mobs: room.mobs.map(kind => ({ kind, level: lvl, ...(mult > 1 ? { mult } : {}) })), boss: !!room.boss, label: room.name }));
}

// A joint run: every member stores the same seed and the same ordered party, so the fights are identical for
// all; `me` is this member's place in the party and `who` their id, which gives each member their own loot.
export function resolveDungeon(seed, party, { dungeon, pity = 0, difficulty = 'normal', found = [], startedAt = 0, me = 0, who = null, pooled = false, players = [] }) {
  // pooled: a run with two or more players shares one bigger pool of drops (engine/loot.js settles who gets each).
  const lootSeed = who && !pooled ? `${seed}|${who}` : seed, personal = who ? `${seed}|${who}` : seed, nPlayers = pooled ? Math.max(1, players.length) : 1;
  const d = DUNGEONS[dungeon], diff = DIFFICULTY[difficulty] || DIFFICULTY.normal, ilvl = d.level + diff.levelBonus;
  const encs = dungeonEncounters(d, difficulty), tierTag = difficulty !== 'normal' ? ` (${diff.label})` : '';
  // Not every chest in a dungeon wants to be opened.
  if (startedAt && makeRng(`mimic|${seed}`)() < MIMIC_CHANCE) {
    const room = Math.floor(makeRng(`mimic-room|${seed}`)() * (encs.length - 1));
    encs[room] = { ...encs[room], mobs: [{ kind: 'treasure_mimic', level: encs[room].mobs[0].level, ...(encs[room].mobs[0].mult ? { mult: encs[room].mobs[0].mult } : {}) }], rare: true, label: 'A suspicious chest' };
  }
  const { fights, ko, hp: finalHp } = runChain(`dungeon|${seed}`, party, encs, { healBetween: 0.25 });
  const r = makeRng(`dungeon-loot|${lootSeed}`);
  let xp = 0, gold = 0; const items = [];
  fights.forEach((f, i) => {
    if (f.winner !== 'A') return;
    const count = f.mobs.length;
    xp += Math.round((6 + 2 * ilvl) * count * (f.boss ? 4 : 1) * (diff.xpMult || 1));
    gold += Math.round((4 + ilvl) * count * (f.boss ? 5 : 1) * (0.8 + r() * 0.4) * (diff.goldMult || 1));
    const tag = (it) => (pooled ? { ...it, drop: { fight: i } } : it);
    if (f.rare) { gold += Math.round((4 + ilvl) * 25); items.push(tag(rollItem(`${lootSeed}|mimic`, ilvl, diff.boss, d.zone, { source: 'Treasure Mimic', special: 'rare' })), tag(rollItem(`${lootSeed}|mimic2`, ilvl, diff.boss, d.zone, { source: 'Treasure Mimic', special: 'rare' }))); }
    else if (!f.boss && r() < (diff.roomChance || [0.2, 0.45])[pooled ? 1 : 0]) items.push(tag(rollItem(`${lootSeed}|room${i}`, ilvl, diff.room, d.zone, { source: `${d.name}${tierTag}` })));
  });
  const cleared = !ko && fights.length === d.rooms.length;
  let chase = false;
  if (cleared) {
    const bossFight = fights.length - 1, tagB = (it) => (pooled ? { ...it, drop: { fight: bossFight } } : it);
    for (let k = 0; k < nPlayers; k++) for (let j = 0; j < (diff.bossDrops || 1); j++)
      items.push(tagB(rollItem(`${lootSeed}|boss${k ? k : ''}${j ? `|x${j}` : ''}`, ilvl, diff.boss, d.zone, { source: `${d.name} boss${tierTag}`, special: 'boss' })));
    if (d.chase && r() * 100 < d.chase.chance * diff.chaseMult + pity) { chase = true; items.push(tagB(namedItem(d.chase.key, lootSeed, ilvl, d.name))); }
    // Dungeon set: a boss clear drops a piece 30% of the time (50% on Heroic), sized for the leader's class.
    const setKey = SET_OF_DUNGEON[dungeon];
    if (setKey && r() < (difficulty === 'mythic' ? 0.7 : difficulty === 'heroic' ? 0.5 : 0.3)) {
      const slot = SET_SLOTS[Math.floor(r() * SET_SLOTS.length)];
      items.push(tagB(setPiece(setKey, slot, lootSeed, ilvl, (pooled ? party[0] : party[me] || party[0]).cls, difficulty === 'mythic' ? 'mythic' : difficulty === 'heroic' ? 'legendary' : 'epic', `${d.name}${tierTag}`)));
    }
  }
  const res = { type: 'dungeon', dungeon, difficulty, fights, ko, xp, gold, items, keys: 0, cleared, chase, events: [] };
  // The wyrm's storm answers only the flawless: clear its Crown on Heroic or Mythic with nobody knocked out.
  const md = MOUNT_DROPS[dungeon];
  if (cleared && md && makeRng(`mount|${personal}`)() * 100 < (md[difficulty] || md.normal)) res.events.push(`mount:${md.key}`);
  if (cleared && dungeon === 'wyrms_crown' && difficulty !== 'normal' && finalHp.every(h => h == null || h > 0) && !fights.some(f => f.hpIn?.some(h => h === 0)))
    res.events.push('hidden:token_storm');
  if (cleared) {
    const secret = secretsFor({ dungeon, difficulty }, { snap: party[0], party, startedAt }, found, makeRng(`secret|${seed}`))[0];
    if (secret) {
      const extra = runChain(`dungeon-secret|${seed}`, party, secretEncounters(secret, party[0].level), { healBetween: 0.25 });
      res.fights.push(...extra.fights);
      settleSecret(res, secret, seed, party[0]);
    }
  }
  return res;
}

/* -------------------------------------------------- Landmarks & secrets */

function secretEncounters(id, level) {
  const s = SECRETS[id];
  return s.fights.map(list => {
    const off = typeof list.at(-1) === 'number' ? list.at(-1) : 0;
    return { mobs: list.filter(x => typeof x === 'string').map(kind => ({ kind, level: Math.max(1, level + off) })), boss: true, label: s.title, secret: id };
  });
}

// If the secret's fights were all won, grant its rewards (once per Agent; the page records it in progress.secrets).
function settleSecret(res, id, seed, snap) {
  const s = SECRETS[id], mine = res.fights.filter(f => f.secret === id);
  const won = mine.length === s.fights.length && mine.every(f => f.winner === 'A' && (!s.needsPet || f.petUp));
  res.secret = { id, won };
  if (!won) return;
  const rw = s.rewards;
  res.xp += rw.xp || 0; res.gold += rw.gold || 0;
  if (rw.named) res.items.push(namedItem(rw.named, `${seed}|secret`, snap.level, s.title));
  if (rw.transform) res.transform = rw.transform;
  if (rw.title) res.title = rw.title;
  if (rw.mount) res.events.push(`mount:${rw.mount}`);
  res.events.push(`secret:${id}`);
}

export function resolveExplore(seed, snap, { site, found = [], startedAt = 0 }) {
  const s = SITES[site];
  const lvl = Math.max(s.level, Math.min(snap.level, s.level + 4));
  const encounters = s.fights.map(list => ({ mobs: list.map(kind => ({ kind, level: lvl })), label: s.name }));
  const secret = secretsFor({ site }, { snap, party: [snap], startedAt }, found, makeRng(`secret|${seed}`))[0];
  if (secret) encounters.push(...secretEncounters(secret, snap.level));
  const { fights, ko } = runChain(`explore|${seed}`, [snap], encounters, { healBetween: 0.5 });
  const r = makeRng(`explore-loot|${seed}`);
  const wins = fights.filter(f => f.winner === 'A' && !f.secret);
  const items = [];
  let xp = 0, gold = 0;
  wins.forEach((f, i) => { xp += Math.round((5 + 1.6 * lvl) * f.mobs.length); gold += Math.round((3 + lvl) * f.mobs.length * (0.8 + r() * 0.4)); });
  if (!ko && r() < 0.25) items.push(rollItem(`${seed}|explore`, lvl, 'room', s.zone, { source: s.name }));
  const res = { type: 'explore', site, fights, ko, xp, gold, items, keys: 0, events: djinnDrop(seed, fights) };
  if (secret) settleSecret(res, secret, seed, snap);
  return res;
}

/* ------------------------------------------------------------ Actions */

export function actionMinutes(action) {
  // A mount shortens every journey; the fights and rewards are the same, the trip is quicker.
  const base = action.type === 'patrol' ? action.minutes : action.type === 'quest' ? QUESTS.find(q => q.id === action.quest).minutes
    : action.type === 'dungeon' ? DUNGEONS[action.dungeon].minutes : action.type === 'explore' ? SITES[action.site].minutes : 0;
  return Math.round(base * travelFactor(action));
}

// One entry point: resolve a stored action from its own seed and snapshot.
export function resolveAction(action) {
  const res = resolveRaw(action);
  // Mount perks on the way home: more gold, more XP, sometimes an extra find.
  const p = MOUNTS[action.mount]?.perks;
  if (p && res) {
    if (p.gold) res.gold = Math.round(res.gold * (1 + p.gold / 100));
    if (p.xp) res.xp = Math.round(res.xp * (1 + p.xp / 100));
    if (p.loot && !res.ko && makeRng(`mount-loot|${action.seed}`)() < 0.25) res.items.push(rollItem(`${action.seed}|mount`, action.snap.level, 'room', action.zone || 'promptwood', { source: `Found from the saddle` }));
  }
  return res;
}
function resolveRaw(action) {
  if (action.type === 'patrol') return resolvePatrol(action.seed, action.snap, action);
  if (action.type === 'quest') return resolveQuest(action.seed, action.snap, action);
  if (action.type === 'dungeon') return resolveDungeon(action.seed, [action.snap, ...(action.party || [])], action);
  if (action.type === 'explore') return resolveExplore(action.seed, action.snap, action);
  throw new Error(`Unknown action ${action.type}`);
}

// Rebuild one fight of a stored action exactly as it happened, for its battle log.
export function replayFight(action, index) {
  const res = resolveAction(action);
  const f = res.fights[index];
  if (!f || f.rest) return null;
  const party = action.type === 'dungeon' || action.type === 'quest' ? [action.snap, ...(action.party || [])] : [action.snap];
  const units = party.map((p, j) => unitFrom(p, j === 0 ? 'agent' : `ally${j}`, f.hpIn[j])).filter((u, j) => f.hpIn[j] == null || f.hpIn[j] > 0);
  const mobs = f.mobs.map((m, k) => makeMobUnit(m.kind, m.level, `${m.kind}${k}`, { mult: m.mult || 1 }));
  const sim = simulate(f.seed, units, mobs);
  return { ...sim, matches: sim.hash === f.hash };
}

// Keys: +3 each new SAST day (banked up to 7). Returns the updated count and day.
export function refillKeys(keys, lastDay, today) {
  if (!lastDay) return { keys: Math.min(KEYS.max, Math.max(keys ?? 0, KEYS.perDay)), day: today };
  if (today <= lastDay) return { keys, day: lastDay };
  const days = Math.round((Date.parse(today) - Date.parse(lastDay)) / 86_400_000);
  return { keys: Math.min(KEYS.max, keys + KEYS.perDay * Math.max(1, days)), day: today };
}

export { MIN };
