// Agents of Claude — mounts (Season 1).
//
// Riding unlocks at level 25. A mount shortens every journey (patrols, quests, landmarks, dungeons) and
// brings its own perk. Combat perks apply in PvE only: the Arena and duels stay on foot, and fair.
// Mounts come from the stable, boss drops, rare creatures, quest finales, the Gala and the world's secrets.

export const RIDING_LEVEL = 25;
export const TIER_LEVEL = { common: 25, rare: 25, epic: 30, legendary: 35, mythic: 40 };

// perk: gold/xp (+% rewards), loot (+chance of an extra item), scout (rare creatures more likely),
// charge (+25% damage on your first action in each fight), ward (+8% max HP), phase (+5% dodge).
export const MOUNTS = {
  trail_horse:       { name: 'Trail Horse', tier: 'common', speed: 0.10, perks: { xp: 5 }, source: 'The stable', price: 2500, blurb: 'Sure-footed, unflappable, and very fond of apples.' },
  desert_camel:      { name: 'Desert Camel', tier: 'common', speed: 0.10, perks: { gold: 8 }, source: 'The stable', price: 3000, blurb: 'Has opinions. Shares them. Carries a remarkable amount of loot.' },
  mountain_goat:     { name: 'Mountain Goat', tier: 'common', speed: 0.12, perks: { ward: 1 }, source: 'The stable', price: 3500, blurb: 'Climbs anything. Eats anything. Fears nothing, including you.' },
  war_pig:           { name: "Grubnose's War Pig", tier: 'rare', speed: 0.12, perks: { charge: 1 }, source: 'Gobbler Warren, rarely', blurb: 'Armoured in pot lids. Squeals like a war horn.' },
  brass_strider:     { name: 'Brass Strider', tier: 'rare', speed: 0.15, perks: { gold: 12 }, source: 'Sunken Bazaar, rarely', blurb: 'A clockwork camel from the old market, still trying to make a sale.' },
  golden_boar:       { name: 'Golden Boar', tier: 'rare', speed: 0.15, perks: { gold: 20 }, source: 'A creature that only comes out on certain days', blurb: 'Snuffles for gold the way other pigs snuffle for truffles.' },
  frostmane_elk:     { name: 'Frostmane Elk', tier: 'epic', speed: 0.18, perks: { ward: 1 }, source: 'Reward for seeing the peaks through to the end', blurb: 'Its breath leaves frost on everything it passes.' },
  rime_wolf:         { name: 'Rimeheart Wolf', tier: 'epic', speed: 0.20, perks: { charge: 1 }, source: 'Glacier Vault, rarely', blurb: 'Bred in the Matron\'s kennels. Loyal to whoever is still standing.' },
  champions_warhorse: { name: "Champion's Warhorse", tier: 'epic', speed: 0.18, perks: { xp: 10 }, source: 'Win an Arena Gala', blurb: 'Barded in gold, cheered wherever it goes.' },
  bookwyrm:          { name: 'Bookwyrm', tier: 'epic', speed: 0.20, perks: { loot: 1 }, source: 'Reward for reading the Archive to its last page', blurb: 'A long paper dragon that hoards footnotes.' },
  ink_drake:         { name: 'Ink Drake', tier: 'legendary', speed: 0.22, perks: { phase: 1 }, source: 'The Restricted Section, rarely', blurb: 'It flows more than it flies, and leaves no tracks.' },
  stormcloud_ram:    { name: 'Stormcloud Ram', tier: 'legendary', speed: 0.22, perks: { scout: 1 }, source: 'Reward for bringing calm to the Spire', blurb: 'Its wool crackles. Its horns hum before a storm.' },
  moonlit_stag:      { name: 'Moonlit Stag', tier: 'legendary', hidden: true, speed: 0.24, perks: { phase: 1 }, source: 'Something white, under something round', blurb: 'It only lets you ride because it wants to see where you go.' },
  storm_wyrmling:    { name: 'Storm Wyrmling', tier: 'mythic', speed: 0.30, perks: { charge: 1, ward: 1 }, source: "The Wyrm's Crown, very rarely", blurb: 'A hatchling of the Storm Wyrm. It is already bigger than a horse.' },
  wishweave_carpet:  { name: 'Wishweave Carpet', tier: 'mythic', hidden: true, speed: 0.30, perks: { loot: 1, gold: 15 }, source: 'Some wishes come true in the small hours', blurb: 'Woven by a djinn, from a wish someone else did not need.' },
  skyfrost_pegasus:  { name: 'Skyfrost Pegasus', tier: 'mythic', hidden: true, speed: 0.30, perks: { scout: 1, phase: 1 }, source: 'The top of a stair that has no top', blurb: 'It lives where the Frozen Stair ends, on the days it ends anywhere.' },
};
export const MOUNT_KEYS = Object.keys(MOUNTS);
export const PERK_TEXT = {
  xp: (v) => `+${v}% world XP`, gold: (v) => `+${v}% gold`, loot: () => 'Chance of an extra item', scout: () => 'Rare creatures appear more often',
  charge: () => '+25% damage on your first action in each fight (not in the Arena)', ward: () => '+8% max HP (not in the Arena)', phase: () => '+5% dodge (not in the Arena)',
};
export const perkLines = (key) => Object.entries(MOUNTS[key]?.perks || {}).map(([k, v]) => PERK_TEXT[k](v));
export const canRide = (key, level) => !!MOUNTS[key] && level >= TIER_LEVEL[MOUNTS[key].tier];

// The mount an action may use: owned and ridable are checked when the action starts; the action stores the key.
export const mountOf = (snapOrAction) => (MOUNTS[snapOrAction?.mount] ? snapOrAction.mount : null);
export const travelFactor = (action) => 1 - (MOUNTS[action?.mount]?.speed || 0);

// Boss drops: chance in percent by difficulty.
export const MOUNT_DROPS = {
  gobbler_warren: { key: 'war_pig', normal: 2, heroic: 4, mythic: 6 },
  sunken_bazaar: { key: 'brass_strider', normal: 2, heroic: 4, mythic: 6 },
  glacier_vault: { key: 'rime_wolf', normal: 1.5, heroic: 3, mythic: 5 },
  restricted_section: { key: 'ink_drake', normal: 1, heroic: 2.5, mythic: 4 },
  wyrms_crown: { key: 'storm_wyrmling', normal: 0.5, heroic: 1.5, mythic: 3 },
};
export const RARE_MOUNT_DROPS = { golden_goblin: { key: 'golden_boar', chance: 0.05 } };
