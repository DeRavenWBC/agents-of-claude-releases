// Agents of Claude — the battlefield layout for replays (build 155). Pure: the page's PixiJS replay and its canvas
// fallback both place units with it, so they always agree. Nothing here touches a fight or its log.
//
// The stage is 320×180 pixels; side A stands on the left, side B on the right (mirrored). Each side has:
//   - three main places, for the main fighters: Agents, hirelings and the first three ordinary (non-swarm) monsters;
//   - a minion area: a grid of MINION_CELLS small places in front of the main line (two rows of six), for summons
//     (skeletons, golems, robots, pets, imps, the Beloved), swarm creatures and any main fighter past the third.
// Minions are drawn at most MINION_H pixels tall (scaled down), so no two places ever overlap. A place opens again when
// its unit falls or vanishes; a new unit prefers a place nobody has fallen on yet, so it does not stand on a corpse.

export const STAGE = { w: 320, h: 180 };
export const MINION_H = 14;          // tallest a minion is drawn (pixels); the cell pitch leaves room for its HP bar
export const MINION_W = 22;          // widest a minion is drawn
const MAIN_A = [[100, 132], [58, 118], [138, 116]];
const MINION_ROWS = [160, 178], MINION_COLS = [14, 38, 62, 86, 110, 134];
const MINION_A = MINION_ROWS.flatMap(y => MINION_COLS.map(x => [x, y]));
const mirror = (list) => list.map(([x, y]) => [STAGE.w - x, y]);
export const MAIN = { A: MAIN_A, B: mirror(MAIN_A) };
export const MINION = { A: MINION_A, B: mirror(MINION_A) };
export const MINION_CELLS = MINION_A.length;

// Where a new unit stands. `placed`: the units already on the field, each { side, alive, area: 'main'|'minion', i }.
// `minion`: the unit is a summon or a swarm creature. Returns { area, i, x, y, scaleCap }.
export function place(side, placed, minion = false) {
  const mine = placed.filter(u => u.side === side);
  const taken = (area, i) => mine.some(u => u.alive && u.area === area && u.i === i);
  const fallen = (area, i) => mine.some(u => !u.alive && u.area === area && u.i === i);
  const pick = (area, list) => {
    const free = list.map((_, i) => i).filter(i => !taken(area, i));
    return free.find(i => !fallen(area, i)) ?? free[0];
  };
  if (!minion) {
    const i = pick('main', MAIN[side]);
    if (i != null) return { area: 'main', i, x: MAIN[side][i][0], y: MAIN[side][i][1] };
  }
  const i = pick('minion', MINION[side]) ?? MINION_CELLS - 1;   // more than twelve: the last place is shared
  return { area: 'minion', i, x: MINION[side][i][0], y: MINION[side][i][1], minion: true };
}

// How much to scale a minion's sprite (w×h at its own scale s) so it fits its place.
export const minionScale = (w, h, s = 1) => Math.min(1, MINION_H / (h * s), MINION_W / (w * s)) * s;

// One label per group of identical minions: [{ name, n, x, y }] for those still standing, where x is the middle of the
// group and y the top of its highest member. `units`: [{ name, side, x, top, alive }].
export function minionLabels(units) {
  const groups = new Map();
  for (const u of units) if (u.alive) {
    const k = `${u.side}|${u.name}`;
    const g = groups.get(k) || { name: u.name, side: u.side, n: 0, xs: [], top: Infinity };
    g.n++; g.xs.push(u.x); g.top = Math.min(g.top, u.top); groups.set(k, g);
  }
  return [...groups.values()].map(g => ({ name: g.name, side: g.side, n: g.n, label: groupLabel(g.name, g.n), x: (Math.min(...g.xs) + Math.max(...g.xs)) / 2, y: g.top }));
}
export const groupLabel = (name, n) => (n > 1 ? `${n}× ${name}` : name);

// The HP bars over a replay: identical units on the same side (ten Warren Rats) share one bar, "10× Warren Rat", with
// their HP summed. `units`: [{ name, side, hp, maxHp, alive }]. Order is kept (first appearance).
export function groupBars(units) {
  const out = [], at = new Map();
  for (const u of units) {
    const k = `${u.side}|${u.name}`;
    if (!at.has(k)) { at.set(k, out.length); out.push({ name: u.name, side: u.side, n: 0, hp: 0, maxHp: 0, up: 0 }); }
    const g = out[at.get(k)];
    g.n++; g.hp += Math.max(0, u.hp); g.maxHp += u.maxHp; if (u.alive) g.up++;
  }
  return out.map(g => ({ ...g, label: groupLabel(g.name, g.n), alive: g.up > 0 }));
}

// Labels that would overlap move up a line: items [{ x, y, w }] (centre x, baseline y, width), h the line height.
// Returns the y for each, in order.
export function spreadLabels(items, h = 6) {
  const done = [];
  return items.map(it => {
    let y = it.y;
    for (let k = 0; k < 20; k++) {
      const hit = done.find(d => Math.abs(d.x - it.x) < (d.w + it.w) / 2 + 2 && Math.abs(d.y - y) < h);
      if (!hit) break;
      y = hit.y - h;
    }
    done.push({ x: it.x, y, w: it.w });
    return y;
  });
}
