import { TZ_OFFSET_MS, TZ_ISO, worldDay, dayAt } from './worldtime.js';
// Agents of Claude — the Bestiary (creatures you have defeated) and the Encyclopedia (items you have held).
//
// Rare creatures appear only under special conditions: a weekend, the midday sun, the dead of night, a
// storm day, or an Agent who has already found some of the world's secrets. The Bestiary hints at them
// vaguely; it never states the rule.

import { fnv1a } from './rng.js';
import { BASES, NAMED, DUNGEON_SETS, WEIGHTS, ARMOUR_SLOTS } from './items.js';

export const MOB_LORE = {
  goblin_scout: 'Small, quick and convinced that anything not nailed down is a gift.',
  dire_wolf: 'Hunts in pairs. Remembers faces. Holds grudges.',
  goblin_shaman: 'Patches up other goblins with mud, spit and terrible confidence.',
  old_mossback: 'A turtle the size of a cart, older than the road it naps on.',
  grubnose: 'Goblin King of the Warren. Rules by ladle.',
  bandit_raider: 'Takes a toll on the trade road. The toll is everything.',
  dune_scorpion: 'Buries itself in the sand and waits for footsteps.',
  sand_wraith: 'The dunes sing at dusk. This is what is singing.',
  brass_golem: 'Built to guard a market that sank three hundred years ago. Still on shift.',
  mirage_djinn: 'Young, vain and very good at not being where you aimed.',
  brass_sultan: 'Owns the Sunken Bazaar, and everyone in it, and possibly you.',
  rime_stalker: 'A cat made of winter. You hear it only when it wants you to.',
  glacier_troll: 'Builds bridges, charges tolls, eats the ones who cannot pay.',
  frost_wisp: 'A light on the ice that leads travellers somewhere colder.',
  icebound_revenant: 'Climbers lost to the mountain, still climbing.',
  crag_harpy: 'Nests on the ledges and screams at everything below.',
  hoarfrost_wyvern: 'Its breath frosts the air for a mile. Nests above the Vault.',
  matron_rimeheart: 'Keeper of the Glacier Vault, and of everything the mountain ever froze.',
  ink_wraith: 'Spilled ink that learned to walk, and to hold a grudge against readers.',
  book_golem: 'A thousand overdue books bound into one very angry librarian\'s assistant.',
  lantern_wisp: 'Keeps the reading lamps lit. Also keeps you from reading.',
  archive_warden: 'Gilded guard of the stacks. Checks every book out, and every reader.',
  paper_moth: 'Eats the margins first. Then the pages. Then you.',
  the_redactor: 'Blacks out words, then the people who said them.',
  head_librarian: 'Never stopped reading. Never stopped shushing.',
  thunder_giant: 'Climbs the Spire to be nearer the storm, and gets cranky when it stops.',
  spark_imp: 'Rides lightning down to farms to steal butter. Nobody knows why butter.',
  static_elemental: 'A storm with nowhere to go, wearing copper.',
  storm_harpy: 'Louder than thunder, and much ruder.',
  skyguard_sentinel: 'Bronze guards built to keep something in. Still keeping.',
  tempest_roc: 'A bird so large its shadow has weather.',
  storm_wyrm: 'Coiled around the summit of Thundercrag, inside the storm it makes.',
  morwen: 'A witch who became something worse, and wants her staff back.',
  white_stag: 'Seen once in a lifetime, if you are lucky. Twice, if you are luckier.',
  the_stew: 'The goblin king\'s larder, still cooking, and now cooking you.',
  rimeheart_echo: 'What is left of the Matron when her heart remembers her.',
  moonless_reaver: 'A Reaver who lost his blades and kept his grudge. Only walks when there is no moon.',
  glaciers_grudge: 'Something the glacier froze along with an axe. Lightning woke it, and it is still angry.',
  hoarfrost_matriarch: 'Mother of every wyvern in the Peaks. Fair, in her way, to archers who look after their own.',
  the_last_reader: 'Has been reading the same book since before the Archive had walls. Does not like to be interrupted.',
  heartwood_guardian: 'The roots of the Heartwood, standing up. Slow to anger, slower to forgive.',
  golden_goblin: 'A goblin who found a hoard and refused to put any of it down.',
  ember_phoenix: 'Burns brightest when the sun is highest.',
  aurora_wisp: 'Dances only in the dark, in colours the day never sees.',
  lost_page: 'A page torn from a book nobody can find. It looks for those who know where to look.',
  thunderbird: 'Rides in on the worst of the weather and leaves with the best of the loot.',
  treasure_mimic: 'Looks like treasure. Is not treasure. Has treasure.',
  // Swarms and their keepers (build 155)
  warren_rat: 'Fled the Gobbler Warren when the goblins started cooking. Never travels in fewer than ten.',
  spiderling: 'Small enough to step on. There are always more than you have feet.',
  brood_mother: 'Spins her web across the forest paths and keeps her children close. Very close. On you.',
  rat_king: 'Wears a bottle-cap crown and is followed everywhere by his court. The court bites.',
  sand_beetle: 'Polishes its shell on the bones of caravans. Comes up out of the sand in tens.',
  dust_devil: 'A whirlwind that picked up a grudge somewhere on the old trade road and kept it spinning.',
  frost_mite: 'Lives in the cracks of the glacier and eats the warmth out of anything that sits down.',
  bookworm: 'Ate the index. Then the appendix. One at a time is nothing; they never come one at a time.',
  storm_bat: 'Roosts in the Spire\'s bells and hangs upside down from the lightning. Arrives in a crackling cloud.',
};

/* --------------------------------------------------------- Rare creatures */

const SAST = TZ_OFFSET_MS;
export const sastHour = (ms) => new Date(ms + SAST).getUTCHours();
export const sastWeekday = (ms) => new Date(ms + SAST).getUTCDay(); // 0 Sunday
export const sastDay = (ms) => new Date(ms + SAST).toISOString().slice(0, 10);
// Weather: about one day in four is a storm day over Thundercrag, the same for everyone.
export const isStormDay = (ms) => parseInt(fnv1a(`storm|${sastDay(ms)}`).slice(0, 6), 16) % 4 === 0;

// zone → rare spawn. `when(ctx)` gets { startedAt, minutes, found }; `chance` is per patrol.
export const RARE_SPAWNS = {
  golden_goblin: { zone: 'promptwood', chance: 0.25, when: (c) => [0, 6].includes(sastWeekday(c.startedAt)), hint: 'Some goblins only come out when nobody is working.', reward: { goldMult: 12 } },
  ember_phoenix: { zone: 'ashen', chance: 0.3, when: (c) => [12, 13].includes(sastHour(c.startedAt)) && c.minutes >= 60, hint: 'Look up at the hottest hour, and stay out long enough to be seen.', reward: { goldMult: 3 } },
  aurora_wisp: { zone: 'frostfang', chance: 0.25, when: (c) => sastHour(c.startedAt) >= 20 || sastHour(c.startedAt) < 4, hint: 'It only dances for those who walk the peaks after dark.', reward: { goldMult: 3 } },
  lost_page: { zone: 'archive', chance: 0.2, when: (c) => (c.found || []).length >= 2, hint: 'It finds readers who have already found something.', reward: { goldMult: 3 } },
  thunderbird: { zone: 'thundercrag', chance: 0.3, when: (c) => isStormDay(c.startedAt), hint: 'Comes with the weather, not the season.', reward: { goldMult: 4 } },
};
export const MIMIC_CHANCE = 0.06; // per dungeon run, replacing one room
// Entries nobody sees in the Bestiary or Encyclopedia until they have found them.
export const HIDDEN_MOBS = ['morwen', 'white_stag', 'the_stew', 'rimeheart_echo', 'moonless_reaver', 'glaciers_grudge', 'hoarfrost_matriarch', 'the_last_reader', 'heartwood_guardian'];
export const HIDDEN_ITEMS = ['named:morwens_hexstaff', 'named:wish_knot', 'named:heart_of_the_thaw', 'named:stag_antler', 'named:pot_lid',
  'named:grubnoses_cleaver', 'named:fangs_of_the_new_moon', 'named:thunderforged_splitter', 'named:wyvernstring', 'named:staff_of_the_last_page', 'named:heartwood_totem'];
export const RARE_KEYS = [...Object.keys(RARE_SPAWNS), 'treasure_mimic'];
export const RARE_HINTS = { ...Object.fromEntries(Object.entries(RARE_SPAWNS).map(([k, v]) => [k, v.hint])), treasure_mimic: 'Not every chest in a dungeon wants to be opened.' };

// The rare creature (if any) joining a patrol, decided from the patrol's own seeded RNG.
export function rareFor(zone, ctx, r) {
  if (!ctx?.startedAt) return null;
  for (const [kind, s] of Object.entries(RARE_SPAWNS)) if (s.zone === zone && s.when(ctx) && r() < s.chance * (ctx.scout ? 1.5 : 1)) return kind;
  return null;
}

/* -------------------------------------------------------------- Habitats */

// Where each creature can be met, from the world's own data (passed in to avoid an import cycle).
export function habitats({ ZONES, QUESTS, DUNGEONS, SITES, SECRETS }) {
  const out = {};
  const add = (kind, where) => { (out[kind] ??= new Set()).add(where); };
  for (const z of Object.values(ZONES)) for (const e of z.encounters) for (const m of e.mobs) add(m, `${z.name} patrols`);
  for (const q of QUESTS) for (const f of Object.values(q.paths || { x: { fights: q.fights } }).flatMap(p => p.fights)) for (const m of f) if (typeof m === 'string') add(m, q.zone === 'door' ? 'a strange hallway' : `${ZONES[q.zone]?.name || ''} quests`);
  for (const d of Object.values(DUNGEONS)) for (const room of d.rooms) for (const m of room.mobs) add(m, d.name);
  for (const s of Object.values(SITES)) for (const f of s.fights) for (const m of f) add(m, s.name);
  for (const k of Object.keys(SECRETS || {})) for (const f of SECRETS[k].fights) for (const m of f) if (typeof m === 'string') add(m, 'somewhere secret');
  for (const [k, s] of Object.entries(RARE_SPAWNS)) add(k, `${ZONES[s.zone].name}, rarely`);
  add('treasure_mimic', 'any dungeon, rarely');
  return Object.fromEntries(Object.entries(out).map(([k, v]) => [k, [...v]]));
}

/* ---------------------------------------------------------- Special drops */

// What a creature drops beyond ordinary loot, from the world's own data (passed in to avoid an import cycle):
// dungeon bosses (chase item, set pieces, mount, the zone's named items), rare creatures, the mimic, quest fights with
// a named reward, and creatures guarding a secret: that secret's rewards, only once this Agent has found it (`found`:
// secret ids), so nothing hidden leaks. Returns short lines; [] for nothing special.
export function specialDrops(kind, { ZONES, QUESTS, DUNGEONS, SECRETS, MOUNTS, MOUNT_DROPS, RARE_MOUNT_DROPS, namedPool }, found = []) {
  const out = [], named = (k) => NAMED[k]?.name || k, pct = (n) => `${n}%`;
  const zoneNamed = (zone) => { const pool = namedPool(zone).map(named); return pool.length ? pool.join(', ') : null; };
  for (const [dk, d] of Object.entries(DUNGEONS)) {
    if (!d.rooms.some(r => r.boss && r.mobs.includes(kind))) continue;
    if (d.chase) out.push(`${named(d.chase.key)}: its rare chase drop (${pct(d.chase.chance)} a clear, more on Heroic and Mythic, and more likely each time it doesn't drop)`);
    const set = Object.values(DUNGEON_SETS).find(x => x.dungeon === dk);
    if (set) out.push(`${set.name} set pieces (30% a clear, 50% on Heroic, 70% on Mythic)`);
    const md = MOUNT_DROPS[dk]; if (md && MOUNTS[md.key]) out.push(`${MOUNTS[md.key].name} mount (${pct(md.normal)}, ${pct(md.heroic)} on Heroic, ${pct(md.mythic)} on Mythic)`);
    const zn = zoneNamed(d.zone); if (zn) out.push(`Sometimes a named item of ${ZONES[d.zone]?.name || 'its zone'}: ${zn}`);
  }
  const rare = RARE_SPAWNS[kind];
  if (rare) {
    out.push(`${rare.reward.goldMult}× the usual gold`);
    const zn = zoneNamed(rare.zone); if (zn) out.push(`A good item, half the time a named item of ${ZONES[rare.zone]?.name}: ${zn}`);
    const rm = RARE_MOUNT_DROPS[kind]; if (rm && MOUNTS[rm.key]) out.push(`${MOUNTS[rm.key].name} mount (${Math.round(rm.chance * 100)}%)`);
  }
  if (kind === 'treasure_mimic') out.push('Two good items, each half the time a named item of the dungeon\'s zone, and a pile of gold');
  for (const q of QUESTS) for (const p of Object.values(q.paths || {})) if (p.reward?.named && p.fights?.at(-1)?.includes(kind)) out.push(`${named(p.reward.named)}, for beating it in the quest "${q.title}" (${p.label})`);
  for (const [id, sc] of Object.entries(SECRETS || {})) {
    if (!found.includes(id) || !sc.fights.some(f => f.includes(kind))) continue;
    const rw = sc.rewards, from = ` (secret: ${sc.title})`;
    if (rw.named) out.push(named(rw.named) + from);
    if (rw.transform) out.push(`Turns your ${named(rw.transform.from)} into ${named(rw.transform.to)}${from}`);
    if (rw.mount && MOUNTS[rw.mount]) out.push(`${MOUNTS[rw.mount].name} mount${from}`);
    if (rw.title) out.push(`The title "${rw.title}"${from}`);
  }
  return out;
}

/* ----------------------------------------------------------- Encyclopedia */

// Every collectable entry: base items (by weapon kind, off-hand, armour weight × slot, jewellery), named items, set pieces.
export function catalogue() {
  const entries = [];
  for (const [k, b] of Object.entries(BASES)) {
    const group = b.slot === 'weapon' ? 'Weapons' : b.slot === 'offhand' ? 'Off-hands' : b.slot === 'cape' ? 'Capes' : ARMOUR_SLOTS.includes(b.slot) ? `Armour: ${b.weight[0].toUpperCase()}${b.weight.slice(1)}` : 'Jewellery and trinkets';
    entries.push({ key: `base:${k}`, group, name: b.name, slot: b.slot, base: k });
  }
  for (const [k, n] of Object.entries(NAMED)) entries.push({ key: `named:${k}`, group: 'Named items', name: n.name, base: n.base, named: k, rarity: n.rarity, lore: n.lore });
  for (const [k, s] of Object.entries(DUNGEON_SETS)) for (const [slot, name] of Object.entries(s.pieces)) entries.push({ key: `set:${k}:${slot}`, group: `Set: ${s.name}`, name, slot, set: k, lore: s.lore?.[slot] });
  return entries;
}
export const entryKey = (it) => (it?.named ? `named:${it.named}` : it?.set ? `set:${it.set}:${it.slot}` : it?.base ? `base:${it.base}` : null);

export { WEIGHTS };
