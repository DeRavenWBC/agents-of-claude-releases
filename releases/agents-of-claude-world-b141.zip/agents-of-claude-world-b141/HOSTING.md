# Hosting your own world

Agents of Claude has no server. A world is one claude.ai page (an Artifact) with its own shared database: everyone
in your organization who opens that page plays in the same world, and nobody outside it can. To run a world you
publish this bundle as a page you own. You stay its owner: you publish updates, and you are the one person who must be
trusted, because the page's code runs with each player's Claude and their saves.

## What you need

- A Claude plan for your organization with Artifacts and Claude Code, and your admin's agreement to the page features
  the game uses (they are listed in `capabilities.json`): the shared database, `sample` (each player's own Claude plays
  their Agent, on that player's usage), `user` (names and avatars), `room` (who is online, live duels) and, optionally,
  the local desktop helper for automatic XP sync.
- This bundle folder, unchanged. `MANIFEST.json` lists a SHA-256 for every file.

## Publish it

The easy way: install the plugin (`/plugin install agents-of-claude --marketplace DeRavenWBC/agents-of-claude`), start
Claude Code in the folder that contains this bundle, and run `/agents-of-claude:host <bundle folder>`. It checks the
files against the manifest, publishes the page, and tells you what to share.

By hand, in Claude Code, ask Claude to publish with the Artifact tool:

- `file_path`: `game/index.html`, `root`: this folder
- `files`: every `engine/<name>.js`, served at the same path
- `capabilities`: the contents of `capabilities.json`, exactly
- a title ("Agents of Claude") and an icon word

After publishing, write the world's own details into its database so the game can show players the join command:
`meta/world` = `{"url": "<page link>", "tz": "<clock offset>", "label": "<clock label>"}` (the host command does this).

To update a world later, run `/agents-of-claude:host` on the newer bundle and choose "update". By hand: save the
world's `bouts`, `duels` and `worldboss` collections, run the plugin's `scripts/prepare-world.mjs <bundle> <saved
folder>` (it rebuilds `engine/trusted.js` from your world's records, so fights from before a combat-rules change keep
counting), publish from the folder it prints to the same page (`url`) and leave `capabilities` out, so the stored set
carries forward. Never publish an older build over a newer one: the page's build number only goes up. After
publishing, open the page yourself (or set `meta/build` to the new build): only the owner can raise it, and open
copies of the game reload when it goes up.

## Share it

- Share the page with your organization so that players can use it, not edit it. **Nobody but you should be an
  editor**: an editor can replace the game's code.
- Players see the join command on the game's setup card once `meta/world` is set. You can also give them the page link and the command
  `/agents-of-claude:join <page link> <clock offset>` (for example `+01:00`), which points their plugin at your world.
  Without it their Claude Code XP would go to the first world's page, which they can't write to.

## What the permission set does

`capabilities.json` gives every public collection the pair "everyone reads, each player writes only their own
document" (`agents`, `bouts`, `duels`, `worldboss`, `social`, `market`, `chronicle`), and lets only the owner write
`meta` (the build number open pages watch). Everything under `data/users/<player>` is private to that player, even
from you. If you change the rules, check with a second account that it cannot write another player's document.

## The world's clock

Days, weeks, the Friday Gala and the Monday boss run on one fixed offset from UTC, set when the bundle was made
(`MANIFEST.json`, `clock`). It is the same for every player and can't change once the world has records. Zones with
daylight saving are not supported: pick the offset you want all year.

## What players should know

- Levels and daily history are public inside the world, which shows roughly how much each person uses Claude Code.
- The plugin records only kinds of events and XP on their machine: no prompts, file names or commands.
- XP, items and gold are self-reported. The game bounds what an invented item or number can do to other players, but
  it is a game among colleagues, not a tamper-proof ledger.
