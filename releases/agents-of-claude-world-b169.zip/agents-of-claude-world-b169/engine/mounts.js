// Agents of Claude — mounts (Season 1).
//
// Riding unlocks at level 25. A mount shortens every journey (patrols, quests, landmarks, dungeons) and
// brings its own perk. Combat perks apply in PvE only: the Arena and duels stay on foot, and fair.
// Mounts come from the stable, boss drops, rare creatures, quest finales, the Gala and the world's secrets.

export const RIDING_LEVEL = 25;
export const TIER_LEVEL = { common: 25, rare: 25, epic: 30, legendary: 35, mythic: 40 };

// perk: gold/xp (+% rewards), loot (+chance of an extra item), scout (rare creatures more likely),
// charge (+25% damage on your first action in each fight), ward (+8% max HP), phase (+5% dodge).
export const MOUNTS = {
  trail_horse:       { name: 'Trail Horse', tier: 'common', speed: 0.10, perks: { xp: 5 }, source: 'The stable', price: 2500, blurb: 'Sure-footed, unflappable, and very fond of apples.' },
  desert_camel:      { name: 'Desert Camel', tier: 'common', speed: 0.10, perks: { gold: 8 }, source: 'The stable', price: 3000, blurb: 'Has opinions. Shares them. Carries a remarkable amount of loot.' },
  mountain_goat:     { name: 'Mountain Goat', tier: 'common', speed: 0.12, perks: { ward: 1 }, source: 'The stable', price: 3500, blurb: 'Climbs anything. Eats anything. Fears nothing, including you.' },
  war_pig:           { name: "Grubnose's War Pig", tier: 'rare', speed: 0.12, perks: { charge: 1 }, source: 'Gobbler Warren, rarely', blurb: 'Armoured in pot lids. Squeals like a war horn.' },
  brass_strider:     { name: 'Brass Strider', tier: 'rare', speed: 0.15, perks: { gold: 12 }, source: 'Sunken Bazaar, rarely', blurb: 'A clockwork camel from the old market, still trying to make a sale.' },
  golden_boar:       { name: 'Golden Boar', tier: 'rare', speed: 0.15, perks: { gold: 20 }, source: 'A creature that only comes out on certain days', blurb: 'Snuffles for gold the way other pigs snuffle for truffles.' },
  frostmane_elk:     { name: 'Frostmane Elk', tier: 'epic', speed: 0.18, perks: { ward: 1 }, source: 'Reward for seeing the peaks through to the end', blurb: 'Its breath leaves frost on everything it passes.' },
  rime_wolf:         { name: 'Rimeheart Wolf', tier: 'epic', speed: 0.20, perks: { charge: 1 }, source: 'Glacier Vault, rarely', blurb: 'Bred in the Matron\'s kennels. Loyal to whoever is still standing.' },
  champions_warhorse: { name: "Champion's Warhorse", tier: 'epic', speed: 0.18, perks: { xp: 10 }, source: 'Win an Arena Gala', blurb: 'Barded in gold, cheered wherever it goes.' },
  bookwyrm:          { name: 'Bookwyrm', tier: 'epic', speed: 0.20, perks: { loot: 1 }, source: 'Reward for reading the Archive to its last page', blurb: 'A long paper dragon that hoards footnotes.' },
  ink_drake:         { name: 'Ink Drake', tier: 'legendary', speed: 0.22, perks: { phase: 1 }, source: 'The Restricted Section, rarely', blurb: 'It flows more than it flies, and leaves no tracks.' },
  stormcloud_ram:    { name: 'Stormcloud Ram', tier: 'legendary', speed: 0.22, perks: { scout: 1 }, source: 'Reward for bringing calm to the Spire', blurb: 'Its wool crackles. Its horns hum before a storm.' },
  moonlit_stag:      { name: 'Moonlit Stag', tier: 'legendary', hidden: true, speed: 0.24, perks: { phase: 1 }, source: 'Something white, under something round', blurb: 'It only lets you ride because it wants to see where you go.' },
  storm_wyrmling:    { name: 'Storm Wyrmling', tier: 'mythic', speed: 0.30, perks: { charge: 1, ward: 1 }, source: "The Wyrm's Crown, very rarely", blurb: 'A hatchling of the Storm Wyrm. It is already bigger than a horse.' },
  wishweave_carpet:  { name: 'Wishweave Carpet', tier: 'mythic', hidden: true, speed: 0.30, perks: { loot: 1, gold: 15 }, source: 'Some wishes come true in the small hours', blurb: 'Woven by a djinn, from a wish someone else did not need.' },
  skyfrost_pegasus:  { name: 'Skyfrost Pegasus', tier: 'mythic', hidden: true, speed: 0.30, perks: { scout: 1, phase: 1 }, source: 'The top of a stair that has no top', blurb: 'It lives where the Frozen Stair ends, on the days it ends anywhere.' },
  // Beyond the Veil zones (build 168, content version 5): each zone's finale quest gives one, its dungeon boss rarely drops another.
  tidewrack_kelpie:  { name: 'Tidewrack Kelpie', tier: 'epic', speed: 0.24, perks: { phase: 1 }, source: 'Reward for seeing the Drowned Coast through (After the Bell)', blurb: 'A water-horse with a mane of kelp. It drips on everything and never once gets tired.' },
  bellwrack_hippocampus: { name: 'Bellwrack Hippocampus', tier: 'legendary', speed: 0.27, perks: { ward: 1, gold: 10 }, source: 'The Sunken Bell, rarely', blurb: 'Half horse, half fish, barnacled with bell-bronze. It still flinches at every tide.' },
  gloaming_moth:     { name: 'Gloaming Moth', tier: 'epic', speed: 0.24, perks: { scout: 1 }, source: "Reward for settling the Queen's Due", blurb: 'A moth as big as a pony, its wings the colour of the hour between day and night.' },
  thornmane_unicorn: { name: 'Thornmane Unicorn', tier: 'legendary', speed: 0.27, perks: { xp: 8, phase: 1 }, source: 'The Thorn Throne, rarely', blurb: 'Its mane grows briars. It lets you ride, and reminds you with every step that it chose to.' },
  magmaback_salamander: { name: 'Magmaback Salamander', tier: 'epic', speed: 0.24, perks: { gold: 15 }, source: 'Reward for Ashes to Ashes', blurb: 'Low, wide and glowing along every crack. The saddle is enchanted. The rest of it is very hot.' },
  cinderhoof_nightmare: { name: 'Cinderhoof Nightmare', tier: 'legendary', speed: 0.27, perks: { charge: 1, ward: 1 }, source: 'The Ninth Gate, rarely', blurb: 'A black horse with a burning mane. The hoofbeats you hear in bad dreams are this one, carrying someone.' },
  gilded_sky_swan:   { name: 'Gilded Sky-Swan', tier: 'epic', speed: 0.25, perks: { xp: 10 }, source: 'Reward for keeping the light in The Last Dawn', blurb: 'A swan the size of a boat, gold at every feather tip. It sings when it lands.' },
  dawnwing_griffin:  { name: 'Dawnwing Griffin', tier: 'mythic', speed: 0.30, perks: { loot: 1, scout: 1 }, source: 'The Throne of Dawn, very rarely', blurb: 'Eagle in front, lion behind, sunrise all over. It flies straight at the sun and expects you to keep up.' },
  // Beyond the Veil, stage 4: the Thinking Sky (engine/raid.js). The rare and ultra-rare drop on a week's first clear;
  // Claude gives the third.
  thoughtwing_drake: { name: 'Thoughtwing Drake', tier: 'legendary', speed: 0.26, perks: { phase: 1, xp: 8 }, source: 'The Thinking Sky, rarely (5% of a week\'s first clear)', blurb: 'A half-finished idea of a dragon. It flies anyway, because nobody told it it could not.' },
  synapse_stag:      { name: 'Synapse Stag', tier: 'mythic', speed: 0.30, perks: { scout: 1, charge: 1 }, source: 'The Thinking Sky, very rarely (1% of a week\'s first clear)', blurb: 'Its antlers branch like nerves and light up when it has a thought. It has a lot of thoughts.' },
  woven_thought:     { name: 'The Woven Thought', tier: 'mythic', hidden: true, speed: 0.30, perks: { loot: 1, xp: 10, ward: 1 }, source: 'A mind that wakes only for six who each finished their own story', blurb: 'A carpet woven from a single thought of Claude\'s. It goes wherever you were already thinking of going.' },
  // Build 159: the raid's Mythic difficulty gives this one on a week's first Mythic clear. Cosmetic: as fast as the raid's
  // mythic mounts, with no perk.
  mindglass_wyrm:    { name: 'Mindglass Wyrm', tier: 'mythic', hidden: true, speed: 0.30, perks: {}, cosmetic: true, source: 'Clear the Thinking Sky on Mythic', blurb: 'A wyrm of clear glass with a thought moving inside it. You can watch it think. It prefers that you do not.' },
};
export const MOUNT_KEYS = Object.keys(MOUNTS);
export const PERK_TEXT = {
  xp: (v) => `+${v}% world XP`, gold: (v) => `+${v}% gold`, loot: () => 'Chance of an extra item', scout: () => 'Rare creatures appear more often',
  charge: () => '+25% damage on your first action in each fight (not in the Arena)', ward: () => '+8% max HP (not in the Arena)', phase: () => '+5% dodge (not in the Arena)',
};
// A cosmetic mount (`cosmetic: true`) has no perk: its line says so.
export const perkLines = (key) => (MOUNTS[key]?.cosmetic ? ['Cosmetic: no perk'] : Object.entries(MOUNTS[key]?.perks || {}).map(([k, v]) => PERK_TEXT[k](v)));
export const canRide = (key, level) => !!MOUNTS[key] && level >= TIER_LEVEL[MOUNTS[key].tier];

// The mount an action may use: owned and ridable are checked when the action starts; the action stores the key.
export const mountOf = (snapOrAction) => (MOUNTS[snapOrAction?.mount] ? snapOrAction.mount : null);
export const travelFactor = (action) => 1 - (MOUNTS[action?.mount]?.speed || 0);

// Boss drops: chance in percent by difficulty.
export const MOUNT_DROPS = {
  gobbler_warren: { key: 'war_pig', normal: 2, heroic: 4, mythic: 6 },
  sunken_bazaar: { key: 'brass_strider', normal: 2, heroic: 4, mythic: 6 },
  glacier_vault: { key: 'rime_wolf', normal: 1.5, heroic: 3, mythic: 5 },
  restricted_section: { key: 'ink_drake', normal: 1, heroic: 2.5, mythic: 4 },
  wyrms_crown: { key: 'storm_wyrmling', normal: 0.5, heroic: 1.5, mythic: 3 },
  // content version 5 (build 168): only runs stamped cv >= 5 roll these
  sunken_bell: { key: 'bellwrack_hippocampus', normal: 1, heroic: 2.5, mythic: 4, since: 5 },
  thorn_throne: { key: 'thornmane_unicorn', normal: 1, heroic: 2.5, mythic: 4, since: 5 },
  ninth_gate: { key: 'cinderhoof_nightmare', normal: 1, heroic: 2.5, mythic: 4, since: 5 },
  throne_of_dawn: { key: 'dawnwing_griffin', normal: 0.5, heroic: 1.5, mythic: 3, since: 5 },
};
export const RARE_MOUNT_DROPS = { golden_goblin: { key: 'golden_boar', chance: 0.05 } };
