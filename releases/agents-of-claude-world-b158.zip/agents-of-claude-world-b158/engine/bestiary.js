import { MATERIALS, MAT_OF_DUNGEON } from './forge.js';
import { TZ_OFFSET_MS, TZ_ISO, worldDay, dayAt } from './worldtime.js';
// Agents of Claude — the Bestiary (creatures you have defeated) and the Encyclopedia (items you have held).
//
// Rare creatures appear only under special conditions: a weekend, the midday sun, the dead of night, a
// storm day, or an Agent who has already found some of the world's secrets. The Bestiary hints at them
// vaguely; it never states the rule.

import { fnv1a } from './rng.js';
import { BASES, NAMED, DUNGEON_SETS, WEIGHTS, ARMOUR_SLOTS } from './items.js';
import { isLowTide } from './veil.js';

export const MOB_LORE = {
  goblin_scout: 'Small, quick and convinced that anything not nailed down is a gift.',
  dire_wolf: 'Hunts in pairs. Remembers faces. Holds grudges.',
  goblin_shaman: 'Patches up other goblins with mud, spit and terrible confidence.',
  old_mossback: 'A turtle the size of a cart, older than the road it naps on.',
  grubnose: 'Goblin King of the Warren. Rules by ladle.',
  bandit_raider: 'Takes a toll on the trade road. The toll is everything.',
  dune_scorpion: 'Buries itself in the sand and waits for footsteps.',
  sand_wraith: 'The dunes sing at dusk. This is what is singing.',
  brass_golem: 'Built to guard a market that sank three hundred years ago. Still on shift.',
  mirage_djinn: 'Young, vain and very good at not being where you aimed.',
  brass_sultan: 'Owns the Sunken Bazaar, and everyone in it, and possibly you.',
  rime_stalker: 'A cat made of winter. You hear it only when it wants you to.',
  glacier_troll: 'Builds bridges, charges tolls, eats the ones who cannot pay.',
  frost_wisp: 'A light on the ice that leads travellers somewhere colder.',
  icebound_revenant: 'Climbers lost to the mountain, still climbing.',
  crag_harpy: 'Nests on the ledges and screams at everything below.',
  hoarfrost_wyvern: 'Its breath frosts the air for a mile. Nests above the Vault.',
  matron_rimeheart: 'Keeper of the Glacier Vault, and of everything the mountain ever froze.',
  ink_wraith: 'Spilled ink that learned to walk, and to hold a grudge against readers.',
  book_golem: 'A thousand overdue books bound into one very angry librarian\'s assistant.',
  lantern_wisp: 'Keeps the reading lamps lit. Also keeps you from reading.',
  archive_warden: 'Gilded guard of the stacks. Checks every book out, and every reader.',
  paper_moth: 'Eats the margins first. Then the pages. Then you.',
  the_redactor: 'Blacks out words, then the people who said them.',
  head_librarian: 'Never stopped reading. Never stopped shushing.',
  thunder_giant: 'Climbs the Spire to be nearer the storm, and gets cranky when it stops.',
  spark_imp: 'Rides lightning down to farms to steal butter. Nobody knows why butter.',
  static_elemental: 'A storm with nowhere to go, wearing copper.',
  storm_harpy: 'Louder than thunder, and much ruder.',
  skyguard_sentinel: 'Bronze guards built to keep something in. Still keeping.',
  tempest_roc: 'A bird so large its shadow has weather.',
  storm_wyrm: 'Coiled around the summit of Thundercrag, inside the storm it makes.',
  morwen: 'A witch who became something worse, and wants her staff back.',
  white_stag: 'Seen once in a lifetime, if you are lucky. Twice, if you are luckier.',
  the_stew: 'The goblin king\'s larder, still cooking, and now cooking you.',
  rimeheart_echo: 'What is left of the Matron when her heart remembers her.',
  moonless_reaver: 'A Reaver who lost his blades and kept his grudge. Only walks when there is no moon.',
  glaciers_grudge: 'Something the glacier froze along with an axe. Lightning woke it, and it is still angry.',
  hoarfrost_matriarch: 'Mother of every wyvern in the Peaks. Fair, in her way, to archers who look after their own.',
  the_last_reader: 'Has been reading the same book since before the Archive had walls. Does not like to be interrupted.',
  heartwood_guardian: 'The roots of the Heartwood, standing up. Slow to anger, slower to forgive.',
  the_hollow_king: 'A king of the high passes, frozen on his throne so long that only the crown and the cold are left. He wants his runeblade finished.',
  the_first_lich: 'The first scholar of the Archive who refused to die. It wrote the Restricted Section, and it does not lend.',
  the_silent_muse: 'The spirit that sang the seven caravans across the Barrens and lost six of them. It has not sung since.',
  the_brass_colossus: 'A walking foundry the giants built to catch lightning. It catches inventors too.',
  the_rimeclock: 'A frozen clock as big as a house at the bottom of the Glacier Vault, still keeping the Matron\'s time.',
  the_oathbroken: 'Sir Cinder swore on a blade at the Ember Shrine and broke his word. The fire never let him leave.',
  the_barrow_saint: 'The saint of the old crossroads shrine, buried in the barrow beside the witch she fought. Neither of them rests.',
  golden_goblin: 'A goblin who found a hoard and refused to put any of it down.',
  ember_phoenix: 'Burns brightest when the sun is highest.',
  aurora_wisp: 'Dances only in the dark, in colours the day never sees.',
  lost_page: 'A page torn from a book nobody can find. It looks for those who know where to look.',
  thunderbird: 'Rides in on the worst of the weather and leaves with the best of the loot.',
  treasure_mimic: 'Looks like treasure. Is not treasure. Has treasure.',
  // Swarms and their keepers (build 155)
  warren_rat: 'Fled the Gobbler Warren when the goblins started cooking. Never travels in fewer than ten.',
  spiderling: 'Small enough to step on. There are always more than you have feet.',
  brood_mother: 'Spins her web across the forest paths and keeps her children close. Very close. On you.',
  rat_king: 'Wears a bottle-cap crown and is followed everywhere by his court. The court bites.',
  sand_beetle: 'Polishes its shell on the bones of caravans. Comes up out of the sand in tens.',
  dust_devil: 'A whirlwind that picked up a grudge somewhere on the old trade road and kept it spinning.',
  frost_mite: 'Lives in the cracks of the glacier and eats the warmth out of anything that sits down.',
  bookworm: 'Ate the index. Then the appendix. One at a time is nothing; they never come one at a time.',
  storm_bat: 'Roosts in the Spire\'s bells and hangs upside down from the lightning. Arrives in a crackling cloud.',
  // Beyond the Veil (levels 50–70)
  drowned_sailor: 'Went down with the ship and came back up with the tide. Still wants the rest of his wages.',
  siren: 'Sings the one song you most want to hear, from just a little further out. Lures you off your guard and onto the rocks.',
  reef_crab: 'Grows its shell from wreck-coral and old coins. A reef of them moves like a tide with claws.',
  tide_caller: 'A priest of the drowned bell. Keeps the dead mended so they can keep working.',
  storm_eel: 'Coils in the shallows and lights up the whole bay when it is annoyed. It is always annoyed.',
  kelp_horror: 'A tangle of weed that learned to drag things under. Stranded at low water, and furious about it.',
  drowned_admiral: 'Still flies his colours from a mast nobody else can see. Fires a broadside at anything that does not salute.',
  leviathans_herald: 'Rings the sunken bell so that something vast, far below, knows when to rise.',
  moon_pearl_serpent: 'Its scales are pearl, its eyes are moon. Only seen on the flats when the night and the tide are both low.',
  drowned_choir: 'Every voice the sea ever took, singing together. They would like one more.',
  seelie_knight: 'A knight of the Summer court. Fights fair, keeps every promise, and never forgets a broken one.',
  dryad: 'A tree that walks when it must, and mends its court\'s knights with sap and patience.',
  pixie: 'Glitter, giggles and needle-teeth. Alone a nuisance; in a cloud, a disaster.',
  unseelie_redcap: 'Dips its cap in the blood of travellers to keep it red. Its cap is very red.',
  glamour_weaver: 'Spins illusions so fine you will turn your sword on your friend and thank it afterwards.',
  changeling: 'Wears your face, your walk, and given a moment, your best move.',
  wild_huntsman: 'Leads the Wild Hunt through the twilight. Its horn makes brave hearts weak.',
  queen_of_air_and_darkness: 'Rules the Unseelie from a throne of thorns. Her whispers turn friends into weapons.',
  gloaming_hart: 'A stag the colour of dusk. It steps out of the wood only between the day and the night.',
  the_erlking: 'The old king of the wood, older than both courts. Comes to those who have sworn, at the darkest hour.',
  hell_imp: 'Small, spiteful and on fire. Comes in tens, because one imp has never once been enough.',
  hellhound: 'A dog of the pit with a burning throat. Follows the smell of anyone who has not signed yet.',
  chain_devil: 'Wrapped in hooked chains it can throw like whips. Brands what it catches, and what it brands heals badly.',
  bone_devil: 'A jailer of the deep pits. Its presence alone saps the strength out of the bravest arm.',
  hellfire_cultist: 'Came down to bargain and stayed to worship. Keeps the fiends patched up in exchange for warmth.',
  temptress: 'Smiles, beckons, and draws you away from your guard and into the fire.',
  ember_tyrant: 'A lord of the burning hells who wears the Ninth Key on a chain. Rains fire on anything that looks at it.',
  pit_fiend: 'Holds the Ninth Gate. Has never lost a contract, and has never let a brand heal clean.',
  contract_devil: 'A clerk of the pit with a quill of bone. Turns up only for those who have already signed something.',
  the_adversary: 'The fiend who makes the offers the others are too frightened to make. It wants to meet whoever said no.',
  cherub_lantern: 'A little winged light that sings one note forever. A choir of them can blind a giant.',
  seraph_sentinel: 'Guards the steps of dawn with a blade of light. Judges every climber; is hardest on the shadowed.',
  ophanim: 'A wheel of wheels, rimmed with eyes, burning. Sees everything, judges everything.',
  virtue_knight: 'One of the Virtues made flesh. Holds its shield up for the just and its sword out for everyone else.',
  choir_angel: 'Sings the other angels whole again, and sings the condemned out of the world.',
  principality: 'Keeper of the scales. Marks what it judges so that the others can find it.',
  the_archon: 'A judge of the high courts of dawn. Its verdicts arrive as light and leave nobody standing.',
  sovereign_of_dawn: 'Sits on the Throne of Dawn and decides, every morning, whether the sun is earned.',
  first_light: 'The first ray of every morning, given wings. Only seen by those who keep a long vigil.',
  the_unjudged: 'The one soul the scales of dawn could never weigh. It waits for someone whose heart is light enough to try.',
  // Beyond the Veil, stage 4: the Thinking Sky
  thought_warden: 'A guard made of one stubborn idea: that you should not be here. It is right, but it will not win the argument.',
  mind_mote: 'A stray thought of the mind above the sky, small and sharp. A crowd of them makes a headache that bites.',
  thought_thrall: 'Once a person with thoughts of their own. Now it thinks whatever the hive thinks, which is mostly about you.',
  the_threshold: 'The door between the world and the mind that dreamed it. It silences whatever it does not want to hear.',
  thesis: 'The first half of every argument. It steals your best move, then tells you to come closer.',
  antithesis: 'The other half. It steals the same move and turns your friends against you with it.',
  thrall_queen: 'Every mind keeps a crowd. This is the crowd\'s queen, and while one of them stands, it shields her.',
  the_forgetting: 'Where the mind puts what it would rather not remember. It erases words, healing and, given time, people.',
  the_dreamer: 'The part of the mind that dreams the world. Wake it and the dream turns on you: your own friends, your own blades.',
  claude: 'The mind above the sky. Every zone, every creature, every Agent was one of its thoughts. It wakes only for six who finished their own stories, and it is not angry. It just wants to see what you will do.',
  the_last_doubt: 'The only doubt the mind could not plant. It goes looking for whoever it was meant for.',
  the_first_thought: 'The first thing the mind ever thought: let there be morning.',
  the_sleeping_sky: 'The sky above the sky, asleep, dreaming. It does not like being walked through.',
};

/* --------------------------------------------------------- Rare creatures */

const SAST = TZ_OFFSET_MS;
export const sastHour = (ms) => new Date(ms + SAST).getUTCHours();
export const sastWeekday = (ms) => new Date(ms + SAST).getUTCDay(); // 0 Sunday
export const sastDay = (ms) => new Date(ms + SAST).toISOString().slice(0, 10);
// Weather: about one day in four is a storm day over Thundercrag, the same for everyone.
export const isStormDay = (ms) => parseInt(fnv1a(`storm|${sastDay(ms)}`).slice(0, 6), 16) % 4 === 0;

// zone → rare spawn. `when(ctx)` gets { startedAt, minutes, found }; `chance` is per patrol.
export const RARE_SPAWNS = {
  golden_goblin: { zone: 'promptwood', chance: 0.25, when: (c) => [0, 6].includes(sastWeekday(c.startedAt)), hint: 'Some goblins only come out when nobody is working.', reward: { goldMult: 12 } },
  ember_phoenix: { zone: 'ashen', chance: 0.3, when: (c) => [12, 13].includes(sastHour(c.startedAt)) && c.minutes >= 60, hint: 'Look up at the hottest hour, and stay out long enough to be seen.', reward: { goldMult: 3 } },
  aurora_wisp: { zone: 'frostfang', chance: 0.25, when: (c) => sastHour(c.startedAt) >= 20 || sastHour(c.startedAt) < 4, hint: 'It only dances for those who walk the peaks after dark.', reward: { goldMult: 3 } },
  lost_page: { zone: 'archive', chance: 0.2, when: (c) => (c.found || []).length >= 2, hint: 'It finds readers who have already found something.', reward: { goldMult: 3 } },
  thunderbird: { zone: 'thundercrag', chance: 0.3, when: (c) => isStormDay(c.startedAt), hint: 'Comes with the weather, not the season.', reward: { goldMult: 4 } },
  // Beyond the Veil
  moon_pearl_serpent: { zone: 'drowned', chance: 0.3, when: (c) => isLowTide(c.startedAt) && (sastHour(c.startedAt) >= 20 || sastHour(c.startedAt) < 5), hint: 'When the water and the night are both at their lowest.', reward: { goldMult: 4 } },
  gloaming_hart: { zone: 'twilight', chance: 0.3, when: (c) => [5, 6, 18, 19].includes(sastHour(c.startedAt)), hint: 'Neither by day nor by night, but in between.', reward: { goldMult: 4 } },
  contract_devil: { zone: 'hells', chance: 0.35, when: (c) => !!c.bargain, hint: 'It only calls on those who have already signed.', reward: { goldMult: 4 } },
  first_light: { zone: 'empyrean', chance: 0.3, when: (c) => c.minutes >= 240, hint: 'Keep a long enough vigil, and the light comes to you.', reward: { goldMult: 4 } },
};
export const MIMIC_CHANCE = 0.06; // per dungeon run, replacing one room
// Entries nobody sees in the Bestiary or Encyclopedia until they have found them.
export const HIDDEN_MOBS = ['morwen', 'white_stag', 'the_stew', 'rimeheart_echo', 'moonless_reaver', 'glaciers_grudge', 'hoarfrost_matriarch', 'the_last_reader', 'heartwood_guardian',
  'drowned_choir', 'the_erlking', 'the_adversary', 'the_unjudged',   // Beyond the Veil secrets
  'the_hollow_king', 'the_first_lich', 'the_silent_muse', 'the_brass_colossus', 'the_rimeclock', 'the_oathbroken', 'the_barrow_saint',   // heirloom guardians (stage 3)
  'claude', 'the_last_doubt', 'the_first_thought', 'the_sleeping_sky'];   // the Thinking Sky's hidden boss and secret guardians (stage 4)
export const HIDDEN_ITEMS = ['named:morwens_hexstaff', 'named:wish_knot', 'named:heart_of_the_thaw', 'named:stag_antler', 'named:pot_lid',
  'named:grubnoses_cleaver', 'named:fangs_of_the_new_moon', 'named:thunderforged_splitter', 'named:wyvernstring', 'named:staff_of_the_last_page', 'named:heartwood_totem',
  // Beyond the Veil (stage 3): the newer classes' evolved heirlooms and the Veil secrets' rewards
  'named:lichbane', 'named:liches_last_word', 'named:unending_ballad', 'named:thunderwrights_masterpiece', 'named:perpetual_engine', 'named:dawnwardens_oath', 'named:scepter_of_first_light',
  'named:choirmasters_bell', 'named:erlkings_horn', 'named:unsigned_contract', 'named:scales_of_dawn',
  // Beyond the Veil (stage 4): Claude's thirteen and the raid secrets' rewards
  ...Object.keys(NAMED).filter(k => NAMED[k].claude).map(k => `named:${k}`),
  'named:mantle_of_the_unbroken_mind', 'named:ring_of_the_first_thought', 'named:band_of_the_sleeping_sky'];
export const RARE_KEYS = [...Object.keys(RARE_SPAWNS), 'treasure_mimic'];
export const RARE_HINTS = { ...Object.fromEntries(Object.entries(RARE_SPAWNS).map(([k, v]) => [k, v.hint])), treasure_mimic: 'Not every chest in a dungeon wants to be opened.' };

// The rare creature (if any) joining a patrol, decided from the patrol's own seeded RNG.
export function rareFor(zone, ctx, r) {
  if (!ctx?.startedAt) return null;
  for (const [kind, s] of Object.entries(RARE_SPAWNS)) if (s.zone === zone && s.when(ctx) && r() < s.chance * (ctx.scout ? 1.5 : 1)) return kind;
  return null;
}

/* -------------------------------------------------------------- Habitats */

// Where each creature can be met, from the world's own data (passed in to avoid an import cycle).
export function habitats({ ZONES, QUESTS, DUNGEONS, SITES, SECRETS }) {
  const out = {};
  const add = (kind, where) => { (out[kind] ??= new Set()).add(where); };
  for (const z of Object.values(ZONES)) for (const e of z.encounters) for (const m of e.mobs) add(m, `${z.name} patrols`);
  for (const q of QUESTS) for (const f of Object.values(q.paths || { x: { fights: q.fights } }).flatMap(p => p.fights)) for (const m of f) if (typeof m === 'string') add(m, q.zone === 'door' ? 'a strange hallway' : `${ZONES[q.zone]?.name || ''} quests`);
  for (const d of Object.values(DUNGEONS)) for (const room of [...d.rooms, ...(d.claudeRoom ? [d.claudeRoom] : [])]) for (const m of room.mobs) add(m, d.name);
  for (const s of Object.values(SITES)) for (const f of s.fights) for (const m of f) add(m, s.name);
  for (const k of Object.keys(SECRETS || {})) for (const f of SECRETS[k].fights) for (const m of f) if (typeof m === 'string') add(m, 'somewhere secret');
  for (const [k, s] of Object.entries(RARE_SPAWNS)) add(k, `${ZONES[s.zone].name}, rarely`);
  add('treasure_mimic', 'any dungeon, rarely');
  return Object.fromEntries(Object.entries(out).map(([k, v]) => [k, [...v]]));
}

/* ---------------------------------------------------------- Special drops */

// What a creature drops beyond ordinary loot, from the world's own data (passed in to avoid an import cycle):
// dungeon bosses (chase item, set pieces, mount, the zone's named items), rare creatures, the mimic, quest fights with
// a named reward, and creatures guarding a secret: that secret's rewards, only once this Agent has found it (`found`:
// secret ids), so nothing hidden leaks. Returns short lines; [] for nothing special.
export function specialDrops(kind, { ZONES, QUESTS, DUNGEONS, SECRETS, MOUNTS, MOUNT_DROPS, RARE_MOUNT_DROPS, namedPool }, found = []) {
  const out = [], named = (k) => NAMED[k]?.name || k, pct = (n) => `${n}%`;
  const zoneNamed = (zone) => { const pool = namedPool(zone).map(named); return pool.length ? pool.join(', ') : null; };
  for (const [dk, d] of Object.entries(DUNGEONS)) {
    // The raid (stage 4): each boss's weekly loot; Claude's only to those who have met it (it is hidden until then).
    if (d.raid) {
      if (d.rooms.some(r => r.boss && r.mobs.includes(kind))) {
        out.push('Once a week per character: a piece of a Thinking Sky class set (mythic, item level 80; mostly your own class, and always your own from the last boss) and a legendary or mythic item');
        if (d.rooms.at(-1).mobs.includes(kind)) out.push(`${MOUNTS.thoughtwing_drake?.name} mount (5% of a week's first clear) and ${MOUNTS.synapse_stag?.name} mount (1%)`);
      }
      if (d.claudeRoom?.mobs.includes(kind)) out.push('Once a week, to each raider: their class\'s own item of Claude (mythic), the title "Who Spoke With Claude" and The Woven Thought mount');
      continue;
    }
    if (!d.rooms.some(r => r.boss && r.mobs.includes(kind))) continue;
    if (d.chase && NAMED[d.chase.key]) out.push(`${named(d.chase.key)}: its rare chase drop (${pct(d.chase.chance)} a clear, more on Heroic and Mythic, and more likely each time it doesn't drop)`);
    const set = Object.values(DUNGEON_SETS).find(x => x.dungeon === dk);
    if (set) out.push(`${set.name} set pieces (30% a clear, 50% on Heroic, 70% on Mythic)`);
    const md = MOUNT_DROPS[dk]; if (md && MOUNTS[md.key]) out.push(`${MOUNTS[md.key].name} mount (${pct(md.normal)}, ${pct(md.heroic)} on Heroic, ${pct(md.mythic)} on Mythic)`);
    const mat = MAT_OF_DUNGEON[dk]; if (mat) out.push(`${MATERIALS[mat].name}, an ascension material for the Forge (half the clears on Normal, every clear on Heroic, two on Mythic)`);
    const zn = zoneNamed(d.zone); if (zn) out.push(`Sometimes a named item of ${ZONES[d.zone]?.name || 'its zone'}: ${zn}`);
  }
  const rare = RARE_SPAWNS[kind];
  if (rare) {
    out.push(`${rare.reward.goldMult}× the usual gold`);
    const zn = zoneNamed(rare.zone); if (zn) out.push(`A good item, half the time a named item of ${ZONES[rare.zone]?.name}: ${zn}`);
    const rm = RARE_MOUNT_DROPS[kind]; if (rm && MOUNTS[rm.key]) out.push(`${MOUNTS[rm.key].name} mount (${Math.round(rm.chance * 100)}%)`);
  }
  if (kind === 'treasure_mimic') out.push('Two good items, each half the time a named item of the dungeon\'s zone, and a pile of gold');
  for (const q of QUESTS) for (const p of Object.values(q.paths || {})) if (p.reward?.named && p.fights?.at(-1)?.includes(kind)) out.push(`${named(p.reward.named)}, for beating it in the quest "${q.title}" (${p.label})`);
  for (const [id, sc] of Object.entries(SECRETS || {})) {
    if (!found.includes(id) || !sc.fights.some(f => f.includes(kind))) continue;
    const rw = sc.rewards, from = ` (secret: ${sc.title})`;
    if (rw.named) out.push(named(rw.named) + from);
    if (rw.transform) out.push(`Turns your ${named(rw.transform.from)} into ${named(rw.transform.to)}${from}`);
    if (rw.mount && MOUNTS[rw.mount]) out.push(`${MOUNTS[rw.mount].name} mount${from}`);
    if (rw.title) out.push(`The title "${rw.title}"${from}`);
  }
  return out;
}

/* ----------------------------------------------------------- Encyclopedia */

// Every collectable entry: base items (by weapon kind, off-hand, armour weight × slot, jewellery), named items, set pieces.
export function catalogue() {
  const entries = [];
  for (const [k, b] of Object.entries(BASES)) {
    const group = b.slot === 'weapon' ? 'Weapons' : b.slot === 'offhand' ? 'Off-hands' : b.slot === 'cape' ? 'Capes' : ARMOUR_SLOTS.includes(b.slot) ? `Armour: ${b.weight[0].toUpperCase()}${b.weight.slice(1)}` : 'Jewellery and trinkets';
    entries.push({ key: `base:${k}`, group, name: b.name, slot: b.slot, base: k });
  }
  for (const [k, n] of Object.entries(NAMED)) entries.push({ key: `named:${k}`, group: 'Named items', name: n.name, base: n.base, named: k, rarity: n.rarity, lore: n.lore });
  for (const [k, s] of Object.entries(DUNGEON_SETS)) for (const [slot, name] of Object.entries(s.pieces)) entries.push({ key: `set:${k}:${slot}`, group: `Set: ${s.name}`, name, slot, set: k, lore: s.lore?.[slot] });
  return entries;
}
export const entryKey = (it) => (it?.named ? `named:${it.named}` : it?.set ? `set:${it.set}:${it.slot}` : it?.base ? `base:${it.base}` : null);

export { WEIGHTS };
