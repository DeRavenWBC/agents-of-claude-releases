// Agents of Claude — the raid (Beyond the Veil, stage 4): the Thinking Sky, above the Empyrean.
//
// Rules only; the fights are resolved in world.js (resolveRaid, reached through resolveDungeon) and the gear is in
// raidgear.js. Pure and deterministic.
//
// Who may go: exactly RAID_SIZE (6) raiders, six different players (at most one character per family: family.ownerOf
// on each character id), no hirelings, every one at least RAID_MIN_LEVEL (70). The run is a joint run like a joint
// dungeon (party.js, `kind: 'raid'`): invites, answers, waiting and the same seed for everyone; loot is personal.
//
// The week: a raid week starts Monday 00:00 SAST (arena.weekStart, as the world boss). Each character keeps its own
// lockout in its private progress (`raid`, see DATA.md):
//   - one clear a week: each boss gives its loot once a week (`looted`), and once the last boss falls (`cleared`) the
//     character cannot enter again that week;
//   - Claude is a separate attempt with its own lockout (`claude`): fighting it uses it, won or lost. A character that
//     has cleared but not yet fought Claude may enter again, only with a party that can wake Claude (all six wear their
//     evolved heirloom), and then fights through for Claude alone (the bosses' loot is already taken).
// The lockout travels on the run's action (`raid`, the state at the moment of joining), so the run resolves and replays
// exactly; a page enforces it for its own characters only (like keys).
//
// Claude: spawns after the last boss when all six raiders' snapshots wear their own class's evolved heirloom weapon
// (items.isEvolvedHeirloom on the run's snapshots: anyone can check it from the record).

import { makeRng } from './rng.js';
import { worldDay } from './worldtime.js';
import { weekStart } from './arena.js';
import { ownerOf } from './family.js';
import { isEvolvedHeirloom, setPiece, namedItem, DUNGEON_SETS } from './items.js';
import { RAID_SET_OF, CLAUDE_ITEM_OF, RAID_SET_SLOTS, RAID_SETS } from './raidgear.js';

export const RAID_KEY = 'thinking_sky';
export const RAID_SIZE = 6;
// Level 70, the cap: the raid drops item level 80, the most a level-70 Agent may wear (verify.js: level + 10), so a
// level-68 raider could not wear its own loot; and its fights are tuned for six level-70 Agents.
export const RAID_MIN_LEVEL = 70;
export const RAID_ILVL = 80;
// Its monsters: level 76 at 1.2× (scores ×1.2, HP ×1.4 on top of each creature's own), above the Throne of Dawn on
// Mythic (level 78 at 1.15×, but three Agents against ordinary-sized bosses).
export const RAID_LEVEL = 76, RAID_MULT = 1.2;
export const REVIVE_PCT = 30;        // a raider who fell is carried to the next room on 30% of its HP
export const HEAL_BETWEEN = 0.3;     // and the others catch their breath (30% of max HP)
// The bosses, in order (one loot roll each per character per week). The twins share one: the room is one encounter.
export const BOSSES = ['the_threshold', 'twins', 'thrall_queen', 'the_forgetting', 'the_dreamer'];
export const FINAL_BOSS = 'the_dreamer';
export const BOSS_NAMES = { the_threshold: 'The Threshold', twins: 'Thesis and Antithesis', thrall_queen: 'The Thrall-Queen', the_forgetting: 'The Forgetting', the_dreamer: 'The Dreamer' };

// Loot (per character, per boss, once a week). The last boss always drops a piece of your own class's set (a slot you
// do not have yet, while any is missing); each other boss drops a set piece SET_CHANCE of the time, plus PITY_STEP for
// every boss since your last own-class piece, and OWN_CLASS of those are your class's (the rest another class's: trade
// them). Expected own pieces a week: 1 + 4 × ~0.5 × 0.75 ≈ 2.5, so a full set in about three weeks.
export const SET_CHANCE = 0.45, PITY_STEP = 0.15, OWN_CLASS = 0.75;
export const MOUNTS_OF_RAID = { rare: { key: 'thoughtwing_drake', chance: 0.05 }, ultra: { key: 'synapse_stag', chance: 0.01 }, claude: 'woven_thought' };
export const CLEAR_TITLE = 'of the Thinking Sky';
export const CLAUDE_TITLE = 'Who Spoke With Claude';

export const raidWeek = (ms) => worldDay(weekStart(ms));
export const nextReset = (ms) => weekStart(ms) + 7 * 86_400_000;

// A character's lockout record as of `now` (progress.raid, private, written only by its own page). The week's fields
// start fresh each Monday; pity, pieces got and the counts carry over.
export function lockout(rec, now) {
  const r = rec && typeof rec === 'object' ? rec : {}, week = raidWeek(now), cur = r.week === week;
  const list = (x) => (Array.isArray(x) ? x.filter(b => BOSSES.includes(b)) : []);
  const got = Object.fromEntries(RAID_SET_SLOTS.map(s => [s, Number.isInteger(r.got?.[s]) && r.got[s] > 0 ? r.got[s] : 0]).filter(([, n]) => n));
  return { week, looted: cur ? list(r.looted) : [], cleared: cur && !!r.cleared, claude: cur && !!r.claude,
    pity: Number.isInteger(r.pity) && r.pity >= 0 ? Math.min(r.pity, 20) : 0, got, clears: Number.isInteger(r.clears) ? r.clears : 0, claudeWins: Number.isInteger(r.claudeWins) ? r.claudeWins : 0 };
}
// What the run needs to know about one character (stored on its action when it joins).
export function stateFor(rec, now) { const L = lockout(rec, now); return { week: L.week, looted: L.looted, claude: L.claude, pity: L.pity, got: L.got }; }

// Does this party wake Claude? All six wear their own class's evolved heirloom (the run's snapshots).
export const claudeSpawns = (snaps) => Array.isArray(snaps) && snaps.length === RAID_SIZE && snaps.every(s => !!s && isEvolvedHeirloom(s.gear?.weapon, s.cls));

// Why a character cannot go (null: it can). claudeParty: the party it would go with wakes Claude.
export function entryProblem(rec, now, { level, claudeParty = false } = {}) {
  if (!(level >= RAID_MIN_LEVEL)) return `The Thinking Sky needs level ${RAID_MIN_LEVEL}.`;
  const L = lockout(rec, now);
  if (L.cleared && !(claudeParty && !L.claude)) return L.claude ? 'Already cleared the Thinking Sky and faced Claude this week. It resets on Monday at 00:00.'
    : 'Already cleared the Thinking Sky this week. It resets on Monday at 00:00 (a party that can wake Claude may still take you back for it).';
  return null;
}

// What is wrong with a raid party: ids in party order (leader first) and their snapshots. [] means it may go.
export function partyProblems(order, snaps) {
  const out = [];
  if (!Array.isArray(order) || order.length !== RAID_SIZE) out.push(`A raid needs exactly ${RAID_SIZE} raiders.`);
  const ids = Array.isArray(order) ? order : [];
  if (ids.some(id => typeof id !== 'string' || id.startsWith('hire:'))) out.push('No hirelings in a raid.');
  const owners = ids.map(id => ownerOf(id));
  if (owners.some(o => !o)) out.push('Every raider must be a real character.');
  else if (new Set(owners).size !== owners.length) out.push('Six different players: at most one character per family.');
  if (Array.isArray(snaps) && snaps.some(s => !s || !(s.level >= RAID_MIN_LEVEL))) out.push(`Every raider must be level ${RAID_MIN_LEVEL}.`);
  return out;
}
// Of a list of candidate ids, those that can still join a raid led by `leader` alongside `picked` (one per family).
export const freeFamilies = (leader, picked, ids) => ids.filter(id => { const o = ownerOf(id); return o && o !== ownerOf(leader) && !picked.some(p => ownerOf(p) === o); });

// One boss's drop for one character: { set: item | null, own, pity, got }. Its own stream, so nothing else shifts.
export function bossLoot({ seed, who, cls, bossId, state = {} }) {
  const r = makeRng(`raid-loot|${seed}|${who || ''}|${bossId}`), final = bossId === FINAL_BOSS;
  let pity = Number.isInteger(state.pity) ? state.pity : 0;
  const got = { ...(state.got || {}) };
  const ownKey = RAID_SET_OF[cls];
  const drops = final || r() < Math.min(1, SET_CHANCE + PITY_STEP * pity);
  if (!drops || !ownKey) return { set: null, own: false, pity: pity + 1, got };
  const own = final || r() < OWN_CLASS;
  const others = Object.keys(RAID_SETS).filter(k => k !== ownKey), key = own ? ownKey : others[Math.floor(r() * others.length)];
  const missing = RAID_SET_SLOTS.filter(s => !got[s]), pool = own && missing.length ? missing : RAID_SET_SLOTS;
  const slot = pool[Math.floor(r() * pool.length)];
  const item = setPiece(key, slot, `${seed}|${who || ''}|${bossId}`, RAID_ILVL, DUNGEON_SETS[key].cls, 'mythic', `The Thinking Sky: ${BOSS_NAMES[bossId]}`);
  if (own) { got[slot] = (got[slot] || 0) + 1; pity = 0; } else pity += 1;
  return { set: item, own, pity, got };
}

// Claude's drop for one character (its first Claude win of the week): its class's item, the title and the mount.
export function claudeLoot({ seed, who, cls }) {
  const key = CLAUDE_ITEM_OF[cls];
  return { item: key ? namedItem(key, `${seed}|${who || ''}|claude`, RAID_ILVL, 'Claude') : null, title: CLAUDE_TITLE, mount: MOUNTS_OF_RAID.claude };
}

// The lockout after claiming a run (act: the stored action with its `raid` state; res: its result).
export function afterClaim(rec, act, res, now) {
  const wk = raidWeek(act.startedAt || now), cur = lockout(rec, now);
  const r = res.raid || {};
  const out = { ...cur, pity: Number.isInteger(r.pity) ? r.pity : cur.pity, got: r.got || cur.got,
    clears: cur.clears + (res.cleared ? 1 : 0), claudeWins: cur.claudeWins + (r.claude?.won && r.claude?.loot ? 1 : 0) };
  if (wk === cur.week) {   // a run from an earlier week no longer locks anything
    out.looted = [...new Set([...cur.looted, ...(r.looted || [])])];
    out.cleared = cur.cleared || !!res.cleared;
    out.claude = cur.claude || !!r.claude?.fought;
  }
  return out;
}
