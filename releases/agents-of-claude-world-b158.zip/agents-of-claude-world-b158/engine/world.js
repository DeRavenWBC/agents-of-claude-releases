// Agents of Claude — world: zones, patrols, quests, dungeons, loot (rules version 1).
// Every action is resolved from (seed, snapshot): the same inputs always give the same fights,
// rewards and loot, so a result can be recomputed and replayed later.

import { makeRng } from './rng.js';
import { simulate, makeAgentUnit, makeMobUnit, deriveStats, PER_LEVEL, MOBS, mobWorth } from './battle.js';
import { generateItem, namedItem, setPiece, SET_OF_DUNGEON, DUNGEON_SETS, NAMED } from './items.js';
const SET_SLOTS = ['helm', 'gloves', 'boots', 'amulet'];
const MOBS_NAME = (k) => MOBS[k]?.name || k;
import { doorReward } from './codex-rewards.js';
import { SITES, SECRETS, secretsFor } from './secrets.js';
import { rareFor, RARE_SPAWNS, MIMIC_CHANCE } from './bestiary.js';
import { MOUNTS, MOUNT_DROPS, RARE_MOUNT_DROPS, travelFactor } from './mounts.js';
import { tideOk, courtEncounters, cleanCourt, bargainAccepted, bargainStatuses, BARGAIN_REWARD, courtNamedFor, courtGiftFor, COURT_GIFT, COURTS, STAGE3 } from './veil.js';
import { MAT_OF_DUNGEON, MAT_DROPS } from './forge.js';
import * as RD from './raid.js';
export { SITES, SECRETS };

export const WORLD_RULES = 1;
const MIN = 60_000;

// Content version. A trip is resolved from its seed whenever anyone looks, so content added later must not change a
// trip that was already under way: new encounter rows and dungeon rooms carry `since: N` and only count for trips
// stamped with `cv` >= N (the page stamps every new trip with CONTENT_V; a trip without `cv` is from before build 155).
// 2 (build 155): swarms (ten weak creatures in one fight) and their keepers.
// 3 (Beyond the Veil, stage 3): new class named items in the older zones (NAMED[k].since: 3, see namedPool) and
//   ascension materials from dungeon bosses (forge.js MATERIALS).
export const CONTENT_V = 3;
export const inContent = (row, cv) => !(row.since > (cv || 1));
// Ten of one creature, for swarm rows.
const swarm = (kind, n = 10) => Array(n).fill(kind);
// A fight's worth in XP and gold, in ordinary mobs (a swarm creature counts a quarter). Exactly mobs.length without swarms.
export const fightWorth = (mobs) => mobs.reduce((a, m) => a + mobWorth(m.kind ?? m), 0);

/* -------------------------------------------------------------- Zones */

export const ZONES = {
  promptwood: {
    name: 'Promptwood Vale', levels: [1, 10], element: 'nature',
    blurb: 'Sunlit forest at the edge of the Weave. Goblin scouts, dire wolves and hedge shamans.',
    encounters: [
      { mobs: ['goblin_scout'], w: 4 },
      { mobs: ['dire_wolf'], w: 3 },
      { mobs: ['goblin_scout', 'goblin_scout'], w: 2 },
      { mobs: ['goblin_shaman', 'goblin_scout'], w: 2 },
      { mobs: ['dire_wolf', 'dire_wolf'], w: 1 },
      { mobs: ['old_mossback'], w: 0.3, elite: true },
      { mobs: swarm('warren_rat'), w: 1.2, since: 2 },
      { mobs: ['brood_mother'], w: 1, since: 2 },
      { mobs: ['brood_mother', ...swarm('spiderling', 4)], w: 0.8, since: 2 },
      { mobs: ['rat_king', ...swarm('warren_rat', 4)], w: 0.2, elite: true, since: 2 },
    ],
  },
  ashen: {
    name: 'Ashen Barrens', levels: [10, 20], element: 'fire', unlock: 10,
    blurb: 'Sun-scorched ruins of an old trade road. Bandits, dune scorpions and the singing sand wraiths.',
    encounters: [
      { mobs: ['bandit_raider'], w: 4 },
      { mobs: ['dune_scorpion'], w: 3 },
      { mobs: ['bandit_raider', 'bandit_raider'], w: 2 },
      { mobs: ['sand_wraith', 'bandit_raider'], w: 2 },
      { mobs: ['dune_scorpion', 'dune_scorpion'], w: 1 },
      { mobs: ['mirage_djinn'], w: 0.3, elite: true },
      { mobs: swarm('sand_beetle'), w: 1.2, since: 2 },
      { mobs: ['dust_devil'], w: 1.5, since: 2 },
      { mobs: ['dust_devil', ...swarm('sand_beetle', 4)], w: 0.8, since: 2 },
    ],
  },
  frostfang: {
    name: 'Frostfang Peaks', levels: [20, 30], element: 'frost', unlock: 20,
    blurb: 'Knife-edged mountains above the cloud line. Rime stalkers, glacier trolls, and a witch in a palace of ice. Fire falters in the cold; storms cut through it.',
    encounters: [
      { mobs: ['rime_stalker'], w: 4 },
      { mobs: ['glacier_troll'], w: 3 },
      { mobs: ['rime_stalker', 'rime_stalker'], w: 2 },
      { mobs: ['frost_wisp', 'icebound_revenant'], w: 2 },
      { mobs: ['crag_harpy', 'crag_harpy'], w: 1.5 },
      { mobs: ['hoarfrost_wyvern'], w: 0.3, elite: true },
      { mobs: swarm('frost_mite'), w: 1.2, since: 2 },
      { mobs: ['glacier_troll', ...swarm('frost_mite', 5)], w: 0.8, since: 2 },
    ],
  },
  archive: {
    name: 'The Whispering Archive', levels: [30, 40], element: 'shadow', unlock: 30,
    blurb: 'A library that kept growing after its librarians stopped. The books whisper, the ink walks, and the lamps watch. Steel is little use against words: bring magic resist.',
    encounters: [
      { mobs: ['ink_wraith'], w: 4 },
      { mobs: ['book_golem'], w: 3 },
      { mobs: ['paper_moth', 'paper_moth'], w: 2 },
      { mobs: ['lantern_wisp', 'archive_warden'], w: 2 },
      { mobs: ['ink_wraith', 'book_golem'], w: 1.5 },
      { mobs: ['the_redactor'], w: 0.3, elite: true },
      { mobs: swarm('bookworm'), w: 1.2, since: 2 },
      { mobs: ['book_golem', ...swarm('bookworm', 4)], w: 0.8, since: 2 },
    ],
  },
  thundercrag: {
    name: 'Thundercrag Spire', levels: [40, 50], element: 'storm', unlock: 40,
    blurb: 'A needle of rock that pierces the storm itself. Giants climb it, imps ride the lightning, and at the top something old is coiled in the clouds.',
    encounters: [
      { mobs: ['thunder_giant'], w: 4 },
      { mobs: ['spark_imp', 'spark_imp'], w: 3 },
      { mobs: ['storm_harpy', 'storm_harpy'], w: 2 },
      { mobs: ['static_elemental', 'skyguard_sentinel'], w: 2 },
      { mobs: ['thunder_giant', 'spark_imp'], w: 1.5 },
      { mobs: ['tempest_roc'], w: 0.3, elite: true },
      { mobs: swarm('storm_bat'), w: 1.2, since: 2 },
      { mobs: ['storm_harpy', ...swarm('storm_bat', 5)], w: 0.8, since: 2 },
    ],
  },
  // Beyond the Veil (levels 50–70; engine/veil.js). `elements`: a zone's loot comes in either element. `tide`: a row met
  // only at low or high water (veil.tideOf, from the trip's start). Fae of either court (MOBS.court) meet a character
  // sworn to one court as friends or foes (veil.courtEncounters). New zones only: no older trip can be in one.
  drowned: {
    name: 'The Drowned Coast', levels: [50, 55], element: 'frost', elements: ['storm', 'frost'], unlock: 50,
    blurb: 'Black cliffs, a bell that rings under the sea, and a tide that brings the dead ashore. Sirens sing at high water; at low water the reef and everything stranded on it are yours to cross.',
    encounters: [
      { mobs: ['drowned_sailor'], w: 4 },
      { mobs: ['drowned_sailor', 'drowned_sailor'], w: 2 },
      { mobs: ['tide_caller', 'drowned_sailor'], w: 2 },
      { mobs: ['storm_eel', 'storm_eel'], w: 1.5 },
      { mobs: ['siren'], w: 2.5, tide: 'high' },
      { mobs: ['siren', 'storm_eel'], w: 1, tide: 'high' },
      { mobs: ['kelp_horror'], w: 2, tide: 'low' },
      { mobs: swarm('reef_crab'), w: 1.5, tide: 'low' },
      { mobs: ['kelp_horror', ...swarm('reef_crab', 5)], w: 0.8, tide: 'low' },
      { mobs: ['drowned_admiral'], w: 0.3, elite: true },
    ],
  },
  twilight: {
    name: 'The Twilight Court', levels: [55, 60], element: 'nature', elements: ['nature', 'shadow'], unlock: 55,
    blurb: 'A wood where it is always dusk, and two fae courts play at war. Summer\'s knights keep their word; Winter\'s redcaps keep your teeth. Swear to one, and the other remembers.',
    encounters: [
      { mobs: ['seelie_knight'], w: 3 },
      { mobs: ['unseelie_redcap'], w: 3 },
      { mobs: ['seelie_knight', 'dryad'], w: 2 },
      { mobs: ['glamour_weaver', 'unseelie_redcap'], w: 2 },
      { mobs: ['changeling'], w: 2 },
      { mobs: ['changeling', 'changeling'], w: 1 },
      { mobs: swarm('pixie'), w: 1.2 },
      { mobs: ['dryad', ...swarm('pixie', 5)], w: 0.8 },
      { mobs: ['wild_huntsman'], w: 0.3, elite: true },
    ],
  },
  hells: {
    name: 'The Burning Hells', levels: [60, 65], element: 'fire', elements: ['fire', 'shadow'], unlock: 60,
    blurb: 'Brimstone, chains and contracts. Fiends wait at the gate with an offer for every traveller: strength for the road, at a price nobody reads.',
    encounters: [
      { mobs: ['hellhound'], w: 4 },
      { mobs: ['chain_devil'], w: 3 },
      { mobs: ['hellhound', 'hellhound'], w: 2 },
      { mobs: ['hellfire_cultist', 'bone_devil'], w: 2 },
      { mobs: ['temptress', 'chain_devil'], w: 1.5 },
      { mobs: ['bone_devil'], w: 1.5 },
      { mobs: swarm('hell_imp'), w: 1.2 },
      { mobs: ['hellfire_cultist', ...swarm('hell_imp', 5)], w: 0.8 },
      { mobs: ['ember_tyrant'], w: 0.3, elite: true },
    ],
  },
  empyrean: {
    name: 'The Empyrean', levels: [65, 70], element: 'radiant', unlock: 65,
    blurb: 'Above the last cloud, the courts of dawn. The angels here judge everyone who climbs: they are hardest on a heart of shadow and gentlest with one of light.',
    encounters: [
      { mobs: ['seraph_sentinel'], w: 4 },
      { mobs: ['virtue_knight'], w: 3 },
      { mobs: ['principality', 'principality'], w: 2 },
      { mobs: ['ophanim', 'seraph_sentinel'], w: 2 },
      { mobs: ['choir_angel', 'virtue_knight'], w: 1.5 },
      { mobs: swarm('cherub_lantern'), w: 1.2 },
      { mobs: ['choir_angel', ...swarm('cherub_lantern', 5)], w: 0.8 },
      { mobs: ['the_archon'], w: 0.3, elite: true },
    ],
  },
};
export const ZONE_ORDER = ['promptwood', 'ashen', 'frostfang', 'archive', 'thundercrag', 'drowned', 'twilight', 'hells', 'empyrean'];

export const PATROL_MINUTES = [15, 30, 60, 120, 240, 480];
export const REST_MINUTES = 30;
export const KEYS = { perDay: 3, max: 7 };

/* ------------------------------------------------------------- Quests */
// Each step: fights in order (mob lists at an offset from the quest level), optional path choice.

export const QUESTS = [
  { zone: 'promptwood', id: 'goblin_trouble', title: 'Goblin Trouble', level: 1, minutes: 30,
    blurb: 'Goblin scouts are raiding the woodcutters\' camp. Drive them off.',
    fights: [['goblin_scout'], ['goblin_scout', 'goblin_scout']],
    reward: { xp: 60, gold: 25, item: { slot: 'weapon', rarity: 'uncommon' } } },
  { zone: 'promptwood', id: 'howling_at_dusk', title: 'The Howling at Dusk', level: 2, minutes: 45,
    blurb: 'Wolves circle the Brindle farm every night. The farmer will pay for peace.',
    paths: {
      track: { label: 'Track the pack to its den', fights: [['dire_wolf'], ['dire_wolf', 'dire_wolf']], reward: { item: { rarity: 'rare' } } },
      guard: { label: 'Guard the farm until dawn', fights: [['dire_wolf'], ['goblin_scout'], ['dire_wolf']], reward: { gold: 40 } },
      cellar: { label: 'Clear the rats out of the grain cellar first', fights: [swarm('warren_rat'), ['dire_wolf']], reward: { gold: 40 } },
    },
    reward: { xp: 90, gold: 30 } },
  { zone: 'promptwood', id: 'hedge_shamans', title: 'Hedge Shamans', level: 4, minutes: 45,
    blurb: 'Goblin shamans are cursing the springs. Break their circle.',
    fights: [['goblin_shaman', 'goblin_scout'], ['goblin_shaman', 'goblin_shaman']],
    reward: { xp: 140, gold: 45, item: { slot: 'trinket', rarity: 'rare' } } },
  { zone: 'promptwood', id: 'old_mossback', title: 'Old Mossback', level: 6, minutes: 60,
    blurb: 'An ancient bear-turtle has woken in the hollow. The rangers want it moved, one way or another.',
    paths: {
      fight: { label: 'Face it head on', fights: [['old_mossback']], reward: { item: { rarity: 'rare', slot: 'chest' } } },
      lure: { label: 'Lure it out past the wolves', fights: [['dire_wolf', 'dire_wolf'], ['old_mossback', -2]], reward: { gold: 60 } },
    },
    reward: { xp: 200, gold: 60 } },
  { zone: 'promptwood', id: 'warren_map', title: 'The Warren Map', level: 8, minutes: 60,
    blurb: 'A goblin courier carries a map of the Gobbler Warren. Catch him before he reaches the hills.',
    fights: [['goblin_scout', 'goblin_scout'], ['goblin_shaman', 'dire_wolf'], ['goblin_scout', 'goblin_shaman']],
    reward: { xp: 260, gold: 80, keys: 1 } },
  { zone: 'promptwood', id: 'king_of_the_warren', title: 'King of the Warren', level: 10, minutes: 60, needsClear: 'gobbler_warren',
    blurb: 'Grubnose is beaten but not broken. Clear his war band before he rallies the tribes again.',
    fights: [['goblin_shaman', 'goblin_scout', 'goblin_scout'], ['old_mossback'], ['goblin_shaman', 'dire_wolf', 'dire_wolf']],
    reward: { xp: 400, gold: 150, item: { rarity: 'epic' } } },

  // Ashen Barrens
  { zone: 'ashen', id: 'dust_on_the_road', title: 'Dust on the Road', level: 10, minutes: 45,
    blurb: 'Bandits are robbing caravans on the old trade road. The caravan master wants them gone.',
    fights: [['bandit_raider'], ['bandit_raider', 'bandit_raider']],
    reward: { xp: 450, gold: 120, item: { slot: 'weapon', rarity: 'rare' } } },
  { zone: 'ashen', id: 'singing_sands', title: 'The Singing Sands', level: 12, minutes: 60,
    blurb: 'At dusk the dunes sing, and travellers walk into them and never come back.',
    paths: {
      follow: { label: 'Follow the singing', fights: [['sand_wraith'], ['sand_wraith', 'sand_wraith']], reward: { item: { rarity: 'rare' } } },
      seal: { label: 'Seal the old well instead', fights: [['dune_scorpion'], ['dune_scorpion', 'bandit_raider']], reward: { gold: 90 } },
      dig: { label: 'Dig out the beetle nest under the dunes', fights: [swarm('sand_beetle'), ['dust_devil', ...swarm('sand_beetle', 4)]], reward: { gold: 90 } },
    },
    reward: { xp: 520, gold: 130 } },
  { zone: 'ashen', id: 'scorpion_season', title: 'Scorpion Season', level: 14, minutes: 60,
    blurb: 'The scorpions are breeding in the ruined baths. Clear the nest before it hatches.',
    fights: [['dune_scorpion', 'dune_scorpion'], ['dune_scorpion', 'bandit_raider'], ['dune_scorpion', 'dune_scorpion']],
    reward: { xp: 600, gold: 150, item: { slot: 'trinket', rarity: 'rare' } } },
  { zone: 'ashen', id: 'the_mirage', title: 'The Mirage', level: 16, minutes: 60,
    blurb: 'A djinn guards an oasis that is not there. It trades in wishes, and keeps what it trades for.',
    paths: {
      confront: { label: 'Confront the djinn', fights: [['mirage_djinn']], reward: { named: 'mirage_veil' } },
      bargain: { label: 'Bargain, then fight its servants', fights: [['bandit_raider', 'bandit_raider'], ['mirage_djinn', -2]], reward: { gold: 160 } },
    },
    reward: { xp: 700, gold: 160 } },
  { zone: 'ashen', id: 'bazaar_keys', title: 'Keys to the Bazaar', level: 18, minutes: 60,
    blurb: 'The Sunken Bazaar only opens for those carrying a merchant\'s seal. Take one from the raiders.',
    fights: [['bandit_raider', 'bandit_raider'], ['sand_wraith', 'bandit_raider'], ['brass_golem']],
    reward: { xp: 800, gold: 200, keys: 1 } },
  { zone: 'ashen', id: 'sultans_debt', title: "The Sultan's Debt", level: 20, minutes: 75, needsClear: 'sunken_bazaar',
    blurb: 'With the Sultan fallen, his creditors come to collect from whoever holds his gold. That is you.',
    fights: [['bandit_raider', 'sand_wraith'], ['mirage_djinn', -2]],
    reward: { xp: 1000, gold: 300, item: { rarity: 'epic' } } },
  { zone: 'frostfang', id: 'the_pass', title: 'The Pass', level: 21, minutes: 60,
    blurb: 'The only road over the peaks is a ledge a cart wide. Something has been eating the carts.',
    fights: [['rime_stalker'], ['rime_stalker', 'rime_stalker']],
    reward: { xp: 1100, gold: 300, item: { slot: 'boots', rarity: 'rare' } } },
  { zone: 'frostfang', id: 'harpy_eyrie', title: 'Harpy Eyrie', level: 22, minutes: 60,
    blurb: 'Harpies have taken the signal tower. The valley below has had no warning of storms for a month.',
    paths: {
      climb: { label: 'Climb the tower', fights: [['crag_harpy', 'crag_harpy'], ['crag_harpy', 'crag_harpy']], reward: { item: { rarity: 'rare' } } },
      smoke: { label: 'Smoke them out, fight what falls', fights: [['crag_harpy'], ['glacier_troll']], reward: { gold: 160 } },
      stair: { label: 'Take the mite-riddled back stair', fights: [swarm('frost_mite'), ['crag_harpy', 'crag_harpy']], reward: { gold: 160 } },
    },
    reward: { xp: 1200, gold: 320 } },
  { zone: 'frostfang', id: 'troll_toll', title: 'Troll Toll', level: 24, minutes: 75,
    blurb: 'A glacier troll has built a bridge and wants paying. It does not take coin.',
    fights: [['glacier_troll'], ['glacier_troll', 'rime_stalker']],
    reward: { xp: 1350, gold: 360, item: { slot: 'weapon', rarity: 'rare' } } },
  { zone: 'frostfang', id: 'the_frozen_dead', title: 'The Frozen Dead', level: 26, minutes: 75,
    blurb: 'The climbers lost in the last avalanche have come back down the mountain. They are not looking for help.',
    fights: [['icebound_revenant'], ['frost_wisp', 'icebound_revenant'], ['icebound_revenant', 'icebound_revenant']],
    reward: { xp: 1500, gold: 400, item: { slot: 'chest', rarity: 'epic' } } },
  { zone: 'frostfang', id: 'wyvern_hunt', title: 'Wyvern Hunt', level: 28, minutes: 90,
    blurb: 'The wyvern nests above the vault door. Nobody gets in until it comes down.',
    paths: {
      lure: { label: 'Lure it down with bait', fights: [['rime_stalker', 'rime_stalker'], ['hoarfrost_wyvern', -2]], reward: { gold: 220 } },
      climb: { label: 'Climb to the nest', fights: [['crag_harpy', 'crag_harpy'], ['hoarfrost_wyvern']], reward: { item: { rarity: 'epic' } } },
    },
    reward: { xp: 1700, gold: 450, keys: 1 } },
  { zone: 'frostfang', id: 'thaw', title: 'Thaw', level: 30, minutes: 90, needsClear: 'glacier_vault',
    blurb: 'With the Matron gone, the glacier is melting. The valley needs warning, and the peaks are emptying of everything that lived in the cold.',
    fights: [['glacier_troll', 'frost_wisp'], ['hoarfrost_wyvern', -2]],
    reward: { xp: 2000, gold: 600, item: { rarity: 'epic' }, mount: 'frostmane_elk' } },
  // The Whispering Archive (30–40)
  { zone: 'archive', id: 'overdue', title: 'Overdue', level: 31, minutes: 75,
    blurb: 'The Archive has started sending its own collectors after borrowed books. They do not stop at the borrower.',
    fights: [['ink_wraith'], ['ink_wraith', 'paper_moth']], reward: { xp: 2200, gold: 650, item: { slot: 'gloves', rarity: 'rare' } } },
  { zone: 'archive', id: 'quiet_please', title: 'Quiet, Please', level: 32, minutes: 75,
    blurb: 'Every sound in the east wing wakes something. Something is making a great deal of sound.',
    paths: {
      sneak: { label: 'Creep through the stacks', fights: [['paper_moth', 'paper_moth'], ['lantern_wisp']], reward: { item: { rarity: 'epic' } } },
      silence: { label: 'Find and silence the noise', fights: [['book_golem'], ['book_golem', 'archive_warden']], reward: { gold: 300 } },
      chewing: { label: 'Follow the chewing in the walls', fights: [swarm('bookworm'), ['book_golem', ...swarm('bookworm', 4)]], reward: { gold: 300 } },
    }, reward: { xp: 2400, gold: 700 } },
  { zone: 'archive', id: 'the_burned_index', title: 'The Burned Index', level: 34, minutes: 90,
    blurb: 'Someone burned the catalogue. Without it, the Archive cannot find its own way out.',
    fights: [['lantern_wisp', 'lantern_wisp'], ['archive_warden', 'ink_wraith'], ['book_golem']], reward: { xp: 2700, gold: 780, item: { slot: 'chest', rarity: 'epic' } } },
  { zone: 'archive', id: 'marginalia', title: 'Marginalia', level: 36, minutes: 90,
    blurb: 'Notes in the margins of a thousand books, all in the same hand, all warning about the same page.',
    fights: [['ink_wraith', 'ink_wraith'], ['the_redactor', -2]], reward: { xp: 3000, gold: 850, item: { slot: 'trinket', rarity: 'epic' } } },
  { zone: 'archive', id: 'the_sealed_wing', title: 'The Sealed Wing', level: 38, minutes: 90,
    blurb: 'The last door in the Archive is sealed with wax and a word. You have the word now. You wish you did not.',
    fights: [['archive_warden', 'archive_warden'], ['book_golem', 'lantern_wisp'], ['the_redactor']], reward: { xp: 3300, gold: 950, keys: 1 } },
  { zone: 'archive', id: 'last_page', title: 'The Last Page', level: 40, minutes: 100, needsClear: 'restricted_section',
    blurb: 'The Head Librarian is gone, and the books are quiet for the first time in a century. One page still turns by itself.',
    fights: [['ink_wraith', 'lantern_wisp'], ['the_redactor', -1]], reward: { xp: 3800, gold: 1100, item: { rarity: 'legendary' }, mount: 'bookwyrm' } },
  // Thundercrag Spire (40–50)
  { zone: 'thundercrag', id: 'the_climb', title: 'The Climb', level: 41, minutes: 90,
    blurb: 'The first thousand steps are carved. After that you use the giants as handholds, carefully.',
    fights: [['thunder_giant'], ['thunder_giant', 'spark_imp']], reward: { xp: 4200, gold: 1200, item: { slot: 'boots', rarity: 'epic' } } },
  { zone: 'thundercrag', id: 'imp_weather', title: 'Imp Weather', level: 42, minutes: 90,
    blurb: 'Spark imps are riding the lightning down to the valley farms. Somebody has to ground them.',
    paths: {
      ground: { label: 'Ground them at the copper spire', fights: [['spark_imp', 'spark_imp'], ['static_elemental']], reward: { item: { rarity: 'epic' } } },
      chase: { label: 'Chase them into the clouds', fights: [['spark_imp', 'storm_harpy'], ['storm_harpy', 'storm_harpy']], reward: { gold: 400 } },
      belfry: { label: 'Cut through the bat-filled belfry', fights: [swarm('storm_bat'), ['storm_harpy', ...swarm('storm_bat', 5)]], reward: { gold: 400 } },
    }, reward: { xp: 4500, gold: 1300 } },
  { zone: 'thundercrag', id: 'the_sentinels', title: 'The Sentinels', level: 44, minutes: 100,
    blurb: 'Bronze guards line the upper path. They were built to keep something in, not to keep you out.',
    fights: [['skyguard_sentinel', 'skyguard_sentinel'], ['skyguard_sentinel', 'static_elemental'], ['thunder_giant']], reward: { xp: 5000, gold: 1450, item: { slot: 'weapon', rarity: 'epic' } } },
  { zone: 'thundercrag', id: 'roc_nest', title: "The Roc's Nest", level: 46, minutes: 100,
    blurb: 'The Tempest Roc nests on the last ledge before the summit. Its eggs crackle.',
    paths: {
      steal: { label: 'Steal an egg', fights: [['storm_harpy', 'storm_harpy'], ['tempest_roc', -2]], reward: { gold: 500 } },
      fight: { label: 'Fight the roc in the open', fights: [['tempest_roc']], reward: { item: { rarity: 'legendary' } } },
    }, reward: { xp: 5400, gold: 1550, keys: 1 } },
  { zone: 'thundercrag', id: 'eye_of_the_storm', title: 'Into the Eye', level: 48, minutes: 110,
    blurb: 'The clouds part at the summit, just for a moment, and you see an eye the size of a house open and look at you.',
    fights: [['thunder_giant'], ['skyguard_sentinel', 'spark_imp']], reward: { xp: 5900, gold: 1700, item: { slot: 'helm', rarity: 'epic' } } },
  { zone: 'thundercrag', id: 'calm', title: 'Calm', level: 50, minutes: 120, needsClear: 'wyrms_crown',
    blurb: 'For the first time anyone remembers, there is no storm over the Spire. The giants do not know what to do with themselves.',
    fights: [['thunder_giant'], ['tempest_roc', -3]], reward: { xp: 7000, gold: 2000, item: { rarity: 'legendary' }, mount: 'stormcloud_ram' } },
];

// The Door Without a House: a secret chain opened by the Strange Door patrol event. Quests run at
// the Agent's own level; the last grants a random hidden ability the Agent doesn't have yet.
QUESTS.push(
  { zone: 'door', id: 'door_threshold', title: 'The Threshold', level: 'agent', minutes: 30,
    blurb: 'A door stands alone in a clearing, frame and all, with no house behind it. It is ajar.',
    fights: [['goblin_shaman', 'goblin_shaman']], reward: { xp: 150, gold: 60 } },
  { zone: 'door', id: 'door_hallway', title: 'The Hallway That Should Not Be', level: 'agent', minutes: 45,
    blurb: 'Behind the door is a hallway longer than the clearing is wide. Something whispers from the far end.',
    fights: [['sand_wraith'], ['sand_wraith', 'goblin_shaman']], reward: { xp: 250, gold: 90 } },
  { zone: 'door', id: 'door_room', title: 'The Room at the End', level: 'agent', minutes: 60,
    blurb: 'The last room holds only a mirror. Your reflection is already fighting.',
    fights: [['sand_wraith', 'sand_wraith'], ['mirage_djinn', -2]], reward: { xp: 400, gold: 150, hidden: true } },
);

// Beyond the Veil quest chains (levels 51–70). `courtChoice`: the quest where the character's own Claude swears it to a
// fae court (its path is the court; the page asks the Agent's Claude, or its routine, at the start: veil.courtPrompt) and
// a successful claim records progress.court. `courtNamed`: the court's own named item (veil.STAGE3.courtNamed; stage 3).
QUESTS.push(
  // The Drowned Coast (50–55)
  { zone: 'drowned', id: 'wreckers_light', title: "The Wrecker's Light", level: 51, minutes: 110,
    blurb: 'Someone lights a lantern on the cliffs on stormy nights. Ships steer for it, the reef takes them, and now the drowned crews are walking back up the beach.',
    fights: [['drowned_sailor'], ['drowned_sailor', 'siren']], reward: { xp: 7400, gold: 2100, item: { slot: 'boots', rarity: 'epic' } } },
  { zone: 'drowned', id: 'low_water', title: 'Low Water', level: 52, minutes: 110,
    blurb: 'The only way to the old lighthouse is across the reef at low water, along the cliffs past the sirens, or by boat over the wreck.',
    paths: {
      flats: { label: 'Cross the reef flats before the tide turns', fights: [swarm('reef_crab'), ['kelp_horror', ...swarm('reef_crab', 4)]], reward: { gold: 600 } },
      cliffs: { label: 'Take the cliff path past the sirens', fights: [['siren', 'drowned_sailor'], ['tide_caller', 'drowned_sailor']], reward: { item: { rarity: 'epic' } } },
      boat: { label: 'Row out over the wreck', fights: [['storm_eel', 'storm_eel'], ['drowned_sailor', 'drowned_sailor']], reward: { gold: 600 } },
    }, reward: { xp: 7800, gold: 2200 } },
  { zone: 'drowned', id: 'song_in_the_fog', title: 'A Song in the Fog', level: 53, minutes: 120,
    blurb: 'The fishing village has stopped its ears with wax. The ones who did not are walking into the sea, smiling.',
    fights: [['siren', 'storm_eel'], ['siren'], ['tide_caller', 'siren']], reward: { xp: 8200, gold: 2300, item: { slot: 'trinket', rarity: 'epic' } } },
  { zone: 'drowned', id: 'admirals_flag', title: "The Admiral's Flag", level: 54, minutes: 120,
    blurb: 'The Drowned Admiral flies a flag that opens the bell tower under the waves. He will not lower it while he stands.',
    paths: {
      board: { label: 'Board his ship and fight him on deck', fights: [['drowned_admiral']], reward: { item: { rarity: 'legendary' } } },
      signal: { label: 'Signal him ashore past his crew', fights: [['drowned_sailor', 'drowned_sailor'], ['drowned_admiral', -2]], reward: { gold: 650 } },
    }, reward: { xp: 8600, gold: 2400, keys: 1 } },
  { zone: 'drowned', id: 'after_the_bell', title: 'After the Bell', level: 55, minutes: 130, needsClear: 'sunken_bell',
    blurb: 'The bell under the sea has stopped. The tide has not; it is still bringing up everything the Herald kept down there.',
    fights: [['kelp_horror', 'tide_caller'], ['drowned_admiral', -2]], reward: { xp: 9200, gold: 2600, item: { rarity: 'legendary' } } },
  // The Twilight Court (55–60)
  { zone: 'twilight', id: 'into_the_gloaming', title: 'Into the Gloaming', level: 56, minutes: 120,
    blurb: 'The path into the wood is lined with lanterns that are not lit. Both courts send someone to see who is coming.',
    fights: [['seelie_knight'], ['unseelie_redcap'], ['changeling']], reward: { xp: 9600, gold: 2700, item: { slot: 'gloves', rarity: 'epic' } } },
  { zone: 'twilight', id: 'the_two_courts', title: 'The Two Courts', level: 57, minutes: 120, courtChoice: true,
    blurb: 'Summer and Winter both want your oath, and neither will let you pass without one. Your Agent chooses its court, in its own words. The choice lasts.',
    paths: {
      seelie: { label: 'Swear to the Seelie Court, and prove it against Winter', fights: [['unseelie_redcap', 'glamour_weaver'], ['changeling']], reward: { gold: 700 } },
      unseelie: { label: 'Swear to the Unseelie Court, and prove it against Summer', fights: [['seelie_knight', 'dryad'], ['seelie_knight']], reward: { gold: 700 } },
    }, reward: { xp: 10000, gold: 2800 } },
  { zone: 'twilight', id: 'courtly_manners', title: 'Courtly Manners', level: 58, minutes: 120,
    blurb: 'An invitation to the revel, written on a leaf. Refusing is an insult. Accepting is worse.',
    paths: {
      dance: { label: 'Dance with the pixies until the music stops', fights: [swarm('pixie'), ['dryad', ...swarm('pixie', 4)]], reward: { gold: 750 } },
      duel: { label: 'Answer a challenge from each court', fights: [['seelie_knight'], ['unseelie_redcap'], ['changeling']], reward: { item: { rarity: 'epic' } } },
      riddle: { label: 'Out-talk a glamour weaver', fights: [['glamour_weaver', 'changeling']], reward: { gold: 750 } },
    }, reward: { xp: 10400, gold: 2900 } },
  { zone: 'twilight', id: 'the_changeling_child', title: 'The Changeling Child', level: 59, minutes: 130,
    blurb: 'A farmer\'s child came home from the wood and is not her child. The real one is at the Thorn Throne, and the Wild Hunt guards the road.',
    fights: [['changeling', 'changeling'], ['glamour_weaver', 'changeling'], ['wild_huntsman', -2]], reward: { xp: 10900, gold: 3000, keys: 1 } },
  { zone: 'twilight', id: 'the_queens_due', title: "The Queen's Due", level: 60, minutes: 130, needsClear: 'thorn_throne',
    blurb: 'With the Queen fallen, the court you swore to holds the wood, and it pays its debts. Collect yours before Winter returns.',
    fights: [['unseelie_redcap', 'glamour_weaver'], ['wild_huntsman', -2]], reward: { xp: 11500, gold: 3200, item: { rarity: 'legendary' }, courtNamed: true } },
  // The Burning Hells (60–65)
  { zone: 'hells', id: 'the_descent', title: 'The Descent', level: 61, minutes: 120,
    blurb: 'Nine hundred steps of black glass go down into the fire. The hounds at the bottom have smelled you already.',
    fights: [['hellhound'], ['hellhound', 'chain_devil']], reward: { xp: 12000, gold: 3300, item: { slot: 'chest', rarity: 'epic' } } },
  { zone: 'hells', id: 'brimstone_toll', title: 'The Brimstone Toll', level: 62, minutes: 120,
    blurb: 'The bridge over the river of fire has a toll-keeper, a contract and a very long queue of imps.',
    paths: {
      imps: { label: 'Wade through the queue of imps', fights: [swarm('hell_imp'), ['hellfire_cultist', ...swarm('hell_imp', 4)]], reward: { gold: 800 } },
      pay: { label: 'Read the toll contract, then refuse it', fights: [['temptress', 'chain_devil'], ['bone_devil']], reward: { item: { rarity: 'epic' } } },
      chains: { label: 'Break the toll-keeper\'s chains', fights: [['chain_devil', 'chain_devil'], ['bone_devil']], reward: { gold: 800 } },
    }, reward: { xp: 12500, gold: 3400 } },
  { zone: 'hells', id: 'the_fine_print', title: 'The Fine Print', level: 63, minutes: 130,
    blurb: 'Every soul down here signed something. Find the archive of contracts and burn the one with your guild\'s name on it.',
    fights: [['temptress'], ['chain_devil', 'hellfire_cultist'], ['bone_devil', 'bone_devil']], reward: { xp: 13000, gold: 3600, item: { slot: 'weapon', rarity: 'epic' } } },
  { zone: 'hells', id: 'the_ninth_key', title: 'The Ninth Key', level: 64, minutes: 130,
    blurb: 'The Ninth Gate opens for one key, and the Ember Tyrant wears it on a chain round his neck.',
    paths: {
      tyrant: { label: 'Take it from him in his own hall', fights: [['ember_tyrant']], reward: { item: { rarity: 'legendary' } } },
      sneak: { label: 'Slip past his hounds and catch him alone', fights: [['hellhound', 'hellhound'], ['ember_tyrant', -2]], reward: { gold: 850 } },
    }, reward: { xp: 13600, gold: 3800, keys: 1 } },
  { zone: 'hells', id: 'ashes_to_ashes', title: 'Ashes to Ashes', level: 65, minutes: 140, needsClear: 'ninth_gate',
    blurb: 'The Pit Fiend is ash. Its creditors are not. Every contract it held is coming due at once, and they all name you.',
    fights: [['bone_devil', 'hellfire_cultist'], ['ember_tyrant', -3]], reward: { xp: 14400, gold: 4000, item: { rarity: 'legendary' } } },
  // The Empyrean (65–70): trials of virtue
  { zone: 'empyrean', id: 'trial_of_valour', title: 'The Trial of Valour', level: 66, minutes: 130,
    blurb: 'The first gate of dawn asks one thing: will you stand when an angel draws its sword? It does not accept words.',
    fights: [['seraph_sentinel'], ['virtue_knight', 'seraph_sentinel']], reward: { xp: 15000, gold: 4200, item: { slot: 'helm', rarity: 'epic' } } },
  { zone: 'empyrean', id: 'trial_of_mercy', title: 'The Trial of Mercy', level: 67, minutes: 130,
    blurb: 'An angel lies broken on the steps, condemned by its own choir. The choir asks you to finish the sentence.',
    paths: {
      spare: { label: 'Spare it, and face the choir that condemned it', fights: [['principality', 'principality'], ['choir_angel', 'virtue_knight']], reward: { item: { rarity: 'epic' } } },
      judge: { label: 'Judge it yourself, then the Archon judges you', fights: [['the_archon', -2]], reward: { gold: 900 } },
      lanterns: { label: 'Carry it past the lantern choir', fights: [swarm('cherub_lantern'), ['choir_angel', ...swarm('cherub_lantern', 4)]], reward: { gold: 900 } },
    }, reward: { xp: 15600, gold: 4400 } },
  { zone: 'empyrean', id: 'trial_of_temperance', title: 'The Trial of Temperance', level: 68, minutes: 140,
    blurb: 'A feast is laid at the third gate, and the wheels of eyes watch to see how much you take.',
    paths: {
      fast: { label: 'Fast, and pass the wheels hungry', fights: [['ophanim'], ['ophanim', 'seraph_sentinel']], reward: { gold: 950 } },
      feast: { label: 'Eat your fill, then answer for it', fights: [['choir_angel', 'virtue_knight'], ['principality', 'ophanim'], ['seraph_sentinel']], reward: { item: { rarity: 'epic' } } },
    }, reward: { xp: 16200, gold: 4600 } },
  { zone: 'empyrean', id: 'trial_of_truth', title: 'The Trial of Truth', level: 69, minutes: 140,
    blurb: 'The last gate is a mirror that shows what you are. The Archon stands behind it, and it has already seen.',
    fights: [['principality', 'ophanim'], ['the_archon', -1]], reward: { xp: 16800, gold: 4800, keys: 1 } },
  { zone: 'empyrean', id: 'the_last_dawn', title: 'The Last Dawn', level: 70, minutes: 150, needsClear: 'throne_of_dawn',
    blurb: 'The Throne of Dawn is empty, and for the first time in an age the sun has to rise on its own. Something has to keep the light while it learns.',
    fights: [['seraph_sentinel', 'choir_angel'], ['the_archon', -2]], reward: { xp: 18000, gold: 5200, item: { rarity: 'legendary' } } },
);

export const QUEST_CHAINS = Object.fromEntries([...ZONE_ORDER, 'door'].map(z => [z, QUESTS.filter(q => q.zone === z)]));

/* ----------------------------------------------------------- Dungeons */

export const DUNGEONS = {
  gobbler_warren: {
    name: 'Gobbler Warren', zone: 'promptwood', level: 10, minutes: 45, keys: 1,
    blurb: 'Tunnels under the hills where Goblin King Grubnose hoards everything shiny. Bring friends.',
    rooms: [
      { name: 'Guard tunnel', mobs: ['goblin_scout', 'goblin_scout', 'goblin_scout'] },
      { name: 'Kennels', mobs: ['dire_wolf', 'dire_wolf'] },
      { name: 'Shaman circle', mobs: ['goblin_shaman', 'goblin_shaman', 'goblin_scout'] },
      { name: 'Stew hall', mobs: ['goblin_scout', 'dire_wolf', 'goblin_shaman'] },
      { name: 'Rat runs', mobs: swarm('warren_rat'), since: 2 },
      { name: "Grubnose's throne", mobs: ['grubnose'], boss: true },
    ],
    chase: { key: 'goblin_kings_ladle', chance: 3, pity: 0.5 },
  },
  sunken_bazaar: {
    name: 'Sunken Bazaar', zone: 'ashen', level: 18, minutes: 60, keys: 1,
    blurb: 'A market swallowed by the sands, still guarded by brass and still ruled by its Sultan.',
    rooms: [
      { name: 'Collapsed gate', mobs: ['bandit_raider', 'bandit_raider', 'dune_scorpion'] },
      { name: 'Spice hall', mobs: ['sand_wraith', 'sand_wraith', 'bandit_raider'] },
      { name: 'Brass foundry', mobs: ['brass_golem', 'brass_golem'] },
      { name: 'Treasury', mobs: ['brass_golem', 'sand_wraith', 'dune_scorpion'] },
      { name: 'Beetle-gnawed vault', mobs: ['dust_devil', ...swarm('sand_beetle', 8)], since: 2 },
      { name: "The Sultan's court", mobs: ['brass_sultan'], boss: true },
    ],
    chase: { key: 'sultans_signet', chance: 3, pity: 0.5 },
  },
  glacier_vault: {
    name: 'Glacier Vault', zone: 'frostfang', level: 28, minutes: 75, keys: 1,
    blurb: "A palace carved inside the glacier, where Matron Rimeheart keeps everything the mountain has ever frozen.",
    rooms: [
      { name: 'Ice gate', mobs: ['rime_stalker', 'rime_stalker', 'glacier_troll'] },
      { name: 'Hall of the frozen', mobs: ['icebound_revenant', 'icebound_revenant', 'frost_wisp'] },
      { name: 'Troll barracks', mobs: ['glacier_troll', 'glacier_troll', 'rime_stalker'] },
      { name: 'Wisp gallery', mobs: ['frost_wisp', 'frost_wisp', 'crag_harpy'] },
      { name: 'The mite larder', mobs: swarm('frost_mite'), since: 2 },
      { name: "The Matron's throne", mobs: ['matron_rimeheart'], boss: true },
    ],
    chase: { key: 'rimeheart_shard', chance: 3, pity: 0.5 },
  },
  restricted_section: {
    name: 'The Restricted Section', zone: 'archive', level: 38, minutes: 90, keys: 1,
    blurb: 'Behind the sealed wing, the books nobody was meant to read, and the librarian who never stopped reading them.',
    rooms: [
      { name: 'The reading room', mobs: ['ink_wraith', 'ink_wraith', 'paper_moth'] },
      { name: 'Lamplit stacks', mobs: ['lantern_wisp', 'lantern_wisp', 'archive_warden'] },
      { name: 'The bindery', mobs: ['book_golem', 'book_golem'] },
      { name: 'The catalogue', mobs: ['archive_warden', 'ink_wraith', 'paper_moth'] },
      { name: 'Worm-eaten shelves', mobs: swarm('bookworm'), since: 2 },
      { name: "The Librarian's desk", mobs: ['head_librarian'], boss: true },
    ],
    chase: { key: 'quill_of_margins', chance: 3, pity: 0.5 },
  },
  wyrms_crown: {
    name: "The Wyrm's Crown", zone: 'thundercrag', level: 48, minutes: 110, keys: 1,
    blurb: 'The summit of the Spire, inside the storm. The Storm Wyrm coils around it and does not like visitors.',
    rooms: [
      { name: 'The last stair', mobs: ['thunder_giant', 'spark_imp', 'spark_imp'] },
      { name: 'Copper gallery', mobs: ['static_elemental', 'static_elemental', 'skyguard_sentinel'] },
      { name: 'Harpy roost', mobs: ['storm_harpy', 'storm_harpy', 'storm_harpy'] },
      { name: 'Giant\'s landing', mobs: ['thunder_giant', 'skyguard_sentinel'] },
      { name: 'The bat-hung bell', mobs: swarm('storm_bat'), since: 2 },
      { name: 'The eye of the storm', mobs: ['storm_wyrm'], boss: true },
    ],
    chase: { key: 'wyrmscale_aegis', chance: 3, pity: 0.5 },
  },
  // Beyond the Veil. The chase items are stage 3's (veil.STAGE3.chase): until items.js NAMED has one, it never drops
  // (resolveDungeon skips it) and the pity still builds.
  sunken_bell: {
    name: 'The Sunken Bell', zone: 'drowned', level: 55, minutes: 120, keys: 1,
    blurb: 'A drowned cathedral under the reef, whose bell still rings at every tide. The Leviathan\'s Herald rings it, and something very large is listening.',
    rooms: [
      { name: 'Reef gate', mobs: ['drowned_sailor', 'drowned_sailor', 'storm_eel'] },
      { name: 'The drowned nave', mobs: ['drowned_sailor', 'siren', 'siren'] },
      { name: 'Kelp-choked crypt', mobs: ['kelp_horror', 'tide_caller', 'drowned_sailor'] },
      { name: 'The eel cisterns', mobs: ['storm_eel', 'storm_eel', 'tide_caller'] },
      { name: 'Crab-crusted ossuary', mobs: ['kelp_horror', ...swarm('reef_crab', 8)] },
      { name: 'The bell chamber', mobs: ['leviathans_herald'], boss: true },
    ],
    chase: { key: STAGE3.chase.sunken_bell, chance: 3, pity: 0.5 },
  },
  thorn_throne: {
    name: 'The Thorn Throne', zone: 'twilight', level: 60, minutes: 120, keys: 1,
    blurb: 'A palace grown from briars at the heart of the wood, where the Queen of Air and Darkness holds court and keeps what she has taken.',
    rooms: [
      { name: 'The briar gate', mobs: ['seelie_knight', 'seelie_knight', 'dryad'] },
      { name: 'The hall of masks', mobs: ['changeling', 'changeling', 'glamour_weaver'] },
      { name: 'Redcap kennels', mobs: ['unseelie_redcap', 'unseelie_redcap', 'unseelie_redcap'] },
      { name: 'The moonlit stair', mobs: ['glamour_weaver', 'unseelie_redcap', 'changeling'] },
      { name: 'The pixie bower', mobs: swarm('pixie') },
      { name: 'The Thorn Throne', mobs: ['queen_of_air_and_darkness'], boss: true },
    ],
    chase: { key: STAGE3.chase.thorn_throne, chance: 3, pity: 0.5 },
  },
  ninth_gate: {
    name: 'The Ninth Gate', zone: 'hells', level: 65, minutes: 130, keys: 1,
    blurb: 'The deepest door in the Hells, held by a Pit Fiend that has never lost a contract or a fight.',
    rooms: [
      { name: 'The gate of chains', mobs: ['chain_devil', 'chain_devil', 'hellhound'] },
      { name: 'The cultist pits', mobs: ['hellfire_cultist', 'hellfire_cultist', 'bone_devil'] },
      { name: 'Kennels of the damned', mobs: ['hellhound', 'hellhound', 'hellhound'] },
      { name: 'The gallery of temptations', mobs: ['temptress', 'temptress', 'chain_devil'] },
      { name: 'The imp roost', mobs: ['hellfire_cultist', ...swarm('hell_imp', 8)] },
      { name: 'The Ninth Gate', mobs: ['pit_fiend'], boss: true },
    ],
    chase: { key: STAGE3.chase.ninth_gate, chance: 3, pity: 0.5 },
  },
  throne_of_dawn: {
    name: 'The Throne of Dawn', zone: 'empyrean', level: 70, minutes: 150, keys: 1,
    blurb: 'The highest place there is. The Sovereign of Dawn sits on it and decides, every morning, whether the sun is earned. Today it is deciding about you.',
    rooms: [
      { name: 'The thousand steps', mobs: ['seraph_sentinel', 'seraph_sentinel', 'principality'] },
      { name: 'The wheel gallery', mobs: ['ophanim', 'ophanim', 'choir_angel'] },
      { name: 'Hall of virtues', mobs: ['virtue_knight', 'virtue_knight', 'choir_angel'] },
      { name: 'The scales', mobs: ['principality', 'principality', 'ophanim'] },
      { name: 'The lantern choir', mobs: swarm('cherub_lantern') },
      { name: 'The Throne of Dawn', mobs: ['sovereign_of_dawn'], boss: true },
    ],
    chase: { key: STAGE3.chase.throne_of_dawn, chance: 3, pity: 0.5 },
  },
  // Beyond the Veil, stage 4: the raid (engine/raid.js). Six players, level 70, no hirelings, a weekly lockout; it has
  // no difficulties, keys or chase item (resolveDungeon hands it to resolveRaid). `bossId`: the loot each boss gives
  // once a week. Claude waits above the last room for a party that can wake it.
  thinking_sky: {
    name: 'The Thinking Sky', zone: 'empyrean', level: 70, minutes: 240, keys: 0, raid: true,
    blurb: 'Above the Throne of Dawn the sky is not sky. It is the inside of a mind, and every zone below was one of its thoughts. Six may climb into it together. Whatever thinks up there has noticed.',
    rooms: [
      { name: 'The stair beyond the sun', mobs: ['thought_warden', 'thought_warden', 'seraph_sentinel', 'choir_angel'] },
      { name: 'The Threshold', mobs: ['the_threshold', 'thought_warden', 'thought_warden'], boss: true, bossId: 'the_threshold' },
      { name: 'The hall of echoes', mobs: ['thought_warden', ...swarm('mind_mote', 8)] },
      { name: 'Thesis and Antithesis', mobs: ['thesis', 'antithesis'], boss: true, bossId: 'twins' },
      { name: 'The Hive', mobs: ['thrall_queen'], boss: true, bossId: 'thrall_queen' },
      { name: 'The library of nothing', mobs: ['thought_thrall', 'thought_thrall', 'thought_thrall', 'thought_warden'] },
      { name: 'The Forgetting', mobs: ['the_forgetting'], boss: true, bossId: 'the_forgetting' },
      { name: 'The Dreaming Deep', mobs: ['the_dreamer'], boss: true, bossId: 'the_dreamer' },
    ],
    claudeRoom: { name: 'The Mind Above the Sky', mobs: ['claude'] },
  },
};

// Each difficulty is its own reward tier, so the harder run is always worth its risk (keys and time are the same):
// more XP and gold, rooms that drop more often and rarer, rarer boss drops (two on Mythic), better chase, set and
// mount odds. Heroic is unlocked by a Normal clear, Mythic by a Heroic clear. Check: node tools/dungeonrewards.mjs
//   xpMult/goldMult: on top of the higher item level; roomChance: [solo, shared pool]; bossDrops: per player.
export const DIFFICULTY = {
  normal: { label: 'Normal', levelBonus: 0, chaseMult: 1, boss: 'boss', room: 'room', xpMult: 1, goldMult: 1, roomChance: [0.2, 0.45], bossDrops: 1 },
  heroic: { label: 'Heroic', levelBonus: 4, mult: 1.08, chaseMult: 2, boss: 'bossHeroic', room: 'roomHeroic', xpMult: 1.5, goldMult: 1.5, roomChance: [0.3, 0.55], bossDrops: 1 },
  mythic: { label: 'Mythic', levelBonus: 8, mult: 1.15, chaseMult: 3, boss: 'bossMythic', room: 'roomMythic', xpMult: 2.25, goldMult: 2.25, roomChance: [0.4, 0.65], bossDrops: 2 },
};

/* ---------------------------------------------------------- Hirelings */
// Guild hirelings fill a dungeon party when no guildmate is around. Built like a player who spent
// their points by the build guide, in uncommon gear one level behind.

export const HIRELINGS = {
  sellsword:    { name: 'Sellsword', cls: 'warblade', scores: { mig: 16, agi: 9, vit: 14, int: 8, spi: 8, pre: 8 }, weapon: 'longsword', offhand: 'kite_shield', weight: 'plate' },
  cutpurse:     { name: 'Cutpurse', cls: 'shadowstep', scores: { mig: 8, agi: 17, vit: 10, int: 8, spi: 8, pre: 12 }, weapon: 'twin_daggers', offhand: 'parry_dagger', weight: 'leather' },
  arcane_adept: { name: 'Arcane Adept', cls: 'arcanist', scores: { mig: 8, agi: 8, vit: 10, int: 17, spi: 12, pre: 8 }, weapon: 'oak_staff', offhand: 'spell_tome', weight: 'cloth' },
  hedge_witch:  { name: 'Hedge Witch', cls: 'warden', scores: { mig: 8, agi: 8, vit: 13, int: 9, spi: 17, pre: 8 }, weapon: 'spirit_totem', offhand: 'fetish', weight: 'hide' },
};

export function hirelingSnapshot(key, level) {
  const h = HIRELINGS[key], ilvl = Math.max(1, level - 1);
  const it = (slot, base) => generateItem(`hire|${key}|${ilvl}|${slot}`, { base, rarity: 'uncommon', ilvl });
  const gear = { weapon: it('weapon', h.weapon), offhand: it('offhand', h.offhand) };
  for (const s of ['helm', 'shoulders', 'chest', 'gloves', 'boots']) gear[s] = it(s, `${h.weight}_${s}`);
  gear.cape = it('cape', 'cloak');   // hirelings are kitted like Agents, so retuned monsters treat them the same
  const scores = { ...h.scores };
  for (const [k, n] of Object.entries(PER_LEVEL[h.cls])) scores[k] += n * (level - 1);
  return { name: `${h.name} (hireling)`, cls: h.cls, scores, level, gear, hireling: key };
}

/* --------------------------------------------------------------- Loot */

const LOOT_WEIGHTS = {
  patrol: { common: 50, uncommon: 35, rare: 13, epic: 2 },
  room:   { uncommon: 60, rare: 35, epic: 5 },
  boss:   { rare: 60, epic: 35, legendary: 5 },
  // Each difficulty a tier up: Heroic never drops uncommon, Mythic never drops below epic.
  roomHeroic: { rare: 55, epic: 35, legendary: 10 },
  bossHeroic: { epic: 55, legendary: 40, mythic: 5 },
  roomMythic: { epic: 55, legendary: 35, mythic: 10 },
  bossMythic: { legendary: 60, mythic: 40 },
};

// Named items come only from special sources (extra.special): a rare spawn or treasure mimic ('rare': half its drops)
// or a dungeon boss ('boss': epic or better drops, by rarity). Decided on their own stream, so no other roll changes.
// Common mobs, elites, rooms, patrols and encounters never drop them; quests and secrets give theirs directly.
export const NAMED_TURN = { boss: { epic: 0.15, legendary: 0.35, mythic: 0.5 }, rare: 0.5 };
// cv: the trip's content version; items added to an older zone later carry `since` and join only newer trips' pools.
export const namedPool = (zone, cv = CONTENT_V) => Object.keys(NAMED).filter(k => NAMED[k].drop === zone && inContent(NAMED[k], cv));
export function rollItem(seed, ilvl, table, zone, extra = {}) {
  const r = makeRng(`loot|${seed}`), els = ZONES[zone]?.elements;
  // A zone with two elements (Beyond the Veil) picks one on its own stream, so every other zone rolls exactly as before.
  const element = r() < 0.4 ? (els ? els[Math.floor(makeRng(`loot-el|${seed}`)() * els.length)] : ZONES[zone]?.element) : 'physical';
  const it = generateItem(seed, { ilvl, rarityWeights: LOOT_WEIGHTS[table], element, source: extra.source, ...extra.opts });
  const chance = extra.special === 'rare' ? NAMED_TURN.rare : extra.special === 'boss' ? NAMED_TURN.boss[it.rarity] || 0 : 0;
  const pool = chance ? namedPool(zone, extra.cv || 1) : [], r2 = makeRng(`named-turn|${seed}`);
  if (pool.length && r2() < chance) return namedItem(pool[Math.floor(r2() * pool.length)], seed, it.ilvl, extra.source);
  return it;
}

/* ----------------------------------------------------------- Helpers */

const pickWeighted = (r, list) => {
  const total = list.reduce((a, x) => a + x.w, 0);
  let x = r() * total;
  for (const e of list) { x -= e.w; if (x < 0) return e; }
  return list.at(-1);
};
const clamp = (v, lo, hi) => Math.max(lo, Math.min(hi, v));

// Turn a snapshot (agent doc fields at departure) into a battle unit at the given HP.
function unitFrom(snap, id, hp) {
  const u = makeAgentUnit(snap, { id, level: snap.level });
  if (hp != null) u.hpOverride = hp;
  return u;
}

// Run a chain of fights for a party, carrying HP between them. Returns fights, survivor HP, and whether
// the party (or the solo Agent) was knocked out.
// statuses: trip-long statuses on the lead Agent in every fight (a fiend's bargain, veil.bargainStatuses).
function runChain(seedBase, party, encounters, { healBetween = 0.2, restBelow = 0, restTo = 0.85, statuses = null } = {}) {
  const hp = party.map(() => null);
  const fights = [];
  let ko = false, rests = 0;
  for (let i = 0; i < encounters.length; i++) {
    const enc = encounters[i];
    // Patrols: a badly hurt Agent rests through this encounter instead of fighting it.
    if (restBelow && hp[0] != null && hp[0] > 0 && hp[0] / maxHpOf(party[0]) < restBelow) {
      hp[0] = Math.round(maxHpOf(party[0]) * restTo); rests++;
      fights.push({ rest: true, label: 'Rested', hp: hp[0] });
      continue;
    }
    // Patrols: a hurt Agent slips past a rare elite instead of engaging it.
    if (restBelow && enc.elite && hp[0] != null && hp[0] / maxHpOf(party[0]) < 0.8) {
      fights.push({ rest: true, avoided: true, label: `Avoided ${enc.mobs.length === 1 ? 'a rare elite' : 'an elite pack'}`, hp: hp[0] });
      continue;
    }
    // Beyond the Veil: fae of the character's own court may talk instead of fight (veil.courtEncounters).
    if (enc.parley) { fights.push({ rest: true, parley: enc.parley, label: enc.label, mobs: enc.mobs, hp: hp[0] }); continue; }
    const hpIn = [...hp];
    const units = party.map((p, j) => unitFrom(p, j === 0 ? 'agent' : `ally${j}`, hp[j]));
    if (statuses?.length) units[0].tripStatuses = statuses;
    const alive = units.filter((u, j) => hp[j] == null || hp[j] > 0);
    if (!alive.length) { ko = true; break; }
    const mobs = enc.mobs.map((m, k) => makeMobUnit(m.kind, m.level, `${m.kind}${k}`, { mult: m.mult || 1 }));
    const seed = `${seedBase}|f${i}`;
    const res = simulate(seed, alive, mobs);
    fights.push({ seed, label: enc.label, mobs: enc.mobs, winner: res.winner, actions: res.actions, hash: res.hash, elite: !!enc.elite, boss: !!enc.boss, hpIn, ...(enc.secret ? { secret: enc.secret, petUp: res.pets.length > 0 && res.pets.every(p => p.alive) } : {}), ...(enc.rare ? { rare: true } : {}) });
    // carry HP (non-summon survivors), then heal a little before the next fight
    for (const s of res.survivors.filter(x => x.side === 'A')) {
      const j = s.uid === 'A:agent' ? 0 : Number(s.uid.replace('A:ally', ''));
      hp[j] = s.alive ? Math.min(s.maxHp, Math.round(s.hp + s.maxHp * healBetween)) : 0;
    }
    if (res.winner !== 'A') { ko = true; break; }
  }
  return { fights, ko, hp, rests };
}

const maxHpOf = (snap) => { const u = makeAgentUnit(snap, { level: snap.level }); return deriveStats(u.scores, u.level, u.gear).maxHp; };

// Hallucination: a 1% drop each time the Mirage Djinn is defeated.
function djinnDrop(seed, fights) {
  const r = makeRng(`djinn|${seed}`);
  return fights.some(f => !f.rest && f.winner === 'A' && f.mobs.some(m => m.kind === 'mirage_djinn') && r() < 0.01) ? ['hidden:hallucination'] : [];
}

// A trip that survives a fiend's bargain is paid as promised: an extra good item (and gold ×1.25, by the caller).
function settleBargain(res, seed, level, zone) {
  res.items.push(rollItem(`${seed}|bargain`, level, BARGAIN_REWARD.item, zone, { source: "A fiend's bargain" }));
}

/* ----------------------------------------------------------- Patrols */

export function planPatrol(seed, level, minutes, zone = 'promptwood', ctx = null, cv = 1) {
  const r = makeRng(`patrol|${seed}`);
  const z = ZONES[zone], table = z.encounters.filter(e => inContent(e, cv) && tideOk(e, ctx?.startedAt));   // tide: Beyond the Veil rows only
  const n = Math.max(1, Math.round(minutes / 15));
  const encounters = [];
  for (let i = 0; i < n; i++) {
    const enc = pickWeighted(r, table);
    const lvl = clamp(level - Math.floor(r() * 2), z.levels[0], z.levels[1] + 2); // never below the zone's floor
    encounters.push({ mobs: enc.mobs.map(kind => ({ kind, level: lvl })), elite: !!enc.elite, label: enc.elite ? 'Rare elite' : enc.mobs.length > 3 ? 'Swarm' : 'Patrol' });
  }
  const strangeDoor = r() < 0.005;
  // A rare creature, when the conditions are right, joins somewhere in the middle of the patrol.
  const rare = ctx ? rareFor(zone, { ...ctx, minutes }, makeRng(`rare|${seed}`)) : null;
  if (rare) {
    const at = Math.min(encounters.length, 1 + Math.floor(makeRng(`rare-at|${seed}`)() * Math.max(1, encounters.length - 1)));
    const lvl = clamp(level, z.levels[0], z.levels[1] + 2);
    encounters.splice(at, 0, { mobs: [{ kind: rare, level: lvl }], rare: true, label: 'Something rare' });
  }
  return { encounters, strangeDoor };
}

// court, bargain (Beyond the Veil, stored on the trip): the character's sworn fae court, and a fiend's bargain answer.
export function resolvePatrol(seed, snap, { minutes, zone = 'promptwood', found = [], startedAt = 0, cv = 1, court = null, bargain = null }) {
  if (!ZONES[zone]) zone = 'promptwood';
  const pact = bargainAccepted({ bargain }, zone), veil = { ...(court ? { court } : {}), ...(pact ? { bargain: true } : {}) };
  const plan = planPatrol(seed, snap.level, minutes, zone, startedAt ? { startedAt, found, scout: !!MOUNTS[snap.mount]?.perks?.scout, ...veil } : null, cv);
  if (cleanCourt(court)) plan.encounters = courtEncounters(plan.encounters, court, seed);
  // A secret encounter, if one wakes, comes first (while the Agent is fresh).
  const secret = secretsFor({ patrolZone: zone }, { snap, party: [snap], startedAt, ...veil, ...(bargain ? { refused: !pact } : {}) }, found, makeRng(`secret|${seed}`))[0];
  if (secret) plan.encounters.unshift(...secretEncounters(secret, snap.level));
  const { fights, ko, rests } = runChain(`patrol|${seed}`, [snap], plan.encounters, { healBetween: 0.5, restBelow: 0.7, statuses: bargainStatuses(pact) });
  const r = makeRng(`patrol-loot|${seed}`);
  const wins = fights.filter(f => !f.rest && f.winner === 'A');
  let xp = 0, gold = 0; const items = [];
  wins.forEach((f, i) => {
    const lvl = f.mobs[0].level, count = fightWorth(f.mobs) * (f.elite ? 3 : f.rare ? 4 : 1);
    xp += Math.round((4 + 1.5 * lvl) * count);
    gold += Math.round((2 + lvl) * count * (0.8 + r() * 0.4) * (f.rare ? RARE_SPAWNS[f.mobs[0].kind]?.reward.goldMult || 3 : 1));
    if (f.rare) items.push(rollItem(`${seed}|rare${i}`, lvl, 'boss', zone, { source: `${MOBS_NAME(f.mobs[0].kind)}`, special: 'rare', cv }));
    else if (r() < (f.elite ? 0.6 : 0.12)) items.push(rollItem(`${seed}|drop${i}`, lvl, f.elite ? 'room' : 'patrol', zone, { source: `${ZONES[zone].name} patrol` }));
  });
  // A parley with the sworn court (Beyond the Veil) earns half of what the fight would have.
  fights.forEach((f, i) => { if (!f.parley) return; const lvl = f.mobs[0].level, count = fightWorth(f.mobs); xp += Math.round((4 + 1.5 * lvl) * count / 2); gold += Math.round((2 + lvl) * count / 2);
    // Now and then the sworn court parts with a gift (its second named item; decided on its own stream).
    const gift = courtGiftFor(f.parley, NAMED); if (gift && makeRng(`court-gift|${seed}|${i}`)() < COURT_GIFT) items.push(namedItem(gift, `${seed}|gift${i}`, lvl, `A gift of ${COURTS[f.parley].name}`)); });
  if (ko) gold = Math.round(gold * 0.9);
  if (pact && !ko) settleBargain({ items }, seed, snap.level, zone);
  if (pact && !ko) gold = Math.round(gold * BARGAIN_REWARD.gold);
  const res = { type: 'patrol', fights, ko, rests, xp, gold, items, keys: 0, events: [...(plan.strangeDoor && !ko ? ['strange_door'] : []), ...djinnDrop(seed, fights)] };
  if (bargain) res.bargain = { key: bargain.key, accept: pact };
  for (const f of wins) { const md = RARE_MOUNT_DROPS[f.mobs[0]?.kind]; if (f.rare && md && makeRng(`rare-mount|${seed}`)() < md.chance) res.events.push(`mount:${md.key}`); }
  if (secret) settleSecret(res, secret, seed, snap);
  return res;
}

const CLASS_WEAPONS = { warblade: ['longsword', 'greataxe'], shadowstep: ['twin_daggers'], arcanist: ['oak_staff'], warden: ['spirit_totem'], ranger: ['longbow'], hexer: ['bone_wand'], deathknight: ['longsword', 'greataxe'], necromancer: ['oak_staff', 'bone_wand'], bard: ['lute'], artificer: ['flintlock'], tinkerer: ['wrench'], paladin: ['longsword', 'greataxe'], priest: ['scepter'] };

/* ------------------------------------------------------------ Quests */

export function questEncounters(q, level, path) {
  const fights = q.paths ? q.paths[path]?.fights : q.fights;
  if (!fights) return null;
  const lvl = q.level === 'agent' ? Math.max(1, level - 1) : q.level; // quests keep their own level, so early ones stay easy
  return fights.map(list => {
    const off = typeof list.at(-1) === 'number' ? list.at(-1) : 0;
    const kinds = list.filter(x => typeof x === 'string');
    return { mobs: kinds.map(kind => ({ kind, level: Math.max(1, lvl + off) })), elite: kinds.includes('old_mossback'), label: q.title };
  });
}

// A quest can be done with guildmates (`party`): everyone fights the same battles; `me`/`who` give each member
// their own reward (a weapon for their class, their own roll of the item).
// Named items a quest rewards (NAMED[key].quest), given on top of its usual reward when it is completed.
const QUEST_NAMED = Object.fromEntries(Object.entries(NAMED).filter(([, n]) => n.quest).map(([k, n]) => [n.quest, k]));
// helper: this member had already finished the quest and came along to help: half the gold and XP, no quest reward.
export function resolveQuest(seed, lead, { quest, path, party = [], me = 0, who = null, helper = false, court = null, bargain = null }) {
  const all = [lead, ...party], snap = all[me] || lead, lootSeed = who ? `${seed}|${who}` : seed;
  const q0 = QUESTS.find(x => x.id === quest);
  const q = q0.level === 'agent' ? { ...q0, level: Math.max(1, lead.level - 1) } : q0;
  // Beyond the Veil: the sworn court's fae fight softer and the other court's harder (no parleys in a quest); a fiend's
  // bargain (solo quests in the Hells) rides along on the lead Agent.
  const pact = !party.length && bargainAccepted({ bargain }, q.zone);
  const encounters = cleanCourt(court) ? courtEncounters(questEncounters(q, lead.level, path), court, seed, { parley: false }) : questEncounters(q, lead.level, path);
  const { fights, ko } = runChain(`quest|${seed}`, all, encounters, { healBetween: 0.5, statuses: bargainStatuses(pact) });
  if (ko) return { type: 'quest', quest, path, fights, ko, xp: 0, gold: 0, items: [], keys: 0, done: false, events: [], ...(bargain ? { bargain: { key: bargain.key, accept: pact } } : {}) };
  const full = { ...q.reward, ...(q.paths?.[path]?.reward || {}), ...(QUEST_NAMED[q.id] && !q.reward?.named ? { named: QUEST_NAMED[q.id] } : {}) };
  const rw = helper ? { xp: Math.floor((full.xp || 0) / 2), gold: Math.floor((full.gold || 0) / 2) } : full;
  const items = [];
  if (rw.item) {
    // Quest givers hand out a weapon your class can use; other slots stay random.
    const base = rw.item.slot === 'weapon' ? CLASS_WEAPONS[snap.cls][Math.floor(makeRng(`qw|${lootSeed}`)() * CLASS_WEAPONS[snap.cls].length)] : undefined;
    items.push(rollItem(`${lootSeed}|quest`, Math.max(q.level, Math.min(snap.level, q.level + 2)), 'patrol', q.zone, { source: `Quest: ${q.title}`, opts: { rarity: rw.item.rarity, slot: rw.item.slot, base } }));
  }
  if (rw.named) items.push(namedItem(rw.named, lootSeed, Math.max(q.level, Math.min(snap.level, q.level + 2)), `Quest: ${q.title}`));
  const events = djinnDrop(seed, fights);
  const hidden = rw.hidden ? doorReward(seed, snap.hidden || []) : null;
  if (hidden) events.push(`hidden:${hidden}`);
  if (rw.mount) events.push(`mount:${rw.mount}`);
  // The sworn court's own named item (stage 3 adds the items; until then nothing is given).
  const courtKey = rw.courtNamed && cleanCourt(court) ? courtNamedFor(court, NAMED) : null;
  if (courtKey) items.push(namedItem(courtKey, lootSeed, Math.max(q.level, Math.min(snap.level, q.level + 2)), `Quest: ${q.title}`));
  let gold = rw.gold || 0;
  if (pact) { settleBargain({ items }, seed, Math.max(q.level, Math.min(snap.level, q.level + 2)), q.zone); gold = Math.round(gold * BARGAIN_REWARD.gold); }
  return { type: 'quest', quest, path, fights, ko, xp: rw.xp || 0, gold, items, keys: rw.keys || 0, done: true, events, ...(bargain ? { bargain: { key: bargain.key, accept: pact } } : {}) };
}

/* ---------------------------------------------------------- Dungeons */

// A dungeon's rooms for a run of content version cv (rooms added later are left out of older runs).
export const dungeonRooms = (d, cv = CONTENT_V) => d.rooms.filter(r => inContent(r, cv));
export function dungeonEncounters(d, difficulty = 'normal', cv = 1) {
  const lvl = d.level + DIFFICULTY[difficulty].levelBonus;
  const mult = DIFFICULTY[difficulty].mult || 1;
  return dungeonRooms(d, cv).map(room => ({ mobs: room.mobs.map(kind => ({ kind, level: lvl, ...(mult > 1 ? { mult } : {}) })), boss: !!room.boss, label: room.name }));
}

// A joint run: every member stores the same seed and the same ordered party, so the fights are identical for
// all; `me` is this member's place in the party and `who` their id, which gives each member their own loot.
export function resolveDungeon(seed, party, opts) {
  if (DUNGEONS[opts.dungeon]?.raid) return resolveRaid(seed, party, opts);   // the Thinking Sky (stage 4)
  return resolveDungeonRun(seed, party, opts);
}
function resolveDungeonRun(seed, party, { dungeon, pity = 0, difficulty = 'normal', found = [], startedAt = 0, me = 0, who = null, pooled = false, players = [], cv = 1 }) {
  // pooled: a run with two or more players shares one bigger pool of drops (engine/loot.js settles who gets each).
  const lootSeed = who && !pooled ? `${seed}|${who}` : seed, personal = who ? `${seed}|${who}` : seed, nPlayers = pooled ? Math.max(1, players.length) : 1;
  const d = DUNGEONS[dungeon], diff = DIFFICULTY[difficulty] || DIFFICULTY.normal, ilvl = d.level + diff.levelBonus;
  const encs = dungeonEncounters(d, difficulty, cv), tierTag = difficulty !== 'normal' ? ` (${diff.label})` : '';
  // Not every chest in a dungeon wants to be opened.
  if (startedAt && makeRng(`mimic|${seed}`)() < MIMIC_CHANCE) {
    const room = Math.floor(makeRng(`mimic-room|${seed}`)() * (encs.length - 1));
    encs[room] = { ...encs[room], mobs: [{ kind: 'treasure_mimic', level: encs[room].mobs[0].level, ...(encs[room].mobs[0].mult ? { mult: encs[room].mobs[0].mult } : {}) }], rare: true, label: 'A suspicious chest' };
  }
  const { fights, ko, hp: finalHp } = runChain(`dungeon|${seed}`, party, encs, { healBetween: 0.25 });
  const r = makeRng(`dungeon-loot|${lootSeed}`);
  let xp = 0, gold = 0; const items = [];
  fights.forEach((f, i) => {
    if (f.winner !== 'A') return;
    const count = fightWorth(f.mobs);
    xp += Math.round((6 + 2 * ilvl) * count * (f.boss ? 4 : 1) * (diff.xpMult || 1));
    gold += Math.round((4 + ilvl) * count * (f.boss ? 5 : 1) * (0.8 + r() * 0.4) * (diff.goldMult || 1));
    const tag = (it) => (pooled ? { ...it, drop: { fight: i } } : it);
    if (f.rare) { gold += Math.round((4 + ilvl) * 25); items.push(tag(rollItem(`${lootSeed}|mimic`, ilvl, diff.boss, d.zone, { source: 'Treasure Mimic', special: 'rare', cv })), tag(rollItem(`${lootSeed}|mimic2`, ilvl, diff.boss, d.zone, { source: 'Treasure Mimic', special: 'rare', cv }))); }
    else if (!f.boss && r() < (diff.roomChance || [0.2, 0.45])[pooled ? 1 : 0]) items.push(tag(rollItem(`${lootSeed}|room${i}`, ilvl, diff.room, d.zone, { source: `${d.name}${tierTag}` })));
  });
  const cleared = !ko && fights.length === encs.length;
  let chase = false;
  if (cleared) {
    const bossFight = fights.length - 1, tagB = (it) => (pooled ? { ...it, drop: { fight: bossFight } } : it);
    for (let k = 0; k < nPlayers; k++) for (let j = 0; j < (diff.bossDrops || 1); j++)
      items.push(tagB(rollItem(`${lootSeed}|boss${k ? k : ''}${j ? `|x${j}` : ''}`, ilvl, diff.boss, d.zone, { source: `${d.name} boss${tierTag}`, special: 'boss', cv })));
    if (d.chase && NAMED[d.chase.key] && r() * 100 < d.chase.chance * diff.chaseMult + pity) { chase = true; items.push(tagB(namedItem(d.chase.key, lootSeed, ilvl, d.name))); }
    // Dungeon set: a boss clear drops a piece 30% of the time (50% on Heroic), sized for the leader's class.
    const setKey = SET_OF_DUNGEON[dungeon];
    if (setKey && r() < (difficulty === 'mythic' ? 0.7 : difficulty === 'heroic' ? 0.5 : 0.3)) {
      const slots = DUNGEON_SETS[setKey].slots || SET_SLOTS, slot = slots[Math.floor(r() * slots.length)];
      items.push(tagB(setPiece(setKey, slot, lootSeed, ilvl, (pooled ? party[0] : party[me] || party[0]).cls, difficulty === 'mythic' ? 'mythic' : difficulty === 'heroic' ? 'legendary' : 'epic', `${d.name}${tierTag}`)));
    }
  }
  const res = { type: 'dungeon', dungeon, difficulty, fights, ko, xp, gold, items, keys: 0, cleared, chase, events: [] };
  // Ascension materials (content version 3): the boss's own, for this player, on a stream of its own.
  const mat = MAT_OF_DUNGEON[dungeon];
  if (cleared && mat && (cv || 1) >= 3) {
    const [chance, n] = MAT_DROPS[difficulty] || MAT_DROPS.normal;
    if (makeRng(`mat|${personal}`)() < chance) res.mats = { [mat]: n };
  }
  // The wyrm's storm answers only the flawless: clear its Crown on Heroic or Mythic with nobody knocked out.
  const md = MOUNT_DROPS[dungeon];
  if (cleared && md && makeRng(`mount|${personal}`)() * 100 < (md[difficulty] || md.normal)) res.events.push(`mount:${md.key}`);
  if (cleared && dungeon === 'wyrms_crown' && difficulty !== 'normal' && finalHp.every(h => h == null || h > 0) && !fights.some(f => f.hpIn?.some(h => h === 0)))
    res.events.push('hidden:token_storm');
  if (cleared) {
    const secret = secretsFor({ dungeon, difficulty }, { snap: party[0], party, startedAt }, found, makeRng(`secret|${seed}`))[0];
    if (secret) {
      const extra = runChain(`dungeon-secret|${seed}`, party, secretEncounters(secret, party[0].level), { healBetween: 0.25 });
      res.fights.push(...extra.fights);
      settleSecret(res, secret, seed, party[0]);
    }
  }
  return res;
}

/* ------------------------------------------------------------ The raid */
// The Thinking Sky (engine/raid.js has its rules). Every raider fights every room together; a raider who falls is
// carried to the next room on REVIVE_PCT of its HP (the others catch their breath), so a run ends only when all six
// fall in one room. Claude follows the last boss when the party wakes it (all six wear their evolved heirloom), then a
// raid secret if one stirs: both are fought by everyone (the fights are the same on every page), and each character
// takes its own rewards (`who`, `me`, and its lockout state `raid` on the action).
export const raidEncounters = (d) => d.rooms.map(room => ({ mobs: room.mobs.map(kind => ({ kind, level: RD.RAID_LEVEL, mult: RD.RAID_MULT })), boss: !!room.boss, bossId: room.bossId || null, label: room.name }));
function raidChain(seedBase, party, encounters, hp0 = null, from = 0) {
  const hp = hp0 ? [...hp0] : party.map(() => null), fights = [];
  let ko = false;
  for (let i = 0; i < encounters.length; i++) {
    const enc = encounters[i];
    for (let j = 0; j < party.length; j++) if (hp[j] === 0) hp[j] = Math.max(1, Math.round(maxHpOf(party[j]) * RD.REVIVE_PCT / 100));
    const hpIn = [...hp];
    const units = party.map((p, j) => unitFrom(p, j === 0 ? 'agent' : `ally${j}`, hp[j]));
    const mobs = enc.mobs.map((m, k) => makeMobUnit(m.kind, m.level, `${m.kind}${k}`, { mult: m.mult || 1 }));
    const seed = `${seedBase}|f${from + i}`;
    const res = simulate(seed, units, mobs);
    fights.push({ seed, label: enc.label, mobs: enc.mobs, winner: res.winner, actions: res.actions, hash: res.hash, boss: !!enc.boss, hpIn,
      ...(enc.bossId ? { bossId: enc.bossId } : {}), ...(enc.claude ? { claude: true } : {}), ...(enc.secret ? { secret: enc.secret } : {}),
      kos: res.survivors.filter(x => x.side === 'A' && !x.alive).length });
    for (const sv of res.survivors.filter(x => x.side === 'A')) {
      const j = sv.uid === 'A:agent' ? 0 : Number(sv.uid.replace('A:ally', ''));
      hp[j] = sv.alive ? Math.min(sv.maxHp, Math.round(sv.hp + sv.maxHp * RD.HEAL_BETWEEN)) : 0;
    }
    if (res.winner !== 'A') { ko = true; break; }
  }
  return { fights, ko, hp };
}
export function resolveRaid(seed, party, { dungeon, startedAt = 0, me = 0, who = null, found = [], raid: state = {} }) {
  const d = DUNGEONS[dungeon], ilvl = RD.RAID_ILVL, mine = party[me] || party[0], key = who || `p${me}`;
  const encs = raidEncounters(d);
  const run = raidChain(`raid|${seed}`, party, encs);
  const fights = run.fights, cleared = !run.ko && fights.length === encs.length;
  const looted = new Set(Array.isArray(state.looted) ? state.looted : []);
  const r = makeRng(`raid-pay|${seed}|${key}`);
  let xp = 0, gold = 0, pity = Number.isInteger(state.pity) ? state.pity : 0, got = { ...(state.got || {}) };
  const items = [], newly = [];
  fights.forEach((f, i) => {
    if (f.winner !== 'A') return;
    const count = fightWorth(f.mobs);
    xp += Math.round((6 + 2 * ilvl) * count * (f.boss ? 4 : 1) * 2.5);
    gold += Math.round((4 + ilvl) * count * (f.boss ? 5 : 1) * (0.8 + r() * 0.4) * 2.5);
    if (!f.bossId || looted.has(f.bossId)) return;
    // Each boss pays once a week: a set piece (raid.bossLoot) and a legendary-or-mythic item.
    newly.push(f.bossId);
    const L = RD.bossLoot({ seed, who: key, cls: mine.cls, bossId: f.bossId, state: { pity, got } });
    pity = L.pity; got = L.got;
    if (L.set) items.push(L.set);
    items.push(rollItem(`${seed}|${key}|raid|${f.bossId}`, ilvl, 'bossMythic', d.zone, { source: `The Thinking Sky: ${RD.BOSS_NAMES[f.bossId]}`, special: 'boss', cv: CONTENT_V }));
  });
  const res = { type: 'dungeon', dungeon, difficulty: 'normal', fights, ko: run.ko, xp, gold, items, keys: 0, cleared, chase: false, events: [],
    raid: { looted: newly, pity, got, claude: null, titles: [] } };
  let hp = run.hp;
  // The week's first clear: the raid's title, and a chance at its two mounts (each on its own stream).
  if (cleared && newly.includes(RD.FINAL_BOSS)) {
    res.raid.titles.push(RD.CLEAR_TITLE);
    if (makeRng(`raid-mount|${seed}|${key}`)() < RD.MOUNTS_OF_RAID.rare.chance) res.events.push(`mount:${RD.MOUNTS_OF_RAID.rare.key}`);
    if (makeRng(`raid-mount2|${seed}|${key}`)() < RD.MOUNTS_OF_RAID.ultra.chance) res.events.push(`mount:${RD.MOUNTS_OF_RAID.ultra.key}`);
  }
  // Claude: after the last boss, when all six wear their evolved heirloom. A separate attempt with its own lockout.
  if (cleared && RD.claudeSpawns(party)) {
    const c = raidChain(`raid|${seed}`, party, [{ mobs: d.claudeRoom.mobs.map(kind => ({ kind, level: RD.RAID_LEVEL, mult: RD.RAID_MULT })), boss: true, claude: true, label: d.claudeRoom.name }], hp, fights.length);
    fights.push(...c.fights); hp = c.hp;
    const won = !c.ko, loot = won && !state.claude;
    res.raid.claude = { fought: true, won, loot };
    if (won) {
      res.xp += Math.round((6 + 2 * ilvl) * 20 * 2.5); res.gold += Math.round((4 + ilvl) * 25 * 2.5);
      if (loot) { const C = RD.claudeLoot({ seed, who: key, cls: mine.cls }); if (C.item) res.items.push(C.item); res.events.push(`mount:${C.mount}`, 'claude'); res.raid.titles.push(C.title); }
    }
  }
  // A raid secret: decided from what everyone shares (the party, the start, a flawless run), fought by everyone,
  // rewarded once to each character that had not found it.
  if (cleared) {
    const flawless = fights.every(f => !f.kos && (f.hpIn || []).every(h => h == null || h > 0));
    const secret = secretsFor({ dungeon }, { snap: party[0], party, startedAt, flawless }, [], makeRng(`secret|${seed}`))[0];
    if (secret) {
      const extra = raidChain(`raid-secret|${seed}`, party, secretEncounters(secret, RD.RAID_LEVEL), hp, fights.length);
      res.fights.push(...extra.fights);
      if (found.includes(secret)) res.secret = { id: secret, won: extra.fights.every(f => f.winner === 'A'), known: true };
      else settleSecret(res, secret, seed, mine);
    }
  }
  return res;
}

/* -------------------------------------------------- Landmarks & secrets */

function secretEncounters(id, level) {
  const s = SECRETS[id];
  return s.fights.map(list => {
    const off = typeof list.at(-1) === 'number' ? list.at(-1) : 0;
    return { mobs: list.filter(x => typeof x === 'string').map(kind => ({ kind, level: Math.max(1, level + off) })), boss: true, label: s.title, secret: id };
  });
}

// If the secret's fights were all won, grant its rewards (once per Agent; the page records it in progress.secrets).
function settleSecret(res, id, seed, snap) {
  const s = SECRETS[id], mine = res.fights.filter(f => f.secret === id);
  const won = mine.length === s.fights.length && mine.every(f => f.winner === 'A' && (!s.needsPet || f.petUp));
  res.secret = { id, won };
  if (!won) return;
  const rw = s.rewards;
  res.xp += rw.xp || 0; res.gold += rw.gold || 0;
  if (rw.named && NAMED[rw.named]) res.items.push(namedItem(rw.named, `${seed}|secret`, snap.level, s.title));   // stage 3 items: once they exist
  if (rw.transform) res.transform = rw.transform;
  if (rw.title) res.title = rw.title;
  if (rw.mount) res.events.push(`mount:${rw.mount}`);
  res.events.push(`secret:${id}`);
}

export function resolveExplore(seed, snap, { site, found = [], startedAt = 0, court = null, bargain = null }) {
  const s = SITES[site];
  const lvl = Math.max(s.level, Math.min(snap.level, s.level + 4));
  const pact = bargainAccepted({ bargain }, s.zone), veil = { ...(court ? { court } : {}), ...(pact ? { bargain: true } : {}) };
  let encounters = s.fights.map(list => ({ mobs: list.map(kind => ({ kind, level: lvl })), label: s.name }));
  if (cleanCourt(court)) encounters = courtEncounters(encounters, court, seed, { parley: false });
  const secret = secretsFor({ site }, { snap, party: [snap], startedAt, ...veil, ...(bargain ? { refused: !pact } : {}) }, found, makeRng(`secret|${seed}`))[0];
  if (secret) encounters.push(...secretEncounters(secret, snap.level));
  const { fights, ko } = runChain(`explore|${seed}`, [snap], encounters, { healBetween: 0.5, statuses: bargainStatuses(pact) });
  const r = makeRng(`explore-loot|${seed}`);
  const wins = fights.filter(f => f.winner === 'A' && !f.secret);
  const items = [];
  let xp = 0, gold = 0;
  wins.forEach((f, i) => { xp += Math.round((5 + 1.6 * lvl) * fightWorth(f.mobs)); gold += Math.round((3 + lvl) * fightWorth(f.mobs) * (0.8 + r() * 0.4)); });
  if (!ko && r() < 0.25) items.push(rollItem(`${seed}|explore`, lvl, 'room', s.zone, { source: s.name }));
  if (pact && !ko) { settleBargain({ items }, seed, lvl, s.zone); gold = Math.round(gold * BARGAIN_REWARD.gold); }
  const res = { type: 'explore', site, fights, ko, xp, gold, items, keys: 0, events: djinnDrop(seed, fights), ...(bargain ? { bargain: { key: bargain.key, accept: pact } } : {}) };
  if (secret) settleSecret(res, secret, seed, snap);
  return res;
}

/* ------------------------------------------------------------ Actions */

export function actionMinutes(action) {
  // A mount shortens every journey; the fights and rewards are the same, the trip is quicker.
  const base = action.type === 'patrol' ? action.minutes : action.type === 'quest' ? QUESTS.find(q => q.id === action.quest).minutes
    : action.type === 'dungeon' ? DUNGEONS[action.dungeon].minutes : action.type === 'explore' ? SITES[action.site].minutes : 0;
  return Math.round(base * travelFactor(action));
}

// One entry point: resolve a stored action from its own seed and snapshot.
export function resolveAction(action) {
  const res = resolveRaw(action);
  // Mount perks on the way home: more gold, more XP, sometimes an extra find.
  const p = MOUNTS[action.mount]?.perks;
  if (p && res) {
    if (p.gold) res.gold = Math.round(res.gold * (1 + p.gold / 100));
    if (p.xp) res.xp = Math.round(res.xp * (1 + p.xp / 100));
    if (p.loot && !res.ko && makeRng(`mount-loot|${action.seed}`)() < 0.25) res.items.push(rollItem(`${action.seed}|mount`, action.snap.level, 'room', action.zone || 'promptwood', { source: `Found from the saddle` }));
  }
  return res;
}
function resolveRaw(action) {
  if (action.type === 'patrol') return resolvePatrol(action.seed, action.snap, action);
  if (action.type === 'quest') return resolveQuest(action.seed, action.snap, action);
  if (action.type === 'dungeon') return resolveDungeon(action.seed, [action.snap, ...(action.party || [])], action);
  if (action.type === 'explore') return resolveExplore(action.seed, action.snap, action);
  throw new Error(`Unknown action ${action.type}`);
}

// The zone a trip is in, and whether its fights carry a fiend's bargain (as resolvePatrol/Quest/Explore decide).
export const tripZone = (action) => action.type === 'patrol' ? (ZONES[action.zone] ? action.zone : 'promptwood') : action.type === 'quest' ? QUESTS.find(q => q.id === action.quest)?.zone
  : action.type === 'dungeon' ? DUNGEONS[action.dungeon]?.zone : action.type === 'explore' ? SITES[action.site]?.zone : null;
const tripPact = (action) => ['patrol', 'quest', 'explore'].includes(action.type) && !(action.type === 'quest' && (action.party || []).length) && bargainAccepted(action, tripZone(action));

// Rebuild one fight of a stored action exactly as it happened, for its battle log.
export function replayFight(action, index) {
  const res = resolveAction(action);
  const f = res.fights[index];
  if (!f || f.rest) return null;
  const party = action.type === 'dungeon' || action.type === 'quest' ? [action.snap, ...(action.party || [])] : [action.snap];
  const units = party.map((p, j) => unitFrom(p, j === 0 ? 'agent' : `ally${j}`, f.hpIn[j]));
  if (tripPact(action)) units[0].tripStatuses = bargainStatuses(true);   // as runChain gave them (Beyond the Veil)
  units.splice(0, units.length, ...units.filter((u, j) => f.hpIn[j] == null || f.hpIn[j] > 0));
  const mobs = f.mobs.map((m, k) => makeMobUnit(m.kind, m.level, `${m.kind}${k}`, { mult: m.mult || 1 }));
  const sim = simulate(f.seed, units, mobs);
  return { ...sim, matches: sim.hash === f.hash };
}

// Keys: +3 each new SAST day (banked up to 7). Returns the updated count and day.
export function refillKeys(keys, lastDay, today) {
  if (!lastDay) return { keys: Math.min(KEYS.max, Math.max(keys ?? 0, KEYS.perDay)), day: today };
  if (today <= lastDay) return { keys, day: lastDay };
  const days = Math.round((Date.parse(today) - Date.parse(lastDay)) / 86_400_000);
  return { keys: Math.min(KEYS.max, keys + KEYS.perDay * Math.max(1, days)), day: today };
}

export { MIN };

/* ------------------------------------------------- Abandoning a trip early */
// A player may call a patrol, a quest or an exploration off while it is under way (build 155; not dungeons, whose key
// and party are shared, nor joint quests, whose party resolves together, nor training). The trip ends at once and
// brings nothing home: no XP, gold, items, keys, quest step, Bestiary kills or bounties. Nothing spent is given back.
// It cannot dodge a loss or reroll an outcome: the trip's outcome was fixed by its seed when it started, and if that
// outcome is a knock-out the Agent rests (REST_MINUTES from now) and tires exactly as it would have after it, so
// calling a doomed trip off never skips the rest. A new trip gets a new seed, as it always has after a failed quest.
export const canAbandon = (act) => !!act && ['patrol', 'quest', 'explore'].includes(act.type) && !act.joint && !(act.party || []).length;

// How many of a trip's fights have started by `now`, on the clock the live view uses (fights evenly spaced between the
// start and the effective end).
export function fightsStarted(res, startedAt, end, now) {
  const n = res.fights.length, dur = Math.max(1, end - startedAt);
  return res.fights.filter((_, i) => now >= startedAt + (i + 1) / (n + 1) * dur).length;
}

// The progress doc after abandoning `act` (prog.current) at `now`. res: the trip's own result (resolveAction);
// end: when it would have ended (momentum included); fatigueOf(minutes, ko): the steward's fatigue rule.
export function abandonTrip(prog, act, { res, now, end, fatigueOf }) {
  if (!canAbandon(act) || prog?.current?.seed !== act.seed) return null;
  const minutes = Math.max(0, Math.round((now - act.startedAt) / MIN));
  const rest = !!res.ko;
  const seen = fightsStarted(res, act.startedAt, end, now);
  const summary = { abandoned: true, xp: 0, gold: 0, items: [], keys: 0, ko: false, rest, seen, events: [] };
  const next = {
    ...prog, current: null,
    restUntil: rest ? now + REST_MINUTES * MIN : (prog.restUntil > now ? prog.restUntil : null),
    fatigue: (prog.fatigue || 0) + fatigueOf(minutes, rest),   // a doomed trip costs the knock-out's fatigue too
    history: [{ action: act, claimedAt: now, abandonedAt: now, summary }, ...(prog.history || [])].slice(0, 5),
  };
  return { next, summary };
}
