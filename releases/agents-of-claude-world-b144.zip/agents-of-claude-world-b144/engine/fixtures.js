// Shared test/balance fixtures: level-1 Agents built with each class's recommended spread
// (base 8 + build-guide spread + class bonus), matching the game's "Use recommended spread".
export const STARTERS = {
  warblade:   { name: 'Brakka', cls: 'warblade',   scores: { mig: 16, agi: 9, vit: 14, int: 8, spi: 8, pre: 8 } },
  shadowstep: { name: 'Vex',    cls: 'shadowstep', scores: { mig: 8, agi: 17, vit: 10, int: 8, spi: 8, pre: 12 } },
  arcanist:   { name: 'Ilsa',   cls: 'arcanist',   scores: { mig: 8, agi: 8, vit: 10, int: 17, spi: 12, pre: 8 } },
  warden:     { name: 'Moss',   cls: 'warden',     scores: { mig: 8, agi: 8, vit: 13, int: 9, spi: 17, pre: 8 } },
  ranger:     { name: 'Wren',   cls: 'ranger',     scores: { mig: 8, agi: 16, vit: 11, int: 8, spi: 12, pre: 8 } },
  hexer:      { name: 'Morrow', cls: 'hexer',      scores: { mig: 8, agi: 9, vit: 11, int: 16, spi: 8, pre: 11 } },
};

import { generateItem } from './items.js';

// Level-appropriate uncommon gear in the class's proficient weight, for balance runs and tests.
const KIT = {
  warblade:   { weapon: 'longsword', offhand: 'kite_shield', weight: 'plate' },
  shadowstep: { weapon: 'twin_daggers', offhand: 'parry_dagger', weight: 'leather' },
  arcanist:   { weapon: 'oak_staff', offhand: 'spell_tome', weight: 'cloth' },
  warden:     { weapon: 'spirit_totem', offhand: 'fetish', weight: 'hide' },
  ranger:     { weapon: 'longbow', offhand: 'parry_dagger', weight: 'leather' },
  hexer:      { weapon: 'bone_wand', offhand: 'spell_tome', weight: 'cloth' },
};
// extras: also wear shoulders of the class's weight and a cloak (the slots added after the first balance passes).
// focus: gear like a real player builds it, one element across armour and weapon (casters their class element), so
// affinity and elemental bonuses line up. Used by the Pit tuner and matchup checks (since epoch 11).
const FOCUS = { arcanist: ['fire', 'frost', 'storm'], hexer: ['shadow'], warden: ['nature'], warblade: ['fire', 'storm', 'frost', 'nature', 'shadow'],
  shadowstep: ['shadow', 'storm', 'fire', 'frost', 'nature'], ranger: ['storm', 'nature', 'frost', 'fire', 'shadow'] };
export function geared(cls, level, rarity = 'uncommon', variant = 0, { extras = true, focus = false } = {}) {
  const element = focus ? FOCUS[cls][variant % FOCUS[cls].length] : undefined;
  const k = KIT[cls], it = (slot, base) => generateItem(`bal|${cls}|${level}|${slot}${variant ? '|' + variant : ''}${focus ? '|f' : ''}`, { base, rarity, ilvl: level, ...(element ? { element } : {}) });
  const eq = { weapon: it('weapon', k.weapon), offhand: it('offhand', k.offhand) };
  for (const s of ['helm', 'chest', 'gloves', 'boots']) eq[s] = it(s, `${k.weight}_${s}`);
  if (extras) { eq.shoulders = it('shoulders', `${k.weight}_shoulders`); eq.cape = it('cape', 'cloak'); }
  // A focused build also steers its elemental damage bonuses to that element, as players do when they pick their gear.
  if (element) for (const it of Object.values(eq)) if (it?.affixes) it.affixes = it.affixes.map(a => (/^(fire|frost|storm|nature|shadow|radiant)Dmg$/.test(a.k) ? { ...a, k: `${element}Dmg` } : a));
  return eq;
}
