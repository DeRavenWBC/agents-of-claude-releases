// Agents of Claude — items (rules version 1).
// Pure and deterministic: generateItem(seed, opts) always builds the same item for the same inputs.
// computeGear(equipped, cls) turns equipped items into the bonuses the battle engine reads.
// Rules follow the design doc: Items → slots, rarity, affixes, item abilities, armour weight and affinity.

import { makeRng, fnv1a } from './rng.js';

export const SLOTS = ['weapon', 'offhand', 'helm', 'shoulders', 'chest', 'cape', 'gloves', 'boots', 'ring1', 'ring2', 'amulet', 'trinket'];
export const SLOT_LABEL = { weapon: 'Weapon', offhand: 'Off-hand', helm: 'Helm', chest: 'Chest', gloves: 'Gloves', boots: 'Boots', ring1: 'Ring', ring2: 'Ring', amulet: 'Amulet', trinket: 'Trinket', shoulders: 'Shoulders', cape: 'Cape' };
export const ARMOUR_SLOTS = ['helm', 'shoulders', 'chest', 'gloves', 'boots'];
// The four pieces the original rules were built on (supply crates, the full-set bonus). Shoulders came later.
const CORE_ARMOUR = ['helm', 'chest', 'gloves', 'boots'];
export const WEIGHTS = ['plate', 'leather', 'hide', 'cloth'];
export const PROFICIENT = { warblade: 'plate', shadowstep: 'leather', arcanist: 'cloth', warden: 'hide', ranger: 'leather', hexer: 'cloth' };

export const RARITIES = ['common', 'uncommon', 'rare', 'epic', 'legendary', 'mythic'];
export const RARITY = {
  common:    { label: 'Common',    affixes: 0, mult: 1.0,  abilityChance: 0 },
  uncommon:  { label: 'Uncommon',  affixes: 1, mult: 1.05, abilityChance: 0 },
  rare:      { label: 'Rare',      affixes: 2, mult: 1.1,  abilityChance: 0.1 },
  epic:      { label: 'Epic',      affixes: 3, mult: 1.2,  abilityChance: 0.5 },
  legendary: { label: 'Legendary', affixes: 3, mult: 1.3,  abilityChance: 1 },
  mythic:    { label: 'Mythic',    affixes: 4, mult: 1.4,  abilityChance: 1 },
};

// Base items. kind: what a weapon's power feeds (blade → physical and finesse, staff → spell, totem → healing).
export const BASES = {
  longsword:    { slot: 'weapon', name: 'Longsword', kind: 'blade', power: 1.0 },
  greataxe:     { slot: 'weapon', name: 'Greataxe', kind: 'blade', power: 1.15, implicit: { speed: -2 } },
  twin_daggers: { slot: 'weapon', name: 'Twin Daggers', kind: 'daggers', power: 0.85, implicit: { crit: 2 } },
  oak_staff:    { slot: 'weapon', name: 'Oak Staff', kind: 'staff', power: 1.0 },
  spirit_totem: { slot: 'weapon', name: 'Spirit Totem', kind: 'totem', power: 1.0 },
  longbow:      { slot: 'weapon', name: 'Longbow', kind: 'bow', power: 1.0, implicit: { crit: 1 } },
  bone_wand:    { slot: 'weapon', name: 'Bone Wand', kind: 'wand', power: 0.95, implicit: { crit: 1 } },
  kite_shield:  { slot: 'offhand', name: 'Kite Shield', kind: 'shield', armour: 0.8, implicit: { block: 5 } },
  spell_tome:   { slot: 'offhand', name: 'Spell Tome', kind: 'tome', power: 0.2 },
  parry_dagger: { slot: 'offhand', name: 'Parrying Dagger', kind: 'daggers', power: 0.3, implicit: { dodge: 2 } },
  fetish:       { slot: 'offhand', name: 'Wooden Fetish', kind: 'totem', power: 0.4 },
  band:         { slot: 'ring', name: 'Band' },
  pendant:      { slot: 'amulet', name: 'Pendant', implicit: { hp: 10 } },
  charm:        { slot: 'trinket', name: 'Charm', implicit: { resist: 2 } },
  // Capes: any class can wear one. They guard against spells more than blows; the style is how it hangs.
  cloak:        { slot: 'cape', name: 'Cloak', cape: 'long' },
  short_cape:   { slot: 'cape', name: 'Short Cape', cape: 'short', implicit: { speed: 1 } },
  tattered_cloak: { slot: 'cape', name: 'Tattered Cloak', cape: 'tattered', implicit: { dodge: 1 } },
};
const ARMOUR_NAMES = {
  plate:   { helm: 'Plate Helm', shoulders: 'Pauldrons', chest: 'Breastplate', gloves: 'Gauntlets', boots: 'Sabatons' },
  leather: { helm: 'Leather Hood', shoulders: 'Leather Spaulders', chest: 'Leather Jerkin', gloves: 'Leather Grips', boots: 'Leather Boots' },
  hide:    { helm: 'Antler Circlet', shoulders: 'Fur Mantle', chest: 'Hide Vest', gloves: 'Hide Wraps', boots: 'Hide Treads' },
  cloth:   { helm: 'Pointed Hat', shoulders: 'Silk Amice', chest: 'Robe', gloves: 'Silk Gloves', boots: 'Slippers' },
};
for (const w of WEIGHTS) for (const s of ARMOUR_SLOTS) BASES[`${w}_${s}`] = { slot: s, name: ARMOUR_NAMES[w][s], weight: w };

const ARMOUR_SLOT_MULT = { helm: 1, shoulders: 0.6, chest: 1.6, gloves: 0.7, boots: 0.8 };
const WEIGHT_ARMOUR = { plate: 1.5, leather: 1, hide: 0.9, cloth: 0.5 };
// Magic resist per piece, by weight: plate is weakest against spells, cloth strongest.
const WEIGHT_MR = { plate: 0.8, leather: 0.8, hide: 1.1, cloth: 1.3 };

// Affixes: value(ilvl, roll 0..1) → number. `name` is the prefix an item takes from its first affix.
export const AFFIXES = {
  mig:       { label: 'Might', name: 'Mighty', score: true, value: (l, r) => 1 + Math.floor(l / 5 + r * (1 + l / 6)) },
  agi:       { label: 'Agility', name: 'Swift', score: true, value: (l, r) => 1 + Math.floor(l / 5 + r * (1 + l / 6)) },
  vit:       { label: 'Vitality', name: 'Sturdy', score: true, value: (l, r) => 1 + Math.floor(l / 5 + r * (1 + l / 6)) },
  int:       { label: 'Intellect', name: 'Learned', score: true, value: (l, r) => 1 + Math.floor(l / 5 + r * (1 + l / 6)) },
  spi:       { label: 'Spirit', name: 'Serene', score: true, value: (l, r) => 1 + Math.floor(l / 5 + r * (1 + l / 6)) },
  pre:       { label: 'Presence', name: 'Regal', score: true, value: (l, r) => 1 + Math.floor(l / 5 + r * (1 + l / 6)) },
  crit:      { label: 'Crit chance', name: 'Keen', unit: '%', value: (l, r) => Math.round((1 + r * 2 + l / 12) * 10) / 10 },
  critDmg:   { label: 'Crit damage', name: 'Brutal', unit: '%', value: (l, r) => Math.round(5 + r * 10 + l / 4) },
  speed:     { label: 'Speed', name: 'Quick', value: (l, r) => Math.round(2 + r * 3 + l / 6) },
  lifesteal: { label: 'Lifesteal', name: 'Vampiric', unit: '%', value: (l, r) => Math.round(2 + r * 3 + l / 15) },
  thorns:    { label: 'Thorns', name: 'Spiked', unit: '%', value: (l, r) => Math.round(5 + r * 10 + l / 8) },
  hp:        { label: 'Max HP', name: 'Hale', value: (l, r) => Math.round(10 + r * 10 + l * 3) },
  armor:     { label: 'Armour', name: 'Reinforced', value: (l, r) => Math.round(3 + r * 4 + l) },
  mr:        { label: 'Magic resist', name: 'Warded', value: (l, r) => Math.round(3 + r * 4 + l) },
  fireDmg:   { label: 'Fire damage', name: 'Blazing', unit: '%', elem: 'fire', value: (l, r) => Math.round(5 + r * 10 + l / 5) },
  frostDmg:  { label: 'Frost damage', name: 'Frigid', unit: '%', elem: 'frost', value: (l, r) => Math.round(5 + r * 10 + l / 5) },
  stormDmg:  { label: 'Storm damage', name: 'Crackling', unit: '%', elem: 'storm', value: (l, r) => Math.round(5 + r * 10 + l / 5) },
  natureDmg: { label: 'Nature damage', name: 'Verdant', unit: '%', elem: 'nature', value: (l, r) => Math.round(5 + r * 10 + l / 5) },
  shadowDmg: { label: 'Shadow damage', name: 'Umbral', unit: '%', elem: 'shadow', value: (l, r) => Math.round(5 + r * 10 + l / 5) },
  healRecv:  { label: 'Healing received', name: 'Blessed', unit: '%', value: (l, r) => Math.round(4 + r * 6 + l / 6) },
};
const AFFIX_KEYS = Object.keys(AFFIXES);

// Item abilities. `active` ones can be slotted in the loadout; `proc` ones trigger on their own.
export const ITEM_ABILITIES = {
  inferno_arc:  { type: 'active', slots: ['weapon'] },
  shimmer:      { type: 'active', slots: ['helm', 'chest', 'boots', 'trinket', 'cape'] },
  second_wind:  { type: 'active', slots: ['amulet', 'trinket', 'chest', 'shoulders'] },
  stew_of_fortitude: { type: 'active', slots: [] }, // only on Goblin King's Ladle
  sultans_ward: { type: 'active', slots: [] },      // only on the Sultan's Signet
  glacial_aegis: { type: 'active', slots: [] },     // only on the Rimeheart Shard
  annotate: { type: 'active', slots: [] },
  lightning_rod: { type: 'active', slots: [] },
  hexmothers_brew: { type: 'active', slots: [] },   // secret rewards (Brew: the old sword Hexstaff, kept for old records)
  hexmothers_cauldron: { type: 'active', slots: [] }, // heirloom weapons (stage two)
  moonless_step: { type: 'active', slots: [] },
  unyielding: { type: 'active', slots: [] },
  wyvern_volley: { type: 'active', slots: [] },
  rewrite: { type: 'active', slots: [] },
  grove_of_rebirth: { type: 'active', slots: [] },
  granted_wish: { type: 'active', slots: [] },
  thaw_tide: { type: 'active', slots: [] },
  moonlit_bound: { type: 'active', slots: [] },
  lid_slam: { type: 'active', slots: [] },
  static_spark: { type: 'proc', slots: ['ring', 'weapon', 'gloves'], proc: { on: 'crit', chance: 20, coef: 0.6, element: 'storm', name: 'Static Spark' },
                  desc: 'On crit, 20% chance to strike again for 60% Storm spell damage.' },
};

const pick = (r, arr) => arr[Math.floor(r() * arr.length)];
const cap = (s) => s[0].toUpperCase() + s.slice(1);

/**
 * Build one item. opts: { ilvl, rarity?, base?, slot?, element?, source? }
 * The same seed and opts always give the same item.
 */
// An item type's base stats at an item level and rarity (before affixes, upgrades and abilities). The fixed
// `implicit` bonuses (a kite shield's 5% block, twin daggers' 2% crit) never grow with level.
export function baseStats(baseKey, rarity, ilvl) {
  const base = BASES[baseKey], m = RARITY[rarity]?.mult ?? 1, st = {};
  if (!base) return st;
  if (base.weight) {
    st.armor = Math.round((3 + ilvl) * ARMOUR_SLOT_MULT[base.slot] * WEIGHT_ARMOUR[base.weight] * m);
    st.mr = Math.round((3 + ilvl) * ARMOUR_SLOT_MULT[base.slot] * WEIGHT_MR[base.weight] * m);
  }
  if (base.kind === 'blade' || base.kind === 'daggers' || base.kind === 'bow') st.weapon = Math.round((4 + ilvl * 1.6) * base.power * m);
  if (base.kind === 'staff' || base.kind === 'tome' || base.kind === 'wand') st.spell = Math.round((4 + ilvl * 1.6) * base.power * m);
  if (base.kind === 'totem') st.heal = Math.round((3 + ilvl * 1.2) * base.power * m);
  if (base.kind === 'shield') st.armor = Math.round((3 + ilvl) * base.armour * m);
  if (base.cape) { st.mr = Math.round((3 + ilvl) * 0.5 * m); st.armor = Math.round((3 + ilvl) * 0.2 * m); }
  for (const [k, v] of Object.entries(base.implicit || {})) st[k] = (st[k] || 0) + v;
  return st;
}

export function generateItem(seed, opts = {}) {
  const r = makeRng(`item|${seed}`);
  const ilvl = Math.max(1, Math.round(opts.ilvl || 1));
  const rarity = opts.rarity || rollRarity(r, opts.rarityWeights);
  const rr = RARITY[rarity];
  let baseKey = opts.base;
  if (!baseKey) {
    // Shoulders and capes are decided on their own stream, so every other seed still makes exactly the item it always did.
    const r2 = makeRng(`item-slot2|${seed}`), late = !opts.slot && r2() < 2 / 11 ? (r2() < 0.5 ? 'shoulders' : 'cape') : null;
    const slot = opts.slot || late || pick(r, ['weapon', 'offhand', 'helm', 'chest', 'gloves', 'boots', 'ring', 'amulet', 'trinket']);
    baseKey = pick(r, Object.keys(BASES).filter(k => BASES[k].slot === slot));
  }
  const base = BASES[baseKey];
  const item = { id: `it-${hashId(seed)}`, base: baseKey, slot: base.slot, rarity, ilvl, name: base.name, stats: {}, affixes: [] };
  if (opts.source) item.source = opts.source;

  // Base stats
  item.stats = baseStats(baseKey, rarity, ilvl);
  if (base.weight) { item.weight = base.weight; item.element = opts.element || 'physical'; }
  if (base.kind) item.kind = base.kind;
  if (base.cape) { item.cape = base.cape; if (opts.element && opts.element !== 'physical') item.element = opts.element; }

  // Affixes (distinct)
  const pool = [...AFFIX_KEYS];
  for (let i = 0; i < rr.affixes && pool.length; i++) {
    const k = pool.splice(Math.floor(r() * pool.length), 1)[0];
    item.affixes.push({ k, v: AFFIXES[k].value(ilvl, r()) });
  }

  // Item ability
  if (r() < rr.abilityChance) {
    const slotKey = base.slot;
    const fits = Object.entries(ITEM_ABILITIES).filter(([, a]) => a.slots.includes(slotKey)).map(([k]) => k);
    if (fits.length) item.ability = pick(r, fits);
  }

  // Name: rarity uncommon+ takes a prefix from its first affix
  if (item.affixes.length) item.name = `${AFFIXES[item.affixes[0].k].name} ${base.name}`;
  if (item.element && item.element !== 'physical') item.name += ` of ${cap(item.element === 'nature' ? 'the Grove' : item.element)}`;
  return item;
}

function rollRarity(r, weights = { common: 40, uncommon: 35, rare: 18, epic: 6, legendary: 1, mythic: 0 }) {
  const total = Object.values(weights).reduce((a, b) => a + b, 0);
  let x = r() * total;
  for (const k of RARITIES) { x -= weights[k] || 0; if (x < 0) return k; }
  return 'common';
}

function hashId(seed) {
  let h = 0x811c9dc5; const s = String(seed);
  for (let i = 0; i < s.length; i++) { h ^= s.charCodeAt(i); h = Math.imul(h, 0x01000193); }
  return (h >>> 0).toString(36);
}

/* --------------------------------------------------------- Named items */

// Hand-made chase items. Their stats scale with item level like any other item.
// `lore` is flavour text on the item card. Some of it is a clue.
export const NAMED = {
  goblin_kings_ladle: { name: "Goblin King's Ladle", base: 'oak_staff', rarity: 'legendary', ability: 'stew_of_fortitude',
    lore: "The handle is bone-white wood, carved with runes and sawn off short. Grubnose stirred stew with it. It was a witch's staff first.",
    affixes: [{ k: 'int', per: 0.35 }, { k: 'pre', per: 0.3 }, { k: 'shadowDmg', per: 0.8 }] },
  // The Ladle as it was before it became a staff (build 130). Agents who already owned the sword keep it under this
  // name, with the same stats; nothing drops it any more.
  grubnoses_cleaver: { name: "Grubnose's Cleaver", base: 'longsword', rarity: 'legendary', ability: 'stew_of_fortitude', legacy: true,
    lore: 'Grubnose used it as a ladle for years. It was always a sword. Nobody told him.',
    affixes: [{ k: 'vit', per: 0.35 }, { k: 'hp', per: 4 }, { k: 'mig', per: 0.3 }] },
  sultans_signet: { name: "Sultan's Signet", base: 'band', rarity: 'legendary', ability: 'sultans_ward',
    lore: "Inside the band, in tiny letters: 'Paid in full. Never in full.'",
    affixes: [{ k: 'pre', per: 0.3 }, { k: 'fireDmg', per: 0.8 }, { k: 'mr', per: 1.2 }] },
  mirage_veil: { name: 'Mirage Veil', base: 'cloth_helm', rarity: 'epic', ability: 'shimmer', element: 'storm',
    lore: 'In the small hours of the night the veil turns damp, like cloth dipped in water that should not be there.',
    affixes: [{ k: 'agi', per: 0.3 }, { k: 'crit', per: 0.12 }] },
  morwens_hexstaff: { name: "Morwen's Hexstaff", base: 'oak_staff', rarity: 'mythic', ability: 'hexmothers_cauldron', element: 'shadow',
    lore: 'Whole again, and it still smells faintly of stew. The runes on it read the same backwards.',
    affixes: [{ k: 'int', per: 0.45 }, { k: 'pre', per: 0.4 }, { k: 'shadowDmg', per: 1.0 }, { k: 'vit', per: 0.3 }] },
  // Heirloom weapons: one per class. A legendary that drops somewhere, then a secret turns it into this.
  fangs_of_the_new_moon: { name: 'Fangs of the New Moon', base: 'twin_daggers', rarity: 'mythic', ability: 'moonless_step', element: 'shadow',
    lore: 'They do not shine. Not even in the sun. Especially not in the sun.',
    affixes: [{ k: 'agi', per: 0.45 }, { k: 'crit', per: 0.15 }, { k: 'shadowDmg', per: 0.9 }, { k: 'speed', per: 0.15 }] },
  glacier_splitter: { name: 'Glacier-Splitter', base: 'greataxe', rarity: 'legendary', ability: 'second_wind', element: 'frost', drop: 'frostfang',
    lore: 'Frozen into the glacier, blade first, as if someone had tried to split it. The glacier won. The axe still remembers the sound lightning makes.',
    affixes: [{ k: 'mig', per: 0.3 }, { k: 'vit', per: 0.35 }, { k: 'armor', per: 1.2 }] },
  thunderforged_splitter: { name: 'Thunderforged Splitter', base: 'greataxe', rarity: 'mythic', ability: 'unyielding', element: 'storm',
    lore: 'Re-tempered by lightning. It hums when its bearer should already be dead.',
    affixes: [{ k: 'mig', per: 0.4 }, { k: 'vit', per: 0.45 }, { k: 'armor', per: 1.5 }, { k: 'hp', per: 5 }] },
  wyvernstring: { name: 'Wyvernstring', base: 'longbow', rarity: 'mythic', ability: 'wyvern_volley', element: 'frost',
    lore: 'Restrung with a tendon of the Hoarfrost Wyvern. Every arrow leaves with a wingbeat.',
    affixes: [{ k: 'agi', per: 0.45 }, { k: 'frostDmg', per: 1.0 }, { k: 'crit', per: 0.15 }, { k: 'speed', per: 0.15 }] },
  staff_of_the_last_page: { name: 'Staff of the Last Page', base: 'oak_staff', rarity: 'mythic', ability: 'rewrite', element: 'storm',
    lore: 'The lightning in it has learned to read. It prefers the endings.',
    affixes: [{ k: 'int', per: 0.5 }, { k: 'stormDmg', per: 1.0 }, { k: 'crit', per: 0.15 }, { k: 'spi', per: 0.3 }] },
  heartwood_totem: { name: 'Heartwood Totem', base: 'spirit_totem', rarity: 'mythic', ability: 'grove_of_rebirth', element: 'nature',
    lore: 'The faces are looking down now, at the roots. One of them is smiling.',
    affixes: [{ k: 'spi', per: 0.5 }, { k: 'healRecv', per: 0.4 }, { k: 'natureDmg', per: 0.9 }, { k: 'vit', per: 0.3 }] },
  wish_knot: { name: 'Wish-Knot', base: 'band', rarity: 'legendary', ability: 'granted_wish',
    lore: 'A knot of blue silk that can be untied only once. You have not untied it.',
    affixes: [{ k: 'agi', per: 0.3 }, { k: 'stormDmg', per: 0.8 }, { k: 'speed', per: 0.15 }] },
  heart_of_the_thaw: { name: 'Heart of the Thaw', base: 'charm', rarity: 'mythic', ability: 'thaw_tide',
    lore: 'Fire and frost, finally agreeing on something.',
    affixes: [{ k: 'frostDmg', per: 0.9 }, { k: 'fireDmg', per: 0.9 }, { k: 'mr', per: 1.4 }, { k: 'int', per: 0.35 }] },
  stag_antler: { name: 'Moonshed Antler', base: 'charm', rarity: 'legendary', ability: 'moonlit_bound',
    lore: 'Shed under a full moon. It glows faintly whenever the moon is full again.',
    affixes: [{ k: 'agi', per: 0.35 }, { k: 'crit', per: 0.12 }, { k: 'healRecv', per: 0.3 }] },
  quill_of_margins: { name: 'Quill of Infinite Margins', base: 'charm', rarity: 'legendary', ability: 'annotate',
    lore: 'It never runs out of ink, and it always has a note for you.',
    affixes: [{ k: 'int', per: 0.35 }, { k: 'shadowDmg', per: 0.8 }, { k: 'crit', per: 0.1 }] },
  wyrmscale_aegis: { name: 'Wyrmscale Aegis', base: 'kite_shield', rarity: 'legendary', ability: 'lightning_rod',
    lore: 'A single scale from the Storm Wyrm, big enough to hide behind. It hums before lightning strikes.',
    affixes: [{ k: 'vit', per: 0.4 }, { k: 'mr', per: 1.3 }, { k: 'stormDmg', per: 0.8 }] },
  pot_lid: { name: "Grubnose's Pot Lid", base: 'kite_shield', rarity: 'legendary', ability: 'lid_slam',
    lore: "The goblin king's second-best lid. It has seen things.",
    affixes: [{ k: 'vit', per: 0.35 }, { k: 'armor', per: 1.2 }, { k: 'thorns', per: 0.4 }] },
  rimeheart_shard: { name: 'Rimeheart Shard', base: 'charm', rarity: 'legendary', ability: 'glacial_aegis',
    lore: 'Cold enough to burn. It hisses near open flame, as if it remembers being warm.',
    affixes: [{ k: 'frostDmg', per: 0.8 }, { k: 'mr', per: 1.2 }, { k: 'vit', per: 0.3 }] },
  // One named item for every weapon, off-hand and armour category, each from somewhere special: `drop` names the
  // zone whose rare spawns, treasure mimics and dungeon bosses can drop it (world.js rollItem, never common mobs);
  // `quest` the quest that rewards it (and nothing else drops it). Themed to the zone and its element.
  // Promptwood Vale (nature)
  thornwarden_mantle: { name: "Thornwarden's Mantle", base: 'hide_shoulders', rarity: 'epic', ability: 'second_wind', element: 'nature', drop: 'promptwood',
    lore: 'Bramble and fox fur, stitched by someone who never once pricked a finger.', affixes: [{ k: 'vit', per: 0.3 }, { k: 'healRecv', per: 0.3 }] },
  woodcutters_gauntlets: { name: "Woodcutter's Gauntlets", base: 'plate_gloves', rarity: 'epic', ability: 'second_wind', drop: 'promptwood',
    lore: 'The knuckles are worn smooth on the right hand only.', affixes: [{ k: 'mig', per: 0.3 }, { k: 'armor', per: 1.0 }] },
  greenwake_treads: { name: 'Greenwake Treads', base: 'hide_boots', rarity: 'epic', ability: 'shimmer', element: 'nature', drop: 'promptwood',
    lore: 'Clover grows in the footprints. Only clover, and only for a day.', affixes: [{ k: 'agi', per: 0.25 }, { k: 'natureDmg', per: 0.7 }] },
  shamans_rattle: { name: "Hedge Shaman's Rattle", base: 'fetish', rarity: 'epic', ability: 'second_wind', element: 'nature', drop: 'promptwood',
    lore: 'Something inside it rattles back.', affixes: [{ k: 'spi', per: 0.3 }, { k: 'natureDmg', per: 0.7 }] },
  foxglove_hood: { name: 'Foxglove Hood', base: 'leather_helm', rarity: 'epic', ability: 'shimmer', drop: 'promptwood',
    lore: 'Dyed with a flower nobody should eat. It smells of summer anyway.', affixes: [{ k: 'agi', per: 0.3 }, { k: 'crit', per: 0.1 }] },
  wolfpelt_cloak: { name: 'Wolfpelt Cloak', base: 'cloak', rarity: 'epic', ability: 'second_wind', element: 'nature', quest: 'king_of_the_warren',
    lore: 'The wolf it came from was the size of a cart. The cloak is still warm in the mornings.', affixes: [{ k: 'vit', per: 0.3 }, { k: 'mr', per: 1.0 }] },
  // Ashen Barrens (fire)
  sandstrider_boots: { name: 'Sandstrider Boots', base: 'leather_boots', rarity: 'epic', ability: 'shimmer', element: 'fire', drop: 'ashen',
    lore: 'They leave no tracks on sand, which the bandits find very annoying.', affixes: [{ k: 'agi', per: 0.3 }, { k: 'speed', per: 0.12 }] },
  dune_reavers_fangs: { name: "Dune Reaver's Fangs", base: 'twin_daggers', rarity: 'legendary', ability: 'inferno_arc', element: 'fire', drop: 'ashen',
    lore: 'Two blades, one grudge. They are hot to the touch at noon, and cold as a grave on a night with no moon.', affixes: [{ k: 'agi', per: 0.35 }, { k: 'fireDmg', per: 0.8 }, { k: 'crit', per: 0.12 }] },
  emberwrought_breastplate: { name: 'Emberwrought Breastplate', base: 'plate_chest', rarity: 'legendary', ability: 'second_wind', element: 'fire', drop: 'ashen',
    lore: 'Forged in the Ember Shrine\'s fire. The smith did not ask permission, and the fire did not refuse.', affixes: [{ k: 'vit', per: 0.35 }, { k: 'armor', per: 1.2 }, { k: 'fireDmg', per: 0.6 }] },
  cinder_silk_robe: { name: 'Cinder-Silk Robe', base: 'cloth_chest', rarity: 'epic', ability: 'inferno_arc', element: 'fire', drop: 'ashen',
    lore: 'Spun from the cocoons of moths that only fly towards fire.', affixes: [{ k: 'int', per: 0.3 }, { k: 'fireDmg', per: 0.8 }] },
  caravan_medallion: { name: "Caravan Master's Medallion", base: 'pendant', rarity: 'epic', ability: 'second_wind', quest: 'sultans_debt',
    lore: 'Every oasis on the old road is scratched into the back. One of them is not on any map.', affixes: [{ k: 'pre', per: 0.3 }, { k: 'hp', per: 3 }] },
  scorpion_spaulders: { name: 'Scorpion-Tail Spaulders', base: 'leather_shoulders', rarity: 'epic', ability: 'shimmer', element: 'fire', drop: 'ashen',
    lore: 'The stingers point backwards. Anyone who grabs you from behind learns why.', affixes: [{ k: 'agi', per: 0.3 }, { k: 'thorns', per: 0.4 }] },
  // Frostfang Peaks (frost)
  rimewalker_sabatons: { name: 'Rimewalker Sabatons', base: 'plate_boots', rarity: 'epic', ability: 'second_wind', element: 'frost', drop: 'frostfang',
    lore: 'Spiked soles for walking up glaciers, and occasionally up wyverns.', affixes: [{ k: 'vit', per: 0.3 }, { k: 'mr', per: 1.0 }] },
  wyvernhide_vest: { name: 'Wyvernhide Vest', base: 'hide_chest', rarity: 'legendary', ability: 'shimmer', element: 'frost', drop: 'frostfang',
    lore: 'The scales still lift a little when it gets cold, as if remembering how to fly.', affixes: [{ k: 'vit', per: 0.35 }, { k: 'frostDmg', per: 0.7 }, { k: 'healRecv', per: 0.3 }] },
  frostbite_longbow: { name: 'Frostbite Longbow', base: 'longbow', rarity: 'legendary', ability: 'static_spark', element: 'frost', drop: 'frostfang',
    lore: 'The string is spun from a single frozen hair of the Rimeheart Matron. It never slackens, but it twangs like a wing when a wyvern is near.', affixes: [{ k: 'agi', per: 0.35 }, { k: 'frostDmg', per: 0.8 }, { k: 'crit', per: 0.12 }] },
  snowveil_mantle: { name: 'Snowveil Mantle', base: 'short_cape', rarity: 'epic', ability: 'shimmer', element: 'frost', quest: 'thaw',
    lore: 'White on white. In a blizzard you are a rumour.', affixes: [{ k: 'agi', per: 0.25 }, { k: 'frostDmg', per: 0.6 }] },
  matrons_grasp: { name: "Matron's Grasp", base: 'hide_gloves', rarity: 'epic', ability: 'static_spark', element: 'frost', drop: 'frostfang',
    lore: 'Frost forms on whatever you hold, but never on your hands.', affixes: [{ k: 'mig', per: 0.25 }, { k: 'frostDmg', per: 0.6 }] },
  glacier_amice: { name: 'Glacier Amice', base: 'cloth_shoulders', rarity: 'epic', ability: 'second_wind', element: 'frost', drop: 'frostfang',
    lore: 'Folded like a snowdrift, and just as heavy when it wants to be.', affixes: [{ k: 'int', per: 0.3 }, { k: 'mr', per: 1.1 }] },
  // The Whispering Archive (shadow)
  ink_stained_gloves: { name: 'Ink-Stained Gloves', base: 'cloth_gloves', rarity: 'epic', ability: 'static_spark', element: 'shadow', drop: 'archive',
    lore: 'The stains spell something if you hold your hands just so. You have not managed it yet.', affixes: [{ k: 'int', per: 0.3 }, { k: 'shadowDmg', per: 0.7 }] },
  redactors_pen: { name: "The Redactor's Pen", base: 'bone_wand', rarity: 'legendary', ability: 'inferno_arc', element: 'shadow', drop: 'archive',
    lore: 'Whatever it strikes through is forgotten a little. Mostly the enemy. Mostly.', affixes: [{ k: 'int', per: 0.35 }, { k: 'shadowDmg', per: 0.9 }, { k: 'crit', per: 0.1 }] },
  tome_of_unread_pages: { name: 'Tome of Unread Pages', base: 'spell_tome', rarity: 'legendary', ability: 'shimmer', element: 'shadow', drop: 'archive',
    lore: 'Every time you open it, it is to a page you have not read. It is not a very long book.', affixes: [{ k: 'int', per: 0.35 }, { k: 'spi', per: 0.3 }, { k: 'shadowDmg', per: 0.8 }] },
  archivists_longcoat: { name: "Archivist's Longcoat", base: 'leather_chest', rarity: 'epic', ability: 'shimmer', element: 'shadow', drop: 'archive',
    lore: 'Forty-one pockets, each with a catalogue number.', affixes: [{ k: 'agi', per: 0.3 }, { k: 'mr', per: 1.0 }] },
  reading_room_slippers: { name: 'Slippers of the Reading Room', base: 'cloth_boots', rarity: 'epic', ability: 'shimmer', quest: 'last_page',
    lore: 'Perfectly silent. The librarians insist on it.', affixes: [{ k: 'spi', per: 0.3 }, { k: 'speed', per: 0.12 }] },
  visor_of_the_last_page: { name: 'Visor of the Last Page', base: 'plate_helm', rarity: 'epic', ability: 'second_wind', element: 'shadow', drop: 'archive',
    lore: 'Through the slit you can read any book to its end. Nobody wears it for long.', affixes: [{ k: 'vit', per: 0.3 }, { k: 'mr', per: 1.0 }] },
  // Thundercrag Spire (storm)
  stormcallers_staff: { name: "Stormcaller's Staff", base: 'oak_staff', rarity: 'legendary', ability: 'static_spark', element: 'storm', drop: 'thundercrag',
    lore: 'Lightning struck the oak it was cut from eleven times. The twelfth time, it struck back. Late at night it crackles like pages turning.', affixes: [{ k: 'int', per: 0.4 }, { k: 'stormDmg', per: 0.9 }, { k: 'crit', per: 0.12 }] },
  skyguard_pauldrons: { name: 'Skyguard Pauldrons', base: 'plate_shoulders', rarity: 'legendary', ability: 'second_wind', element: 'storm', quest: 'calm',
    lore: 'Worn by the sentinels of the Spire. They are ridiculous, enormous, and nobody who has worn them would give them back.', affixes: [{ k: 'vit', per: 0.4 }, { k: 'armor', per: 1.3 }, { k: 'stormDmg', per: 0.6 }] },
  thunderhide_circlet: { name: 'Thunderhide Circlet', base: 'hide_helm', rarity: 'epic', ability: 'static_spark', element: 'storm', drop: 'thundercrag',
    lore: 'The antlers hum before a storm, which is useful, and before an argument, which is more useful.', affixes: [{ k: 'spi', per: 0.3 }, { k: 'stormDmg', per: 0.7 }] },
  galeweave_grips: { name: 'Galeweave Grips', base: 'leather_gloves', rarity: 'epic', ability: 'static_spark', element: 'storm', drop: 'thundercrag',
    lore: 'Your arrows and knives land where the wind meant them to.', affixes: [{ k: 'agi', per: 0.3 }, { k: 'crit', per: 0.12 }] },
  totem_of_the_spire: { name: 'Totem of the Spire', base: 'spirit_totem', rarity: 'legendary', ability: 'second_wind', element: 'storm', drop: 'thundercrag',
    lore: 'Carved from a lightning-split pine. The faces on it are all looking up, as if they miss the forest floor.', affixes: [{ k: 'spi', per: 0.4 }, { k: 'healRecv', per: 0.3 }, { k: 'stormDmg', per: 0.7 }] },
  lightning_catcher: { name: 'Lightning-Catcher', base: 'parry_dagger', rarity: 'epic', ability: 'static_spark', element: 'storm', drop: 'thundercrag',
    lore: 'A parrying dagger with a copper spine. It catches more than blades.', affixes: [{ k: 'agi', per: 0.3 }, { k: 'stormDmg', per: 0.6 }] },
};

// An affix as it would have rolled on the same item at another item level, with the same roll quality. Fair Duels
// use it: multiplying a low-level item's percentages (11% thorns on an item-level-1 ring) by the level ratio made
// 91% thorns. Named items follow their own `per` formula.
export function rescaleAffix(a, from, to, named = null) {
  const per = named && NAMED[named]?.affixes?.find(x => x.k === a.k)?.per;
  if (per != null) return { ...a, v: Math.max(1, Math.round(2 + per * to)) };
  const A = AFFIXES[a.k]; if (!A || typeof a.v !== 'number') return a;
  // The rolls that give this value at its own level (a low-level roll is coarse: many rolls give the same number);
  // take the middle of them. A value no roll gives (old or odd data) falls back to its place between the extremes.
  const fits = []; for (let i = 0; i <= 100; i++) if (A.value(from, i / 100) === a.v) fits.push(i / 100);
  const lo = A.value(from, 0), hi = A.value(from, 1);
  const r = fits.length ? (fits[0] + fits.at(-1)) / 2 : hi > lo ? Math.min(1, Math.max(0, (a.v - lo) / (hi - lo))) : 0.5;
  return { ...a, v: A.value(to, r) };
}

export function namedItem(key, seed, ilvl, source, def = null) {
  const n = def || NAMED[key];   // def: an older shape of the item (LEGACY_NAMED), for verifying old records
  const it = generateItem(`named|${key}|${seed}`, { base: n.base, rarity: n.rarity, ilvl, source });
  it.name = n.name; it.named = key; it.ability = n.ability; if (n.lore) it.lore = n.lore;
  it.affixes = n.affixes.map(a => ({ k: a.k, v: Math.max(1, Math.round(2 + a.per * ilvl)) }));
  if (BASES[n.base].kind) it.kind = BASES[n.base].kind; else delete it.kind;
  if (n.element) it.element = n.element;
  return it;
}

/* -------------------------------------------------------- Dungeon sets */
// Each dungeon has a 4-piece set: helm, gloves and boots (in the looter's proficient weight, so no class
// is locked out) plus an amulet. Armour pieces carry the dungeon's element, so a full set pulls your
// affinity that way. Bonuses scale with the lowest item level among the equipped pieces.

export const DUNGEON_SETS = {
  grubnose_hoard: { name: "Grubnose's Hoard", dungeon: 'gobbler_warren', element: 'nature',
    pieces: { helm: 'Stewpot Helm', gloves: 'Greasy Mitts', boots: 'Tunnel Treads', amulet: 'Bottlecap Chain' },
    lore: { amulet: "Every cap is stamped with the name of a stew. One just says 'LARDER: KING'S GUESTS ONLY. NO HIRED HELP.'" },
    bonuses: {
      2: { desc: '+20 Max HP, plus 3 per item level.', apply: (g, L) => { g.hp += 20 + 3 * L; } },
      4: { desc: '+5% lifesteal and +10% healing received.', apply: (g) => { g.lifesteal += 5; g.healRecv += 10; } },
    } },
  sultans_regalia: { name: "Sultan's Regalia", dungeon: 'sunken_bazaar', element: 'fire',
    pieces: { helm: 'Gilded Turban', gloves: 'Coin-Sewn Gloves', boots: 'Silk-Road Boots', amulet: 'Chain of Debts' },
    bonuses: {
      2: { desc: '+12% Fire damage.', apply: (g) => { g.elem.fire = (g.elem.fire || 0) + 12; } },
      4: { desc: '+4% crit chance and +20% crit damage.', apply: (g) => { g.crit += 4; g.critDmg += 20; } },
    } },
  rimeheart_vigil: { name: "Rimeheart's Vigil", dungeon: 'glacier_vault', element: 'frost',
    pieces: { helm: 'Rime Crown', gloves: 'Frostbitten Grips', boots: 'Glacier Stride', amulet: 'Heart of Rime' },
    lore: { helm: 'The points of the crown are melting, very slowly, from the inside.' },
    bonuses: {
      2: { desc: '+5 magic resist, plus 1 per item level, and +5% status resist.', apply: (g, L) => { g.mr += 5 + L; g.resist += 5; } },
      4: { desc: 'On crit, 35% chance of a Rime Burst for 70% Frost spell damage.', apply: (g) => { g.procs.push({ on: 'crit', chance: 35, coef: 0.7, element: 'frost', name: 'Rime Burst', id: 'rime_burst' }); } },
    } },
};
DUNGEON_SETS.librarians_vestments = { name: "Librarian's Vestments", dungeon: 'restricted_section', element: 'shadow',
  pieces: { helm: 'Reading Spectacles', gloves: 'Ink-Stained Gloves', boots: 'Silent Slippers', amulet: 'Catalogue Key' },
  lore: { amulet: 'It opens every door in the Archive except one.' },
  bonuses: {
    2: { desc: '+12% Shadow damage and +5% status resist.', apply: (g) => { g.elem.shadow = (g.elem.shadow || 0) + 12; g.resist += 5; } },
    4: { desc: '+15% healing received and +6 Speed.', apply: (g) => { g.healRecv += 15; g.speed += 6; } },
  } };
DUNGEON_SETS.stormcaller = { name: 'Stormcaller', dungeon: 'wyrms_crown', element: 'storm',
  pieces: { helm: 'Thunderhead Crown', gloves: 'Grounding Gauntlets', boots: 'Skystrider Boots', amulet: 'Eye of the Storm' },
  lore: { amulet: 'The storm inside it never stops. Sometimes it looks back.' },
  bonuses: {
    2: { desc: '+12% Storm damage and +3% crit chance.', apply: (g) => { g.elem.storm = (g.elem.storm || 0) + 12; g.crit += 3; } },
    4: { desc: 'On crit, 35% chance of a Thunderstrike for 80% Storm spell damage.', apply: (g) => { g.procs.push({ on: 'crit', chance: 35, coef: 0.8, element: 'storm', name: 'Thunderstrike', id: 'thunderstrike' }); } },
  } };
export const SET_OF_DUNGEON = Object.fromEntries(Object.entries(DUNGEON_SETS).map(([k, s]) => [s.dungeon, k]));

// A set piece. cls picks the armour weight (its proficient weight); slot is helm, gloves, boots or amulet.
export function setPiece(setKey, slot, seed, ilvl, cls, rarity = 'epic', source) {
  const s = DUNGEON_SETS[setKey];
  const base = slot === 'amulet' ? 'pendant' : `${PROFICIENT[cls] || 'plate'}_${slot}`;
  const it = generateItem(`set|${setKey}|${slot}|${seed}`, { base, rarity, ilvl, source, element: slot === 'amulet' ? undefined : s.element });
  it.name = s.pieces[slot]; it.set = setKey;
  if (s.lore?.[slot]) it.lore = s.lore[slot];
  if (slot === 'amulet') delete it.element;
  return it;
}

/* ------------------------------------------------------ Items from other players */
// An item that arrives from another player's doc (a listing, a gift) can hold anything: every player writes their own
// doc. canonItem rebuilds it from what the game itself defines, so no free text and no stray field travels with it:
// the name and lore come from the tables here, the art fields from the base, and only known fields are kept.
// It does not judge whether the item is possible (verify.itemIssues does). null: not an item at all.
export const ITEM_ID = /^[\w:.|-]{1,80}$/;
const ownKey = (table, k) => typeof k === 'string' && Object.hasOwn(table, k);
const smallInt = (v) => (Number.isInteger(v) && v >= 0 && v <= 100_000 ? v : 0);
export function canonName(it) {
  const base = BASES[it.base];
  if (ownKey(NAMED, it.named)) return NAMED[it.named].name;
  if (ownKey(DUNGEON_SETS, it.set)) { const piece = DUNGEON_SETS[it.set].pieces?.[base.slot]; if (piece) return piece; }
  const a0 = Array.isArray(it.affixes) ? it.affixes[0] : null;
  const suffix = typeof it.element === 'string' && it.element !== 'physical' && /^[a-z]{1,12}$/.test(it.element) ? ` of ${cap(it.element === 'nature' ? 'the Grove' : it.element)}` : '';
  // A rerolled item keeps the prefix it dropped with, so any affix's prefix is a name the game could have given it.
  if (typeof it.name === 'string' && it.name.length <= 80 && [base.name, ...AFFIX_KEYS.map(k => `${AFFIXES[k].name} ${base.name}`)].some(n => it.name === n || it.name === n + suffix)) return it.name;
  return (a0 && ownKey(AFFIXES, a0.k) ? `${AFFIXES[a0.k].name} ${base.name}` : base.name) + suffix;
}
export function canonItem(it) {
  if (!it || typeof it !== 'object' || Array.isArray(it) || !ownKey(BASES, it.base) || typeof it.id !== 'string' || !ITEM_ID.test(it.id)) return null;
  const base = BASES[it.base];
  const out = { id: it.id, base: it.base, slot: base.slot, rarity: it.rarity, ilvl: it.ilvl, name: canonName(it),
    stats: it.stats && typeof it.stats === 'object' && !Array.isArray(it.stats) ? Object.fromEntries(Object.entries(it.stats).filter(([k, v]) => /^[a-zA-Z]{1,16}$/.test(k) && Number.isFinite(v))) : {},
    affixes: (Array.isArray(it.affixes) ? it.affixes : []).slice(0, 8).map(a => ({ k: a?.k, v: a?.v })) };
  if (typeof it.source === 'string') out.source = it.source.replace(/[^\p{L}\p{N} ,.'’:()+-]/gu, ' ').replace(/\s+/g, ' ').trim().slice(0, 48);
  if (base.weight) { out.weight = base.weight; out.element = typeof it.element === 'string' ? it.element : 'physical'; }
  else if (typeof it.element === 'string') out.element = it.element;
  if (base.kind) out.kind = base.kind;
  if (base.cape) out.cape = base.cape;
  if (typeof it.ability === 'string' && it.ability.length <= 48) out.ability = it.ability;
  if (ownKey(NAMED, it.named)) { out.named = it.named; if (NAMED[it.named].lore) out.lore = NAMED[it.named].lore; }
  else if (ownKey(DUNGEON_SETS, it.set)) { out.set = it.set; const lore = DUNGEON_SETS[it.set].lore?.[base.slot]; if (lore) out.lore = lore; }
  for (const k of ['upgrade', 'upgradeAttempts', 'rerolls']) if (it[k] != null) out[k] = smallInt(it[k]);
  for (const k of ['transformedFrom', 'migratedFrom']) if (ownKey(NAMED, it[k])) out[k] = it[k];
  return out;
}

// Turn a named item into another, keeping its id, forge upgrades and item level.
export function transformItem(item, toKey) {
  const next = namedItem(toKey, item.id, item.ilvl, item.source);
  return { ...next, id: item.id, upgrade: item.upgrade || 0, upgradeAttempts: item.upgradeAttempts || 0, transformedFrom: item.named };
}

// Named items as they were before a rework, so fight records made with the old shape still verify (verify.js) and
// owned copies can be moved to the new shape (migrateNamed). Keyed by named key; each entry is the old NAMED entry.
export const LEGACY_NAMED = {
  goblin_kings_ladle: [{ name: "Goblin King's Ladle", base: 'longsword', rarity: 'legendary', ability: 'stew_of_fortitude',
    affixes: [{ k: 'vit', per: 0.35 }, { k: 'hp', per: 4 }, { k: 'mig', per: 0.3 }] }],
  morwens_hexstaff: [{ name: "Morwen's Hexstaff", base: 'longsword', rarity: 'mythic', ability: 'hexmothers_brew',
    affixes: [{ k: 'vit', per: 0.45 }, { k: 'hp', per: 5 }, { k: 'mig', per: 0.4 }, { k: 'shadowDmg', per: 0.9 }] }],
};
// The old sword Ladle becomes Grubnose's Cleaver (same stats, so nobody loses a weapon); the old sword Hexstaff
// becomes the new staff Hexstaff (it was always the Hexer's prize). Returns the item unchanged when nothing applies.
export function migrateNamed(item) {
  const n = item?.named && NAMED[item.named];
  if (!n || item.base === n.base) return item;
  const to = item.named === 'goblin_kings_ladle' ? 'grubnoses_cleaver' : item.named === 'morwens_hexstaff' ? 'morwens_hexstaff' : null;
  if (!to || item.base !== 'longsword') return item;
  const next = { ...transformItem(item, to), migratedFrom: item.named };
  if (item.transformedFrom) next.transformedFrom = item.transformedFrom; else delete next.transformedFrom;
  return next;
}

/* ---------------------------------------------------------------- Kits */

const STARTER = {
  warblade:   ['longsword', 'plate_helm', 'plate_chest', 'plate_boots'],
  shadowstep: ['twin_daggers', 'leather_helm', 'leather_chest', 'leather_boots'],
  arcanist:   ['oak_staff', 'cloth_helm', 'cloth_chest', 'cloth_boots'],
  warden:     ['spirit_totem', 'hide_helm', 'hide_chest', 'hide_boots'],
  ranger:     ['longbow', 'leather_helm', 'leather_chest', 'leather_boots'],
  hexer:      ['bone_wand', 'cloth_helm', 'cloth_chest', 'cloth_boots'],
};

export function starterKit(cls) {
  return STARTER[cls].map(b => ({ ...generateItem(`starter|${cls}|${b}`, { base: b, rarity: 'common', ilvl: 1, source: 'Starter kit' }), id: `starter-${b}` }));
}

// One-time Guild supply crate: four level-appropriate items, fixed by the Agent's id.
export function supplyCrate(agentId, level) {
  const s = (i) => `crate|${agentId}|${i}`;
  const r = makeRng(s('roll'));
  const armourSlot = pick(r, CORE_ARMOUR), weight = pick(r, WEIGHTS);
  return [
    generateItem(s(0), { ilvl: level, rarity: 'rare', base: `${weight}_${armourSlot}`, element: r() < 0.5 ? 'nature' : 'physical', source: 'Guild supply crate' }),
    generateItem(s(1), { ilvl: level, rarity: 'uncommon', slot: pick(r, ['ring', 'amulet']), source: 'Guild supply crate' }),
    generateItem(s(2), { ilvl: level, rarity: r() < 0.25 ? 'epic' : 'rare', source: 'Guild supply crate' }),
    generateItem(s(3), { ilvl: level, rarity: 'uncommon', slot: 'weapon', source: 'Guild supply crate' }),
  ];
}

// One-time Guild tailor's parcel, for the slots added later: shoulders of the class's own weight and a cloak,
// uncommon, at the Agent's level. Fixed by the Agent's id, so it is the same on every page.
export function tailorParcel(agentId, cls, level) {
  const w = PROFICIENT[cls] || 'plate', s = (k) => `tailor|${agentId}|${k}`;
  return [
    { ...generateItem(s('shoulders'), { base: `${w}_shoulders`, rarity: 'uncommon', ilvl: level, source: "Guild tailor's parcel" }), id: `tailor-${agentId.slice(-6)}-sh` },
    { ...generateItem(s('cape'), { base: 'cloak', rarity: 'uncommon', ilvl: level, source: "Guild tailor's parcel" }), id: `tailor-${agentId.slice(-6)}-cape` },
  ];
}

/* ------------------------------------------------------- Equip helpers */

// Which equipment slot an item goes into. Rings take ring1 first, then ring2 (or the one given).
export function slotFor(item, equipped = {}, prefer) {
  if (item.slot !== 'ring') return item.slot;
  if (prefer === 'ring1' || prefer === 'ring2') return prefer;
  return !equipped.ring1 ? 'ring1' : !equipped.ring2 ? 'ring2' : 'ring1';
}

/* ------------------------------------------------------ Gear → battle */

const ELEMENT_POINTS = { helm: 1, shoulders: 1, chest: 2, gloves: 1, boots: 1 };

/**
 * equipped: { slot: item } (items, not ids). Returns the gear bonuses the engine reads, plus a summary
 * the page shows: affinity, weight counts, set bonus, proficiency, abilities and procs.
 */
// Forge upgrades raise every positive number on an item (base stats and bonuses) by UPGRADE_PCT per level of the
// larger of its own value and an average roll of that bonus at the item's level. So a weak roll (+2 crit) grows like
// an average one, an item with bonuses only (no base stats) still gains from every level, and every level shows a
// gain (in tenths for small numbers). Drawbacks (negative numbers) never change. Fair Duels drop upgrades (duel.js).
export const UPGRADE_PCT = 0.025;
export function upgradedValue(v, up, typical = v) {
  if (!(v > 0) || !(up > 0)) return v;
  const per = Math.max(0.1, UPGRADE_PCT * Math.max(v, typical || 0)), val = v + per * up;
  return per >= 1 ? Math.round(val) : Math.round(val * 10) / 10;
}
// An item's numbers as battles use them (upgrades applied): { stats, affixes }.
export function effectiveItem(it) {
  const up = it?.upgrade || 0;
  return { stats: Object.fromEntries(Object.entries(it?.stats || {}).map(([k, v]) => [k, upgradedValue(v, up)])),
    affixes: (it?.affixes || []).map(a => ({ ...a, v: upgradedValue(a.v, up, AFFIXES[a.k] ? AFFIXES[a.k].value(it.ilvl || 1, 0.5) : a.v) })) };
}

// Records fought before the upgrade rework (combat rules epoch < 6) used +4% base stats per level and nothing else.
// Baking those numbers into the item (and dropping its upgrade) lets current code replay them exactly.
export const UPGRADE_REWORK_EPOCH = 6;
export function legacyUpgrades(snap) {
  if (!snap?.gear) return snap;
  const gear = Object.fromEntries(Object.entries(snap.gear).map(([sl, it]) => {
    if (!it?.upgrade) return [sl, it];
    const up = 1 + 0.04 * it.upgrade;
    return [sl, { ...it, upgrade: 0, stats: Object.fromEntries(Object.entries(it.stats || {}).map(([k, v]) => [k, v > 0 ? Math.round(v * up) : v])) }];
  }));
  return { ...snap, gear };
}
// The snapshot to replay a record of combat rules epoch `rv` with.
export const replaySnap = (snap, rv) => (Number.isInteger(rv) ? rv : 1) < UPGRADE_REWORK_EPOCH ? legacyUpgrades(snap) : snap;

export function computeGear(equipped = {}, cls) {
  const g = { weapon: 0, spell: 0, heal: 0, armor: 0, mr: 0, block: 0, crit: 0, critDmg: 0, dodge: 0, speed: 0, hp: 0, resist: 0,
    lifesteal: 0, thorns: 0, spellPct: 0, healPct: 0, regenPct: 0, healRecv: 0, elem: {}, scores: {}, procs: [], abilities: [] };
  const weights = { plate: 0, leather: 0, hide: 0, cloth: 0 };
  const elemPts = {};
  for (const [slot, it] of Object.entries(equipped)) {
    if (!it) continue;
    const eff = effectiveItem(it);   // forge upgrades applied (upgradedValue)
    for (const [k, v] of Object.entries(eff.stats)) g[k] = (g[k] || 0) + v;
    for (const { k, v } of eff.affixes) {
      const a = AFFIXES[k]; if (!a) continue;
      if (a.score) g.scores[k] = (g.scores[k] || 0) + v;
      else if (a.elem) g.elem[a.elem] = (g.elem[a.elem] || 0) + v;
      else g[k] = (g[k] || 0) + v;
    }
    if (it.weight && ARMOUR_SLOTS.includes(slot)) {
      weights[it.weight] += 1;
      if (it.element && it.element !== 'physical') elemPts[it.element] = (elemPts[it.element] || 0) + ELEMENT_POINTS[slot];
    }
    if (it.ability) {
      const ia = ITEM_ABILITIES[it.ability];
      if (ia?.type === 'active') g.abilities.push(it.ability);
      if (ia?.type === 'proc') g.procs.push({ ...ia.proc, id: it.ability });
    }
  }
  // Weight perks per piece (WEIGHT_PERKS); the class's proficient weight doubles the perks, never the drawbacks.
  const prof = PROFICIENT[cls];
  for (const w of WEIGHTS) {
    const n = weights[w], wp = WEIGHT_PERKS[w];
    for (const [k, v] of Object.entries(wp.perks)) g[k] += v * n * (w === prof ? 2 : 1);
    for (const [k, v] of Object.entries(wp.drawbacks)) g[k] += v * n;
  }
  // Full set of one weight
  const full = WEIGHTS.find(w => weights[w] >= SET_PIECES) || null;   // four pieces of one weight (shoulders count as one of them)
  if (full === 'leather') g.speed += 10;
  if (full === 'hide') g.healRecv += 10;
  g.set = full ? WEIGHT_PERKS[full].set : null;
  // Dungeon sets: count equipped pieces, apply each reached bonus once.
  const setCount = {}, setLvl = {};
  for (const it of Object.values(equipped)) if (it?.set && DUNGEON_SETS[it.set]) {
    setCount[it.set] = (setCount[it.set] || 0) + 1; setLvl[it.set] = Math.min(setLvl[it.set] ?? Infinity, it.ilvl);
  }
  g.sets = Object.entries(setCount).map(([key, n]) => {
    const active = Object.keys(DUNGEON_SETS[key].bonuses).map(Number).filter(k => n >= k);
    for (const k of active) DUNGEON_SETS[key].bonuses[k].apply(g, setLvl[key]);
    return { key, count: n, active };
  });
  // Affinity: the element with the most points; ties go to the chest's element.
  let affinity = 'physical', best = 0;
  for (const [el, pts] of Object.entries(elemPts)) {
    if (pts > best || (pts === best && equipped.chest?.element === el)) { affinity = el; best = pts; }
  }
  g.affinity = affinity;
  g.weights = weights;
  g.proficient = prof;
  g.hasArmour = Object.values(weights).some(n => n > 0);
  g.abilities = [...new Set(g.abilities)];
  return g;
}

// Armour weights: what each piece gives (perks double in the class's proficient weight; drawbacks never do),
// and the set bonus four pieces of one weight unlock. The single source for computeGear and for the page's text.
export const SET_PIECES = 4;
export const WEIGHT_PERKS = {
  plate:   { perks: { block: 2 }, drawbacks: { speed: -2 }, set: 'bulwark' },
  leather: { perks: { crit: 1, dodge: 0.5 }, drawbacks: {}, set: 'quickstep' },
  hide:    { perks: { healPct: 3, resist: 3 }, drawbacks: {}, set: 'wildheart' },
  cloth:   { perks: { spellPct: 2, regenPct: 5 }, drawbacks: {}, set: 'arcaneFlow' },
};
export const PERK_LABEL = { block: ['% block chance', 1], speed: [' Speed', 0], crit: ['% crit chance', 1], dodge: ['% dodge', 1],
  healPct: ['% healing done', 1], resist: ['% status resist', 1], spellPct: ['% spell power', 1], regenPct: ['% mana regen', 1] };
// "+4% block chance" for a stat change (v may be fractional).
export const perkText = (k, v) => { const [label] = PERK_LABEL[k] || [` ${k}`, 0]; const n = Math.round(v * 10) / 10; return `${n >= 0 ? '+' : '−'}${Math.abs(n)}${label}`; };
// What `pieces` pieces of weight `w` give an Agent of class `cls`: [{ k, v, perk }].
export function weightEffect(w, pieces, cls) {
  const wp = WEIGHT_PERKS[w], x = w === PROFICIENT[cls] ? 2 : 1; if (!wp || !pieces) return [];
  return [...Object.entries(wp.perks).map(([k, v]) => ({ k, v: v * pieces * x, perk: true })), ...Object.entries(wp.drawbacks).map(([k, v]) => ({ k, v: v * pieces, perk: false }))];
}

export const SET_BONUS = {
  bulwark: { name: 'Bulwark', desc: 'The first hit you take each battle deals 50% less.' },
  quickstep: { name: 'Quickstep', desc: '+10 Speed.' },
  wildheart: { name: 'Wildheart', desc: '+10% healing received.' },
  arcaneFlow: { name: 'Arcane Flow', desc: 'Your first spell each battle costs no mana.' },
};

/* ----------------------------------------------------------- Flavour lore */
// Most lore is just flavour: a line of history, a joke, a maker's mark. Rare-or-better items always
// have some; uncommon items often; common items now and then. Picked deterministically from the item's
// id, so every viewer sees the same line. Named and set items keep their own hand-written lore.

const FLAVOUR = {
  blade: ['Notched in three places. Someone kept count.', 'The grip is wrapped in leather from a boot. You hope the owner was done with it.', 'Balanced so well it almost swings itself.', 'Forged in Promptwood, sharpened everywhere else.', 'There is a name scratched near the hilt. It has been scratched out.'],
  daggers: ['A matched pair, though they have clearly never agreed on anything.', 'Light enough to forget you are carrying them, which is the point.', 'The edges are wrapped in cloth, as if to keep them from talking.'],
  staff: ['The wood is warm in the morning and cool at night.', 'Carved with spirals that never quite meet.', 'It has been someone\'s walking stick for longer than it has been a weapon.'],
  totem: ['Faces carved on every side, all of them listening.', 'It smells faintly of pine after rain.', 'Something nests in it every spring. It always leaves before battle.'],
  bow: ['The string hums a single note when drawn.', 'Yew from the Promptwood, strung with something that is not quite gut.', 'Its last owner notched every shot. There are a great many notches.'],
  wand: ['The bone is old. Nobody asks whose.', 'It points north when nobody is holding it.', 'Light as a pencil, heavy as a promise.'],
  shield: ['Dented in the shape of a goblin\'s head. Twice.', 'The paint has been redone so often the rim is thicker than the boss.', 'It has stopped arrows, axes and one very determined chicken.'],
  tome: ['Half the pages are blank. The other half disagree with each other.', 'Someone underlined every word on page 40.', 'It smells like a library that has been closed for a long time.'],
  plate: ['Each plate is stamped with a different smith\'s mark. A team effort.', 'It creaks when the weather turns.', 'Polished by a squire who clearly hated the job.'],
  leather: ['Supple, quiet, and patched with care.', 'There are pockets in places you did not know needed pockets.', 'It smells of smoke and good decisions.'],
  hide: ['Tanned with bark and stubbornness.', 'You can still see where the antlers were.', 'Warm in winter, warmer in summer. Mostly warm.'],
  cloth: ['Embroidered with stars that do not match any sky you know.', 'The hem has been let down twice; its owners kept growing.', 'Spun by someone patient enough to count every thread.'],
  ring: ['Engraved on the inside: "For luck." It does not say whose.', 'Slightly too big, as if it was made for someone else first.', 'It catches the light even when there is none.'],
  amulet: ['The chain has been repaired with three different metals.', 'It ticks very quietly, like a watch with no hands.', 'A keepsake, once. Now it is yours.'],
  cape: ['It snaps in the wind like a flag that knows your name.', 'The lining is a different colour. Nobody has ever seen it twice.', 'Mended so many times it is mostly mending.', 'Heavy enough to sleep under, light enough to run in.'],
  trinket: ['It does nothing obvious, which is suspicious.', 'Lucky, according to the merchant. Everything is lucky, according to the merchant.', 'Small enough to lose, odd enough to keep.'],
};
const ELEMENT_FLAVOUR = {
  fire: ['Warm to the touch, even in the snow.', 'Scorch marks run along it like veins.'],
  frost: ['A thin rime forms on it overnight.', 'Breath fogs when you hold it close.'],
  storm: ['Your hair stands on end when you put it on.', 'It crackles when you walk across a rug.'],
  nature: ['Moss grows on it if you leave it alone for a week.', 'A tiny leaf is pressed into the inside.'],
  shadow: ['It looks darker in daylight than it does at night.', 'Candles gutter a little when it is near.'],
  radiant: ['It glows faintly at dawn.', 'Dust never settles on it.'],
};
const RARITY_FLAVOUR = {
  epic: ['Bards would write about it, if any of them could afford it.', 'Made for a hero. Worn, for now, by you.'],
  legendary: ['There are songs about this. Most of them get the details wrong.', 'Three kingdoms have claimed it. None of them are still kingdoms.'],
  mythic: ['Older than the Weave, or so it insists.', 'Some say it chose its bearer. It has not said so to you.'],
};
const KIND_OF = (it) => it.kind === 'shield' ? 'shield' : it.kind === 'tome' ? 'tome' : it.kind || it.weight || it.slot;

export function flavourLore(item) {
  if (!item?.id) return null;
  const h = parseInt(fnv1a(`lore|${item.id}`).slice(0, 8), 16);
  const chance = { common: 0.15, uncommon: 0.45, rare: 1, epic: 1, legendary: 1, mythic: 1 }[item.rarity] ?? 0;
  if ((h % 1000) / 1000 >= chance) return null;
  const pools = [FLAVOUR[KIND_OF(item)] || [], item.element && item.element !== 'physical' ? ELEMENT_FLAVOUR[item.element] || [] : [], RARITY_FLAVOUR[item.rarity] || []];
  const all = pools.flat();
  return all.length ? all[(h >>> 10) % all.length] : null;
}
