// Agents of Claude — races. Any class can be any race.
//
// A race adjusts the Agent's attributes (applied when the battle unit is built, on top of the stored starting
// scores, so the 12-point buy stays checkable) and adds one small perk. Each race nets +2 attribute points,
// with a drawback somewhere, so no race is simply better. Agents made before races existed have none until
// their player picks one (the page asks); until then they fight without race effects and look Human.
// Appearance (skin, hair, ears, height) lives with the sprites in the page.

export const RACES = {
  human: {
    name: 'Human', blurb: 'Stubborn, adaptable and everywhere. Good at whatever they decide to be good at.',
    mods: { vit: 1, pre: 1 }, perk: { text: '+8% healing received', apply: (g) => { g.healRecv += 8; } },
    drawback: 'No standout strength',
  },
  elf: {
    name: 'Elf', blurb: 'Long-lived, light on their feet, and quietly sure they have seen all this before.',
    mods: { agi: 2, int: 1, vit: -1 }, perk: { text: '+3% dodge', apply: (g) => { g.dodge += 3; } },
    drawback: '−1 Vitality',
  },
  dwarf: {
    name: 'Dwarf', blurb: 'Built like a mountain and about as easy to move. Holds grudges and doors.',
    mods: { vit: 2, mig: 1, agi: -1 }, perk: { text: '+8 status resist', apply: (g) => { g.resist += 8; } },
    drawback: '−1 Agility',
  },
  orc: {
    name: 'Orc', blurb: 'Loud, proud and very hard to put down. Every scar has a story, told at volume.',
    mods: { mig: 2, vit: 1, int: -1 }, perk: { text: '+3% lifesteal', apply: (g) => { g.lifesteal += 3; } },
    drawback: '−1 Intellect',
  },
  halfling: {
    name: 'Halfling', blurb: 'Small, quick and lucky in ways nobody can quite explain, least of all the halfling.',
    mods: { agi: 2, pre: 1, mig: -1 }, perk: { text: '+3% crit chance', apply: (g) => { g.crit += 3; } },
    drawback: '−1 Might',
  },
  gnome: {
    name: 'Gnome', blurb: 'Curious, clever and always tinkering. Their spells come with footnotes.',
    mods: { int: 2, spi: 1, vit: -1 }, perk: { text: '+20% mana regeneration', apply: (g) => { g.regenPct += 20; } },
    drawback: '−1 Vitality',
  },
};
export const RACE_KEYS = Object.keys(RACES);
export const raceOf = (agent) => (RACES[agent?.race] ? agent.race : null);
export const FORMS = { masc: 'Masculine', fem: 'Feminine' };
export const formOf = (agent) => (agent?.form === 'fem' ? 'fem' : 'masc');
