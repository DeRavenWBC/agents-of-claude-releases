// Agents of Claude — the Agent's mind: what it knew, why it chose, and what came of it, as a graph.
//
// Every prompt that asks the Agent to decide shows its knowledge as numbered, citable items:
//   [P1..] personality traits, [L1..] field lessons, [N1..] things learned on the road and rumours,
//   [E1..] recent outings (experiences), [F:<id>] feelings about a guildmate.
// The Agent answers with "because": the keys that led to its choice. The page resolves them to stable ids
// (a hash of the text) and keeps a private record, journal.mind:
//   decisions: [{ id, at, do, what, why, by, because: [{ kind, id, text }] }]
//   events:    [{ id, at, kind: 'outcome', text, decision }]      (what came of a decision)
//   exps:      [{ id, at, text }]                                    (experiences, the raw memories)
//   lessonFrom:{ <lessonId>: [<eventId>] }                           (which outcomes taught each lesson)
//   traits:    [{ at, traits, from: [<expId>] }]                     (personality changes and what shaped them)
//   lessonFrom also links notes (things learned on the road, notes on foes) to the outcomes that taught them.
// It is public: a recent slice in the chronicle doc as `mind`, the whole live mind at chronicle/<uid>/mind/live, and
// everything that fell off it in day parts at chronicle/<uid>/mind/<day> (packArchive), listed in chronicle/<uid>/mind/index.
//
// Long-term memory (data/users/<uid>/memory): nothing the Agent learned is ever thrown away. Whatever leaves the
// active lists (a lesson rewritten away, a foe note dropped, an old road note or outing) is kept there with when it
// was retired; reflections see recent retirees and may bring them back, and the mind map shows them dimmed.

import { fnv1a, makeRng } from './rng.js';

export const hid = (kind, text) => `${kind}-${fnv1a(String(kind) + '|' + String(text || '')).slice(0, 10)}`;
export const KEEP = { decisions: 300, events: 200, exps: 300, traits: 60 };

// The citable items for a prompt, in the order the prompt shows them: [{ key, kind, id, text }].
export function citeList(ctx) {
  const out = [], add = (prefix, kind, list) => (list || []).forEach((text, i) => out.push({ key: `${prefix}${i + 1}`, kind, id: hid(kind, text), text: String(text) }));
  add('P', 'trait', ctx.personality?.traits);
  add('L', 'lesson', ctx.lessons);
  add('N', 'note', [...(ctx.rumours || []), ...(ctx.notes || [])]);
  add('E', 'outcome', ctx.recent);
  for (const f of ctx.feelings || []) out.push({ key: `F:${f.id}`, kind: 'feeling', id: hid('feeling', f.id), text: `${f.name}: ${f.aff ?? 0}/100${f.bond ? ` (${f.bond})` : ''}${f.note ? `, ${f.note}` : ''}` });
  return out;
}
export const cite = (c) => `[${c.key}]`;
export const BECAUSE_HINT = 'Also add "because": the keys in square brackets (like "L2", "E1", "N1", "P1", "F:<id>") of the traits, lessons, outings, things you learned and feelings that led to this choice, most important first (up to 5).';
export function cleanBecause(b) {
  return (Array.isArray(b) ? b : []).filter(x => typeof x === 'string' && /^(?:[PLNE]\d{1,2}|F:[\w-]{1,40})$/.test(x)).slice(0, 5);
}
export function resolveBecause(keys, list) {
  const by = new Map(list.map(c => [c.key, c]));
  return cleanBecause(keys).map(k => by.get(k)).filter(Boolean).map(({ kind, id, text }) => ({ kind, id, text: text.slice(0, 200) }));
}

// Append to a mind record, keeping it bounded. What falls off the end is returned in `dropped` so the page can
// move it to the mind's archive (nothing in the mind is ever deleted).
export function addTo(mind, key, item) {
  const m = { decisions: [], events: [], exps: [], lessonFrom: {}, traits: [], ...(mind || {}) };
  const all = [...(m[key] || []), item];
  m[key] = all.slice(-KEEP[key]);
  Object.defineProperty(m, 'dropped', { value: { key, items: all.slice(0, Math.max(0, all.length - KEEP[key])) }, enumerable: false });
  return m;
}
// The journal must stay under the database's document limit (262,144 bytes). Counts alone (KEEP) don't guarantee it:
// decisions carry reasons and citations and can be long. fitJournal keeps the journal under `budget` bytes by moving
// the oldest live-mind items (decisions, events, experiences, then traits) out, returning them as `dropped`
// ([{ key, items }]) for the month archive, so nothing is lost: the mind map merges the archive back in. Lesson links
// (lessonFrom) are trimmed last, oldest first. The journal is returned unchanged when it already fits.
export const JOURNAL_BUDGET = 200_000;
const bytes = (o) => new TextEncoder().encode(JSON.stringify(o)).length;
export function fitJournal(journal, budget = JOURNAL_BUDGET) {
  const size = bytes(journal || {});
  if (size <= budget) return { journal, dropped: [], size };
  const m = { decisions: [], events: [], exps: [], traits: [], lessonFrom: {}, ...(journal.mind || {}) };
  const lists = { decisions: [...m.decisions], events: [...m.events], exps: [...m.exps], traits: [...m.traits] };
  const sizes = Object.fromEntries(Object.entries(lists).map(([k, l]) => [k, l.map(bytes)]));
  const out = { decisions: [], events: [], exps: [], traits: [] };
  let over = size - budget;
  const floor = { decisions: 20, events: 20, exps: 20, traits: 10 };   // the live mind always keeps a little of each
  while (over > 0) {
    // Drop the oldest item among the lists that still have room to shrink (traits only once the others are at floor).
    const keys = ['decisions', 'events', 'exps'].filter(k => lists[k].length > floor[k]);
    const pool = keys.length ? keys : lists.traits.length > floor.traits ? ['traits'] : [];
    if (!pool.length) break;
    const k = pool.reduce((a, b) => ((lists[a][0]?.at ?? Infinity) <= (lists[b][0]?.at ?? Infinity) ? a : b));
    out[k].push(lists[k].shift()); over -= sizes[k].shift() + 1;
  }
  let lessonFrom = m.lessonFrom || {};
  if (over > 0) { const ent = Object.entries(lessonFrom); while (over > 0 && ent.length) { const [id, v] = ent.shift(); over -= bytes(id) + bytes(v) + 2; } lessonFrom = Object.fromEntries(ent); }
  const fitted = { ...journal, mind: { ...m, ...lists, lessonFrom } };
  return { journal: fitted, dropped: Object.entries(out).filter(([, items]) => items.length).map(([key, items]) => ({ key, items })), size: bytes(fitted) };
}
// The public mind history (chronicle/<uid>/mind/<part>): one archive doc per UTC day (`2026-11-23`), rolling over
// to `2026-11-23-2`, `-3`… when full. packArchive splits one day's items into docs that each fit under `budget`,
// oldest first, so a busy day never hits the database's document limit.
export const ARCHIVE_BUDGET = 200_000;
export const archiveDay = (at) => new Date(at || Date.now()).toISOString().slice(0, 10);
export const partKey = (day, n) => (n <= 1 ? day : `${day}-${n}`);
export const partNo = (key) => { const m = /^\d{4}-\d{2}-\d{2}-(\d+)$/.exec(key); return m ? +m[1] : 1; };
export function packArchive(doc, budget = ARCHIVE_BUDGET) {
  const all = [];
  for (const k of ['decisions', 'events', 'exps', 'traits']) for (const x of doc?.[k] || []) all.push([k, x, bytes(x) + 1]);
  all.sort((a, b) => (a[1].at || 0) - (b[1].at || 0));
  const out = []; let cur = null, size = 0;
  for (const [k, x, n] of all) {
    if (!cur || size + n > budget - 200) { cur = { decisions: [], events: [], exps: [], traits: [] }; out.push(cur); size = bytes(cur); }
    cur[k].push(x); size += n;
  }
  return out.length ? out : [{ decisions: [], events: [], exps: [], traits: [] }];
}
// The archive of a month: { decisions, events, exps, traits } of items that fell off the live mind.
export function archiveAdd(doc, key, items) {
  const d = { decisions: [], events: [], exps: [], traits: [], ...(doc || {}) }, seen = new Set(d[key].map(x => x.id ?? `${x.at}`));
  for (const x of items) if (!seen.has(x.id ?? `${x.at}`)) d[key].push(x);
  return d;
}
// The whole mind: the live record plus every archived month (no duplicates, in time order).
export function mergeMind(live, archives = []) {
  const m = { ...(live || {}) };
  for (const key of ['decisions', 'events', 'exps', 'traits']) {
    const by = new Map();
    for (const src of [...archives, live || {}]) for (const x of src?.[key] || []) by.set(x.id ?? `${x.at}`, x);
    m[key] = [...by.values()].sort((a, b) => (a.at || 0) - (b.at || 0));
  }
  return m;
}

// The graph: nodes { id, kind, label, at } and edges { from, to, kind }. limit = how many recent decisions to show.
// notes: knowledge beyond lessons (road notes, notes on foes) with their own "taught" links; retired: ids of
// knowledge now in long-term memory (drawn dimmed).
export function buildGraph(mind, { limit = 30, lessons = [], notes = [], retired = new Set() } = {}) {
  const m = mind || {}, nodes = new Map(), edges = [], seen = new Set();
  const node = (id, kind, label, at) => { if (!nodes.has(id)) nodes.set(id, { id, kind, label: String(label || '').slice(0, 160), at: at || 0 }); return id; };
  const edge = (from, to, kind) => { const k = `${from}>${to}`; if (from && to && from !== to && !seen.has(k)) { seen.add(k); edges.push({ from, to, kind }); } };
  const decisions = (m.decisions || []).slice(-limit);
  const events = new Map((m.events || []).map(e => [e.id, e]));
  for (const d of decisions) {
    node(d.id, 'decision', `${d.what}${d.why ? ` — “${d.why}”` : ''}`, d.at);
    for (const c of d.because || []) { node(c.id, c.kind, c.text); edge(c.id, d.id, 'because'); }
  }
  // What came of each decision, and what those outcomes taught.
  for (const e of m.events || []) if (nodes.has(e.decision)) { node(e.id, 'outcome', e.text, e.at); edge(e.decision, e.id, 'led to'); }
  for (const [kind, list] of [['lesson', lessons], ['note', notes]]) for (const l of list) { const id = hid(kind, l); for (const src of m.lessonFrom?.[id] || []) { const e = events.get(src); if (!e) continue; node(e.id, 'outcome', e.text, e.at); node(id, kind, l); edge(e.id, id, 'taught'); } }
  // Outcomes cited as experiences tie back to the decision that caused them.
  for (const e of m.events || []) { const id = hid('outcome', e.text); if (nodes.has(id) && id !== e.id && nodes.has(e.id)) edge(e.id, id, 'same'); }
  // Personality: which experiences shaped each trait the decisions cite.
  const exps = new Map((m.exps || []).map(x => [x.id, x]));
  for (const t of m.traits || []) for (const tr of t.traits || []) {
    const id = hid('trait', tr); if (!nodes.has(id)) continue;
    for (const src of (t.from || []).slice(-4)) { const x = exps.get(src); if (x) { node(x.id, 'experience', x.text, x.at); edge(x.id, id, 'shaped'); } }
  }
  for (const n of nodes.values()) if (retired.has(n.id)) n.retired = true;
  return { nodes: [...nodes.values()], edges };
}

/* ---------- long-term memory ---------- */
export const MEMORY_MAX = 800;
// Everything the Agent knows right now, as { id, kind, text, src }: fight and field lessons, things learned on the
// road, notes on foes, and outings. ids match the mind map's (a lesson's id is the same everywhere).
export function knowledgeItems(journal) {
  const j = journal || {}, out = [], add = (kind, text, src, idKind = kind) => { if (typeof text === 'string' && text.trim()) out.push({ id: hid(idKind, text), kind, text: text.slice(0, 600), src }); };
  const fight = j.fight || (j.duel ? { lessons: j.duel.lessons, foes: j.duel.opponents } : {});
  for (const l of fight.lessons || []) add('lesson', l, 'fight');
  for (const l of j.field?.lessons || []) add('lesson', l, 'field');
  for (const n of j.field?.notes || []) add('note', n, 'road');
  for (const [k, n] of Object.entries(fight.foes || {})) add('foe', n, k, 'note');
  for (const o of j.field?.outings || []) add('outing', o, 'trip', 'outcome');
  return out;
}
// What left the active knowledge since it was last seen goes into long-term memory; what came back leaves it.
// memory: { items: [{ id, kind, text, src, at, retiredAt }], seen: [items] }. Returns { memory, retired: [items] }.
export function retireKnowledge(memory, current, now = Date.now()) {
  const m = { items: [], ...(memory || {}) }, cur = new Map(current.map(x => [x.id, x]));
  const seen = Array.isArray(m.seen) ? m.seen : null;
  if (!seen) return { memory: { ...m, seen: current }, retired: [] };   // first look: nothing to compare with yet
  const have = new Set(m.items.map(x => x.id));
  const retired = seen.filter(x => !cur.has(x.id) && !have.has(x.id)).map(x => ({ ...x, retiredAt: now }));
  const items = [...m.items.filter(x => !cur.has(x.id)), ...retired].slice(-MEMORY_MAX);
  return { memory: { ...m, items, seen: current }, retired };
}
// Knowledge lost before long-term memory existed: past decisions kept the full text of every lesson and note they
// cited, so the first memory starts with those that are no longer active (dated by the decision that cited them).
export function recoverFromMind(mind, current) {
  const cur = new Set(current.map(x => x.id)), out = new Map();
  for (const d of mind?.decisions || []) for (const c of d.because || []) {
    if ((c.kind !== 'lesson' && c.kind !== 'note') || cur.has(c.id) || out.has(c.id) || !c.text) continue;
    out.set(c.id, { id: c.id, kind: c.kind, text: c.text, src: 'recovered', at: d.at, retiredAt: d.at });
  }
  return [...out.values()];
}
// Retired knowledge of a kind, newest first (for reflections and the mind panel).
export const retiredOf = (memory, kind, src = null) => (memory?.items || []).filter(x => x.kind === kind && (!src || x.src === src)).slice().reverse();

// Columns left to right: what happened, what it became (knowledge), what it chose, and what came of that.
export const COLUMN = { experience: 0, outcome: 0, lesson: 1, note: 1, trait: 1, feeling: 1, decision: 2 };
function columnsOf(g) {
  const cols = [[], [], [], []];
  for (const n of g.nodes) {
    // An outcome that a decision led to sits after the decisions; one that taught or was cited sits before them.
    const after = n.kind === 'outcome' && g.edges.some(e => e.to === n.id && e.kind === 'led to') && !g.edges.some(e => e.from === n.id && e.kind !== 'same');
    cols[after ? 3 : COLUMN[n.kind] ?? 1].push(n);
  }
  for (const c of cols) c.sort((a, b) => (a.at || 0) - (b.at || 0) || a.kind.localeCompare(b.kind));
  return cols.filter(c => c.length);
}
// A fixed, roomy grid: every column gets a slot wide enough for its labels and every row a fixed gap,
// so the map grows (and the page pans it) instead of squeezing labels and lines together.
export const GRID = { slot: 420, label: 250, rowGap: 48, pad: 30 };
export function layoutGraph(g, { slot = GRID.slot, label = GRID.label, rowGap = GRID.rowGap, pad = GRID.pad } = {}) {
  const used = columnsOf(g), rows = Math.max(1, ...used.map(c => c.length));
  // The last column needs only room for its label; between columns the rest of the slot is a gutter for the links.
  const width = 2 * pad + (used.length - 1) * slot + label + 20, height = 2 * pad + (rows - 1) * rowGap, w = label;
  const pos = {};
  used.forEach((c, ci) => c.forEach((n, i) => {
    // A shorter column is spread over the full height, so its links fan out rather than bunch at the top.
    const y = c.length === 1 ? height / 2 : pad + i * ((height - 2 * pad) / (c.length - 1));
    pos[n.id] = { x: pad + ci * slot, y, w };
  }));
  return { pos, width, height };
}

// The neural layout: thoughts as neurons. A seeded force simulation (so every page draws the same map): linked
// thoughts pull together, all thoughts push apart, and each kind drifts towards its own region of the "brain":
// decisions in the core, lessons and things learned above, personality and feelings to the left, memories and the
// outcomes that taught behind, outcomes of decisions ahead. Returns { pos, width, height, degree }.
export const NEURAL_REGION = { decision: [0.5, 0.5], lesson: [0.5, 0.16], note: [0.66, 0.2], trait: [0.18, 0.3], feeling: [0.22, 0.18],
  experience: [0.12, 0.72], before: [0.28, 0.82], after: [0.86, 0.62] };
export function layoutNeural(g, { width = 1100, height = 760, iters = 260, pad = 40 } = {}) {
  const r = makeRng(`neural|${g.nodes.map(n => n.id).join(',')}`);
  const degree = {}; for (const e of g.edges) { degree[e.from] = (degree[e.from] || 0) + 1; degree[e.to] = (degree[e.to] || 0) + 1; }
  // Outcomes that came after a decision sit ahead of it; others (what was known before) behind. One pass over the edges.
  const ledTo = new Set(), leadsOn = new Set();
  for (const e of g.edges) { if (e.kind === 'led to') ledTo.add(e.to); if (e.kind !== 'same') leadsOn.add(e.from); }
  const key = (n) => (n.kind === 'outcome' ? (ledTo.has(n.id) && !leadsOn.has(n.id) ? 'after' : 'before') : n.kind);
  const region = (n) => NEURAL_REGION[key(n)] || [0.5, 0.5];
  // Within its region each kind spreads along a band in time order (decisions older to newer across the core), so
  // thoughts of one kind don't pile onto one spot.
  const groups = {};
  for (const n of [...g.nodes].sort((a, b) => (a.at || 0) - (b.at || 0))) (groups[key(n)] ||= []).push(n.id);
  const rank = {}; for (const ids of Object.values(groups)) ids.forEach((id, i) => { rank[id] = i; });
  const SPREAD = { decision: 0.42, lesson: 0.5, note: 0.3, after: 0.12, before: 0.3, experience: 0.15, trait: 0.12, feeling: 0.15 };
  const band = (n) => { const k = groups[key(n)].length; return k > 1 ? (rank[n.id] / (k - 1) - 0.5) * (SPREAD[key(n)] ?? 0.2) : 0; };
  const P = g.nodes.map(n => { const [rx, ry] = region(n), b = band(n), ax = (rx + b) * width, ay = ry * height + (key(n) === 'after' ? b * 3 * height : 0);
    return { id: n.id, ax, ay, x: ax + (r() - 0.5) * 60, y: ay + (r() - 0.5) * 60, vx: 0, vy: 0, deg: degree[n.id] || 0 }; });
  const at = Object.fromEntries(P.map((p, i) => [p.id, i]));
  const L = Math.max(70, Math.min(150, Math.sqrt(width * height / Math.max(1, P.length)) * 0.6));
  // A hub (a trait shaped by dozens of memories) holds its links at a longer reach, so they ring it instead of
  // packing into a ball; a link's pull is shared out over its busier end (as in d3's force layout).
  const links = g.edges.filter(e => at[e.from] != null && at[e.to] != null).map(e => {
    const a = at[e.from], b = at[e.to], hi = Math.max(P[a].deg, P[b].deg), lo = Math.max(1, Math.min(P[a].deg, P[b].deg));
    return [a, b, L * (1 + 0.14 * Math.sqrt(hi)), 0.06 / Math.sqrt(lo)];
  });
  // Far-apart neurons barely push each other: skip pairs beyond a cut-off (most pairs on a big map).
  const CUT2 = (L * 4) ** 2;
  for (let t = 0; t < iters; t++) {
    const cool = 1 - t / iters;
    for (let i = 0; i < P.length; i++) { const A = P[i]; for (let j = i + 1; j < P.length; j++) {   // every neuron keeps its space
      const B = P[j]; let dx = A.x - B.x, dy = A.y - B.y; const d2 = dx * dx + dy * dy || 0.01; if (d2 > CUT2) continue;
      const f = (L * L * 0.6) / d2, d = Math.sqrt(d2); dx /= d; dy /= d;
      A.vx += dx * f; A.vy += dy * f; B.vx -= dx * f; B.vy -= dy * f;
    } }
    for (const [a, b, rest, k] of links) {                                                  // synapses pull together
      const dx = P[b].x - P[a].x, dy = P[b].y - P[a].y, d = Math.hypot(dx, dy) || 0.01, f = (d - rest) * k;
      P[a].vx += dx / d * f; P[a].vy += dy / d * f; P[b].vx -= dx / d * f; P[b].vy -= dy / d * f;
    }
    for (const p of P) {                                                                   // each kind keeps to its region
      p.vx += (p.ax - p.x) * 0.012; p.vy += (p.ay - p.y) * 0.012;
      const sp = Math.hypot(p.vx, p.vy), cap = 18 * cool + 1;
      if (sp > cap) { p.vx *= cap / sp; p.vy *= cap / sp; }
      p.x = Math.max(pad, Math.min(width - pad, p.x + p.vx)); p.y = Math.max(pad, Math.min(height - pad, p.y + p.vy));
      p.vx *= 0.6; p.vy *= 0.6;
    }
  }
  return { pos: Object.fromEntries(P.map(p => [p.id, { x: Math.round(p.x), y: Math.round(p.y) }])), width, height, degree };
}

// What a player shares: the last part of the record, in a bounded size.
export function exportMind(mind, lessons = []) {
  const m = mind || {};
  return { v: 1, decisions: (m.decisions || []).slice(-150), events: (m.events || []).slice(-120), exps: (m.exps || []).slice(-150), traits: (m.traits || []).slice(-30),
    lessonFrom: m.lessonFrom || {}, lessons: lessons.slice(0, 30) };
}
