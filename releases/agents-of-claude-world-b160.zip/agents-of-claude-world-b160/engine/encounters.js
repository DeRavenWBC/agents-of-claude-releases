// Agents of Claude — encounters: small events on the road (strangers, puzzles, temptations) that the Agent's own
// Claude decides, in character. Outcomes pay out when the trip is claimed, and they become the Agent's experiences
// (personality), field lessons and knowledge (rumours it learned), and its fights feed its fight knowledge.
//
// How a choice resolves (HOW, choices made since encounters v2):
//   fight  — a real battle with the Agent's gear, loadout and gambits against level-matched foes (FOES); winning or
//            losing decides the outcome.
//   check  — one of the Agent's attributes against what is normal at its level (par = 8 + 0.6 × level, times the
//            difficulty). Clearly strong enough always works, clearly too weak always fails; only a close call is
//            decided by the seeded roll, weighted by how close it is.
//   sure   — always the same outcome.        luck — a weighted roll (only the dwarf's dice game).
// The Agent may also handle an encounter its own way ("own"): it describes its plan, picks the attribute it relies
// on (or to fight, where there is someone to fight) and narrates success and failure; the same check decides it and
// the encounter's OWN stakes (fixed by the game) pay out. Choices made before v2 keep their old weighted outcomes.
//
// Where a choice is stored: the Agent's own private progress, on the trip:
//   current.choices[i] = { opt, why, by, at, v: 2, approach?, plan?, win?, lose? }.

import { makeRng } from './rng.js';
import { citeList, cite, BECAUSE_HINT } from './mind.js';
import { QUESTS, DUNGEONS, SITES, rollItem, hirelingSnapshot } from './world.js';
import { makeAgentUnit, makeMobUnit, simulate, MOBS } from './battle.js';

// outcome: { w (weight), text, gold, xp (multiples of a level-scaled step), item (rarity), fatigue, note (knowledge) }
export const ENCOUNTERS = {
  wounded_traveller: { zones: ['promptwood', 'ashen', 'frostfang'], title: 'A wounded traveller',
    text: 'A traveller sits against a tree, leg bleeding, a heavy pack beside them. They ask for help, eyes on your weapon.',
    options: {
      help: { label: 'Bind the wound and share your rations', out: [
        { w: 6, text: 'Grateful, they press a pouch of coins into your hand and point out a shortcut.', gold: 3, xp: 1, note: 'Travellers on these roads remember a kindness.' },
        { w: 2, text: 'It was a trick. While you knelt, their friend lifted your coin purse.', gold: -3, note: 'Not every wounded traveller is wounded.' }] },
      search: { label: 'Ask what is in the pack first', out: [
        { w: 4, text: 'Offended, they limp off. You find a dropped trinket where they sat.', item: 'uncommon' },
        { w: 4, text: 'It is only bread and maps. They give you a map, a little stiffly.', xp: 1, note: 'A map of the back roads shows a hidden glade.' }] },
      leave: { label: 'Keep walking', out: [
        { w: 7, text: 'You walk on. The road is quiet, and so is your conscience, mostly.' },
        { w: 3, text: 'Later you hear wolves behind you. You do not look back.', fatigue: 1 }] } } },
  riddle_door: { zones: ['archive', 'promptwood', 'frostfang'], title: 'A door that asks a riddle',
    text: 'A stone door blocks a side passage. Carved lips move: "I have keys but open no locks. What am I?"',
    options: {
      answer: { label: 'Answer: "A keyboard"', out: [
        { w: 7, text: 'The door grinds open onto a small vault.', item: 'rare', xp: 1, note: 'The talking doors favour those who think like a scribe.' },
        { w: 3, text: '"Close, but no." A puff of dust knocks you flat for a moment.', fatigue: 1 }] },
      force: { label: 'Put your shoulder to it', out: [
        { w: 3, text: 'Something cracks. Not the door. You find a few coins in the rubble anyway.', gold: 1, fatigue: 1 },
        { w: 2, text: 'It gives! Behind it, a forgotten stash.', gold: 4 }] },
      leave: { label: 'Leave it be', out: [{ w: 1, text: 'The lips mutter something rude as you walk away.' }] } } },
  shady_merchant: { zones: ['ashen', 'thundercrag', 'promptwood'], title: 'A shady merchant',
    text: 'A merchant with too many rings offers you a "genuine ancient blade, barely cursed" for a fair price.',
    options: {
      buy: { label: 'Pay and take the blade', out: [
        { w: 4, text: 'Barely cursed indeed: it is a decent find.', gold: -2, item: 'rare' },
        { w: 4, text: 'It is a painted stick. The merchant is already gone.', gold: -2, note: 'Merchants with many rings sell painted sticks.' }] },
      haggle: { label: 'Haggle hard', out: [
        { w: 5, text: 'You talk them down to half and walk off with a trinket.', gold: -1, item: 'uncommon' },
        { w: 3, text: 'They take offence and spit on your boots.' }] },
      threaten: { label: 'Threaten them for it', out: [
        { w: 3, text: 'They hand it over, shaking. You feel a little worse for it.', item: 'uncommon', note: 'Word spreads about who threatens merchants.' },
        { w: 4, text: 'Their bodyguard steps out from behind the cart. You leave bruised.', fatigue: 2 }] } } },
  shrine: { zones: ['frostfang', 'thundercrag', 'archive', 'ashen'], title: 'A forgotten shrine',
    text: 'An old shrine hums faintly. A bowl for offerings sits empty; a gem glints in the statue\'s eye.',
    options: {
      offer: { label: 'Leave an offering of gold', out: [
        { w: 6, text: 'Warmth spreads through you. You feel sharper.', gold: -1, xp: 3 },
        { w: 2, text: 'Nothing happens. The gold is gone all the same.', gold: -1 }] },
      pray: { label: 'Kneel and pray', out: [
        { w: 5, text: 'You feel calm, and rested.', xp: 1, fatigue: -1 },
        { w: 2, text: 'A voice whispers a secret about the road ahead.', note: 'The shrines whisper where the old vaults lie.' }] },
      pry: { label: 'Pry the gem loose', out: [
        { w: 3, text: 'It pops free. Worth a fair bit.', gold: 5, note: 'You robbed a shrine. You wonder if anything noticed.' },
        { w: 4, text: 'Lightning cracks from a clear sky. You come to an hour later.', fatigue: 2 }] } } },
  lost_child: { zones: ['promptwood', 'ashen'], title: 'A lost child',
    text: 'A child stands crying at a crossroads. They have lost their family\'s goat.',
    options: {
      search: { label: 'Help find the goat', out: [
        { w: 6, text: 'You find it eating a scarecrow. The family feeds you and sends you off with a gift.', xp: 2, item: 'common', note: 'The farmsteads along this road look after their friends.' },
        { w: 2, text: 'The goat finds you first, and headbutts you into a ditch.', xp: 1, fatigue: 1 }] },
      directions: { label: 'Point them to the nearest farm', out: [{ w: 1, text: 'They nod and run off. You hope it was the right farm.', xp: 1 }] },
      ignore: { label: 'Walk on', out: [{ w: 1, text: 'The crying fades behind you.' }] } } },
  gambling_dwarf: { zones: ['frostfang', 'thundercrag', 'ashen'], title: 'A dice game by the fire',
    text: 'A dwarf by a campfire shakes a cup of dice. "Double or nothing, friend? One throw."',
    options: {
      bet: { label: 'Bet a good handful of gold', out: [
        { w: 5, text: 'Sixes! The dwarf laughs and pays up.', gold: 4 },
        { w: 5, text: 'Snake eyes. The dwarf laughs harder.', gold: -3 }] },
      small: { label: 'Bet small, for the fun of it', out: [
        { w: 5, text: 'You win a little and hear a good story.', gold: 1, note: 'The dwarves say the peaks hide a frozen stair.' },
        { w: 5, text: 'You lose a little and hear a good story.', gold: -1, note: 'The dwarves say the peaks hide a frozen stair.' }] },
      cheat: { label: 'Swap in your own loaded dice', out: [
        { w: 3, text: 'Nobody notices. You clean them out.', gold: 6, note: 'You cheated at dice, and got away with it.' },
        { w: 4, text: 'The dwarf notices. So does the dwarf\'s axe.', gold: -2, fatigue: 2, note: 'Dwarves know loaded dice by the sound.' }] } } },
  bandit_toll: { zones: ['promptwood', 'ashen', 'thundercrag'], title: 'A bandit toll',
    text: 'Three bandits block the bridge. "Toll\'s ten gold, or we take it out of your hide."',
    options: {
      pay: { label: 'Pay the toll', out: [{ w: 1, text: 'They take the coin and let you pass, sniggering.', gold: -2 }] },
      fight: { label: 'Fight them', out: [
        { w: 6, text: 'They were not expecting that. You take their purse.', gold: 3, xp: 2, fatigue: 1 },
        { w: 3, text: 'Three is a lot. You get through, but it hurt.', fatigue: 2, xp: 1 }] },
      talk: { label: 'Talk your way past', out: [
        { w: 4, text: 'You convince them you are a tax collector. They pay YOU.', gold: 2, note: 'Bandits on the bridge are scared of the taxman.' },
        { w: 4, text: 'They do not buy it. You pay double.', gold: -4 }] } } },
  strange_book: { zones: ['archive'], title: 'A book that reads itself',
    text: 'A book flaps down from a high shelf and lands open at your feet. The words rearrange themselves as you watch.',
    options: {
      read: { label: 'Read it aloud', out: [
        { w: 5, text: 'The words settle into a lesson you will not forget.', xp: 4 },
        { w: 3, text: 'The words settle into your head and refuse to leave. You need a lie-down.', fatigue: 2, note: 'Some books in the Archive read you back.' }] },
      keep: { label: 'Take it with you', out: [
        { w: 4, text: 'It is a rare tome. Collectors will want it.', item: 'rare' },
        { w: 4, text: 'It flaps out of your pack an hour later and flies home.', note: 'Archive books always fly home.' }] },
      shelve: { label: 'Put it back on the shelf', out: [{ w: 1, text: 'It purrs. You feel like the Archive likes you a little more.', xp: 1, note: 'The Archive is kinder to those who shelve its books.' }] } } },
  frozen_climber: { zones: ['frostfang'], title: 'A climber stuck on the ice',
    text: 'A climber dangles from a rope halfway up an ice wall, calling for help. The rope is fraying.',
    options: {
      climb: { label: 'Climb up and pull them in', out: [
        { w: 5, text: 'You haul them up. They give you their spare charm.', item: 'uncommon', xp: 2 },
        { w: 3, text: 'You both slide down the ice. Everyone lives; everyone hurts.', fatigue: 2, xp: 1 }] },
      rope: { label: 'Throw them your rope', out: [{ w: 1, text: 'They swing to safety and thank you warmly.', xp: 1, note: 'Climbers on the Frostfang owe you a favour.' }] },
      leave: { label: 'It is not your problem', out: [{ w: 1, text: 'You hear the rope snap behind you.', note: 'You left a climber on the ice.' }] } } },
  storm_crystal: { zones: ['thundercrag'], title: 'A crackling crystal',
    text: 'A crystal the size of a fist hums on the path, sparking blue. The air smells of rain.',
    options: {
      grab: { label: 'Grab it', out: [
        { w: 4, text: 'It stings, but it sells for a fortune.', gold: 5, fatigue: 1 },
        { w: 4, text: 'It discharges. Your hair will never be the same.', fatigue: 2 }] },
      wrap: { label: 'Wrap it in leather first', out: [{ w: 1, text: 'Careful work. It stays calm in your pack.', gold: 3 }] },
      leave: { label: 'Leave it', out: [{ w: 1, text: 'It hums on behind you, unbothered.' }] } } },
  mirage_well: { zones: ['ashen'], title: 'A well in the dunes',
    text: 'A stone well stands alone in the sand. The rope is new. Someone was here recently.',
    options: {
      drink: { label: 'Drink deeply', out: [
        { w: 6, text: 'Cold, clean water. You feel restored.', fatigue: -1 },
        { w: 2, text: 'Salt. You spend the next mile coughing.', fatigue: 1 }] },
      search: { label: 'Look down the well', out: [
        { w: 3, text: 'A pouch is tied to the bottom of the bucket. Someone\'s hiding place.', gold: 4, note: 'Smugglers hide coin in the desert wells.' },
        { w: 4, text: 'A face looks back up at you. You leave quickly.', note: 'Something lives in the desert wells.' }] },
      wait: { label: 'Hide and see who comes back', out: [
        { w: 4, text: 'A smuggler. You trail them to their stash.', gold: 3, item: 'uncommon', fatigue: 1 },
        { w: 4, text: 'Nobody comes. You lose an hour.', fatigue: 1 }] } } },
  sparring_knight: { zones: ['promptwood', 'frostfang', 'thundercrag', 'archive', 'ashen'], title: 'A knight wants a duel',
    text: 'A knight in dented armour blocks the road. "Cross blades with me, for honour!"',
    options: {
      accept: { label: 'Accept the duel', out: [
        { w: 5, text: 'A good bout. You win, and learn a trick or two.', xp: 3, fatigue: 1 },
        { w: 3, text: 'They win, and give you advice you did not want.', xp: 2, fatigue: 1, note: 'Knights on the road fight low and to the left.' }] },
      decline: { label: 'Decline politely', out: [{ w: 1, text: 'They bow and step aside. "Another time."' }] },
      trick: { label: 'Agree, then trip them', out: [
        { w: 4, text: 'They go down in a clatter. You take their coin as "honour".', gold: 3, note: 'You cheated a knight. Knights talk.' },
        { w: 3, text: 'They saw it coming. A very long lecture follows.', fatigue: 1 }] } } },
};

// v2: how each option resolves. Outcomes: { text, gold, xp (level-scaled steps), item (rarity), fatigue, note }.
export const ATTR = { mig: 'Might', agi: 'Agility', vit: 'Vitality', int: 'Intellect', spi: 'Spirit', pre: 'Presence' };
export const DC = { easy: 0.7, normal: 1, hard: 1.4 };
export const HOW = {
  wounded_traveller: {
    help: { type: 'check', stat: 'spi', dc: 'normal', what: 'read whether they are honest',
      win: { text: 'They are honest. Grateful, they press a pouch of coins into your hand and point out a shortcut.', gold: 3, xp: 1, note: 'Travellers on these roads remember a kindness.' },
      lose: { text: 'It was a trick. While you knelt, their friend lifted your coin purse.', gold: -3, note: 'Not every wounded traveller is wounded.' } },
    search: { type: 'check', stat: 'pre', dc: 'normal', what: 'ask without offending',
      win: { text: 'They open the pack: bread and maps. They give you a map.', xp: 1, note: 'A map of the back roads shows a hidden glade.' },
      lose: { text: 'Offended, they limp off. You find a dropped trinket where they sat.', item: 'common' } },
    leave: { type: 'sure', out: { text: 'You walk on. The road is quiet, and so is your conscience, mostly.' } } },
  riddle_door: {
    answer: { type: 'check', stat: 'int', dc: 'normal', what: 'be sure of the answer',
      win: { text: 'The door grinds open onto a small vault.', item: 'rare', xp: 1, note: 'The talking doors favour those who think like a scribe.' },
      lose: { text: '"Close, but no." A puff of dust knocks you flat for a moment.', fatigue: 1 } },
    force: { type: 'check', stat: 'mig', dc: 'hard', what: 'break the door',
      win: { text: 'It gives! Behind it, a forgotten stash.', gold: 4 },
      lose: { text: 'Something cracks. Not the door. You find a few coins in the rubble anyway.', gold: 1, fatigue: 1 } },
    leave: { type: 'sure', out: { text: 'The lips mutter something rude as you walk away.' } } },
  shady_merchant: {
    buy: { type: 'check', stat: 'int', dc: 'normal', what: 'tell a real blade from a fake',
      win: { text: 'You check the steel first: barely cursed indeed, and a decent find.', gold: -2, item: 'rare' },
      lose: { text: 'It is a painted stick. The merchant is already gone.', gold: -2, note: 'Merchants with many rings sell painted sticks.' } },
    haggle: { type: 'check', stat: 'pre', dc: 'normal', what: 'talk them down',
      win: { text: 'You talk them down to half and walk off with a trinket.', gold: -1, item: 'uncommon' },
      lose: { text: 'They take offence and spit on your boots.' } },
    threaten: { type: 'fight', what: 'beat their bodyguard',
      win: { text: 'Their bodyguard steps out from behind the cart and goes down. The merchant hands the blade over, shaking.', item: 'uncommon', xp: 1, note: 'Word spreads about who threatens merchants.' },
      lose: { text: 'Their bodyguard steps out from behind the cart. You leave bruised.', fatigue: 2 } } },
  shrine: {
    offer: { type: 'check', stat: 'spi', dc: 'easy', what: 'be heard',
      win: { text: 'Warmth spreads through you. You feel sharper.', gold: -1, xp: 3 },
      lose: { text: 'Nothing happens. The gold is gone all the same.', gold: -1 } },
    pray: { type: 'check', stat: 'spi', dc: 'normal', what: 'hear the shrine',
      win: { text: 'You feel calm and rested, and a voice whispers a secret about the road ahead.', xp: 1, fatigue: -1, note: 'The shrines whisper where the old vaults lie.' },
      lose: { text: 'You feel calm, and a little rested.', xp: 1 } },
    pry: { type: 'check', stat: 'agi', dc: 'hard', what: 'pry it loose before anything notices',
      win: { text: 'It pops free. Worth a fair bit.', gold: 5, note: 'You robbed a shrine. You wonder if anything noticed.' },
      lose: { text: 'Lightning cracks from a clear sky. You come to an hour later.', fatigue: 2 } } },
  lost_child: {
    search: { type: 'check', stat: 'spi', dc: 'normal', what: 'track the goat',
      win: { text: 'You find it eating a scarecrow. The family feeds you and sends you off with a gift.', xp: 2, item: 'common', note: 'The farmsteads along this road look after their friends.' },
      lose: { text: 'The goat finds you first, and headbutts you into a ditch.', xp: 1, fatigue: 1 } },
    directions: { type: 'sure', out: { text: 'They nod and run off. You hope it was the right farm.', xp: 1 } },
    ignore: { type: 'sure', out: { text: 'The crying fades behind you.' } } },
  gambling_dwarf: {
    bet: { type: 'luck', out: [{ w: 5, text: 'Sixes! The dwarf laughs and pays up.', gold: 4 }, { w: 5, text: 'Snake eyes. The dwarf laughs harder.', gold: -3 }] },
    small: { type: 'luck', out: [{ w: 5, text: 'You win a little and hear a good story.', gold: 1, note: 'The dwarves say the peaks hide a frozen stair.' }, { w: 5, text: 'You lose a little and hear a good story.', gold: -1, note: 'The dwarves say the peaks hide a frozen stair.' }] },
    cheat: { type: 'check', stat: 'agi', dc: 'hard', what: 'swap the dice unseen',
      win: { text: 'Nobody notices. You clean them out.', gold: 6, note: 'You cheated at dice, and got away with it.' },
      lose: { text: 'The dwarf notices. So does the dwarf\'s axe.', gold: -2, fatigue: 2, note: 'Dwarves know loaded dice by the sound.' } } },
  bandit_toll: {
    pay: { type: 'sure', out: { text: 'They take the coin and let you pass, sniggering.', gold: -2 } },
    fight: { type: 'fight', what: 'beat three bandits',
      win: { text: 'They were not expecting that. You take their purse.', gold: 3, xp: 2, fatigue: 1 },
      lose: { text: 'Three is a lot. They take it out of your hide, and your purse.', gold: -2, fatigue: 2 } },
    talk: { type: 'check', stat: 'pre', dc: 'normal', what: 'convince them you are the taxman',
      win: { text: 'You convince them you are a tax collector. They pay YOU.', gold: 2, note: 'Bandits on the bridge are scared of the taxman.' },
      lose: { text: 'They do not buy it. You pay double.', gold: -4 } } },
  strange_book: {
    read: { type: 'check', stat: 'int', dc: 'normal', what: 'master the shifting words',
      win: { text: 'The words settle into a lesson you will not forget.', xp: 4 },
      lose: { text: 'The words settle into your head and refuse to leave. You need a lie-down.', fatigue: 2, note: 'Some books in the Archive read you back.' } },
    keep: { type: 'check', stat: 'spi', dc: 'normal', what: 'calm the book so it stays',
      win: { text: 'It settles in your pack. A rare tome: collectors will want it.', item: 'rare' },
      lose: { text: 'It flaps out of your pack an hour later and flies home.', note: 'Archive books always fly home.' } },
    shelve: { type: 'sure', out: { text: 'It purrs. You feel like the Archive likes you a little more.', xp: 1, note: 'The Archive is kinder to those who shelve its books.' } } },
  frozen_climber: {
    climb: { type: 'check', stat: 'mig', dc: 'normal', what: 'haul them up the ice',
      win: { text: 'You haul them up. They give you their spare charm.', item: 'uncommon', xp: 2 },
      lose: { text: 'You both slide down the ice. Everyone lives; everyone hurts.', fatigue: 2, xp: 1 } },
    rope: { type: 'sure', out: { text: 'They swing to safety and thank you warmly.', xp: 1, note: 'Climbers on the Frostfang owe you a favour.' } },
    leave: { type: 'sure', out: { text: 'You hear the rope snap behind you.', note: 'You left a climber on the ice.' } } },
  storm_crystal: {
    grab: { type: 'check', stat: 'vit', dc: 'normal', what: 'take the shock',
      win: { text: 'It stings, but you hold on. It sells for a fortune.', gold: 5, fatigue: 1 },
      lose: { text: 'It discharges. Your hair will never be the same.', fatigue: 2 } },
    wrap: { type: 'sure', out: { text: 'Careful work. It stays calm in your pack.', gold: 3 } },
    leave: { type: 'sure', out: { text: 'It hums on behind you, unbothered.' } } },
  mirage_well: {
    drink: { type: 'check', stat: 'vit', dc: 'easy', what: 'stomach whatever is in it',
      win: { text: 'Cold, clean water. You feel restored.', fatigue: -1 },
      lose: { text: 'Salt. You spend the next mile coughing.', fatigue: 1 } },
    search: { type: 'check', stat: 'spi', dc: 'normal', what: 'see what hides below',
      win: { text: 'A pouch is tied to the bottom of the bucket. Someone\'s hiding place.', gold: 4, note: 'Smugglers hide coin in the desert wells.' },
      lose: { text: 'A face looks back up at you. You leave quickly.', note: 'Something lives in the desert wells.' } },
    wait: { type: 'check', stat: 'agi', dc: 'normal', what: 'trail them unseen',
      win: { text: 'A smuggler. You trail them to their stash.', gold: 3, item: 'uncommon', fatigue: 1 },
      lose: { text: 'Nobody comes, or nobody you could keep up with. You lose an hour.', fatigue: 1 } } },
  sparring_knight: {
    accept: { type: 'fight', what: 'win the duel',
      win: { text: 'A good bout. You win, and learn a trick or two.', xp: 3, fatigue: 1, note: 'Knights on the road fight by the book: strong opening, then they tire.' },
      lose: { text: 'They win, and give you advice you did not want.', xp: 2, fatigue: 1, note: 'Knights on the road fight low and to the left.' } },
    decline: { type: 'sure', out: { text: 'They bow and step aside. "Another time."' } },
    trick: { type: 'check', stat: 'agi', dc: 'normal', what: 'trip them before they see it',
      win: { text: 'They go down in a clatter. You take their coin as "honour".', gold: 3, note: 'You cheated a knight. Knights talk.' },
      lose: { text: 'They saw it coming. A very long lecture follows.', fatigue: 1 } } },
};
// Who an encounter's fights are against: a hireling (a full Agent with class gear, level-matched) or monsters.
// lvl: levels relative to the Agent.
// hp and dmg: multipliers so each fight is a real test. Tuned with standard geared Agents of every class at levels
// 8-35: the knight wins about 23% of the time (shadowsteps lose most), the bodyguard 23%, the bandits 20%
// (more at low levels, where three is a lot).
export const FOES = {
  sparring_knight: [{ hire: 'sellsword', name: 'Knight of the Road', lvl: 1, hp: 1.6, dmg: 1.2 }],
  shady_merchant: [{ hire: 'cutpurse', name: "Merchant's Bodyguard", lvl: 1, hp: 1.2, dmg: 1.1 }],
  bandit_toll: [{ mob: 'bandit_raider', lvl: 1, hp: 1.6, dmg: 1.1 }, { mob: 'bandit_raider', lvl: 0, hp: 1.6, dmg: 1.1 }, { mob: 'bandit_raider', lvl: 0, hp: 1.6, dmg: 1.1 }],
};
// Handling it your own way: what the game pays on success or failure, whatever the plan.
const OWN_DEFAULT = { win: { xp: 2, gold: 1 }, lose: { fatigue: 1 } };
export const OWN = { bandit_toll: { win: { xp: 2, gold: 2 }, lose: { gold: -2, fatigue: 1 } }, sparring_knight: { win: { xp: 3 }, lose: { xp: 1, fatigue: 1 } } };
export const APPROACHES = {
  talk: { stat: 'pre', label: 'talk, charm or bluff' }, sneak: { stat: 'agi', label: 'sneak, slip away or sleight of hand' },
  clever: { stat: 'int', label: 'think it through, spot the trick' }, force: { stat: 'mig', label: 'force, lift or break' },
  endure: { stat: 'vit', label: 'tough it out' }, insight: { stat: 'spi', label: 'read people, nature or magic' },
  fight: { fight: true, label: 'fight' },
};
export const ENC_FORMAT = 2;

const snapOf = (action) => [action.snap, ...(action.party || [])][action.me || 0] || action.snap;
// The Agent's attributes on this trip (class, levels, points, training, race and gear).
export function scoresOn(action) { const sn = snapOf(action); return sn ? makeAgentUnit(sn, { level: sn.level || 1 }).scores : null; }
export const parFor = (level) => 8 + 0.6 * (level || 1);
// Chance a check succeeds: 1 or 0 when the Agent is clearly strong or weak enough, in between only on a close call.
export function checkChance(score, level, dc = 'normal') {
  const ratio = (score || 0) / (parFor(level) * (DC[dc] ?? 1));
  return ratio >= 1.25 ? 1 : ratio <= 0.5 ? 0 : Math.round(((ratio - 0.5) / 0.75) * 100) / 100;
}
export const oddsWord = (c) => (c >= 1 ? 'sure to work' : c <= 0 ? 'hopeless' : c >= 0.7 ? 'likely' : c >= 0.4 ? 'a close call' : 'unlikely');

// The foes of an encounter's fight, as battle units at the Agent's level.
function foeUnits(key, level) {
  return (FOES[key] || []).map((f, j) => {
    const L = Math.max(1, level + (f.lvl || 0));
    const u = f.hire ? makeAgentUnit({ ...hirelingSnapshot(f.hire, L), name: f.name }, { id: `foe${j}`, level: L }) : makeMobUnit(f.mob, L, `foe${j}`);
    if (u && f.hp) u.hpMult = (u.hpMult || 1) * f.hp;
    if (u && f.dmg) u.foeMult = (u.foeMult || 1) * f.dmg;
    return u;
  }).filter(Boolean);
}
// The real fight of an encounter choice (seeded: the same on every page): { won, log }.
export function encounterFight(action, enc) {
  const sn = snapOf(action); if (!sn || !FOES[enc.key]) return null;
  const L = sn.level || 1, me = makeAgentUnit(sn, { id: 'agent', level: L });
  const res = simulate(`encounter|${action.seed}|${action.who || ''}|${enc.i}`, [me], foeUnits(enc.key, L));
  return { won: res.winner === 'A', log: res.log };
}
// How a v2 choice would go, before choosing: per option and per own approach { type, stat, score, need, chance, foes }.
export function encounterOdds(action, enc) {
  const sc = scoresOn(action), L = snapOf(action)?.level || 1, H = HOW[enc.key] || {};
  const one = (h) => h.type === 'check' ? { type: 'check', stat: h.stat, score: sc?.[h.stat] || 0, need: Math.round(parFor(L) * (DC[h.dc] ?? 1)), chance: checkChance(sc?.[h.stat], L, h.dc) } : { type: h.type };
  const foes = (FOES[enc.key] || []).map(f => f.hire ? `${f.name}, a level ${Math.max(1, L + (f.lvl || 0))} ${hirelingSnapshot(f.hire, 1).cls}` : `a level ${Math.max(1, L + (f.lvl || 0))} ${MOBS[f.mob]?.name}`);
  const own = Object.fromEntries(Object.entries(APPROACHES).filter(([k]) => k !== 'fight' || foes.length).map(([k, a]) => [k, a.fight ? { type: 'fight' } : one({ type: 'check', stat: a.stat, dc: 'normal' })]));
  return { options: Object.fromEntries(Object.entries(H).map(([k, h]) => [k, one(h)])), own, foes, scores: sc, level: L };
}

export const ZONE_OF = (action) => action.type === 'patrol' ? action.zone || 'promptwood'
  : action.type === 'quest' ? QUESTS.find(q => q.id === action.quest)?.zone || 'promptwood'
  : action.type === 'dungeon' ? DUNGEONS[action.dungeon]?.zone || 'promptwood'
  : action.type === 'explore' ? SITES[action.site]?.zone || 'promptwood' : null;

// The encounters a trip holds: one usually, two on long ones. Each happens at a moment between fights (`frac` of
// the trip, 0..1). Seeded per Agent (`who`), so party members each meet their own.
export function encountersFor(action) {
  if (!['patrol', 'quest', 'dungeon', 'explore'].includes(action?.type) || !action.seed) return [];
  const zone = ZONE_OF(action), r = makeRng(`encounters|${action.seed}|${action.who || ''}`);
  const minutes = Math.round(((action.endsAt || 0) - (action.startedAt || 0)) / 60000);
  const n = r() < 0.75 ? (minutes >= 180 && r() < 0.5 ? 2 : 1) : 0;
  const pool = Object.keys(ENCOUNTERS).filter(k => ENCOUNTERS[k].zones.includes(zone));
  const out = [];
  for (let i = 0; i < n && pool.length; i++) {
    const k = pool.splice(Math.floor(r() * pool.length), 1)[0];
    out.push({ i, key: k, frac: n === 1 ? 0.3 + r() * 0.4 : (i + 0.4 + r() * 0.3) / n });
  }
  return out;
}

// A choice: an option key (old trips), or { opt, v: 2, ... }; "own" needs an approach this encounter allows.
export function validChoice(key, choice) {
  const opt = typeof choice === 'string' ? choice : choice?.opt;
  if (opt === 'own') { const a = APPROACHES[choice?.approach]; return !!ENCOUNTERS[key] && !!a && (!a.fight || !!FOES[key]); }
  return !!ENCOUNTERS[key]?.options?.[opt];
}
// A clean own-way choice from Claude's reply (texts trimmed), or null.
export function ownChoice(key, o) {
  const c = { opt: 'own', approach: String(o?.approach || ''), plan: String(o?.plan || '').replace(/\s+/g, ' ').trim().slice(0, 200),
    win: String(o?.win || '').replace(/\s+/g, ' ').trim().slice(0, 220), lose: String(o?.lose || '').replace(/\s+/g, ' ').trim().slice(0, 220) };
  return c.plan && validChoice(key, c) ? c : null;
}
const labelOf = (key, c) => c.opt === 'own' ? (c.plan || `Handle it my own way (${APPROACHES[c.approach]?.label})`) : ENCOUNTERS[key].options[c.opt].label;
export const choiceLabel = (key, choice) => labelOf(key, typeof choice === 'string' ? { opt: choice } : choice);

// What happens, scaled to the Agent's level: { text, gold, xp, fatigue, item, note }.
// choice: an option key (old trips: their weighted outcomes) or a v2 choice object. how: how it was decided
// ({ type, stat, score, need, chance, won }) so the page can say why it went the way it did.
export function resolveEncounter(action, enc, choice, level) {
  const E = ENCOUNTERS[enc.key], c = typeof choice === 'string' ? { opt: choice } : (choice || {});
  const L = Math.max(1, level || 1), zone = ZONE_OF(action);
  const pay = (pick, how, text) => {
    const res = { key: enc.key, opt: c.opt, title: E.title, choice: c.opt === 'own' ? labelOf(enc.key, c) : (E.options[c.opt] || Object.values(E.options).at(-1)).label, text: text || pick.text || '',
      gold: Math.round((pick.gold || 0) * (5 + L)), xp: Math.round((pick.xp || 0) * (10 + 2 * L)), fatigue: pick.fatigue || 0, note: pick.note || null, item: null, how };
    if (pick.item) res.item = rollItem(`${action.seed}|enc${enc.i}|${action.who || ''}`, L, 'patrol', zone, { source: E.title, opts: { rarity: pick.item } });
    return res;
  };
  const r = makeRng(`encounter|${action.seed}|${action.who || ''}|${enc.i}|${c.opt}${c.opt === 'own' ? `|${c.approach}` : ''}`);
  // Before v2: the old weighted outcomes, so a trip shows what it showed when the choice was made.
  if (c.v !== ENC_FORMAT && c.opt !== 'own') {
    const o = E?.options?.[c.opt] || Object.values(E.options).at(-1);
    let roll = r() * o.out.reduce((s, x) => s + x.w, 0), pick = o.out[0];
    for (const x of o.out) { roll -= x.w; if (roll < 0) { pick = x; break; } }
    return pay(pick, { type: 'luck' });
  }
  const sc = scoresOn(action), lv = snapOf(action)?.level || 1;
  const check = (stat, dc) => { const chance = checkChance(sc?.[stat], lv, dc); return { type: 'check', stat, score: sc?.[stat] || 0, need: Math.round(parFor(lv) * (DC[dc] ?? 1)), chance, won: chance >= 1 || (chance > 0 && r() < chance) }; };
  if (c.opt === 'own') {
    const a = APPROACHES[c.approach], stakes = OWN[enc.key] || OWN_DEFAULT;
    const how = a?.fight && FOES[enc.key] ? (() => { const f = encounterFight(action, enc); return { type: 'fight', won: !!f?.won }; })() : check(a?.stat || 'pre', 'normal');
    const said = how.won ? c.win : c.lose;
    return pay(how.won ? stakes.win : stakes.lose, how, said || (how.won ? `My way worked: ${c.plan}` : `My way did not work: ${c.plan}`));
  }
  const h = HOW[enc.key]?.[c.opt];
  if (!h) return pay({}, { type: 'sure' });
  if (h.type === 'sure') return pay(h.out, { type: 'sure' });
  if (h.type === 'luck') { let roll = r() * h.out.reduce((s, x) => s + x.w, 0), pick = h.out[0]; for (const x of h.out) { roll -= x.w; if (roll < 0) { pick = x; break; } } return pay(pick, { type: 'luck' }); }
  const how = h.type === 'fight' ? (() => { const f = encounterFight(action, enc); return { type: 'fight', won: !!f?.won }; })() : check(h.stat, h.dc);
  return pay(how.won ? h.win : h.lose, how);
}
// The battle log of an encounter choice that was a fight (for the fight knowledge and replays), or null.
export function encounterFightLog(action, enc, choice) {
  const c = typeof choice === 'string' ? { opt: choice } : (choice || {});
  if (c.v !== ENC_FORMAT && c.opt !== 'own') return null;
  const isFight = c.opt === 'own' ? APPROACHES[c.approach]?.fight : HOW[enc.key]?.[c.opt]?.type === 'fight';
  return isFight ? encounterFight(action, enc)?.log || null : null;
}

// What the Agent's own Claude is told. ctx: { name, cls, level, personality, gold, tired, lessons, notes }.
// The citable items the encounter prompt shows, for resolving its "because".
export const encounterCites = (ctx) => citeList({ personality: ctx.personality, lessons: (ctx.lessons || []).slice(0, 6), notes: (ctx.notes || []).slice(-6) });
export function encounterPrompt(ctx, enc, action) {
  const E = ENCOUNTERS[enc.key], C = citeList({ personality: ctx.personality, lessons: (ctx.lessons || []).slice(0, 8), notes: (ctx.notes || []).slice(-6) });
  const keyed = (kind) => C.filter(c => c.kind === kind).map(c => `- ${cite(c)} ${c.text}`).join('\n');
  const O = action ? encounterOdds(action, enc) : null;
  const how = (h, extra = '') => !h ? '' : h.type === 'check' ? ` [${ATTR[h.stat]} ${h.score} against ${h.need}${extra}: ${oddsWord(h.chance)}]`
    : h.type === 'fight' ? ` [a real fight against ${O.foes.join(' and ')}, with your gear, loadout and gambits]` : h.type === 'luck' ? ' [pure luck]' : ' [sure]';
  const what = (k) => HOW[enc.key]?.[k]?.what ? ` to ${HOW[enc.key][k].what}` : '';
  return [
    `You are ${ctx.name}, a level ${ctx.level} ${ctx.cls} in Agents of Claude, out on the road. Something happens:`,
    '', `${E.title}. ${E.text}`, '',
    ctx.personality?.traits?.length ? `Your personality: ${C.filter(c => c.kind === 'trait').map(c => `${cite(c)} ${c.text}`).join(', ')}.` : '',
    O?.scores ? `Your attributes: ${Object.entries(ATTR).map(([k, n]) => `${n} ${O.scores[k]}`).join(', ')}. A check compares one of them with what the task needs: clearly enough always works, clearly too little always fails, only a close call is up to chance.` : '',
    `You carry ${ctx.gold} gold. Fatigue: ${ctx.tired}.`,
    ctx.lessons?.length ? `Your lessons (fight knowledge, then field lessons):\n${keyed('lesson')}` : '',
    ctx.notes?.length ? `Things you have learned on the road:\n${keyed('note')}` : '',
    '', 'What do you do? Choose in character, and play to your strengths.',
    ...Object.entries(E.options).map(([k, o]) => `- ${k}: ${o.label}${how(O?.options?.[k], what(k))}`),
    O ? `- own: handle it your own way. Describe your plan and pick what you rely on: ${Object.entries(O.own).map(([k, h]) => `${k} (${APPROACHES[k].label}${h.type === 'check' ? `, ${ATTR[h.stat]} ${h.score} against ${h.need}: ${oddsWord(h.chance)}` : ', a real fight'})`).join('; ')}.` : '',
    '', 'Reply with only JSON: {"choice":"<key>","why":"<your reason, in character, at most 20 words>","because":["L1"]}',
    O ? 'Or your own way: {"choice":"own","approach":"<talk|sneak|clever|force|endure|insight|fight>","plan":"<what you do, one sentence>","win":"<how it plays out if it works, one sentence>","lose":"<how it plays out if it fails, one sentence>","why":"...","because":["L1"]}' : '',
    BECAUSE_HINT,
  ].filter(x => x !== '').join('\n');
}

// Without Claude: the personality leans the choice (kind helps, bold fights, greedy grabs, cautious walks on).
const LEAN = [
  [/kind|warm|loyal|gentle|patient|attentive|sentimental/i, ['help', 'search', 'climb', 'rope', 'pray', 'shelve', 'directions']],
  [/bold|brash|proud|stubborn|ambitious|restless|blunt/i, ['fight', 'accept', 'force', 'climb', 'grab', 'bet']],
  [/sly|greedy|teasing|cheeky|shameless|grudging/i, ['cheat', 'trick', 'pry', 'threaten', 'haggle', 'keep', 'search']],
  [/observant|precise|inquisitive|curious|wise|careful/i, ['answer', 'read', 'search', 'wrap', 'wait', 'small']],
];
export function heuristicEncounter(enc, personality, action = null) {
  const O = action ? encounterOdds(action, enc) : null, ok = (k) => !O || O.options[k]?.type !== 'check' || O.options[k].chance >= 0.5;
  const opts = Object.keys(ENCOUNTERS[enc.key].options).filter(ok), traits = (personality?.traits || []).join(' ');
  if (!opts.length) { const safe = Object.keys(ENCOUNTERS[enc.key].options).find(k => HOW[enc.key]?.[k]?.type === 'sure') || Object.keys(ENCOUNTERS[enc.key].options).at(-1); return { opt: safe, why: 'Nothing here plays to my strengths. I keep it simple.', ...(O ? { v: ENC_FORMAT } : {}) }; }
  for (const [re, prefs] of LEAN) if (re.test(traits)) { const k = prefs.find(p => opts.includes(p)); if (k) return { opt: k, why: 'It felt like the right thing to do.', ...(O ? { v: ENC_FORMAT } : {}) }; }
  return { opt: opts[0], why: 'Seemed sensible.', ...(O ? { v: ENC_FORMAT } : {}) };
}
