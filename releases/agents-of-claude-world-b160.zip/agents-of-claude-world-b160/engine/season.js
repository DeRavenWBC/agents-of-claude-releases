import { TZ_OFFSET_MS, TZ_ISO, worldDay, dayAt } from './worldtime.js';
// Agents of Claude — seasons, titles and cosmetic dyes.

export const SEASONS = [
  { id: 1, name: 'Season 1: The Storm Rises', start: '2026-11-23', end: '2027-02-22',
    blurb: 'The Whispering Archive and Thundercrag Spire open, the Ranger and Hexer join the guild, and something enormous wakes every Monday.' },
];
export function currentSeason(ms) {
  const day = worldDay(ms);
  return SEASONS.find(s => day >= s.start && day < s.end) || SEASONS.filter(s => s.start <= day).at(-1) || SEASONS[0];
}
export const seasonEndsIn = (s, ms) => dayAt(s.end) - ms;
export const seasonTitle = (s, rank) => `S${s.id} ${rank} Duelist`;

// Dyes recolour your Agent's clothing. ctx: { level, galaWins, bossKills, eloPeak, secrets, hidden, duels }.
export const DYES = {
  default: { name: 'Guild colours', c: null, C: null, how: 'Always available', unlocked: () => true },
  ember: { name: 'Ember', c: '#b8452f', C: '#7f2a1c', how: 'Win 5 duels', unlocked: (x) => (x.duelWins || 0) >= 5 },
  frost: { name: 'Frost', c: '#9fd6f0', C: '#5f9ab8', how: 'Reach Platinum in duels', unlocked: (x) => (x.eloPeak || 0) >= 1400 },
  storm: { name: 'Storm', c: '#e7d14a', C: '#8a7a1c', how: 'Help defeat a world boss', unlocked: (x) => (x.bossKills || 0) >= 1 },
  gilded: { name: 'Gilded', c: '#e7b53d', C: '#b48a26', how: 'Win an Arena Gala', unlocked: (x) => (x.galaWins || 0) >= 1 },
  ink: { name: 'Ink', c: '#2b2236', C: '#15101c', how: 'Find three secrets', unlocked: (x) => (x.secrets || 0) >= 3 },
  verdigris: { name: 'Verdigris', c: '#4fa88f', C: '#2f6b5a', how: 'Reach level 50', unlocked: (x) => (x.level || 0) >= 50 },
  mythic: { name: 'Mythweave', c: '#ff8a3c', C: '#b2502a', how: 'Discover five hidden abilities', unlocked: (x) => (x.hidden || 0) >= 5 },
};
export const unlockedDyes = (ctx) => Object.entries(DYES).filter(([, d]) => d.unlocked(ctx)).map(([k]) => k);
