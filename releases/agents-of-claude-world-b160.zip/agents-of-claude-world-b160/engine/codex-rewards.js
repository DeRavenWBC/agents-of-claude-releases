// The Strange Door chain's reward pick, shared by world.js and codex.js without an import cycle.
import { makeRng } from './rng.js';

export function doorReward(seed, owned = []) {
  const pool = ['hallucination', 'refactor', 'echo_first_prompt', 'ship_it'].filter(k => !owned.includes(k));
  if (!pool.length) return null;
  return pool[Math.floor(makeRng(`door|${seed}`)() * pool.length)];
}
