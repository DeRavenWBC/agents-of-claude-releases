// Agents of Claude — what actually raises an Agent's damage, in plain words, from the same rules battle.js uses.
// The item card's bonus tooltips ("Boosts: Firebolt, Meteor") and the Gear window's "How your damage works" read it.
//
// A hit's element comes from the ability (or proc) that deals it; an "affinity" ability takes the Agent's affinity
// (the element it wears most). "+X% <element> damage" multiplies only hits of that element: it never adds an element
// to other attacks. A hit in the Agent's own affinity element deals 10% more. Physical attacks are cut by armour,
// everything else by magic resist. Elements: fire beats nature, nature beats storm, storm beats frost, frost beats
// fire (×1.5 one way, ×0.67 the other); radiant and shadow beat each other.

import { ABILITIES } from './battle.js';
import { AFFIXES } from './items.js';

const ELEM_OF_AFFIX = Object.fromEntries(Object.entries(AFFIXES).filter(([, a]) => a.elem).map(([k, a]) => [k, a.elem]));
export const POWER = {
  phys: { label: 'Physical power', from: 'Might (2 per point) and weapon power' },
  finesse: { label: 'Finesse power', from: 'Agility (1.6 per point) and weapon power' },
  spell: { label: 'Spell power', from: 'Intellect (2 per point), spell power and spell power %' },
  nature: { label: 'Nature power', from: 'Spirit (1.5 per point) and half your healing power' },
};
const BEATS = { fire: 'nature', nature: 'storm', storm: 'frost', frost: 'fire', radiant: 'shadow', shadow: 'radiant' };
const BEATEN_BY = Object.fromEntries(Object.entries(BEATS).map(([a, b]) => [b, a]));
const cap = (s) => s ? s[0].toUpperCase() + s.slice(1) : s;
const list = (xs) => xs.length <= 1 ? (xs[0] || '') : `${xs.slice(0, -1).join(', ')} and ${xs.at(-1)}`;

const powerOf = (ab) => ab.power === 'finesse' ? 'finesse' : ab.power === 'spirit' ? 'nature' : ab.kind === 'phys' ? 'phys' : 'spell';
const deals = (ab) => !!ab && (ab.kind === 'phys' || ab.kind === 'spell') && (ab.coef || ab.coefs);

// Everything the Agent hits with: { key, name, element, power, vs, how } for its basic attack, ultimate, loadout and procs.
// loadout: the sanitized loadout (ability keys); procs: computeGear(...).procs; affinity: computeGear(...).affinity.
export function attacks({ cls, loadout = [], procs = [], affinity = 'physical', ultimate = null }) {
  const own = Object.entries(ABILITIES).filter(([, a]) => a.cls === cls);
  const basic = own.find(([, a]) => a.basic)?.[0], ult = ultimate || own.find(([, a]) => a.ultimate)?.[0];
  const keys = [...new Set([basic, ult, ...loadout].filter(Boolean))];
  const out = keys.map(k => [k, ABILITIES[k]]).filter(([, a]) => deals(a)).map(([k, a]) => {
    const element = a.element === 'affinity' ? (affinity || 'physical') : a.element || 'physical';
    return { key: k, name: a.name, element, power: powerOf(a), vs: a.kind === 'phys' ? 'armour' : 'magic resist',
      how: k === basic ? 'basic attack' : k === ult ? 'ultimate' : 'loadout', affinityBased: a.element === 'affinity' };
  });
  for (const p of procs || []) out.push({ key: p.id, name: p.name, element: p.element || 'physical', power: 'spell', vs: 'magic resist', how: 'item proc' });
  return out;
}

// What one item bonus (affix key) does for this Agent, as a short line for its tooltip.
export function affixBoost(k, atks, { affinity = 'physical' } = {}) {
  const names = (f) => atks.filter(f).map(a => a.name);
  const elem = ELEM_OF_AFFIX[k];
  if (elem) {
    const hit = names(a => a.element === elem);
    if (hit.length) return `Boosts your ${cap(elem)} attacks: ${list(hit)}.`;
    const via = atks.filter(a => a.affinityBased).map(a => a.name);
    return `None of your attacks deal ${cap(elem)} damage, so this does nothing for you`
      + (via.length ? ` (yet: wear mostly ${cap(elem)} gear to make ${list(via)} ${cap(elem)}).` : '. It never turns other damage into ' + cap(elem) + '.');
  }
  const by = (p) => names(a => a.power === p);
  switch (k) {
    case 'mig': { const h = by('phys'); return (h.length ? `Raises physical power: ${list(h)}.` : 'None of your attacks use physical power.') + ' Also a little block chance.'; }
    case 'agi': { const h = by('finesse'); return (h.length ? `Raises finesse power: ${list(h)}. ` : '') + 'Also crit chance, dodge and speed (more actions), which help every attack.'; }
    case 'int': { const h = by('spell'); return (h.length ? `Raises spell power: ${list(h)}.` : 'None of your attacks use spell power.') + ' Also more mana.'; }
    case 'spi': { const h = by('nature'); return (h.length ? `Raises nature power: ${list(h)}. ` : '') + 'Also healing power, mana regeneration, magic resist and status resist.'; }
    case 'crit': return 'Every attack can crit (except damage over time).';
    case 'critDmg': return 'Every crit hits harder, including always-crit abilities.';
    case 'speed': return 'More actions in a fight: more of every attack.';
    case 'lifesteal': return 'Heals you for part of the damage you deal.';
    case 'thorns': return 'Hits back part of the damage attackers deal to you.';
    case 'vit': return 'Max HP and armour: survival, not damage.';
    case 'pre': return 'Presence: more threat (monsters focus you) and leadership; not damage.';
    default: return '';
  }
}

// The "How your damage works" summary: attacks grouped by power, what feeds each, element notes and the gear bonuses.
export function damageSummary({ cls, loadout, procs, affinity = 'physical', elem = {}, ultimate = null }) {
  const atks = attacks({ cls, loadout, procs, affinity, ultimate });
  const powers = [...new Set(atks.map(a => a.power))].map(p => ({ key: p, ...POWER[p], attacks: atks.filter(a => a.power === p).map(a => a.name) }));
  const elements = [...new Set(atks.map(a => a.element))];
  const bonuses = Object.entries(elem || {}).filter(([, v]) => v).map(([el, v]) => {
    const hit = atks.filter(a => a.element === el).map(a => a.name);
    return { element: el, pct: v, attacks: hit, wasted: !hit.length };
  });
  const aff = affinity && affinity !== 'physical' ? {
    element: affinity, strong: BEATS[affinity] || null, weak: BEATEN_BY[affinity] || null,
    boosted: atks.filter(a => a.element === affinity).map(a => a.name),
  } : null;
  return { attacks: atks, powers, elements, bonuses, affinity: aff };
}
