// What identifies an old-rules record in the frozen list (engine/trusted.js): who, when, and the result it claims.
const s = (v) => String(v ?? '').slice(0, 120);
export const boutKey = (b) => `${s(b.id)}|${s(b.c)}|${s(b.d)}|${s(b.at)}|${s(b.winner)}|${s(b.hash)}`;
export const duelKey = (r) => `${s(r.id)}|${s(r.a)}|${s(r.b)}|${s(r.winner)}|${s(r.hash)}`;
export const bossKey = (uid, a) => `${s(uid)}|${s(a.week)}|${s(a.day)}|${s(a.dmg)}|${s(a.hash)}`;
