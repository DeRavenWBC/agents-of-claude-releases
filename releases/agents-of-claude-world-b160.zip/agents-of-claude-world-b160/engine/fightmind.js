// Agents of Claude — fight knowledge: one pool that every fight feeds and every fight decision reads.
//
// After each fight (a duel, a Pit bout, a world boss attempt, the fights of a trip) the page works out a digest
// straight from the battle log (exact numbers: damage to HP, absorbed by shields, blocked, missed, what hurt the
// Agent, when Sudden Death began, how much healing it smothered) and files it in the mind map as an outcome of the
// decision that led to the fight. Claude then reflects on the pending fights and rewrites the pool: lessons (each
// citing the fights that taught it, so the mind map links outcome → taught → lesson) and short notes per foe.
// Duel picks, gambit set-ups, stat spending, duel answers and the autopilot's plans all read this pool and cite
// its lessons in their "because", so every fight decision builds on it.
//
// journal.fight: { lessons: [text], foes: { key: note }, fights, byKind: { duel, pit, boss, trip }, pending: [fight], updatedAt }
// Foe keys: a player's id, 'ghost:<name>' for a practice ghost, 'mob:<monster key>' for a monster.

export const FIGHT_LESSONS_MAX = 16;
export const FOES_MAX = 30;
export const PENDING_MAX = 12;
export const REFLECT_BATCH = 6;
export const emptyPool = () => ({ lessons: [], foes: {}, fights: 0, byKind: {}, pending: [], updatedAt: null });

// The pool, starting from the duel journal for players who learned before it existed: every duel lesson and
// rival note carries over, so nothing the Agent learned is lost.
export function poolOf(journal) {
  const j = journal || {};
  if (j.fight) return { ...emptyPool(), ...j.fight };
  const d = j.duel || {};
  return { ...emptyPool(), lessons: (d.lessons || []).slice(0, FIGHT_LESSONS_MAX), foes: { ...(d.opponents || {}) },
    fights: d.duels || 0, byKind: d.duels ? { duel: d.duels } : {} };
}

// Rules the reflection can rely on, so it explains a fight by what the engine did, not by guesswork.
export const RULES_FACTS = [
  'Sudden Death: after 60 actions every hit grows ×1.1 per action and healing shrinks ×0.9 per action.',
  'Armour cuts physical damage and magic resist cuts spells by A/(100+A) (200 armour cuts 67%). Block halves a physical hit.',
  'A shield soaks damage after every other reduction and lasts until broken; absorbed damage triggers no thorns or lifesteal.',
  'Guard halves the damage you take until your own next action; Riposte halves physical hits and strikes 80% back.',
  'In the Pit and Fair Duels healing is reduced and dodge counts 40%; Fair Duels put both Agents at level 30 with 2.5× HP.',
  'Monsters attack whoever they hold most threat against (Presence multiplies threat; taunts pull them); the Pit and duels have no threat.',
];

// Exact facts about one Agent's fights, from battle logs. uid: the Agent's unit in the logs.
export function digest(logs, uid, { names = (k) => k } = {}) {
  const d = { fights: 0, won: 0, lost: 0, actions: 0, dealt: 0, absorbed: 0, hits: 0, blocked: 0, crits: 0, missed: 0,
    taken: 0, takenBy: {}, healed: 0, lowest: 1, ko: 0, suddenAt: null, shieldsFaced: 0, byAbility: {}, biggest: null, used: {} };
  for (const log of logs) {
    if (!log?.length) continue; d.fights++;
    const start = log.find(e => e.t === 'start'), side = uid.slice(0, 1), max = {};
    for (const u of start?.units || []) max[u.uid] = u.maxHp || u.hp;
    let n = 0;
    for (const e of log) {
      if (e.t === 'act') { n = e.n || n + 1; if (e.uid === uid && !e.echo) d.used[e.ab] = (d.used[e.ab] || 0) + 1; if (n > 60 && d.suddenAt == null) d.suddenAt = d.actions + 61; }
      if (e.t === 'status' && e.status === 'shield' && !e.uid.startsWith(side)) d.shieldsFaced++;
      if (e.t === 'miss' && e.src === uid) d.missed++;
      if (e.t === 'dmg' && e.src === uid && !e.uid.startsWith(side)) {
        d.dealt += e.amt; d.absorbed += e.absorbed || 0;
        if (!e.dot) { d.hits++; if (e.blocked) d.blocked++; if (e.crit) d.crits++; }
        const a = (d.byAbility[e.ab] ||= { hits: 0, hp: 0, absorbed: 0 }); a.hits++; a.hp += e.amt; a.absorbed += e.absorbed || 0;
        const total = e.amt + (e.absorbed || 0);
        if (!d.biggest || total > d.biggest.amt) d.biggest = { ab: e.ab, amt: total, crit: !!e.crit };
      }
      if (e.t === 'dmg' && e.uid === uid) {
        d.taken += e.amt; const k = `${e.ab}${e.el && e.el !== 'physical' ? ` (${e.el})` : ''}`; d.takenBy[k] = (d.takenBy[k] || 0) + e.amt;
        if (max[uid]) d.lowest = Math.min(d.lowest, Math.max(0, e.hp) / max[uid]);
      }
      if (e.t === 'heal' && e.uid === uid) d.healed += e.amt;
      if (e.t === 'ko' && e.uid === uid) d.ko++;
      if (e.t === 'end') { if (e.winner === side) d.won++; else if (e.winner) d.lost++; }
    }
    d.actions += n;
  }
  d.name = names;
  return d;
}

// One line of facts for the mind map and the reflection. title: what the fight was ("Duel vs X (Arcanist)").
export function digestLine(d, title, result) {
  if (!d.fights) return '';
  const nm = (k) => (typeof d.name === 'function' ? d.name(k) : k);
  const pct = (x, y) => `${Math.round(100 * x / Math.max(1, y))}%`;
  const out = [`${title}: ${result || (d.fights > 1 ? `won ${d.won} of ${d.fights} fights` : d.won ? 'won' : 'lost')}.`];
  const reach = d.dealt + d.absorbed;
  out.push(`I dealt ${d.dealt} to HP${d.absorbed ? `, ${d.absorbed} absorbed by shields (${pct(d.absorbed, reach)})` : ''} over ${d.hits} hits${d.blocked ? `, ${d.blocked} blocked` : ''}${d.missed ? `, ${d.missed} missed` : ''}${d.crits ? `, ${d.crits} crits` : ''}.`);
  const top = Object.entries(d.byAbility).sort((a, b) => (b[1].hp + b[1].absorbed) - (a[1].hp + a[1].absorbed)).slice(0, 3)
    .map(([k, a]) => `${nm(k)} ${a.hits}× avg ${Math.round((a.hp + a.absorbed) / a.hits)}${a.absorbed ? ` (${pct(a.absorbed, a.hp + a.absorbed)} absorbed)` : ''}`);
  if (top.length) out.push(`Best: ${top.join(', ')}${d.biggest ? `; biggest hit ${nm(d.biggest.ab)} ${d.biggest.amt}${d.biggest.crit ? ' crit' : ''}` : ''}.`);
  const hurt = Object.entries(d.takenBy).sort((a, b) => b[1] - a[1]).slice(0, 3).map(([k, v]) => `${nm(k.split(' (')[0])}${k.includes('(') ? ` ${k.slice(k.indexOf('('))}` : ''} ${v}`);
  out.push(`Took ${d.taken}${hurt.length ? ` (${hurt.join(', ')})` : ''}; lowest HP ${pct(d.lowest, 1)}${d.ko ? `, knocked out ${d.ko}×` : ''}; healed ${d.healed}.`);
  if (d.suddenAt) out.push(`Sudden Death began at action ${d.suddenAt}.`);
  if (d.shieldsFaced) out.push(`Foes raised ${d.shieldsFaced} shield${d.shieldsFaced === 1 ? '' : 's'}.`);
  return out.join(' ').slice(0, 600);
}

// The reflection. fights: [{ key: 'F1', kind, line, detail }] (detail: a duel's picks and story, a trip's notes).
// foes: [{ key, name }] the foes in these fights.
// retired: fight lessons from long-term memory (newest first): shown so a lesson that holds again comes back.
export function reflectPrompt(ctx, fights, pool, foes, retired = []) {
  const p = { ...emptyPool(), ...(pool || {}) };
  return [
    `You are ${ctx.name}, a level ${ctx.level} ${ctx.cls} Agent in Agents of Claude. Your fight knowledge is one pool of lessons that you read before every fight decision: duel picks, your gambits and loadout, Pit challenges, world boss attempts and trips. You just fought:`,
    ...fights.flatMap(f => [`[${f.key}] (${f.kind}) ${f.line}`, ...(f.detail ? [f.detail] : [])]),
    '', 'Rules you can rely on:', ...RULES_FACTS.map(x => `- ${x}`),
    '', 'Your fight lessons now:', ...(p.lessons.length ? p.lessons.map(l => `- ${l}`) : ['(none yet)']),
    retired.length ? `\nLessons you retired earlier (kept in your long-term memory; bring one back if these fights show it holds):\n${retired.slice(0, 10).map(l => `- ${l}`).join('\n')}` : '',
    foes.length ? `\nYour notes on these foes:\n${foes.map(f => `- ${f.key} (${f.name}): ${p.foes[f.key] || '(none)'}`).join('\n')}` : '',
    '', `Rewrite your fight lessons so you fight better everywhere. Ground every new lesson in the numbers above (never guess why something happened when the rules explain it), keep lessons that still hold (including duel tactics: round timing, Guard, Focus, when to use the ultimate, how specific rivals play), merge duplicates and drop what these fights disproved. Say where a lesson applies when it matters (duels, the Pit, monsters, a class or a foe). At most ${FIGHT_LESSONS_MAX}, one concrete sentence each.`,
    foes.length ? `Also rewrite your note on each foe above: their habits and how to beat them, one short paragraph.` : '',
    `Reply with only JSON: {"lessons": [{"text": "...", "from": ["F1"]}], "foes": {"<foe key>": "<note>"}}, where "from" lists the fights a new or changed lesson comes from (empty for one you kept as it was).`,
  ].filter(x => x !== '').join('\n');
}

// Apply a reflection: the new pool, and which fights taught each lesson ({ lessonText: [fight line] }).
export function applyReflection(pool, out, fights, foeKeys = []) {
  const p = { ...emptyPool(), ...(pool || {}) }, sources = {};
  if (Array.isArray(out?.lessons)) {
    const next = [];
    for (const x of out.lessons) {
      const text = String(typeof x === 'string' ? x : x?.text || '').replace(/\s+/g, ' ').trim().slice(0, 260);
      if (!text || next.includes(text)) continue;
      next.push(text);
      const from = (Array.isArray(x?.from) ? x.from : []).map(k => fights.find(f => f.key === String(k).trim())?.line).filter(Boolean);
      if (from.length) sources[text] = from;
    }
    if (next.length) p.lessons = next.slice(0, FIGHT_LESSONS_MAX);
  }
  const foes = { ...p.foes };
  for (const [k, v] of Object.entries(out?.foes && typeof out.foes === 'object' ? out.foes : {})) {
    if (!foeKeys.includes(k) || typeof v !== 'string' || !v.trim()) continue;
    delete foes[k]; foes[k] = v.replace(/\s+/g, ' ').trim().slice(0, 600);   // most recent last
  }
  const keys = Object.keys(foes); for (const k of keys.slice(0, Math.max(0, keys.length - FOES_MAX))) delete foes[k];
  return { pool: { ...p, foes, updatedAt: new Date().toISOString() }, sources };
}

// File a fight in the pool, waiting for reflection. fight: { id, kind, line, detail, foes: [{ key, name }], at }.
export function addFight(pool, fight) {
  const p = { ...emptyPool(), ...(pool || {}) };
  return { ...p, fights: (p.fights || 0) + 1, byKind: { ...p.byKind, [fight.kind]: (p.byKind?.[fight.kind] || 0) + 1 },
    pending: [...(p.pending || []).filter(f => f.id !== fight.id), fight].slice(-PENDING_MAX) };
}
// Take reflected fights off the pending list.
export const settle = (pool, ids) => ({ ...pool, pending: (pool.pending || []).filter(f => !ids.includes(f.id)) });

// The lessons and foe notes a fight decision should see: all lessons, plus notes on the foes involved.
export function knowledgeFor(pool, foeKeys = []) {
  const p = { ...emptyPool(), ...(pool || {}) };
  return { lessons: p.lessons, notes: foeKeys.filter(k => p.foes[k]).map(k => p.foes[k]) };
}
