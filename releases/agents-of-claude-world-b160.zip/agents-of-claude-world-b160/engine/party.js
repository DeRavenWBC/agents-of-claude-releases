// Agents of Claude — joint dungeon runs.
//
// A run with guildmates needs everyone's agreement. Nobody writes anyone else's record:
//   1. The leader writes an invite into their own `social/<leader>` doc (field `party`).
//   2. Each invited player answers in their own `social/<them>` doc (field `reply`), with their Agent's snapshot.
//   3. When nobody is still deciding and at least one accepted, the leader starts the run: the invite gains
//      `started` (seed, start and end time, the ordered party and its snapshots).
//   4. Every member's page sees the start and puts its own Agent on the same run (same seed, same party order,
//      so the same fights; own loot via `who`). The member is busy, away from the tavern, until it ends.
// Accepting commits you: you can't start anything else until the run starts, the invite lapses or you leave.
//
// Agents can be busy (on a quest, a patrol, in a dungeon) on both sides. The invite carries `freeAt` (when the leader
// will be back), and a reply carries `freeAt` (when that member will be back). A yes from a busy member says "after my
// trip": once back, their page rewrites the reply with `ready: true` and a fresh snapshot. The leader waits for every
// yes to be ready; a member who said yes but is not back long after they said they would be is left behind.

import { fnv1a } from './rng.js';
import { CONTENT_V } from './world.js';
import { ownerOf } from './family.js';

export const INVITE_MS = 5 * 60_000;    // time to answer, from when the invite is sent: Agents answer at once, so nobody is held up
export const MAX_WAIT_MS = 4 * 3_600_000; // nobody waits longer than this from the invite: a later yes can't be given
export const LATE_MS = 20 * 60_000;     // a yes not ready this long after its freeAt is left behind
export const answerBy = (p) => p.at + INVITE_MS;
export const MAX_GUESTS = 2;            // a party is the leader plus two
// A raid (`kind: 'raid'`, Beyond the Veil stage 4, engine/raid.js) is the leader plus five: six different players (one
// character per family), no hirelings, and it goes only when all five said yes and are ready.
export const MAX_RAID_GUESTS = 5;
export const guestCap = (p) => (p?.kind === 'raid' ? MAX_RAID_GUESTS : MAX_GUESTS);
// A raid's guest list: real characters, none of the leader's family, at most one per family (the first one named).
function raidGuests(leader, ids) {
  const seen = new Set([ownerOf(leader)]), out = [];
  for (const id of ids) { const o = ownerOf(id); if (!o || seen.has(o)) continue; seen.add(o); out.push(id); }
  return out;
}
export const partyId = (leader, at) => `p-${at.toString(36)}-${fnv1a(`${leader}|${at}`).slice(0, 6)}`;

// A party goes on a dungeon (`kind: 'dungeon'`, dungeon, difficulty) or a quest (`kind: 'quest'`, quest, path).
// Every live party from the social docs: { id, leader, kind, dungeon | quest, at, invited, members[], started, ready }.
// members: { uid, state: 'pending' | 'accepted' | 'declined' | 'lapsed', snap, freeAt, ready, late }.
//   ready: said yes and is free to go now (a reply without `ready` from before busy answers counts as ready).
//   late: said yes, is not ready, and is well past when they said they would be back.
// The party: ready (everyone answered, a yes exists, every yes is ready or late, at least one ready), waitUntil (the
// latest freeAt among the yeses that are still coming), answerBy.
export function parties(socialDocs, now) {
  const out = [];
  for (const [leader, doc] of Object.entries(socialDocs || {})) {
    const p = doc?.party;
    // A malformed invite is no invite: it must never stop every page's party list.
    if (!p || typeof p !== 'object' || typeof p.id !== 'string' || !p.id || p.leader !== leader || p.cancelled || !Number.isFinite(p.at) || p.at > now + 60_000 || !Array.isArray(p.invited ?? [])
      || (p.started && (typeof p.started !== 'object' || !Number.isFinite(p.started.endsAt) || !Array.isArray(p.started.order)))) continue;
    const by = answerBy(p);
    const ids = (p.invited || []).filter(u => typeof u === 'string' && u && u !== leader);
    const invited = (p.kind === 'raid' ? raidGuests(leader, ids) : ids).slice(0, guestCap(p));
    const members = invited.map(uid => {
      const r = socialDocs[uid]?.reply;
      const mine = r?.id === p.id && r.leader === leader ? r : null;
      const state = mine ? (mine.accept ? 'accepted' : 'declined') : now > by ? 'lapsed' : 'pending';
      const freeAt = Number.isFinite(mine?.freeAt) ? mine.freeAt : (mine?.at || p.at);
      const ready = state === 'accepted' && !!mine.snap && (mine.ready ?? true);
      return { uid, state, snap: state === 'accepted' ? mine.snap || null : null, freeAt, ready, late: state === 'accepted' && !ready && now > freeAt + LATE_MS };
    });
    const yes = members.filter(m => m.state === 'accepted'), coming = yes.filter(m => !m.ready && !m.late);
    if (p.started) { if (now > p.started.endsAt) continue; }
    // Unstarted: gone past the longest wait, when nobody is left to wait for, or when the leader never started it
    // (it gets LATE_MS to start after the last yes is ready or left behind, counting its own return too).
    else if (now > p.at + MAX_WAIT_MS || (now > by && !yes.some(m => !m.late)) || now > Math.max(by, p.freeAt || 0, ...yes.map(m => m.freeAt)) + 2 * LATE_MS) continue;
    // A raid goes only with all six: every guest said yes and is ready (anyone late or saying no means it cannot go).
    const ready = p.kind === 'raid' ? !p.started && members.length === MAX_RAID_GUESTS && members.every(m => m.state === 'accepted' && m.ready)
      : !p.started && members.every(m => m.state !== 'pending') && yes.some(m => m.ready) && !coming.length;
    out.push({ ...p, invited, members, ready, answerBy: by, waitUntil: coming.length ? Math.max(...coming.map(m => m.freeAt)) : null });
  }
  return out;
}
// Who this player is waiting for in a party that hasn't left, and until when: the leader waits for every yes still out;
// a member who said yes waits for the leader (if it is out) and the other yeses still out. null: nobody to wait for.
// Both sides may fill the time with something that is over by `until` (the page asks the steward, fitPlan).
export function waitFor(p, uid, now) {
  if (!p || p.started) return null;
  const coming = p.members.filter(m => m.uid !== uid && m.state === 'accepted' && !m.ready && !m.late && m.freeAt > now);
  const out = coming.map(m => ({ uid: m.uid, at: m.freeAt }));
  if (p.leader !== uid) {
    if (!p.members.some(m => m.uid === uid && m.state === 'accepted')) return null;
    if ((p.freeAt || 0) > now) out.push({ uid: p.leader, at: p.freeAt });
  }
  return out.length ? { until: Math.max(...out.map(x => x.at)), who: out.map(x => x.uid) } : null;
}
// May this member still say yes? Only if they will be back before the party's longest wait runs out.
export const canWaitFor = (p, freeAt) => freeAt <= p.at + MAX_WAIT_MS - LATE_MS;

export const invitesFor = (uid, list) => list.filter(p => !p.started && p.members.some(m => m.uid === uid && m.state !== 'lapsed'));
export const ledBy = (uid, list) => list.find(p => p.leader === uid) || null;
// The party this player has said yes to and that has not started yet (they are committed to it).
export const committedTo = (uid, list) => list.find(p => !p.started && p.members.some(m => m.uid === uid && m.state === 'accepted')) || null;
// A started run this player belongs to.
export const runFor = (uid, list) => list.find(p => p.started && (p.leader === uid || p.started.order.includes(uid))) || null;

// The `started` record the leader writes. order: member ids in party order (leader first), then hirelings as `hire:<key>`.
export function startRun(p, { leaderSnap, hires = [], now, minutes, seed }) {
  const accepted = p.members.filter(m => m.state === 'accepted' && m.ready && m.snap);
  if (p.kind === 'raid') hires = [];   // no hirelings in a raid
  const order = [p.leader, ...accepted.map(m => m.uid), ...hires.map(h => `hire:${h.key}`)].slice(0, 1 + guestCap(p));
  const snaps = [leaderSnap, ...accepted.map(m => m.snap), ...hires.map(h => h.snap)].slice(0, 1 + guestCap(p))
    .map((s, i) => ({ ...s, agentId: order[i].startsWith('hire:') ? undefined : order[i] }));
  return { at: now, seed: seed || `${p.leader}|joint|${p.id}`, endsAt: now + minutes * 60_000, order, snaps, cv: CONTENT_V };
}

// The action a member stores in their own progress: the shared run, seen from their place in it.
export function memberAction(p, uid) {
  const st = p.started, me = st.order.indexOf(uid);
  if (me < 0) return null;
  const what = p.kind === 'quest' ? { type: 'quest', quest: p.quest, ...(p.path ? { path: p.path } : {}) } : { type: 'dungeon', dungeon: p.dungeon, difficulty: p.kind === 'raid' ? 'normal' : p.difficulty };
  const players = st.order.filter(id => !id.startsWith('hire:'));
  // A dungeon with two or more players shares its loot, settled drop by drop as it falls (engine/loot.js). A raid's
  // loot is personal (each raider's own rolls, engine/raid.js).
  const pooled = p.kind !== 'quest' && p.kind !== 'raid' && players.length > 1 ? { pooled: true, players } : {};
  // cv: the content version the leader's run was started under (every member resolves the same rooms).
  // A raid's difficulty (engine/raid.js RAID_TIERS) rides as `tier`; a party from before difficulties has none (Heroic).
  if (p.kind === 'raid' && typeof p.tier === 'string') what.tier = p.tier;
  return { ...what, seed: st.seed, startedAt: st.at, endsAt: st.endsAt, snap: st.snaps[0], party: st.snaps.slice(1), me, who: uid, joint: p.id, leader: p.leader, ...pooled, ...(st.cv ? { cv: st.cv } : {}) };
}
