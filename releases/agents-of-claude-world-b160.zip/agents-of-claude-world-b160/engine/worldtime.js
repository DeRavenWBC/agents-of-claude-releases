// Agents of Claude — the world's clock.
//
// Every world keeps one fixed offset from UTC: days, weeks, the Friday Gala, the Monday boss and hour-based secrets all
// run on it, and every page must use the same one (results are replayed by everyone). The first world runs on South
// Africa Standard Time. A world for another organization gets its own copy of this file (tools/bundle.mjs --tz):
// nothing else in the game names a timezone. Use a fixed offset, not a zone with daylight saving.
export const TZ_OFFSET_MS = 2 * 3_600_000;   // ahead of UTC
export const TZ_ISO = '+02:00';              // the same offset as ISO text
export const TZ_LABEL = 'SAST';              // what the game calls it
// For showing times: a fixed-offset zone name the browser knows (whole hours only; note the reversed sign).
export const TZ_NAME = `Etc/GMT${TZ_OFFSET_MS > 0 ? '-' : '+'}${Math.abs(TZ_OFFSET_MS) / 3_600_000}`.replace('Etc/GMT+0', 'Etc/GMT').replace('Etc/GMT-0', 'Etc/GMT');
export const worldDay = (ms) => new Date(ms + TZ_OFFSET_MS).toISOString().slice(0, 10);      // YYYY-MM-DD on the world's clock
export const worldHour = (ms) => new Date(ms + TZ_OFFSET_MS).getUTCHours();
export const worldWeekday = (ms) => new Date(ms + TZ_OFFSET_MS).getUTCDay();                  // 0 Sunday
export const dayAt = (day, hhmm = '00:00') => Date.parse(`${day}T${hhmm}:00${TZ_ISO}`);       // a moment on a world day
