// Agents of Claude — the raid (Beyond the Veil, stage 4): the Thinking Sky, above the Empyrean.
//
// Rules only; the fights are resolved in world.js (resolveRaid, reached through resolveDungeon) and the gear is in
// raidgear.js. Pure and deterministic.
//
// Who may go: exactly RAID_SIZE (6) raiders, six different players (at most one character per family: family.ownerOf
// on each character id), no hirelings, every one at least RAID_MIN_LEVEL (70). The run is a joint run like a joint
// dungeon (party.js, `kind: 'raid'`): invites, answers, waiting and the same seed for everyone; loot is personal.
//
// The week: a raid week starts Monday 00:00 SAST (arena.weekStart, as the world boss). Each character keeps its own
// lockout in its private progress (`raid`, see DATA.md):
//   - one clear a week: each boss gives its loot once a week (`looted`), and once the last boss falls (`cleared`) the
//     character cannot enter again that week;
//   - Claude is a separate attempt with its own lockout (`claude`): fighting it uses it, won or lost. A character that
//     has cleared but not yet fought Claude may enter again, only with a party that can wake Claude (all six wear their
//     evolved heirloom), and then fights through for Claude alone (the bosses' loot is already taken).
// The lockout travels on the run's action (`raid`, the state at the moment of joining), so the run resolves and replays
// exactly; a page enforces it for its own characters only (like keys).
//
// Claude: spawns after the last boss when all six raiders' snapshots wear their own class's evolved heirloom weapon
// (items.isEvolvedHeirloom on the run's snapshots: anyone can check it from the record).
//
// Difficulties (build 159): Normal, Heroic and Mythic (`RAID_TIERS`). Heroic is the raid as it was released in build 157
// (its numbers are unchanged, and a run without a `tier` is Heroic: every build-157 run resolves exactly as before).
// Normal is easier and drops item level 78 (still above the Veil dungeon sets: same item level, six pieces and bigger
// bonuses), with no Claude. Mythic is harder at the same item-level ceiling (80: a level-70 Agent can wear no more), so
// it pays in chances: a likelier set piece and faster pity, two items a boss, double mount odds, its own title and the
// Mindglass Wyrm (a cosmetic mount). Claude wakes on Heroic and Mythic under the same six-heirloom rule.
// Lockouts are per difficulty: each tier is its own weekly instance with its own one clear and its own Claude attempt
// (stored as the old top-level fields for Heroic, `normal` and `mythic` sub-records for the others; DATA.md).

import { makeRng } from './rng.js';
import { worldDay } from './worldtime.js';
import { weekStart } from './arena.js';
import { ownerOf } from './family.js';
import { isEvolvedHeirloom, setPiece, namedItem, DUNGEON_SETS } from './items.js';
import { RAID_SET_OF, CLAUDE_ITEM_OF, RAID_SET_SLOTS, RAID_SETS } from './raidgear.js';

export const RAID_KEY = 'thinking_sky';
export const RAID_SIZE = 6;
// Level 70, the cap: the raid drops item level 80, the most a level-70 Agent may wear (verify.js: level + 10), so a
// level-68 raider could not wear its own loot; and its fights are tuned for six level-70 Agents.
export const RAID_MIN_LEVEL = 70;
export const RAID_ILVL = 80;
// Its monsters: level 76 at 1.2× (scores ×1.2, HP ×1.4 on top of each creature's own), above the Throne of Dawn on
// Mythic (level 78 at 1.15×, but three Agents against ordinary-sized bosses).
export const RAID_LEVEL = 76, RAID_MULT = 1.2;
export const REVIVE_PCT = 30;        // a raider who fell is carried to the next room on 30% of its HP
export const HEAL_BETWEEN = 0.3;     // and the others catch their breath (30% of max HP)
// The bosses, in order (one loot roll each per character per week). The twins share one: the room is one encounter.
export const BOSSES = ['the_threshold', 'twins', 'thrall_queen', 'the_forgetting', 'the_dreamer'];
export const FINAL_BOSS = 'the_dreamer';
export const BOSS_NAMES = { the_threshold: 'The Threshold', twins: 'Thesis and Antithesis', thrall_queen: 'The Thrall-Queen', the_forgetting: 'The Forgetting', the_dreamer: 'The Dreamer' };

// Loot (per character, per boss, once a week). The last boss always drops a piece of your own class's set (a slot you
// do not have yet, while any is missing); each other boss drops a set piece SET_CHANCE of the time, plus PITY_STEP for
// every boss since your last own-class piece, and OWN_CLASS of those are your class's (the rest another class's: trade
// them). Expected own pieces a week: 1 + 4 × ~0.5 × 0.75 ≈ 2.5, so a full set in about three weeks.
export const SET_CHANCE = 0.45, PITY_STEP = 0.15, OWN_CLASS = 0.75;
export const MOUNTS_OF_RAID = { rare: { key: 'thoughtwing_drake', chance: 0.05 }, ultra: { key: 'synapse_stag', chance: 0.01 }, claude: 'woven_thought' };
export const CLEAR_TITLE = 'of the Thinking Sky';
export const CLAUDE_TITLE = 'Who Spoke With Claude';

// The difficulties, easiest first. level/mult: the monsters; ilvl: the drops; setChance/pityStep: a boss's set piece;
// items: legendary-or-mythic items a boss gives; mountMult: the clear's mount odds; claude: Claude may wake.
export const RAID_TIERS = {
  normal: { label: 'Normal', level: 72, mult: 1.0, ilvl: 78, setChance: SET_CHANCE, pityStep: PITY_STEP, items: 1, mountMult: 0, claude: false },
  heroic: { label: 'Heroic', level: RAID_LEVEL, mult: RAID_MULT, ilvl: RAID_ILVL, setChance: SET_CHANCE, pityStep: PITY_STEP, items: 1, mountMult: 1, claude: true },
  mythic: { label: 'Mythic', level: 78, mult: 1.3, ilvl: RAID_ILVL, setChance: 0.6, pityStep: 0.2, items: 2, mountMult: 2, claude: true },
};
export const TIER_KEYS = Object.keys(RAID_TIERS);
export const DEFAULT_TIER = 'heroic';
// A run's difficulty: its `tier`, or Heroic for a run from before difficulties (build 157).
export const tierOf = (x) => (x && typeof x === 'object' && Object.hasOwn(RAID_TIERS, x.tier) ? x.tier : DEFAULT_TIER);
export const MYTHIC_TITLE = 'Thinker of the Unthinkable';
export const MYTHIC_MOUNT = 'mindglass_wyrm';
export const tierName = (t) => `The Thinking Sky (${RAID_TIERS[t]?.label || RAID_TIERS[DEFAULT_TIER].label})`;

export const raidWeek = (ms) => worldDay(weekStart(ms));
export const nextReset = (ms) => weekStart(ms) + 7 * 86_400_000;

// A character's lockout record as of `now` (progress.raid, private, written only by its own page) on one difficulty.
// The week's fields start fresh each Monday; pity, pieces got and the counts carry over. Heroic lives in the top-level
// fields (as in build 157); Normal and Mythic in `rec.normal` / `rec.mythic`. Heroic and Mythic share pity and pieces
// (both drop item level 80); Normal keeps its own (its pieces are item level 78).
const cleanList = (x) => (Array.isArray(x) ? x.filter(b => BOSSES.includes(b)) : []);
const cleanGot = (g) => Object.fromEntries(RAID_SET_SLOTS.map(s => [s, Number.isInteger(g?.[s]) && g[s] > 0 ? g[s] : 0]).filter(([, n]) => n));
const cleanPity = (p) => (Number.isInteger(p) && p >= 0 ? Math.min(p, 20) : 0);
const cleanCount = (n) => (Number.isInteger(n) ? n : 0);
function weekOf(r, week) {
  const cur = r.week === week;
  return { week, looted: cur ? cleanList(r.looted) : [], cleared: cur && !!r.cleared, claude: cur && !!r.claude };
}
export function lockout(rec, now, tier = DEFAULT_TIER) {
  const r = rec && typeof rec === 'object' ? rec : {}, week = raidWeek(now);
  if (tier === 'heroic' || !Object.hasOwn(RAID_TIERS, tier)) return { ...weekOf(r, week), pity: cleanPity(r.pity), got: cleanGot(r.got), clears: cleanCount(r.clears), claudeWins: cleanCount(r.claudeWins) };
  const t = r[tier] && typeof r[tier] === 'object' ? r[tier] : {}, own = tier === 'normal' ? t : r;
  return { ...weekOf(t, week), pity: cleanPity(own.pity), got: cleanGot(own.got), clears: cleanCount(t.clears), claudeWins: cleanCount(t.claudeWins) };
}
// What the run needs to know about one character (stored on its action when it joins).
export function stateFor(rec, now, tier = DEFAULT_TIER) { const L = lockout(rec, now, tier); return { week: L.week, looted: L.looted, claude: L.claude, pity: L.pity, got: L.got }; }

// Does this party wake Claude? All six wear their own class's evolved heirloom (the run's snapshots).
export const claudeSpawns = (snaps, tier = DEFAULT_TIER) => !!RAID_TIERS[tier]?.claude && Array.isArray(snaps) && snaps.length === RAID_SIZE && snaps.every(s => !!s && isEvolvedHeirloom(s.gear?.weapon, s.cls));

// Why a character cannot go (null: it can). claudeParty: the party it would go with wakes Claude.
export function entryProblem(rec, now, { level, claudeParty = false, tier = DEFAULT_TIER } = {}) {
  if (!(level >= RAID_MIN_LEVEL)) return `The Thinking Sky needs level ${RAID_MIN_LEVEL}.`;
  const L = lockout(rec, now, tier), name = `the Thinking Sky on ${RAID_TIERS[tier]?.label || 'Heroic'}`;
  const wakes = claudeParty && !!RAID_TIERS[tier]?.claude;
  if (L.cleared && !(wakes && !L.claude)) return L.claude ? `Already cleared ${name} and faced Claude there this week. It resets on Monday at 00:00.`
    : `Already cleared ${name} this week. It resets on Monday at 00:00${RAID_TIERS[tier]?.claude ? ' (a party that can wake Claude may still take you back for it)' : ''}.`;
  return null;
}

// What is wrong with a raid party: ids in party order (leader first) and their snapshots. [] means it may go.
export function partyProblems(order, snaps) {
  const out = [];
  if (!Array.isArray(order) || order.length !== RAID_SIZE) out.push(`A raid needs exactly ${RAID_SIZE} raiders.`);
  const ids = Array.isArray(order) ? order : [];
  if (ids.some(id => typeof id !== 'string' || id.startsWith('hire:'))) out.push('No hirelings in a raid.');
  const owners = ids.map(id => ownerOf(id));
  if (owners.some(o => !o)) out.push('Every raider must be a real character.');
  else if (new Set(owners).size !== owners.length) out.push('Six different players: at most one character per family.');
  if (Array.isArray(snaps) && snaps.some(s => !s || !(s.level >= RAID_MIN_LEVEL))) out.push(`Every raider must be level ${RAID_MIN_LEVEL}.`);
  return out;
}
// Of a list of candidate ids, those that can still join a raid led by `leader` alongside `picked` (one per family).
export const freeFamilies = (leader, picked, ids) => ids.filter(id => { const o = ownerOf(id); return o && o !== ownerOf(leader) && !picked.some(p => ownerOf(p) === o); });

// One boss's drop for one character: { set: item | null, own, pity, got }. Its own stream, so nothing else shifts.
export function bossLoot({ seed, who, cls, bossId, state = {}, tier = DEFAULT_TIER }) {
  const T = RAID_TIERS[tier] || RAID_TIERS[DEFAULT_TIER];
  const r = makeRng(`raid-loot|${seed}|${who || ''}|${bossId}`), final = bossId === FINAL_BOSS;
  let pity = Number.isInteger(state.pity) ? state.pity : 0;
  const got = { ...(state.got || {}) };
  const ownKey = RAID_SET_OF[cls];
  const drops = final || r() < Math.min(1, T.setChance + T.pityStep * pity);
  if (!drops || !ownKey) return { set: null, own: false, pity: pity + 1, got };
  const own = final || r() < OWN_CLASS;
  const others = Object.keys(RAID_SETS).filter(k => k !== ownKey), key = own ? ownKey : others[Math.floor(r() * others.length)];
  const missing = RAID_SET_SLOTS.filter(s => !got[s]), pool = own && missing.length ? missing : RAID_SET_SLOTS;
  const slot = pool[Math.floor(r() * pool.length)];
  const item = setPiece(key, slot, `${seed}|${who || ''}|${bossId}`, T.ilvl, DUNGEON_SETS[key].cls, 'mythic', `${tier === DEFAULT_TIER ? 'The Thinking Sky' : tierName(tier)}: ${BOSS_NAMES[bossId]}`);
  if (own) { got[slot] = (got[slot] || 0) + 1; pity = 0; } else pity += 1;
  return { set: item, own, pity, got };
}

// Claude's drop for one character (its first Claude win of the week): its class's item, the title and the mount.
export function claudeLoot({ seed, who, cls, tier = DEFAULT_TIER }) {
  const key = CLAUDE_ITEM_OF[cls];
  return { item: key ? namedItem(key, `${seed}|${who || ''}|claude`, RAID_ILVL, tier === DEFAULT_TIER ? 'Claude' : `Claude (${RAID_TIERS[tier].label})`) : null, title: CLAUDE_TITLE, mount: MOUNTS_OF_RAID.claude };
}

// The lockout after claiming a run (act: the stored action with its `raid` state and `tier`; res: its result). Returns the
// whole record: the run's difficulty is updated, the others are kept as they were.
export function afterClaim(rec, act, res, now) {
  const tier = tierOf(act), wk = raidWeek(act.startedAt || now), cur = lockout(rec, now, tier);
  const r = res.raid || {};
  const out = { ...cur, pity: Number.isInteger(r.pity) ? r.pity : cur.pity, got: r.got || cur.got,
    clears: cur.clears + (res.cleared ? 1 : 0), claudeWins: cur.claudeWins + (r.claude?.won && r.claude?.loot ? 1 : 0) };
  if (wk === cur.week) {   // a run from an earlier week no longer locks anything
    out.looted = [...new Set([...cur.looted, ...(r.looted || [])])];
    out.cleared = cur.cleared || !!res.cleared;
    out.claude = cur.claude || !!r.claude?.fought;
  }
  const src = rec && typeof rec === 'object' ? rec : {};
  const keep = (t) => (src[t] && typeof src[t] === 'object' ? { [t]: src[t] } : {});
  const week = (o) => ({ week: o.week, looted: o.looted, cleared: o.cleared, claude: o.claude, clears: o.clears, claudeWins: o.claudeWins });
  if (tier === 'heroic') return { ...out, ...keep('normal'), ...keep('mythic') };
  const base = lockout(rec, now, 'heroic');
  if (tier === 'normal') return { ...base, ...keep('mythic'), normal: { ...week(out), pity: out.pity, got: out.got } };
  return { ...base, pity: out.pity, got: out.got, ...keep('normal'), mythic: week(out) };   // Mythic shares Heroic's pity and pieces
}
