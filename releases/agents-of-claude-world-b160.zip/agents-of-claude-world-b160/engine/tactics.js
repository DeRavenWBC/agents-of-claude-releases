// Agents of Claude — the Agent sets up its own build: the gambits (rules) its (every unlocked ability is available)
// automatic fights follow. Asked from the Loadout & gambits editor ("Let my Agent set it up") and, if the player
// allows it (autonomy `tactics`, opt-in), by the autopilot before each trip, knowing the foes ahead.
// The fights themselves stay automatic and seeded: this only changes the build that is snapshotted at the start.

import { ABILITIES, MOBS, CONDITIONS, unlockedActives, sanitizeLoadout, sanitizeGambits, gambitSlots } from './battle.js';
import { ZONES, QUESTS, DUNGEONS } from './world.js';
import { SITES } from './secrets.js';
import { citeList, cite, cleanBecause, BECAUSE_HINT } from './mind.js';

// The citable items a tactics prompt shows (personality, field lessons, things learned, recent outings), so the build
// is a decision like any other: it says what it rests on, and the mind map links them.
export const tacticsCites = (ctx) => citeList({ personality: ctx.personality, lessons: (ctx.lessons || []).slice(0, 14), notes: (ctx.notes || []).slice(-6), recent: (ctx.recent || []).slice(-5) });

// The foes a planned trip can meet, by mob key (unique, in order). plan: { do, zone, quest, path, dungeon, site }.
export function foesFor(plan) {
  const out = [], add = (list) => (list || []).forEach(k => { if (MOBS[k] && !out.includes(k)) out.push(k); });
  if (plan?.do === 'patrol') for (const e of ZONES[plan.zone]?.encounters || []) add(e.mobs);
  if (plan?.do === 'quest' || plan?.activity === 'quest') { const q = QUESTS.find(x => x.id === plan.quest); for (const f of q?.fights || []) add(f); for (const f of q?.paths?.[plan.path]?.fights || []) add(f); }
  if (plan?.do === 'dungeon' || plan?.activity === 'dungeon') for (const r of DUNGEONS[plan.dungeon]?.rooms || []) add(r.mobs);
  if (plan?.do === 'explore') for (const f of SITES[plan.site]?.fights || []) add(f);
  return out;
}
export function describeFoe(k) {
  const m = MOBS[k], abs = [m.basic, ...(m.abilities || [])].map(a => ABILITIES[a]).filter(Boolean);
  const casts = abs.some(a => a.kind === 'spell'), heals = abs.some(a => a.kind === 'heal');
  return `${m.name}${m.boss ? ' (boss)' : m.elite ? ' (elite)' : ''}: ${m.affinity || 'physical'} affinity${casts ? ', casts spells' : ''}${heals ? ', heals its allies' : ''}`;
}

// ctx: { name, cls (key), clsName, level, personality, itemAbilities, current: { loadout, gambits }, foes: [mobKey], lessons }
export function tacticsPrompt(ctx) {
  const actives = unlockedActives(ctx.cls, ctx.level, ctx.itemAbilities || []);
  const own = Object.entries(ABILITIES).filter(([, a]) => a.cls === ctx.cls);
  const basic = own.find(([, a]) => a.basic)?.[0], ult = ctx.ultimate || own.find(([, a]) => a.ultimate)?.[0];
  const ab = (k) => { const a = ABILITIES[k]; return `- ${k}: ${a.name} (${a.kind || 'attack'}${a.cost ? `, ${a.cost} mana` : ''}${a.cd ? `, ${a.cd}-action cooldown` : ''}). ${a.desc}`; };
  const cond = Object.entries(CONDITIONS).map(([k, c]) => `- ${k}: ${c.label}${c.param ? ` (${c.param.key}: ${c.param.kind === 'status' ? c.param.options.join('|') : `${c.param.min}-${c.param.max}`})` : ''}`);
  const C = tacticsCites(ctx), keyed = (kind) => C.filter(c => c.kind === kind).map(c => `- ${cite(c)} ${c.text}`);
  const L = [
    `You are ${ctx.name}, a level ${ctx.level} ${ctx.clsName} in Agents of Claude. Set up your own build for your automatic fights.`,
    C.some(c => c.kind === 'trait') ? `Your personality: ${C.filter(c => c.kind === 'trait').map(c => `${cite(c)} ${c.text}`).join(', ')}. Let it show in how you fight, but fight to win.` : '',
    '', 'Every ability you have unlocked is available in every fight:', ...actives.map(ab),
    '', 'Also always on:', ...[basic, ult].filter(Boolean).map(ab),
    '', `Gambits: up to ${gambitSlots(ctx.level)} rules, checked from the top each time you act. The first rule whose condition is true and whose ability is ready fires; if none fires you use your strongest ready attack. A rule naming an ability you have not unlocked is skipped.`,
    'Conditions:', ...cond,
    '', `Your gambits now: ${JSON.stringify(ctx.current?.gambits || [])}.`,
    ctx.foes?.length ? `\nThe foes ahead:\n${ctx.foes.map(k => `- ${describeFoe(k)}`).join('\n')}` : '\nNo particular trip ahead: set up a good all-round build.',
    ctx.party == null ? 'You may fight alone or in a party: write rules that work in both, using "I fight alone" and "Allies fighting with me" to switch.'
      : ctx.party.length ? `This trip you fight in a party with: ${ctx.party.join('; ')}.` : 'This trip you fight alone: rules for protecting or healing allies would waste actions.',
    'Threat: monsters attack whoever they hold most threat against. Presence multiplies the threat you make; damage to a monster adds to its threat, healing adds to every monster\'s, and a taunt pulls every monster onto you. A tank in a party taunts to keep them off the healer and casters (for example when "An ally (not me) was hit since my last turn", or when "I do not have" taunt); a healer heals others with "Another ally (not me) is below".',
    keyed('lesson').length ? `\nYour fight knowledge, then your field lessons (build on them):\n${keyed('lesson').join('\n')}` : '',
    keyed('note').length ? `\nYour notes on the foes ahead, and things learned on the road:\n${keyed('note').join('\n')}` : '',
    keyed('outcome').length ? `\nYour last outings, with how your build fought (rules that wasted actions, knock-outs, lowest HP):\n${keyed('outcome').join('\n')}` : '',
    '', 'Reply with only JSON: {"gambits":[{"if":{"type":"<condition>","pct":40},"use":"<ability key>"}],"why":"<one short sentence, in character>","because":["L1"]}',
    'Include a condition\'s number or status only when it takes one ("pct", "n" or "status").', BECAUSE_HINT,
  ];
  return L.filter(x => x !== '').join('\n');
}

// Keep only what the game allows; null if nothing usable came back. Gambits must name an ability the build can use.
export function validTactics(o, ctx) {
  if (!o || !Array.isArray(o.gambits)) return null;
  const loadout = sanitizeLoadout(ctx.cls, ctx.level, Array.isArray(o.loadout) ? o.loadout : null, ctx.itemAbilities || []);
  const own = Object.entries(ABILITIES).filter(([, a]) => a.cls === ctx.cls && (a.basic || a.ultimate)).map(([k]) => k);
  const usable = new Set([...loadout, ...own, ...(ctx.ultimate ? [ctx.ultimate] : [])]);
  const gambits = sanitizeGambits(ctx.cls, ctx.level, o.gambits).filter(g => usable.has(g.use));
  if (!gambits.length) return null;
  return { loadout, gambits, why: String(o.why || '').replace(/\s+/g, ' ').trim().slice(0, 200), because: cleanBecause(o.because) };
}
export const sameBuild = (a, b) => JSON.stringify([a?.loadout || [], a?.gambits || []]) === JSON.stringify([b?.loadout || [], b?.gambits || []]);

// How the Agent's build fought on a trip, from its fight logs (uid: the Agent's unit), as one short line for its
// outing record, the mind map and the field-lesson reflection. names: ability key -> name.
export function combatNotes(logs, uid, names = (k) => ABILITIES[k]?.name || k) {
  let fights = 0, won = 0, ko = 0, low = 1, alone = 0, ults = 0; const used = {};
  for (const log of logs) {
    if (!log?.length) continue; fights++;
    const start = log.find(e => e.t === 'start'), side = uid.slice(0, 1), hp = {}, max = {};
    for (const u of start?.units || []) { hp[u.uid] = u.hp; max[u.uid] = u.maxHp || u.hp; }
    for (const e of log) {
      if (e.t === 'dmg' || e.t === 'heal') { hp[e.uid] = e.hp; if (e.uid === uid) low = Math.min(low, e.hp / Math.max(1, max[uid])); }
      if (e.t === 'ko') { hp[e.uid] = 0; if (e.uid === uid) ko++; }
      if (e.t === 'act' && e.uid === uid) {
        used[e.ab] = (used[e.ab] || 0) + 1; if (e.ult) ults++;
        const allies = Object.keys(hp).filter(k => k !== uid && k.startsWith(side + ':') && hp[k] > 0).length;
        if (!allies && (ABILITIES[e.ab]?.effects || []).some(x => x.type === 'taunt')) alone++;
      }
      if (e.t === 'end' && e.winner === side) won++;
    }
  }
  if (!fights) return '';
  const top = Object.entries(used).sort((a, b) => b[1] - a[1]).slice(0, 4).map(([k, n]) => `${names(k)} x${n}`).join(', ');
  return `Fights: won ${won} of ${fights}${ko ? `, knocked out ${ko}` : ''}; lowest HP ${Math.round(100 * Math.max(0, low))}%; used ${top || 'nothing'}`
    + (alone ? `; taunted ${alone} time${alone === 1 ? '' : 's'} with no ally to protect (wasted)` : '') + '.';
}
