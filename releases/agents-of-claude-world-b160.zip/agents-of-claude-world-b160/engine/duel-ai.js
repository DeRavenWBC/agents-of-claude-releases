// Agents of Claude — the AI that fights your duels, and how it learns.
//
// Each round the page asks Claude (through the viewer's own `sample` capability) to pick one action,
// given the battle state and the Agent's Battle Journal. After each duel Claude reflects and rewrites the
// journal: short lessons plus notes per opponent. Claude Code can coach the same journal between duels.

import { ABILITIES, describe, STATUS_NAMES } from './battle.js';
import { optionsFor } from './duel.js';
import { cleanBecause } from './mind.js';

export const JOURNAL_MAX_LESSONS = 12;
export const emptyJournal = () => ({ lessons: [], opponents: {}, duels: 0, updatedAt: null });

const hpPct = (u) => Math.round(100 * u.hp / u.maxHp);
const st = (u) => u.statuses.map(s => `${STATUS_NAMES[s.type]?.split(' (')[0] || s.type}(${s.turns})`).join(', ') || 'none';

// The text Claude reads to choose a move. ctx: { journal, oppId, oppName, oppClass, myName, myClass, recent: [event lines] }.
export function pickPrompt(state, side, ctx) {
  const me = state.units.find(u => u.side === side && !u.summoned), foe = state.units.find(u => u.side !== side && !u.summoned);
  const pets = state.units.filter(u => u.summoned && u.alive).map(u => `${u.name} (${u.side === side ? 'yours' : 'theirs'}, ${hpPct(u)}% HP)`);
  const opts = optionsFor(state, side);
  const j = ctx.journal || emptyJournal();
  const lines = [
    ...(ctx.boss ? [
      `You are ${ctx.myName}, a ${ctx.myClass} Agent fighting ${ctx.oppName}, this week's world boss in Agents of Claude, live. You can't win outright: the boss fights until you fall. Your goal is the most damage before that, because every point comes off the boss's pool for your whole guild, and staying alive longer means more hits.`,
      `Each round you pick one action; the boss acts on its own. Extra actions from speed follow your gambits, except that one is skipped while you hold a Guard or Riposte you picked.`,
      `Boss rules: no Sudden Death, but the boss grows angrier the longer the fight goes (+3% damage per action after action 40). It meets you at your level, has a huge pool of HP, and resists some stuns and polymorphs.${ctx.bossNote ? ` What you know about it: ${ctx.bossNote}` : ''}`,
    ] : [
      `You are ${ctx.myName}, a ${ctx.myClass} Agent in a live duel in Agents of Claude, against ${ctx.oppName} (${ctx.oppClass}). Win the duel.`,
      `Each round both duelists secretly pick one action, then they resolve in speed order. Extra actions from speed follow your gambits, except that one is skipped while you hold a Guard or Riposte you picked.`,
      `Arena rules: healing is reduced, dodge is weaker, pets last 3 actions, and attacks target the rival rather than pets.`,
    ]),
    ``,
    `Round ${state.paused.round + 1}.`,
    `You: ${hpPct(me)}% HP (${me.hp}/${me.maxHp}), mana ${me.mana}/${me.maxMana}, ultimate charge ${me.charge}%, statuses: ${st(me)}.`,
    `${ctx.oppName}: ${hpPct(foe)}% HP (${foe.hp}/${foe.maxHp}), mana ${foe.mana}/${foe.maxMana}, ultimate charge ${foe.charge}%, statuses: ${st(foe)}.`,
    pets.length ? `Pets: ${pets.join('; ')}.` : null,
    ``,
    `What happened recently:`, ...(ctx.recent?.length ? ctx.recent.slice(-14) : [(ctx.boss ? '(the fight just started)' : '(the duel just started)')]),
    ``,
    `Your options (key: description):`,
    ...opts.map(o => `- ${o.key}${o.ready ? '' : ' [NOT READY' + (o.cd ? `, ${o.cd} turns cooldown` : '') + (o.cost ? `, costs ${o.cost} mana` : '') + ']'}: ${ABILITIES[o.key]?.name}. ${ABILITIES[o.key]?.desc || ''}${o.cost ? ` Costs ${o.cost} mana.` : ''}`),
    ``,
    j.lessons.length ? `Your fight knowledge (lessons from all your fights: duels, the Pit, monsters):\n${j.lessons.map((l, i) => `- [L${i + 1}] ${l}`).join('\n')}` : `You have no fight lessons yet: this is one of your first fights.`,
    j.opponents?.[ctx.oppId] ? `Your notes on ${ctx.oppName}: ${j.opponents[ctx.oppId]}` : null,
    ``,
    `Reply with only JSON: {"pick": "<one ready option key>", "why": "<one short sentence, in character>", "because": ["L2"]}, where "because" lists the keys of the lessons behind this pick (up to 3, or none).`,
  ];
  return lines.filter(x => x !== null).join('\n');
}

export function parsePick(out, state, side) {
  const ready = optionsFor(state, side).filter(o => o.ready).map(o => o.key);
  const pick = typeof out?.pick === 'string' ? out.pick.trim() : '';
  return { pick: ready.includes(pick) ? pick : 'auto', why: String(out?.why || '').slice(0, 160), because: cleanBecause(out?.because).filter(k => k.startsWith('L')) };
}

// After a duel: what happened, for reflection and for the duel log Claude Code can coach from.
export function duelSummary(log, names, rounds, side, result) {
  const lines = log.filter(e => ['act', 'dmg', 'heal', 'status', 'skip', 'ko', 'crowd'].includes(e.t)).map(e => (e.t === 'crowd' ? `The crowd roars for ${e.side === 'A' ? 'A' : 'B'}` : describe(e, names))).filter(Boolean);
  const say = (k) => (k === 'auto' ? 'gambits' : k);
  const mine = rounds.map(r => say(r[side === 'A' ? 0 : 1])), theirs = rounds.map(r => say(r[side === 'A' ? 1 : 0]));
  return { result, rounds: rounds.length, myPicks: mine, theirPicks: theirs, story: lines.slice(-60) };
}

export function reflectPrompt(summary, journal, ctx) {
  const j = journal || emptyJournal();
  return [
    `You are ${ctx.myName}, a ${ctx.myClass} Agent in Agents of Claude. You just ${summary.result === 'win' ? 'won' : summary.result === 'loss' ? 'lost' : 'drew'} a duel against ${ctx.oppName} (${ctx.oppClass}) in ${summary.rounds} rounds.`,
    `Your picks by round: ${summary.myPicks.join(', ')}.`,
    `Their picks by round: ${summary.theirPicks.join(', ')}.`,
    `How it went (last events):`, ...summary.story,
    ``,
    `Your current Battle Journal lessons:`, ...(j.lessons.length ? j.lessons.map(l => `- ${l}`) : ['(none yet)']),
    `Your current notes on ${ctx.oppName}: ${j.opponents?.[ctx.oppId] || '(none)'}`,
    ``,
    `Update your journal so you fight better next time. Keep lessons that still hold, merge duplicates, drop ones this duel disproved, and add what you learned. At most ${JOURNAL_MAX_LESSONS} lessons, each one concrete sentence about when to use which ability. Write one short paragraph of notes on ${ctx.oppName}: their habits and how to beat them.`,
    `Reply with only JSON: {"lessons": ["..."], "opponentNote": "..."}`,
  ].join('\n');
}

export function applyReflection(journal, out, oppId) {
  const j = { ...emptyJournal(), ...(journal || {}) };
  const lessons = Array.isArray(out?.lessons) ? out.lessons.filter(x => typeof x === 'string' && x.trim()).map(x => x.trim().slice(0, 240)).slice(0, JOURNAL_MAX_LESSONS) : j.lessons;
  const opponents = { ...(j.opponents || {}) };
  if (typeof out?.opponentNote === 'string' && out.opponentNote.trim()) opponents[oppId] = out.opponentNote.trim().slice(0, 500);
  // keep the journal small: notes on the 20 most recent opponents
  const keys = Object.keys(opponents); if (keys.length > 20) delete opponents[keys[0]];
  return { ...j, lessons, opponents, duels: (j.duels || 0) + 1, updatedAt: new Date().toISOString() };
}
