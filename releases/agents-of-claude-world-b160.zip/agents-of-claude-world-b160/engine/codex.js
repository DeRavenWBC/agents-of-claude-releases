// Agents of Claude — Codex (hidden abilities) and daily bounties (rules version 1).

import { makeRng } from './rng.js';
import { ZONES, ZONE_ORDER } from './world.js';
import { MOBS } from './battle.js';

/* --------------------------------------------------------------- Codex */
// `progress(ctx)` returns { have, need } for trackable feats; ctx = { usage, prog }.
// usage = { streak, shipped, crafted } from synced XP days; prog = the private progress doc.

export const CODEX = [
  { key: 'echo_first_prompt', name: 'Echo of the First Prompt', kind: 'Passive',
    hint: 'Return, day after day, for a whole moon.', how: 'A 30-day usage streak',
    progress: (c) => ({ have: c.usage.streak, need: 30 }) },
  { key: 'ship_it', name: 'Ship It', kind: 'Ultimate',
    hint: 'Ship a hundred times.', how: '100 real git commits made with Claude Code',
    progress: (c) => ({ have: c.usage.shipped, need: 100 }) },
  { key: 'refactor', name: 'Refactor', kind: 'Active',
    hint: 'Rewrite a thousand times; keep what works.', how: '1,000 Edit or Write uses in Claude Code',
    progress: (c) => ({ have: c.usage.crafted, need: 1000 }) },
  { key: 'hallucination', name: 'Hallucination', kind: 'Active',
    hint: 'Some oases are not there. Neither are some foes.', how: 'A 1% drop when you defeat the Mirage Djinn' },
  { key: 'strange_door', name: 'The Door Without a House', kind: 'Quest',
    hint: 'Some doors have no house.', how: 'A rare event on any patrol, then its quest chain' },
  { key: 'context_window', name: 'Context Window', kind: 'Passive', how: 'Read in the Archive\'s Reading Room seven times',
    hint: 'The archive remembers those who read every page.' },
  { key: 'token_storm', name: 'Token Storm', kind: 'Ultimate', how: "A flawless Heroic or Mythic clear of the Wyrm's Crown",
    hint: "The wyrm's storm answers only the flawless." },
  { key: 'nemesis_brand', name: 'Nemesis Brand', kind: 'Passive', how: 'Defeat your Nemesis three times, three times over',
    hint: "Your rival's mark, earned three times." },
];

// Abilities a usage feat unlocks right now (not yet owned).
export function earnedFeats(usage, owned = []) {
  return CODEX.filter(c => c.progress && !owned.includes(c.key)).filter(c => { const p = c.progress({ usage }); return p.have >= p.need; }).map(c => c.key);
}

export { doorReward } from './codex-rewards.js';

// Usage feats from synced XP day docs ({ day, raw, counts }), newest-first or any order.
export function usageFeats(days, today) {
  const byDay = new Map(days.map(d => [d.day, d]));
  let streak = 0;
  const step = (day) => new Date(Date.parse(day + 'T12:00:00Z') - 86_400_000).toISOString().slice(0, 10);
  // the streak may still count if today hasn't been used yet
  let d = byDay.get(today)?.raw > 0 ? today : step(today);
  while (byDay.get(d)?.raw > 0) { streak++; d = step(d); }
  const sum = (k) => days.reduce((n, x) => n + (x.counts?.[k] || 0), 0);
  return { streak, shipped: sum('shipped'), crafted: sum('craft') };
}

/* ------------------------------------------------------------- Bounties */
// Three a day per Agent, from the zones it can reach. Fixed by the Agent's id and the day.

export function dailyBounties(agentId, day, level) {
  const r = makeRng(`bounty|${agentId}|${day}`);
  const zones = ZONE_ORDER.filter(z => level >= (ZONES[z].unlock || 1));
  const zone = zones.at(-1);
  // Rows added later (`since`: swarms) are left out, so a day's board never changed when they arrived.
  const kinds = [...new Set(ZONES[zone].encounters.filter(e => !e.elite && !e.since).flatMap(e => e.mobs))];
  const pickKind = () => kinds[Math.floor(r() * kinds.length)];
  const a = pickKind(); let b = pickKind(); if (b === a && kinds.length > 1) b = kinds.find(k => k !== a);
  const scale = Math.max(1, Math.round(level / 5));
  return [
    { id: `${day}|kill|${a}`, type: 'kill', mob: a, zone, need: 8 + 2 * scale, label: `Defeat ${8 + 2 * scale} ${MOBS[a].name}s`, reward: { gold: 40 * scale, xp: 60 * scale, essence: 3 + scale } },
    { id: `${day}|kill|${b}`, type: 'kill', mob: b, zone, need: 6 + scale, label: `Defeat ${6 + scale} ${MOBS[b].name}s`, reward: { gold: 30 * scale, xp: 45 * scale, essence: 2 + scale } },
    { id: `${day}|wins`, type: 'wins', need: 12, label: 'Win 12 fights anywhere', reward: { gold: 50 * scale, xp: 80 * scale, essence: 5 + scale } },
  ];
}

// How much a claimed action result advances each bounty: mobs defeated (by kind) and fights won.
export function tallyResult(res) {
  const kills = {}; let wins = 0;
  for (const f of res.fights || []) {
    if (f.rest || f.winner !== 'A') continue;
    wins++;
    for (const m of f.mobs) kills[m.kind] = (kills[m.kind] || 0) + 1;
  }
  return { kills, wins };
}

export function bountyCount(b, tally) {
  return b.type === 'kill' ? (tally.kills?.[b.mob] || 0) : b.type === 'wins' ? (tally.wins || 0) : 0;
}
