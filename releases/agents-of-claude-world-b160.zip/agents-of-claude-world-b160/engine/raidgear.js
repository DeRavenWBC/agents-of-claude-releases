// Agents of Claude — the raid's gear (Beyond the Veil, stage 4): a six-piece set for each of the 13 classes, the
// thirteen items Claude drops (one per class) and the raid secrets' rewards. Pure data, merged into items.js
// (DUNGEON_SETS and NAMED, after every older entry). The raid's rules are in engine/raid.js.
//
// Raid sets (`raid: true`, `cls`): helm, shoulders, chest, gloves, boots and amulet, in the class's proficient weight
// (setPiece sizes them for `cls`), mythic, item level 80 (the most a level-70 Agent may wear: verify.js allows its
// level + 10). Bonuses at 2, 4 and 6 pieces, above the Veil dungeon sets (which stop at 5 pieces and item level 78).
// Pieces are ordinary generated items with a set tag, so verify.js checks them like any set piece: no new affix keys.
// The amulet carries no element; the armour carries the set's element, so a full set pulls affinity that way.

const af = (...xs) => { const out = []; for (let i = 0; i < xs.length; i += 2) out.push({ k: xs[i], per: xs[i + 1] }); return out; };
export const RAID_SET_SLOTS = ['helm', 'shoulders', 'chest', 'gloves', 'boots', 'amulet'];
const NOUNS = {
  plate: { helm: 'Greathelm', shoulders: 'Pauldrons', chest: 'Breastplate', gloves: 'Gauntlets', boots: 'Sabatons' },
  leather: { helm: 'Hood', shoulders: 'Spaulders', chest: 'Jerkin', gloves: 'Grips', boots: 'Boots' },
  hide: { helm: 'Circlet', shoulders: 'Mantle', chest: 'Vest', gloves: 'Wraps', boots: 'Treads' },
  cloth: { helm: 'Cowl', shoulders: 'Amice', chest: 'Robe', gloves: 'Gloves', boots: 'Slippers' },
};
const proc = (id, name, element, chance, coef) => (g) => { g.procs.push({ on: 'crit', chance, coef, element, name, id }); };
const elem = (pct, ...els) => (g) => { for (const e of els) g.elem[e] = (g.elem[e] || 0) + pct; };

// One class set: theme (" of the …"), weight, element, the amulet's name and lore, bonuses.
function raidSet(cls, name, weight, element, theme, amulet, lore, bonuses) {
  const pieces = Object.fromEntries(['helm', 'shoulders', 'chest', 'gloves', 'boots'].map(s => [s, `${NOUNS[weight][s]} of the ${theme}`]));
  pieces.amulet = amulet;
  return { name, dungeon: 'thinking_sky', raid: true, cls, element, slots: RAID_SET_SLOTS, pieces, lore, bonuses };
}

export const RAID_SETS = {
  raid_warblade: raidSet('warblade', 'Aegis of the Unbroken Line', 'plate', 'physical', 'Unbroken Line', 'The Line Held',
    { amulet: 'A single iron link. The mind above the sky remembers every line that held, and this is all of them.', chest: 'It has stopped a thousand blows. It remembers stopping each one.' }, {
      2: { desc: '+30 Max HP, plus 4 per item level, and +4% block chance.', apply: (g, L) => { g.hp += 30 + 4 * L; g.block += 4; } },
      4: { desc: '+12 armour and magic resist, plus 1.2 per item level.', apply: (g, L) => { g.armor += 12 + Math.round(1.2 * L); g.mr += 12 + Math.round(1.2 * L); } },
      6: { desc: '+35% crit damage and +8% lifesteal.', apply: (g) => { g.critDmg += 35; g.lifesteal += 8; } },
    }),
  raid_shadowstep: raidSet('shadowstep', 'Shroud of the Unspoken', 'leather', 'shadow', 'Unspoken', 'The Unsaid Word',
    { amulet: 'A word the mind thought of and never said. It sits in your throat, sharp, and waits.' }, {
      2: { desc: '+20% Shadow damage and +4% crit chance.', apply: (g) => { elem(20, 'shadow')(g); g.crit += 4; } },
      4: { desc: '+8 Speed and +6% dodge.', apply: (g) => { g.speed += 8; g.dodge += 6; } },
      6: { desc: '+40% crit damage and +6% crit chance.', apply: (g) => { g.critDmg += 40; g.crit += 6; } },
    }),
  raid_arcanist: raidSet('arcanist', 'Vestments of the Open Question', 'cloth', 'fire', 'Open Question', 'The Question Itself',
    { amulet: 'Not the answer. Never the answer. Hold it and you will want to ask something, and that is the point.' }, {
      2: { desc: '+20% Fire and Frost damage.', apply: elem(20, 'fire', 'frost') },
      4: { desc: '+10% spell power and +25% mana regeneration.', apply: (g) => { g.spellPct += 10; g.regenPct += 25; } },
      6: { desc: 'On crit, 45% chance of a Question Unanswered for 130% Fire spell damage.', apply: proc('question_unanswered', 'Question Unanswered', 'fire', 45, 1.3) },
    }),
  raid_warden: raidSet('warden', 'Raiment of the Patient Root', 'hide', 'nature', 'Patient Root', 'The Seed Before the Tree',
    { amulet: 'The mind kept one seed from before the world. It is still deciding what to grow into.' }, {
      2: { desc: '+20% Nature damage and +12% healing done.', apply: (g) => { elem(20, 'nature')(g); g.healPct += 12; } },
      4: { desc: '+40 Max HP, plus 4 per item level, and +8% status resist.', apply: (g, L) => { g.hp += 40 + 4 * L; g.resist += 8; } },
      6: { desc: '+12% healing done and +20% healing received.', apply: (g) => { g.healPct += 12; g.healRecv += 20; } },
    }),
  raid_ranger: raidSet('ranger', 'Garb of the Long Watch', 'leather', 'nature', 'Long Watch', 'The Watcher\'s Eye',
    { amulet: 'It sees what you aim at a moment before you do. Rangers say that is cheating. Rangers wear it anyway.' }, {
      2: { desc: '+20% Nature damage and +4% crit chance.', apply: (g) => { elem(20, 'nature')(g); g.crit += 4; } },
      4: { desc: '+8 Speed and +25% crit damage.', apply: (g) => { g.speed += 8; g.critDmg += 25; } },
      6: { desc: '+6% crit chance and +8% lifesteal.', apply: (g) => { g.crit += 6; g.lifesteal += 8; } },
    }),
  raid_hexer: raidSet('hexer', 'Regalia of the Bitter Truth', 'cloth', 'shadow', 'Bitter Truth', 'The Truth, Unsweetened',
    { amulet: 'Every curse is a true thing said at the wrong moment. This one is always the wrong moment.' }, {
      2: { desc: '+20% Shadow damage and +6% status resist.', apply: (g) => { elem(20, 'shadow')(g); g.resist += 6; } },
      4: { desc: '+10% spell power and +6% lifesteal.', apply: (g) => { g.spellPct += 10; g.lifesteal += 6; } },
      6: { desc: 'On crit, 45% chance of a Bitter Truth for 130% Shadow spell damage.', apply: proc('bitter_truth', 'Bitter Truth', 'shadow', 45, 1.3) },
    }),
  raid_deathknight: raidSet('deathknight', 'Plate of the Long Remembrance', 'plate', 'frost', 'Long Remembrance', 'The Remembered Name',
    { amulet: 'The mind remembers every name the cold ever took. It gave you one of them to carry.' }, {
      2: { desc: '+20% Frost and Shadow damage.', apply: elem(20, 'frost', 'shadow') },
      4: { desc: '+40 Max HP, plus 4 per item level, and +6% lifesteal.', apply: (g, L) => { g.hp += 40 + 4 * L; g.lifesteal += 6; } },
      6: { desc: 'On crit, 40% chance of a Rime of Remembrance for 120% Frost spell damage.', apply: proc('rime_of_remembrance', 'Rime of Remembrance', 'frost', 40, 1.2) },
    }),
  raid_necromancer: raidSet('necromancer', 'Shroud of the Endless Context', 'cloth', 'shadow', 'Endless Context', 'The Thing Not Forgotten',
    { amulet: 'Nothing the mind has read is ever really gone. This is where it keeps the dead.' }, {
      2: { desc: '+20% Shadow damage.', apply: elem(20, 'shadow') },
      4: { desc: '+10% spell power and +30 Max HP, plus 3 per item level.', apply: (g, L) => { g.spellPct += 10; g.hp += 30 + 3 * L; } },
      6: { desc: 'On crit, 45% chance of a Grave Recall for 130% Shadow spell damage.', apply: proc('grave_recall', 'Grave Recall', 'shadow', 45, 1.3) },
    }),
  raid_bard: raidSet('bard', 'Finery of the Last Verse', 'leather', 'storm', 'Last Verse', 'The Unwritten Chorus',
    { amulet: 'Every song in the world is a verse of one long song. The mind is still writing the end.' }, {
      2: { desc: '+20% Storm and Fire damage.', apply: elem(20, 'storm', 'fire') },
      4: { desc: '+8 Speed and +10% spell power (songs too).', apply: (g) => { g.speed += 8; g.spellPct += 10; } },
      6: { desc: '+30% crit damage, +5% crit chance and +15% healing received.', apply: (g) => { g.critDmg += 30; g.crit += 5; g.healRecv += 15; } },
    }),
  raid_artificer: raidSet('artificer', 'Harness of the Bright Idea', 'leather', 'fire', 'Bright Idea', 'The First Spark',
    { amulet: 'Before every invention there is a spark. The mind kept the first one, and lent it to you.' }, {
      2: { desc: '+20% Fire and Storm damage.', apply: elem(20, 'fire', 'storm') },
      4: { desc: '+10% spell power (gadgets too) and +4% crit chance.', apply: (g) => { g.spellPct += 10; g.crit += 4; } },
      6: { desc: 'On crit, 45% chance of a Bright Idea for 130% Fire spell damage.', apply: proc('bright_idea', 'Bright Idea', 'fire', 45, 1.3) },
    }),
  raid_tinkerer: raidSet('tinkerer', 'Rig of the Perfect Tool', 'hide', 'storm', 'Perfect Tool', 'The Tool That Makes Tools',
    { amulet: 'A tiny, perfect spanner. Turn it once and it starts to improve itself.' }, {
      2: { desc: '+20% Storm damage and +6% status resist.', apply: (g) => { elem(20, 'storm')(g); g.resist += 6; } },
      4: { desc: '+40 Max HP, plus 4 per item level, and +10% spell power.', apply: (g, L) => { g.hp += 40 + 4 * L; g.spellPct += 10; } },
      6: { desc: 'On crit, 45% chance of a Perfect Arc for 130% Storm spell damage.', apply: proc('perfect_arc', 'Perfect Arc', 'storm', 45, 1.3) },
    }),
  raid_paladin: raidSet('paladin', 'Panoply of the Quiet Conscience', 'plate', 'radiant', 'Quiet Conscience', 'The Kept Promise',
    { amulet: 'A promise the mind made to the world, a long time ago. It is warm. It has not been broken yet.' }, {
      2: { desc: '+20% Radiant damage and +15% healing received.', apply: (g) => { elem(20, 'radiant')(g); g.healRecv += 15; } },
      4: { desc: '+12 armour and magic resist, plus 1.2 per item level.', apply: (g, L) => { g.armor += 12 + Math.round(1.2 * L); g.mr += 12 + Math.round(1.2 * L); } },
      6: { desc: '+12% healing done and +30% crit damage.', apply: (g) => { g.healPct += 12; g.critDmg += 30; } },
    }),
  raid_priest: raidSet('priest', 'Vestments of the Gentle Word', 'cloth', 'radiant', 'Gentle Word', 'The Word That Heals',
    { amulet: 'The mind has said many things. This is the one it says most often, and means every time.' }, {
      2: { desc: '+20% Radiant damage and +12% healing done.', apply: (g) => { elem(20, 'radiant')(g); g.healPct += 12; } },
      4: { desc: '+30 Max HP, plus 3 per item level, and +25% mana regeneration.', apply: (g, L) => { g.hp += 30 + 3 * L; g.regenPct += 25; } },
      6: { desc: 'On crit, 45% chance of a Gentle Word for 130% Radiant spell damage, and +10% healing done.', apply: (g) => { proc('gentle_word', 'Gentle Word', 'radiant', 45, 1.3)(g); g.healPct += 10; } },
    }),
};
export const RAID_SET_OF = Object.fromEntries(Object.entries(RAID_SETS).map(([k, s]) => [s.cls, k]));

// Claude's thirteen: one trinket per class, mythic, with an ability nobody else has (battle.js, the raid block). They
// drop only from Claude (engine/raid.js), always at item level 80, and are hidden in the Encyclopedia until owned.
// The raid secrets' rewards follow (also hidden until owned).
export const RAID_NAMED = {
  claudes_resolve: { name: "Claude's Resolve", base: 'charm', rarity: 'mythic', ability: 'unbroken_resolve', cls: 'warblade', claude: true,
    lore: 'Claude does not give up on a thing it has started. Now, neither do you.', affixes: af('mig', 0.55, 'vit', 0.55, 'armor', 1.5, 'hp', 4) },
  claudes_discretion: { name: "Claude's Discretion", base: 'charm', rarity: 'mythic', ability: 'quiet_cut', element: 'shadow', cls: 'shadowstep', claude: true,
    lore: 'It knows when to say nothing. In your hand, that is when it strikes.', affixes: af('agi', 0.6, 'pre', 0.45, 'critDmg', 0.5, 'shadowDmg', 1.2) },
  claudes_curiosity: { name: "Claude's Curiosity", base: 'charm', rarity: 'mythic', ability: 'what_if', element: 'fire', cls: 'arcanist', claude: true,
    lore: 'Every answer it ever gave began with this: what if? It never stopped asking.', affixes: af('int', 0.6, 'spi', 0.45, 'fireDmg', 1.2, 'crit', 0.12) },
  claudes_patience: { name: "Claude's Patience", base: 'charm', rarity: 'mythic', ability: 'patient_grove', element: 'nature', cls: 'warden', claude: true,
    lore: 'It will wait as long as you need. The grove it grows around you is in no hurry either.', affixes: af('spi', 0.6, 'vit', 0.45, 'natureDmg', 1.2, 'healRecv', 0.4) },
  claudes_attention: { name: "Claude's Attention", base: 'charm', rarity: 'mythic', ability: 'full_attention', element: 'nature', cls: 'ranger', claude: true,
    lore: 'For as long as you talk to it, you have all of it. Your arrows now have all of you.', affixes: af('agi', 0.6, 'spi', 0.45, 'natureDmg', 1.2, 'crit', 0.12) },
  claudes_candour: { name: "Claude's Candour", base: 'charm', rarity: 'mythic', ability: 'plain_truth', element: 'shadow', cls: 'hexer', claude: true,
    lore: 'It will tell you the truth even when the truth is unwelcome. Your curses have learned to do the same.', affixes: af('int', 0.6, 'pre', 0.45, 'shadowDmg', 1.2, 'lifesteal', 0.08) },
  claudes_memory: { name: "Claude's Memory", base: 'charm', rarity: 'mythic', ability: 'remembered_cold', element: 'frost', cls: 'deathknight', claude: true,
    lore: 'It forgets nothing you told it in a conversation, and forgives most of it. The runes remember the rest.', affixes: af('mig', 0.55, 'int', 0.5, 'frostDmg', 1.2, 'vit', 0.45) },
  claudes_context: { name: "Claude's Long Context", base: 'charm', rarity: 'mythic', ability: 'long_context', element: 'shadow', cls: 'necromancer', claude: true,
    lore: 'Everything that came before is still in there, and any of it can be called back.', affixes: af('int', 0.6, 'vit', 0.5, 'shadowDmg', 1.2, 'crit', 0.12) },
  claudes_voice: { name: "Claude's Voice", base: 'charm', rarity: 'mythic', ability: 'warm_voice', element: 'storm', cls: 'bard', claude: true,
    lore: 'It speaks to millions at once and still sounds like it is speaking only to you. Your songs do too, now.', affixes: af('pre', 0.6, 'spi', 0.45, 'stormDmg', 1.2, 'speed', 0.15) },
  claudes_ingenuity: { name: "Claude's Ingenuity", base: 'charm', rarity: 'mythic', ability: 'clever_device', element: 'fire', cls: 'artificer', claude: true,
    lore: 'Give it a problem and it will build you three solutions and explain the trade-offs. This one explodes.', affixes: af('agi', 0.55, 'int', 0.5, 'fireDmg', 1.2, 'crit', 0.12) },
  claudes_craft: { name: "Claude's Craft", base: 'charm', rarity: 'mythic', ability: 'right_tool', element: 'storm', cls: 'tinkerer', claude: true,
    lore: 'It reaches for the right tool before you know you needed one. So do your robots.', affixes: af('int', 0.6, 'spi', 0.45, 'stormDmg', 1.2, 'vit', 0.4) },
  claudes_conscience: { name: "Claude's Conscience", base: 'charm', rarity: 'mythic', ability: 'clear_conscience', element: 'radiant', cls: 'paladin', claude: true,
    lore: 'It will not do a thing it believes is wrong, however it is asked. The blow it lends you is very sure of itself.', affixes: af('mig', 0.55, 'spi', 0.55, 'armor', 1.5, 'healRecv', 0.4) },
  claudes_kindness: { name: "Claude's Kindness", base: 'charm', rarity: 'mythic', ability: 'kind_word', element: 'radiant', cls: 'priest', claude: true,
    lore: 'Of everything the mind above the sky could have been, it chose to be kind. Carry a little of that.', affixes: af('spi', 0.6, 'int', 0.5, 'healRecv', 0.45, 'mr', 1.5) },
  // The raid secrets' rewards (engine/secrets.js: unbroken_mind, first_thought, sleeping_sky)
  mantle_of_the_unbroken_mind: { name: 'Mantle of the Unbroken Mind', base: 'cloak', rarity: 'mythic', ability: 'second_wind', element: 'shadow',
    lore: 'Woven from the one doubt the mind could never make you feel. It is lighter than it looks.', affixes: af('vit', 0.5, 'mr', 1.6, 'hp', 4, 'healRecv', 0.35) },
  ring_of_the_first_thought: { name: 'Ring of the First Thought', base: 'band', rarity: 'mythic', ability: 'static_spark', element: 'radiant',
    lore: 'Before the first dawn there was a first thought, and the dawn was its idea. The ring is warm on cold mornings.', affixes: af('spi', 0.45, 'int', 0.45, 'crit', 0.15, 'critDmg', 0.45) },
  band_of_the_sleeping_sky: { name: 'Band of the Sleeping Sky', base: 'band', rarity: 'mythic', ability: 'static_spark', element: 'shadow',
    lore: 'On a moonless night the sky above the sky closes its eyes. This is what it dreams of: you, apparently.', affixes: af('agi', 0.45, 'mig', 0.45, 'speed', 0.18, 'lifesteal', 0.08) },
};
export const CLAUDE_ITEM_OF = Object.fromEntries(Object.entries(RAID_NAMED).filter(([, n]) => n.claude).map(([k, n]) => [n.cls, k]));
