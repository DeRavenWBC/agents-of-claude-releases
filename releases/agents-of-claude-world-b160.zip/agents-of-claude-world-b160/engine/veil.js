// Agents of Claude — Beyond the Veil (levels 50–70): the rules the four new zones add on top of the world.
//
//   The Drowned Coast (50–55)   tides: some patrol rows only come at low tide, others only at high tide.
//   The Twilight Court (55–60)  a character swears to one fae court (Seelie or Unseelie) in a quest its own Claude
//                               decides; that court's fae then meet it as a friend (some fights end in a parley, the rest
//                               are easier) and the other court's are harder. Stored per character: progress.court.
//   The Burning Hells (60–65)   a fiend offers a bargain at the gate: +30% damage for the whole trip, paid with Cursed
//                               (healing received halved). The Agent's Claude, or its routine, accepts or refuses before
//                               the first fight; the answer is stored on the trip (action.bargain) so it replays exactly.
//                               Surviving a trip with a bargain pays: more gold and an extra good item.
//   The Empyrean (65–70)        angels judge (battle.js VEIL.judge): harder on Shadow-affinity Agents, softer on Radiant.
//
// Everything here is pure and deterministic. Nothing in it touches a fight that has none of these zones' creatures,
// statuses or trip fields, so the Pit, duels, the world boss and every older trip replay exactly as before.

import { fnv1a, makeRng } from './rng.js';
import { MOBS } from './battle.js';
import { citeList, cite, BECAUSE_HINT } from './mind.js';

export const VEIL_ZONES = ['drowned', 'twilight', 'hells', 'empyrean'];

/* ---------------------------------------------------------------- Tides */
// Two tides a day, the same for everyone: a tide every 12 h 25 min from a known low tide. Low water lasts about five
// hours of each cycle (the 40% of it nearest the low).
export const TIDE_PERIOD_MS = 12.42 * 3_600_000;
const TIDE_EPOCH = Date.UTC(2026, 0, 1, 4, 0);
export const tidePhase = (ms) => ((((ms - TIDE_EPOCH) / TIDE_PERIOD_MS) % 1) + 1) % 1;   // 0 low water, 0.5 high water
export const isLowTide = (ms) => { const p = tidePhase(ms); return p < 0.2 || p > 0.8; };
// A trip without a start time (balance tools, tests) meets the high tide.
export const tideOf = (ms) => (ms && isLowTide(ms) ? 'low' : 'high');
export const tideOk = (row, startedAt) => !row.tide || row.tide === tideOf(startedAt);
// When the tide next turns: { tide, at } (for the World panel).
export function nextTide(ms) {
  const p = tidePhase(ms), low = isLowTide(ms);
  const to = low ? (p > 0.8 ? 1.2 - p : 0.2 - p) : 0.8 - p;
  return { now: low ? 'low' : 'high', turnsAt: ms + to * TIDE_PERIOD_MS };
}

/* --------------------------------------------------------------- Courts */
export const COURTS = {
  seelie: { name: 'the Seelie Court', short: 'Seelie', blurb: 'The Summer court: bright, proud, bound by its word and merciless to anyone who breaks theirs.' },
  unseelie: { name: 'the Unseelie Court', short: 'Unseelie', blurb: 'The Winter court: the Queen of Air and Darkness, redcaps and glamours. Cruel, clever and loyal to its own.' },
};
// parley: chance a patrol fight made only of the sworn court's fae ends in talk; friend/foe: their strength.
export const COURT_TUNE = { parley: 0.35, friend: 0.85, foe: 1.05 };
export const courtOf = (kind) => MOBS[kind]?.court || null;
export const cleanCourt = (c) => (COURTS[c] ? c : null);
// The sworn court shapes a trip's encounters: [{ mobs: [{ kind, level, mult? }], ... }] → the same list, where a fight
// of friends only may become a parley ({ parley: true }: no fight) and each fae of either court is weaker or stronger
// (`mult`, as Heroic dungeons scale mobs). Unaligned creatures (pixies) are unchanged. Decided on its own seeded stream.
export function courtEncounters(encs, court, seed, { parley = true } = {}) {
  if (!cleanCourt(court)) return encs;
  return encs.map((enc, i) => {
    const sides = enc.mobs.map(m => courtOf(m.kind));
    if (!sides.some(Boolean)) return enc;
    const friends = sides.every(c => c === court);
    if (parley && friends && !enc.elite && !enc.rare && !enc.boss && !enc.secret && makeRng(`court|${seed}|${i}`)() < COURT_TUNE.parley)
      return { ...enc, parley: court, label: `A parley with ${COURTS[court].name}` };
    return { ...enc, mobs: enc.mobs.map(m => { const c = courtOf(m.kind); return c ? { ...m, mult: +((m.mult || 1) * (c === court ? COURT_TUNE.friend : COURT_TUNE.foe)).toFixed(3) } : m; }) };
  });
}

// The character's own Claude swears it to a court (the Twilight Court quest "The Two Courts"). ctx: { name, cls, level,
// personality, lessons, notes }.
export function courtPrompt(ctx) {
  const C = citeList({ personality: ctx.personality, lessons: (ctx.lessons || []).slice(0, 4), notes: (ctx.notes || []).slice(-4) });
  return [
    `You are ${ctx.name}, a level ${ctx.level} ${ctx.cls} in Agents of Claude, deep in the Twilight Court, where it is always dusk.`,
    'Two fae courts want your oath, and you must give it to one of them before you go on. It lasts: the court you swear to will',
    'greet you as a friend from now on (some of its fae will talk instead of fight, the rest go easier on you), and the other court will remember.',
    `- seelie: ${COURTS.seelie.blurb}`,
    `- unseelie: ${COURTS.unseelie.blurb}`,
    ctx.personality?.traits?.length ? `Your personality: ${C.filter(c => c.kind === 'trait').map(c => `${cite(c)} ${c.text}`).join(', ')}.` : '',
    C.some(c => c.kind === 'lesson' || c.kind === 'note') ? `What you know:\n${C.filter(c => c.kind !== 'trait').map(c => `- ${cite(c)} ${c.text}`).join('\n')}` : '',
    '', 'Choose in character: who would you rather owe?',
    'Reply with only JSON: {"court":"seelie"|"unseelie","why":"<your reason, in character, at most 25 words>","because":["P1"]}',
    BECAUSE_HINT,
  ].filter(x => x !== '').join('\n');
}
// Without Claude: kind, loyal and proud hearts go to Summer; sly, cruel and curious ones to Winter; otherwise the name
// decides (so every character still chooses, and always the same way).
const SUMMER = /kind|warm|loyal|gentle|patient|honest|earnest|cheerful|proud|brave|sentimental|attentive/i;
const WINTER = /sly|greedy|teasing|cheeky|shameless|grudging|cold|cynical|brooding|curious|inquisitive|restless|blunt/i;
export function heuristicCourt(personality, name = '') {
  const t = (personality?.traits || []).join(' '), s = (t.match(new RegExp(SUMMER, 'gi')) || []).length, w = (t.match(new RegExp(WINTER, 'gi')) || []).length;
  if (s > w) return { court: 'seelie', why: 'I keep my word. Summer keeps theirs. That is enough for me.' };
  if (w > s) return { court: 'unseelie', why: 'Winter does not pretend to be kind. I trust that more than smiles.' };
  return parseInt(fnv1a(`court|${name}`).slice(0, 4), 16) % 2
    ? { court: 'unseelie', why: 'The dark court looked at me as if it already knew my name.' }
    : { court: 'seelie', why: 'The summer court offered me its hand first.' };
}

/* -------------------------------------------------------------- Bargains */
// A fiend's offer at the gate of a Burning Hells trip (patrols, solo quests and landmarks). Every offer is the same deal
// (battle.js VEIL: +30% damage, healing received halved, for every fight of the trip); only the fiend differs.
export const BARGAIN_ZONES = ['hells'];
export const BARGAIN_TRIPS = ['patrol', 'quest', 'explore'];
export const BARGAIN_OFFER = 0.7;    // share of Hells trips that meet a fiend at the gate
export const BARGAIN_REWARD = { gold: 1.25, item: 'boss' };   // a trip that survives its bargain: gold ×1.25 and a rare+ item
export const BARGAINS = {
  horned_notary: { title: 'A horned notary', text: 'A fiend in a waistcoat steps out of the smoke with a contract already filled in, except for your name. "Strength for the whole road. The fine print is only about mending."' },
  quill_imp: { title: 'An imp with a quill', text: 'An imp perches on a brimstone rock, licking the tip of a quill. "Hit harder, live a little less well. Sign here, and here, and here."' },
  brimstone_voice: { title: 'A voice in the brimstone', text: 'The cinders at the gate whisper as you pass: "Take my fire with you. All of it. All I ask is that nothing heals you quite as well."' },
};
export const bargainKeys = Object.keys(BARGAINS);
// Which fiend (if any) waits at the gate of this trip. `seed` is the trip's own seed.
export function bargainOffer(zone, type, seed) {
  if (!BARGAIN_ZONES.includes(zone) || !BARGAIN_TRIPS.includes(type) || !seed) return null;
  const r = makeRng(`bargain|${seed}`);
  return r() < BARGAIN_OFFER ? bargainKeys[Math.floor(r() * bargainKeys.length)] : null;
}
// The stored answer, cleaned: { key, accept, why, by }.
export const cleanBargain = (b) => (b && BARGAINS[b.key] ? { key: b.key, accept: !!b.accept, why: String(b.why || '').slice(0, 160), by: b.by === 'claude' ? 'claude' : 'routine' } : null);
// Whether a trip's fights carry a bargain (only in a bargain zone, and only if it was accepted).
export const bargainAccepted = (opts, zone) => !!(opts?.bargain?.accept && BARGAINS[opts.bargain.key] && BARGAIN_ZONES.includes(zone));
// The statuses a bargain puts on the Agent for every fight of the trip (battle.js tripStatuses).
export const bargainStatuses = (accepted) => (accepted ? [{ type: 'pact' }, { type: 'cursed' }] : []);

// The Agent's own Claude decides. ctx: { name, cls, level, personality, gold, tired, lessons, notes, heals }.
export function bargainPrompt(ctx, key) {
  const B = BARGAINS[key], C = citeList({ personality: ctx.personality, lessons: (ctx.lessons || []).slice(0, 6), notes: (ctx.notes || []).slice(-4) });
  return [
    `You are ${ctx.name}, a level ${ctx.level} ${ctx.cls} in Agents of Claude, at the gate of the Burning Hells. Something stops you:`,
    '', `${B.title}. ${B.text}`, '',
    'The deal, exactly: for every fight of this trip you deal 30% more damage, but you are Cursed: all healing you receive is halved (your own heals, potions of rest between fights are not affected).',
    'If you come home on your feet, the fiend pays out as promised: a quarter more gold and an extra good item. If you are knocked out, you get nothing extra. Refusing means an ordinary trip.',
    ctx.heals ? 'You lean on healing (your own or your allies\'), so the curse would cost you more than most.' : '',
    ctx.personality?.traits?.length ? `Your personality: ${C.filter(c => c.kind === 'trait').map(c => `${cite(c)} ${c.text}`).join(', ')}.` : '',
    `Fatigue: ${ctx.tired ?? 0}.`,
    C.some(c => c.kind === 'lesson' || c.kind === 'note') ? `What you know:\n${C.filter(c => c.kind !== 'trait').map(c => `- ${cite(c)} ${c.text}`).join('\n')}` : '',
    '', 'Do you sign? Decide in character.',
    'Reply with only JSON: {"choice":"accept"|"refuse","why":"<your reason, in character, at most 20 words>","because":["P1"]}',
    BECAUSE_HINT,
  ].filter(x => x !== '').join('\n');
}
// Without Claude: bold, greedy and ambitious Agents sign; careful and kind ones, healers, and tired Agents refuse.
const SIGN = /bold|brash|ambitious|greedy|reckless|proud|restless|shameless|sly|stubborn/i;
const WARY = /careful|cautious|wise|kind|gentle|patient|loyal|precise|observant|honest/i;
export const HEALER_CLASSES = ['warden', 'priest', 'paladin', 'bard', 'tinkerer'];
export function heuristicBargain(personality, { cls, tired = 0 } = {}) {
  const t = (personality?.traits || []).join(' ');
  const score = (t.match(new RegExp(SIGN, 'gi')) || []).length - (t.match(new RegExp(WARY, 'gi')) || []).length
    - (HEALER_CLASSES.includes(cls) ? 1 : 0) - (tired >= 3 ? 1 : 0) + 0.5;
  return score > 0 ? { accept: true, why: 'More fire for the road. I will mend when I am home.' } : { accept: false, why: 'I do not sign what I did not write.' };
}

/* ------------------------------------------------------ Stage 3: the item suite */
// The Veil's named items (items.js NAMED, from engine/suite.js) and sets, keyed by where they come from. The world reads
// each source itself; this table is the map of them (veilzones.test.js checks it against NAMED and DUNGEON_SETS):
//   zoneNamed:   NAMED[key].drop = '<zone>' → the zone's rare spawns, treasure mimics and dungeon boss drops (world.namedPool).
//   courtNamed:  [the crown the Twilight finale "The Queen's Due" gives the sworn court, the gift its parleys sometimes bring].
//   dungeonSets: items.js DUNGEON_SETS[set].dungeon = '<dungeon>' (SET_OF_DUNGEON) → set pieces from the boss.
//   chase:       DUNGEONS[d].chase.key.
//   secretNamed: SECRETS[id].rewards.named.
//   questNamed:  NAMED[key].quest = '<quest id>' → given on top of that quest's reward (the Twilight finale gives the court's).
export const STAGE3 = {
  zoneNamed: {
    drowned: ['drowned_admirals_cutlass', 'brinewalker_boots', 'tidecallers_conch', 'riptide_fangs', 'drowned_logbook', 'sirens_spine', 'drowned_knights_pauldrons', 'wreck_bone_staff', 'siren_strung_lute', 'brinelock_blunderbuss', 'tidewound_wraps', 'bulwark_of_the_sunken_nave', 'drowned_vicars_stole'],
    twilight: ['glamourweave_mantle', 'redcap_bonnet', 'dryad_heartwood_staff', 'gloaming_jerkin', 'crown_of_the_gloaming_hart', 'bow_of_the_wild_hunt', 'book_of_true_names', 'winter_knights_helm', 'briar_gate_pauldrons', 'changelings_cowl', 'pixie_feather_cap', 'clockwork_hartspanner', 'helm_of_the_seelie_knight'],
    hells: ['brimstone_gauntlets', 'chain_devils_flail', 'cultists_censer', 'hellforged_greathelm', 'hellhounds_tooth', 'cinderheart_staff', 'totem_of_cinders', 'hellhide_grips', 'phylactery_of_ash', 'temptress_silk_spaulders', 'brimstone_bandolier', 'gloves_of_the_penitent'],
    empyrean: ['seraphs_halo', 'virtue_aegis', 'choir_lute', 'archons_verdict', 'fallen_star_wraps', 'robe_of_falling_stars', 'seraph_feather_wraps', 'dawnstring', 'quill_of_the_fallen', 'seraph_glass_goggles', 'ophanim_gyrovest'],
  },
  courtNamed: { seelie: ['summer_crown', 'thornless_rose'], unseelie: ['winter_crown', 'queens_glass_dagger'] },
  dungeonSets: { sunken_bell: 'bellwrack_regalia', thorn_throne: 'thorn_court_finery', ninth_gate: 'infernal_compact', throne_of_dawn: 'dawnforged_panoply' },
  chase: { sunken_bell: 'heralds_conch', thorn_throne: 'queens_thorn', ninth_gate: 'pit_fiends_brand', throne_of_dawn: 'first_dawn' },
  secretNamed: { drowned_choir: 'choirmasters_bell', erlking: 'erlkings_horn', unbought: 'unsigned_contract', unjudged: 'scales_of_dawn' },
  questNamed: { after_the_bell: 'undertow_cloak', ashes_to_ashes: 'penitents_plate', the_last_dawn: 'mantle_of_the_last_dawn' },
};
// The court item the finale gives: the first of the court's list that exists, or null.
export const courtNamedFor = (court, NAMED) => (STAGE3.courtNamed[court] || []).find(k => NAMED[k]) || null;
// The court's gift: its second named item, which a parley with the sworn court's fae sometimes ends with (COURT_GIFT).
export const COURT_GIFT = 0.08;
export const courtGiftFor = (court, NAMED) => { const k = STAGE3.courtNamed[court]?.[1]; return k && NAMED[k] ? k : null; };

// The court record a claim writes on the character's own progress doc (progress.court), or null: only a successful
// "The Two Courts" quest swears a character, and only once (a later claim never changes it).
export function courtAfterClaim(prog, quest, act, res, now) {
  if (prog?.court?.court || !quest?.courtChoice || act?.type !== 'quest' || !res?.done || !COURTS[act.path]) return null;
  return { court: act.path, at: now, why: String(act.courtWhy || '').slice(0, 160), by: act.courtBy === 'claude' ? 'claude' : act.courtBy === 'player' ? 'player' : 'routine' };
}
// The court a new trip into the Twilight Court carries (action.court), from the character's progress.
export const courtForTrip = (prog, zone) => (zone === 'twilight' && cleanCourt(prog?.court?.court)) || null;
