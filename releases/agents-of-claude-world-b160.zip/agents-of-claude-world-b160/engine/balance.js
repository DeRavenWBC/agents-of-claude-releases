// Balance smoke report: win rates over many seeds. Run: npm run balance
import { simulate, makeAgentUnit, makeMobUnit } from './battle.js';
import { STARTERS, geared } from './fixtures.js';
const GEAR = !process.argv.includes('--bare');

const SEEDS = 300;
const CLASSES = Object.keys(STARTERS);
const pct = (n) => `${Math.round(n * 100)}%`.padStart(5);

function run(label, mkA, mkB) {
  let a = 0, b = 0, d = 0, actions = 0, hpLeft = 0;
  for (let s = 0; s < SEEDS; s++) {
    const res = simulate(`${label}-${s}`, mkA(), mkB());
    if (res.winner === 'A') a++; else if (res.winner === 'B') b++; else d++;
    actions += res.actions;
    const me = res.survivors.find(x => x.side === 'A');
    hpLeft += me.hp / me.maxHp;
  }
  return { win: a / SEEDS, loss: b / SEEDS, draw: d / SEEDS, actions: actions / SEEDS, hpLeft: hpLeft / SEEDS };
}

const PVE = [
  ['Goblin Scout L1', 1, () => [makeMobUnit('goblin_scout', 1)]],
  ['2 Goblin Scouts L2', 2, () => [makeMobUnit('goblin_scout', 2, 'g1'), makeMobUnit('goblin_scout', 2, 'g2')]],
  ['Dire Wolf L3', 3, () => [makeMobUnit('dire_wolf', 3)]],
  ['Shaman + Scout L4', 4, () => [makeMobUnit('goblin_shaman', 4, 'sh'), makeMobUnit('goblin_scout', 4, 'sc')]],
  ['Old Mossback L8 (elite)', 8, () => [makeMobUnit('old_mossback', 8)]],
  ['Grubnose L10 (boss)', 10, () => [makeMobUnit('grubnose', 10)]],
];

const party = (lvl) => ['warblade', 'arcanist', 'warden'].map((c, i) => makeAgentUnit(STARTERS[c], { level: lvl, id: `p${i}`, autoSpend: true, equipped: GEAR ? geared(c, lvl) : {} }));

console.log(`\n${GEAR ? 'With level-appropriate uncommon gear' : 'No gear'}`);
console.log(`\nPvE: each class at the encounter's level, ${SEEDS} seeds (win % · HP left · actions)\n`);
console.log('Encounter'.padEnd(26) + CLASSES.map(c => c.padStart(20)).join(''));
for (const [label, lvl, mobs] of PVE) {
  const cells = CLASSES.map(c => {
    const r = run(`${label}-${c}`, () => [makeAgentUnit(STARTERS[c], { level: lvl, autoSpend: true, equipped: GEAR ? geared(c, lvl) : {} })], mobs);
    return `${pct(r.win)} ·${pct(r.hpLeft)} ·${r.actions.toFixed(0).padStart(3)}`.padStart(20);
  });
  console.log(label.padEnd(26) + cells.join(''));
}

for (const [label, lvl, boss] of [['Grubnose L10, party of 3', 10, () => [makeMobUnit('grubnose', 10)]], ['Grubnose L12, party of 3', 12, () => [makeMobUnit('grubnose', 12)]]]) {
  const r = run(label, () => party(lvl), boss);
  console.log(`\n${label}: wins ${pct(r.win)} in ${r.actions.toFixed(0)} actions`);
}

for (const lvl of [1, 10, 20]) {
  console.log(`\nPvP duels at level ${lvl}: row's win % against column (draws excluded)\n`);
  console.log(''.padEnd(12) + CLASSES.map(c => c.padStart(12)).join(''));
  for (const a of CLASSES) {
    const cells = CLASSES.map(b => {
      const r = run(`duel-${lvl}-${a}-${b}`, () => [makeAgentUnit(STARTERS[a], { level: lvl, id: 'a', autoSpend: true, equipped: GEAR ? geared(a, lvl) : {} })], () => [makeAgentUnit(STARTERS[b], { level: lvl, id: 'b', autoSpend: true, equipped: GEAR ? geared(b, lvl) : {} })]);
      return pct(r.win).padStart(12);
    });
    console.log(a.padEnd(12) + cells.join(''));
  }
}
